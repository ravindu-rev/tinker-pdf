# Where the last session stopped

Written 16 October 2026, at the end of round 6's lane F of ROADMAP CD-19.
The next session starts here: read this, then [AGENTS.md](../AGENTS.md),
then continue with "Next, in this order" below. When this note is out of
date, rewrite it or delete it in the same commit that moves the work on.

## Where the work continues

**On `develop`**, once the round's workflow has brought lane F's commits
there (lane K's four, from `35ab4ab` to `05cea0b`, then lane F's seven,
the last of which writes this note). The remote `rtl-probe-kit`,
`wave8/8A-impl` and `wave8/8B-impl` branches still have to be deleted by
the owner on GitHub: this session's proxy refuses branch deletion, and
nothing is lost by deleting them.

## State

- **`develop`** carries round 5 of ROADMAP CD-19, the K-11 follow-ups and
  the probe kit, [tools/probes/rtl](../tools/probes/rtl/README.md), and
  with round 6: the kit's suites as `#[ignore]`d ratchets (lane K), round
  6's hunt and sweep as kit families (75 a build and 4 line families), and
  the read-back of each right-to-left line on the page it is drawn on
  (lane F's fix, `paint::Fonts::set_readings`).
- **`main`** is still the merge of `56dfd93`. By the owner's standing
  instruction, nothing goes to `main` and no pull request is opened until
  the owner says so.
- **What round 6 closed:** V1 of its review and its class (a line read back
  in its runs' space while the page draws it under a transform; glyphs read
  as typed; a reading held to the letters only): RESULTS. V6, a doc that
  read as an accepted price. The Persian digits of Left (4) and the `;` of
  Left (5) read whole again.
- **The suites' baseline** is `BASELINE_NEW` since lane F's last commit but one:
  the families whose books read better there moved, the others are
  935b077's (the kit's README, "Refreshing the baseline").

## The owner's decisions waiting

Each with its measured gains and costs in ROADMAP CD-19 and in lane F's
report; none is accepted, and no doc reads as if one were.

OWNER_OPTIONS

## Still open (ROADMAP CD-19, Left (1)–(8))

LEFT

## Next, in this order

1. **An independent review of round 6's lane F**, with a fresh hunt, on
   `develop`, against `9297d2d`, `56dfd93` and `935b077`.
2. **Put the owner's decisions above to the owner.**
3. **Fix what remains by class** (AGENTS.md): the reader-side mechanisms
   behind Left (3), (4) and (6) are each a change to every page's reading,
   and need their own lane with the whole kit as its sweep.
4. **Then the roadmap's order of work:**
   - MS-11: `ci.yml` on push to `develop`, and the nightly fuzz and corpus
     runs dispatched on `develop`. Its epub-corpus clause is already met.
   - K-06: seven green nightly `jbig2` fuzz runs.
   - K-01, K-02.
   - The rest of Tier 0.
