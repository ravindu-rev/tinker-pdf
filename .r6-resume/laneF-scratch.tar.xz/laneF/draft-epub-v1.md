**Each line is read back on the page it is drawn on** (round 6 of CD-19's
reviews; `paint::OnPage::matrix`, `paint::along_the_line`, `paint::Words`,
`paint::Segment::read_as`). The read-back fed `TextDevice` each glyph in its
run's own space, but the page draws the run under the `cm` its CSS
`transform` writes (`paint::OnPage::open`), and every threshold a reader
has is in the glyphs' size on the page: a transform that scales one axis
more than the other widens or narrows each gap against it. Under
`transform: scaleX(2)` at `word-spacing: 0.6em` a styled `?!` glued to a
Hebrew or Arabic word was read with the word in the model, drawn turned for
that reading, and read alone on the page, turned: `שלום!? עולם.`, where
9297d2d and 56dfd93 read `שלום?! עולם.` (12 books of the review's sweep in a
default build and 6 with `bundled-fonts`). The writer's own rules asked
whether a reader parts two text objects in the run's ems too
(`paint::parted`, `paint::page_lines`, `paint::leading_mark_at`), so that
`25٪ <b>W</b>` in Arabic under `scaleX(1.4)`, which conserved at 56dfd93,
read its number backwards since round 5. Each line is read back under the
matrix the page draws each run under now, and every rule that asks whether
a reader parts two objects asks it in the page's ems: an em of a run's own
spacing is `along_the_line` of its matrix on the page, the scale along the
baseline over the square root of the determinant's magnitude, which is how
`TextDevice` sizes a glyph — `√2` under `scaleX(2)`, one under a turn, a
shift or `scale(2)`. Two more ways the model read another page than the
one written went with it. Each glyph is read back as the page's font gives
it back, not as typed: a standard face draws a NO-BREAK SPACE at
`WinAnsiEncoding`'s `0xA0`, which a reader reads by its glyph name as a
space, and read as typed in a model of the page it was a `CS` that made
`1 234` one number to UAX #9, so that a drawing read right only there. And a reading is right where it holds the line's words, not only
its letters: one that lost a word space was taken, and the block no longer
read whole (`שלום <b>?!</b> עולם.` at `word-spacing: 0.6em` read
`שלום?! עולם.`).
Where nothing tried reads a line right on the page under a transform —
glyphs the transform sets over others, whose letters no drawing reads in
order — the line is searched again in its runs' own space, and what that
finds is drawn only where, read back on the page, it holds more of the
text's pairs of letters in order than the rules' drawing does there and
sets no more glyphs over others; no drawing either search finds sets more
glyphs over others than the rules' (`paint::drawn_over`).
(`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`,
`a_line_is_read_back_as_the_pages_fonts_give_its_characters_back`,
`a_reading_that_cuts_or_joins_a_word_is_not_taken_for_the_lines_text`,
`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`,
`a_drawing_that_sets_more_glyphs_over_others_than_the_rules_is_not_taken`.)
MEASURED: ...
COST: ...
