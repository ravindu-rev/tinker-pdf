//! Lane F scratch (not committed): books where the page's fonts' reading of a
//! NO-BREAK SPACE could decide a drawing. Prints each book's verdicts.
#![allow(missing_docs, clippy::all, unused)]

mod epub_support;

use epub_support::reading::{read, rep, word, AR, HE};

#[test]
fn probe() {
    let styles = [
        "p { word-spacing: 0.6em }",
        "p { word-spacing: 1em }",
        "p { word-spacing: 0.3em }",
        "p { letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify; margin: 0 30% }",
        "p { transform: scaleX(2); word-spacing: 0.6em }",
        "p { word-spacing: 12px }",
    ];
    for (lang, w) in [("ar", &AR), ("he", &HE)] {
        let shapes: Vec<(&str, String)> = vec![
            ("q", rep(2, |i| format!("{} <b>?!</b> {} 1\u{a0}234 {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("qb", rep(2, |i| format!("{} {} <b>1\u{a0}234</b> <i>?!</i> {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("pct", rep(2, |i| format!("{} 1\u{a0}234\u{66a} <b>{}</b> {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("paren", rep(2, |i| format!("{} (1\u{a0}234) <b>{}</b>, {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("comma", rep(2, |i| format!("{} 1\u{a0}234، <b>{}</b> {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("lat", rep(2, |i| format!("{} abc\u{a0}def <b>{}</b> {}!", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("nb2", rep(2, |i| format!("{}\u{a0}<b>?!</b> {} {}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
            ("nb3", rep(2, |i| format!("{} <b>{}</b>\u{a0}{} 25\u{66a}.", word(w, i), word(w, i + 1), word(w, i + 2)))),
        ];
        for (name, text) in &shapes {
            for (d, attr) in [("rtl", " dir=\"rtl\""), ("none", "")] {
                for style in styles {
                    let body = format!("<p{attr}>{text}</p>");
                    let r = read(lang, style, &body);
                    println!("RA\t{lang}/{name}/{d}\t{style}\t[{}]\toverprint={}\t{:?}", r.holding(), r.overprint, r.text);
                }
            }
        }
    }
}
