## State after round 6's lane F

- **V1 is fixed**: each right-to-left line is read back on the page it is
  drawn on (the page's matrix, the page's ems, the page's fonts, the line's
  words). Commit FIXHASH; ROADMAP CD-19 says what it measured.
- **The round-6 families are ratchets**: 74 `rtl_probes` families (63 and
  round 6's eleven), with outputs at 9297d2d, 56dfd93 and 935b077.
- **Pinned, the owner's**: V2 and V3 (the comma tie-break's left end, Left
  (1) and (4)), V5 (the read-back's budget; reading each distinct drawing
  once is an option with a price), V4 (the read-back's cost, stated in
  ROADMAP CD-19 and features/epub.md, unpriced).
- **Owner options measured, not committed**: H1, H6 and V5's dedupe, with
  their gains and costs in lane F's report; H2-3 has no candidate that does
  not move glyphs from where layout put them.

## Still open

ROADMAP CD-19's Left list (1)-(6) holds every item, with counts measured at
the fix:

- H1 / V2 / V3, the comma tie-break, needs the owner;
- H2-3, Latin parity of overflow scripts cut by an inline block, needs the
  owner;
- H6, the mixed stop runs, needs the owner;
- H2-2's remainder (Left (3)), a stretch past an em that no space placement
  parts into halves a reader resumes across, needs a reader change;
- H2-7 (Left (4)), lines K-11's reader reads from the right, needs a reader
  change;
- Left (6), a half turn at `1em` that conserved at 56dfd93 only.
