AR = ["كتاب", "مدرسة", "الطالب", "جميل", "بيت", "كبير", "نور", "يوم", "عوامل", "وقد", "أصبحنا", "نعرف"]


def s(i):
    return AR[i % 12]


def rep(n, f):
    return " ".join(f(k * 3) for k in range(n))


punct = rep(3, lambda i: f"{s(i)} <b>?!</b> {s(i+1)} {s(i+2)}. <i>(</i>{s(i+3)}<i>)</i> {s(i+4)}!")
rows = []
for d, attr in (("none", ""), ("rtl", " dir=\"rtl\"")):
    st = "p { margin: 0 30%; line-height: 0.4; letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }"
    rows.append(f"lh04-{d}\tar\t{st}\t<p{attr}>{punct}</p>")
open("/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/lh.tsv", "w").write("\n".join(rows) + "\n")
