AR = ["كتاب", "مدرسة", "الطالب", "جميل", "بيت", "كبير", "نور", "يوم", "عوامل", "وقد", "أصبحنا", "نعرف"]
HE = ["שלום", "עולם", "מלחמה", "ספר", "בית", "גדול", "אור", "יום", "בראשית", "ברא", "אלהים", "הארץ"]
rows = []
for sc, w in (("ar", AR), ("he", HE)):
    def s(i, w=w):
        return w[i % 12]
    n = "1 234"
    text = f"{s(0)} {s(1)} <b>{n}</b> {s(2)}، {s(3)} {s(4)}."
    rows.append(f"nbsp-{sc}-none\t{sc}\tp {{ word-spacing: 0.6em }}\t<p>{text}</p>")
    rows.append(f"nbsp-{sc}-ltr\t{sc}\tp {{ word-spacing: 0.6em }}\t<p dir=\"ltr\">{text}</p>")
open("/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/nbsp.tsv", "w").write("\n".join(rows) + "\n")
