"""Lane F: candidate cases for the V1/V5 tests, as a diag TSV."""
AR = ["كتاب", "مدرسة", "الطالب", "جميل", "بيت", "كبير", "نور", "يوم", "عوامل", "وقد", "أصبحنا", "نعرف"]
HE = ["שלום", "עולם", "מלחמה", "ספר", "בית", "גדול", "אור", "יום", "בראשית", "ברא", "אלהים", "הארץ"]


def rep(n, f):
    return " ".join(f(k * 3) for k in range(n))


def w(lst, i):
    return lst[i % 12]


rows = []


def add(name, lang, style, body):
    rows.append(f"{name}\t{lang}\t{style}\t{body}")


# V5 (lane V): generated content, bdi.
GEN = "p, li, dt, dd, figcaption, blockquote, h2 { word-spacing: %s } .b::before { content: \"§ \" }"
add("v5-lists-he-06", "he", GEN % "0.6em", "<p dir=\"rtl\" class=\"b\">שלום עולם <b>מלחמה</b> ספר، בית (גדול) אור.</p>")
add("v5-lists-he-1", "he", GEN % "1em", "<p dir=\"rtl\" class=\"b\">שלום עולם <b>מלחמה</b> ספר، בית (גדול) אור.</p>")
add("v5-lists-ar-06", "ar", GEN % "0.6em", "<p dir=\"rtl\" class=\"b\">كتاب مدرسة <b>الطالب</b> جميل، بيت (كبير) نور.</p>")
add("v5-lists-ar-1", "ar", GEN % "1em", "<p dir=\"rtl\" class=\"b\">كتاب مدرسة <b>الطالب</b> جميل، بيت (كبير) نور.</p>")
add("v5-auto", "he", "p { word-spacing: 1em; margin: 0 20% }", "<p dir=\"rtl\">יום <bdi>The word שלום means עולם in <i>מלחמה</i>. The word שלום means עולם in <i>מלחמה</i>.</bdi> בראשית.</p>")
# words: a word space lost (scaleY(2) num justified, f6) and the controls that gain whole.
num = rep(3, lambda i: f"{w(AR, i)} 25٪ <b>{w(AR, i+1)}</b> ١٢٣ {w(AR, i+2)} 2010، {w(AR, i+3)}.")
add("words-num-scaleY2-just", "ar", "p { margin: 0 30%; transform: scaleY(2); letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }", f"<p dir=\"rtl\">{num}</p>")
add("words-num-just", "ar", "p { margin: 0 30%; letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }", f"<p dir=\"rtl\">{num}</p>")
add("words-he-06", "he", "p { word-spacing: 0.6em }", "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>")
# model = page: NBSP between digits (guard) and a soft hyphen.
for sc, lst in (("ar", AR), ("he", HE)):
    t = f"{w(lst,0)} {w(lst,1)} <b>1 234</b> {w(lst,2)}، {w(lst,3)} {w(lst,4)}."
    add(f"nbsp-{sc}-none-06", sc, "p { word-spacing: 0.6em }", f"<p>{t}</p>")
    add(f"nbsp-{sc}-rtl-06", sc, "p { word-spacing: 0.6em }", f"<p dir=\"rtl\">{t}</p>")
add("shy-he-06", "he", "p { word-spacing: 0.6em }", "<p dir=\"rtl\">שלום עו­לם <b>?!</b> מלחמה.</p>")
# model = page: a line height under half an em.
punct = rep(3, lambda i: f"{w(AR, i)} <b>?!</b> {w(AR, i+1)} {w(AR, i+2)}. <i>(</i>{w(AR, i+3)}<i>)</i> {w(AR, i+4)}!")
add("lh04-none", "ar", "p { margin: 0 30%; line-height: 0.4; letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }", f"<p>{punct}</p>")
add("lh04-rtl", "ar", "p { margin: 0 30%; line-height: 0.4; letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }", f"<p dir=\"rtl\">{punct}</p>")
add("lh06-rtl-ws06", "ar", "p { margin: 0 30%; line-height: 0.6; word-spacing: 0.6em }", f"<p dir=\"rtl\">{punct}</p>")
# V1 shapes.
add("v1-he-sx2", "he", "p { transform: scaleX(2); word-spacing: 0.6em }", "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>")
add("v1-num-rot3", "ar", "p { margin: 0 30%; transform: rotate(180deg); word-spacing: 1em }", f"<p dir=\"rtl\">{num}</p>")
add("v1-ctl-scaleY2", "he", "p { transform: scaleY(2); word-spacing: 0.6em }", "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>")
# CR1 (Left (5)): ; glued, letter-spaced 0.25em justified.
add("cr1-semi", "ar", "p { letter-spacing: 0.25em; text-align: justify; margin: 0 25% }", "<p dir=\"rtl\">كتاب <i>;</i> مدرسة <b>;</b>الطالب جميل.</p>")
open("/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/cands.tsv", "w").write("\n".join(rows) + "\n")
print(len(rows))
