
/// The punctuation shape of the round-6 sweeps: a styled `?!` glued to a
/// word, a full stop, a styled bracket pair and a `!`, three times.
fn styled_marks(words: &[&'static str; 12]) -> String {
    rep(3, |i| {
        format!(
            "{} <b>?!</b> {} {}. <i>(</i>{}<i>)</i> {}!",
            word(words, i),
            word(words, i + 1),
            word(words, i + 2),
            word(words, i + 3),
            word(words, i + 4)
        )
    })
}

/// The number shape of the round-6 sweeps: a sign after European digits, a
/// bold word, Arabic-Indic digits and a year with the ARABIC COMMA.
fn signs_and_numbers(sentences: usize) -> String {
    rep(sentences, |i| {
        format!(
            "{} 25\u{66A} <b>{}</b> \u{661}\u{662}\u{663} {} 2010\u{60C} {}.",
            word(&AR, i),
            word(&AR, i + 1),
            word(&AR, i + 2),
            word(&AR, i + 3)
        )
    })
}

/// **A line drawn under a CSS transform is read back on the page it is drawn
/// on** (V1 of round 6's lane V; ROADMAP CD-19).
///
/// The writer reads each line that holds a right-to-left character back as a
/// reader reads it (`paint::Fonts::set_readings`), and its rules ask whether
/// a reader parts two text objects of a run (`paint::parted`,
/// `paint::page_lines`, `paint::leading_mark_at`). A transform writes a `cm`
/// before the text (`paint::OnPage::open`), and a scale of one axis widens or
/// narrows every gap on the page against the glyphs' size, which is what a
/// reader's thresholds are in. Read back under no matrix, a styled `?!` glued
/// to a Hebrew word at `word-spacing: 0.6em` under `scaleX(2)` was read with
/// the word and drawn turned for that reading; on the page, where the gap is
/// twice as wide, it was read alone, and turned: `שלום!? עולם.`, where
/// 9297d2d and 56dfd93 read `שלום?! עולם.`. Each line is read back under the
/// matrix the page draws it under now (`paint::OnPage::matrix`), and every
/// rule that asks whether a reader parts two objects asks it in the page's
/// ems (`paint::along_the_line`): under `scaleX(3)` a `letter-spacing` of
/// `0.3em` parts the line on the page and not in the run.
///
/// `25٪ <b>W</b>` in Arabic under `scaleX(1.4)`, which conserved at 56dfd93
/// and not since round 5, reads right again. Under a half turn at
/// `word-spacing: 1em` three such sentences conserved at 56dfd93 only because
/// the overflow font's moved glyphs drew the bold word apart around its sign;
/// at `0 Tw` no drawing the read-back tries reads the line right (ROADMAP
/// CD-19, Left (6)), pinned. The controls read as they did: no transform,
/// `scale(2)`, whose gaps keep their size against the glyphs, `scaleY(2)` and
/// a Latin paragraph, which is not read back.
#[test]
fn a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on() {
    let right = Expect::Holds("cons logical whole found apart");
    let he = "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>";
    let ar = "<p dir=\"rtl\">كتاب <b>?!</b> مدرسة.</p>";
    let prose = |w: &[&'static str; 12]| {
        let text = rep(3, |i| {
            format!(
                "{} {} {}\u{60C} {} {} {}.",
                word(w, i),
                word(w, i + 1),
                word(w, i + 2),
                word(w, i + 3),
                word(w, i + 4),
                word(w, i + 5)
            )
        });
        format!("<p dir=\"rtl\">{text}</p>")
    };
    let mut cases = vec![
        Case::both("a styled ?! glued to a Hebrew word under scaleX(2) at 0.6em (V1)", "he", "p { transform: scaleX(2); word-spacing: 0.6em }", he, right),
        Case::both("the same at 1em (V1)", "he", "p { transform: scaleX(2); word-spacing: 1em }", he, right),
        Case::both("the same under scaleX(1.4) at 1em (V1)", "he", "p { transform: scaleX(1.4); word-spacing: 1em }", he, right),
        Case::both("the same with no dir (V1)", "he", "p { transform: scaleX(2); word-spacing: 0.6em }", "<p>שלום <b>?!</b> עולם.</p>", Expect::Holds("cons logical found apart")),
        Case::both("a styled ?! glued to an Arabic word under scaleX(2) (V1)", "ar", "p { transform: scaleX(2); word-spacing: 0.6em }", ar, right),
        Case::both(
            "a sign after European digits before a bold word under scaleX(1.4) (V1, since round 5)",
            "ar",
            "p { margin: 0 30%; transform: scaleX(1.4); word-spacing: 0.6em }",
            format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(1)),
            right,
        ),
        Case::both(
            "three such sentences under a half turn at 1em (V1, conserved at 56dfd93 only; Left (6))",
            "ar",
            "p { margin: 0 30%; transform: rotate(180deg); word-spacing: 1em }",
            format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(3)),
            Expect::Pinned("logical found apart"),
        ),
        Case::both("one under a half turn at 1em (guard)", "ar", "p { margin: 0 30%; transform: rotate(180deg); word-spacing: 1em }", format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(1)), right),
        Case::both("Hebrew prose under scaleX(3), letter-spaced by 0.3em (the rules, f6 sweep)", "he", "p { margin: 0 30%; transform: scaleX(3); letter-spacing: 0.3em }", prose(&HE), Expect::Holds("cons logical found")),
        Case::both("Arabic prose under scaleX(3), letter-spaced by 0.3em (the rules, f6 sweep)", "ar", "p { margin: 0 30%; transform: scaleX(3); letter-spacing: 0.3em }", prose(&AR), Expect::Holds("cons logical found")),
        Case::both("no transform (control)", "he", "p { word-spacing: 0.6em }", he, Expect::Holds("cons logical found apart")),
        Case::both("scale(2), both axes alike (control)", "he", "p { transform: scale(2); word-spacing: 0.6em }", he, Expect::Holds("cons logical found apart")),
        Case::both("scaleY(2) (control)", "he", "p { transform: scaleY(2); word-spacing: 0.6em }", he, right),
        Case::both("a Latin paragraph under scaleX(2) at 1em, nothing right to left (guard)", "en", "p { transform: scaleX(2); word-spacing: 1em }", "<p>The word <b>?!</b> means <i>peace</i>, (here) 25%.</p>", right),
    ];
    for (style, language, words) in [
        ("p { margin: 0 30%; transform: scaleX(2); word-spacing: 0.6em }", "he", HE),
        ("p { margin: 0 30%; transform: scaleX(0.5); word-spacing: 0.6em }", "ar", AR),
        ("p { margin: 0 30%; transform: skewX(-15deg); word-spacing: 0.6em }", "he", HE),
        ("p { margin: 0 30%; transform: rotate(12deg); word-spacing: 0.6em }", "ar", AR),
    ] {
        cases.push(Case::both("the punctuation shape under a transform at 0.6em (f6 sweep)", language, style, format!("<p dir=\"rtl\">{}</p>", styled_marks(&words)), Expect::Holds("")));
    }
    check(&cases);
}

/// **A line is read back as the page's fonts give its characters back**
/// (round 6's lane F, the sweep of V1's class).
///
/// The read-back held a reading to the line as typed, and fed `TextDevice`
/// each character as typed. A standard face draws a NO-BREAK SPACE at
/// `WinAnsiEncoding`'s 0xA0, which 9.6.5 reads by its glyph name, `space`, so
/// a reader of the page reads a word space there; read back as typed it was a
/// `CS` between two digits, `1 234` one number to UAX #9, and a drawing that
/// read right only so was taken. Each character is read back now as the face
/// the page draws it in gives it back (`paint::Segment::read_as`,
/// `paint::Fonts::read_as`): the WinAnsi code's character, the overflow
/// font's by its `/Differences` name, the stand-in's own. Guards: these books
/// read as at 05cea0b, and without the decoding the dir-less ones lose their
/// content order.
#[test]
fn a_line_is_read_back_as_the_pages_fonts_give_its_characters_back() {
    let ws = "p { word-spacing: 0.6em }";
    check(&[
        Case::both("a bold 1\u{a0}234 in a dir-less Arabic line (guard)", "ar", ws, "<p>كتاب مدرسة <b>1\u{a0}234</b> الطالب، جميل بيت.</p>", Expect::Holds("cons logical found apart")),
        Case::both("the same, right to left (guard)", "ar", ws, "<p dir=\"rtl\">كتاب مدرسة <b>1\u{a0}234</b> الطالب، جميل بيت.</p>", Expect::Holds("cons logical whole found apart")),
        Case::both("a bold 1\u{a0}234 in a dir-less Hebrew line (guard)", "he", ws, "<p>שלום עולם <b>1\u{a0}234</b> מלחמה، ספר בית.</p>", Expect::Holds("cons logical found apart")),
        Case::both("the same, right to left (guard)", "he", ws, "<p dir=\"rtl\">שלום עולם <b>1\u{a0}234</b> מלחמה، ספר בית.</p>", Expect::Holds("cons logical whole found apart")),
        Case::both("a SOFT HYPHEN inside a Hebrew word (as at every tree)", "he", ws, "<p dir=\"rtl\">שלום עו\u{ad}לם <b>?!</b> מלחמה.</p>", Expect::Holds("")),
    ]);
}

/// **Rows a reader runs together are read back as one line** (round 6's
/// lane F, the sweep of V1's class).
///
/// `TextDevice` asks each glyph whether it is on the line of the one drawn
/// before it, within half an em; under a `line-height` of half an em or less
/// every line of a paragraph is within that of the next, and a reader runs
/// them together. `paint::page_lines` asked each run of the row's first
/// instead, and read the lines back one by one, for a reader that does not
/// exist; it asks the run before it now. An Arabic paragraph at
/// `line-height: 0.4`, letter-spaced and justified, lost its content order at
/// 9297d2d and reads right now, with no `dir` and right to left. A
/// `line-height` of 0.6 parts the rows for both (guard).
#[test]
fn rows_a_reader_runs_together_are_read_back_as_one_line() {
    let tight = "p { margin: 0 30%; line-height: 0.4; letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }";
    check(&[
        Case::both("a justified Arabic paragraph at line-height 0.4, no dir (sweep)", "ar", tight, format!("<p>{}</p>", styled_marks(&AR)), Expect::Holds("cons logical whole found")),
        Case::both("the same, right to left (sweep)", "ar", tight, format!("<p dir=\"rtl\">{}</p>", styled_marks(&AR)), Expect::Holds("cons logical whole found")),
        Case::both("at line-height 0.6, rows apart (guard)", "ar", "p { margin: 0 30%; line-height: 0.6; word-spacing: 0.6em }", format!("<p dir=\"rtl\">{}</p>", styled_marks(&AR)), Expect::Holds("cons logical found")),
    ]);
}

/// **A reading that cuts a word or runs two together is not the line's
/// text** (round 6's lane F, the sweep of V1's class).
///
/// The read-back held a reading to the line's letters, white space aside, so
/// a drawing that a reader reads with a word run into the next, or cut, was
/// taken as right, and search and reading the block whole lost it: a styled
/// `?!` glued to a Hebrew word at `word-spacing: 0.6em` conserved and read
/// `שלום?! עולם.`, its word space gone. A reading is right now where its
/// words are the line's, each run of white space one space
/// (`paint::Words`); where no drawing tried reads the words right, the first
/// that reads the letters right is drawn, as before, and the rules' drawing
/// where it reads the letters right itself.
#[test]
fn a_reading_that_cuts_or_joins_a_word_is_not_taken_for_the_lines_text() {
    let right = Expect::Holds("cons logical whole found apart");
    check(&[
        Case::both("a styled ?! glued to a Hebrew word at 0.6em", "he", "p { word-spacing: 0.6em }", "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>", right),
        Case::both("the same under scale(2)", "he", "p { transform: scale(2); word-spacing: 0.6em }", "<p dir=\"rtl\">שלום <b>?!</b> עולם.</p>", right),
        Case::both("a sign after European digits before a bold word at 1em", "ar", "p { margin: 0 30%; word-spacing: 1em }", format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(1)), right),
        Case::both("two such sentences at 1em", "ar", "p { margin: 0 30%; word-spacing: 1em }", format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(2)), right),
        Case::both("the punctuation shape at line-height 0.6", "ar", "p { margin: 0 30%; line-height: 0.6; word-spacing: 0.6em }", format!("<p dir=\"rtl\">{}</p>", styled_marks(&AR)), right),
        Case::both(
            "three number sentences under scaleY(2), letter-spaced and justified (guard)",
            "ar",
            "p { margin: 0 30%; transform: scaleY(2); letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }",
            format!("<p dir=\"rtl\">{}</p>", signs_and_numbers(3)),
            Expect::Holds("cons logical whole found"),
        ),
    ]);
}
