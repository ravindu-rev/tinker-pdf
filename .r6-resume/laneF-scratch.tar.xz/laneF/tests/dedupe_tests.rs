
/// **Each drawing a line has is read once, so the budget reaches the one that
/// reads it right** (V5 of round 6's lane V; ROADMAP CD-19).
///
/// The read-back tries each run's drawings, then two runs' at a time, and
/// gives up after `paint::READINGS_PER_LINE` readings. Many of a run's
/// drawings write the same text objects as the rules' or as another of its
/// own — a slice that is all one resource cut whole or in pieces, its
/// neutrals turned where they read alike — and each was read again, and
/// spent a reading; on a line of a few spaced runs the pair that reads right
/// came after the budget. A drawing that writes what one before it wrote is
/// not read now (`paint::Fonts::plan_run`): a right-to-left paragraph with a
/// generated `§ ` before it at `word-spacing: 0.6em` or `1em` reads whole,
/// and `<bdi>` holding a Latin sentence with Hebrew in it, in a Hebrew
/// paragraph at `word-spacing: 1em`, conserves, where no tree did.
#[test]
fn each_drawing_a_line_has_is_read_once_so_the_budget_reaches_the_right_one() {
    let generated = |ws: &str| -> &'static str {
        match ws {
            "0.6em" => "p { word-spacing: 0.6em } .b::before { content: \"\u{a7} \" }",
            _ => "p { word-spacing: 1em } .b::before { content: \"\u{a7} \" }",
        }
    };
    let he = "<p dir=\"rtl\" class=\"b\">שלום עולם <b>מלחמה</b> ספר، בית (גדול) אור.</p>";
    let ar = "<p dir=\"rtl\" class=\"b\">كتاب مدرسة <b>الطالب</b> جميل، بيت (كبير) نور.</p>";
    check(&[
        Case::both("a Hebrew paragraph after a generated \u{a7} at 0.6em (V5)", "he", generated("0.6em"), he, Expect::Holds("whole found apart")),
        Case::both("the same at 1em (V5)", "he", generated("1em"), he, Expect::Holds("whole found apart")),
        Case::both("an Arabic paragraph after a generated \u{a7} at 0.6em (V5)", "ar", generated("0.6em"), ar, Expect::Holds("whole found apart")),
        Case::both("the same at 1em (V5)", "ar", generated("1em"), ar, Expect::Holds("whole found apart")),
        Case::both(
            "a bdi of Latin with Hebrew in it in a Hebrew paragraph at 1em (V5)",
            "he",
            "p { word-spacing: 1em; margin: 0 20% }",
            "<p dir=\"rtl\">יום <bdi>The word שלום means עולם in <i>מלחמה</i>. The word שלום means עולם in <i>מלחמה</i>.</bdi> בראשית.</p>",
            Expect::Holds("cons logical whole found apart"),
        ),
    ]);
}
