"""Compare zz_v6_time SCALE lines of two runs: open_ms at each size, and its growth per doubling.

usage: python3 -I timecmp.py A/raw/zz_v6_time.txt B/raw/zz_v6_time.txt
"""
import re
import sys


def load(p):
    d = {}
    for line in open(p, encoding='utf-8'):
        m = re.search(r'SCALE\t(\S+)\tn=(\d+)\tbody=(\d+)\tpages=(\d+)\tchars=(\d+)\topen_ms=([\d.]+)\ttext_ms=([\d.]+)', line)
        if m:
            d[(m.group(1), int(m.group(2)))] = (int(m.group(5)), float(m.group(6)), float(m.group(7)), int(m.group(4)))
    return d


a, b = load(sys.argv[1]), load(sys.argv[2])
print('shape n chars pages | open_ms A -> B (ratio) | growth per doubling A, B | text_ms A -> B')
pa, pb = {}, {}
for k in sorted(b, key=lambda k: (k[0], k[1])):
    if k not in a:
        continue
    ca, oa, ta, pga = a[k]
    cb, ob, tb, pgb = b[k]
    ga = oa / pa[k[0]] if pa.get(k[0]) else float('nan')
    gb = ob / pb[k[0]] if pb.get(k[0]) else float('nan')
    pa[k[0]] = oa
    pb[k[0]] = ob
    print(f'{k[0]} {k[1]} {cb} {pgb} | {oa:.1f} -> {ob:.1f} ({ob / max(oa, 0.01):.1f}x) | x{ga:.2f} x{gb:.2f} | {ta:.1f} -> {tb:.1f}')
