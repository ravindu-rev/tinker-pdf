"""Lane F: paint-A7c.rs = paint-A7.rs with the read-back's readings counted
under cfg(test) (`READINGS`), as `step` counts `cut_run`'s, so that a unit
test holds the Cut rule by count and not by a clock."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A6f.rs')).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""    ) -> Option<(String, usize)> {
        let metrics = BookMetrics::with(self.faces);
        let mut device = tinker_pdf_content::TextDevice::new();
        for (at, run) in line.iter().enumerate() {""", """    ) -> Option<(String, usize)> {
        #[cfg(test)]
        READINGS.with(|readings| readings.set(readings.get().saturating_add(1)));
        let metrics = BookMetrics::with(self.faces);
        let mut device = tinker_pdf_content::TextDevice::new();
        for (at, run) in line.iter().enumerate() {""")
rep("""#[cfg(test)]
thread_local! {
    /// [`step`]'s count, on this thread.
    pub(crate) static STEPS: core::cell::Cell<usize> = const { core::cell::Cell::new(0) };
}""", """#[cfg(test)]
thread_local! {
    /// [`step`]'s count, on this thread.
    pub(crate) static STEPS: core::cell::Cell<usize> = const { core::cell::Cell::new(0) };
    /// How many times [`Fonts::read_back`] read a line back, on this thread:
    /// counted under `cfg(test)` only, so that `epub/tests.rs` holds the
    /// read-back's work by count where a clock would only run slowly.
    pub(crate) static READINGS: core::cell::Cell<usize> = const { core::cell::Cell::new(0) };
}""")
open(os.path.join(HERE, 'paint-A6c.rs'), 'w').write(s)
print('A6c written')
