"""Lane F: paint-A5.rs from paint-A4f.rs: the fallback's drawing, found in the
runs' own space, is taken only where, read back on the page, it reads the
line's letters closer to the order written than the rules' drawing does there
(more of the text's letter pairs in order) and sets no more glyphs over others."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A4f.rs')).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""                    match self.search(&line, &own, frame, &written, &options) {
                        Search::Found(found) => Some(found),
                        Search::Rules | Search::Nothing => None,
                    }""", """                    match self.search(&line, &own, frame, &written, &options) {
                        Search::Found(found)
                            if self.reads_closer(&line, &matrices, frame, &written, &found) =>
                        {
                            Some(found)
                        }
                        Search::Found(_) | Search::Rules | Search::Nothing => None,
                    }""")

rep("""    /// The text objects [`plan_coded`] writes for the whole of `run` drawn as""", """    /// Whether `found`, a drawing [`Fonts::search`] found reading `line` right
    /// in its runs' own space where nothing it tried reads it right on the
    /// page, reads the line's letters closer to the order written on the page
    /// than the rules' drawing does there — more of the text's pairs of
    /// letters in order ([`Words::pairs_in`]) — and sets no more glyphs over
    /// others there. A drawing found right in a space that is not the page's
    /// is no better than a guess on the page: a styled `?!` turned for a
    /// reading in which it joined its word read `!?` alone on the page under
    /// `scaleX(2)`, where the rules' drawing read it right.
    fn reads_closer(
        &self,
        line: &[&TextRun],
        matrices: &[[f64; 6]],
        frame: &Frame,
        written: &Words,
        found: &BTreeMap<RunKey, Drawing>,
    ) -> bool {
        let Some((rules, over_by_rules)) = self.read_back(line, matrices, frame, &BTreeMap::new())
        else {
            return false;
        };
        let Some((read, over)) = self.read_back(line, matrices, frame, found) else {
            return false;
        };
        over <= over_by_rules && written.pairs_in(&read) > written.pairs_in(&rules)
    }

    /// The text objects [`plan_coded`] writes for the whole of `run` drawn as""")

rep("""    /// How `read`, a reading of the line (its lines joined by a line feed),
    /// compares with the line's text.
    fn read_as(&self, read: &str) -> Read {""", """    /// How many of the line's pairs of letters, each letter and the one
    /// written after it, `read` reads in that order, each pair counted as
    /// often as the text has it: how near a reading that is not the text's
    /// comes to it, in time linear in the two, near enough.
    fn pairs_in(&self, read: &str) -> usize {
        let mut wanted: BTreeMap<(char, char), usize> = BTreeMap::new();
        let mut before: Option<char> = None;
        for ch in self.letters.chars() {
            if let Some(first) = before {
                *wanted.entry((first, ch)).or_default() += 1;
            }
            before = Some(ch);
        }
        let mut found = 0;
        let mut before: Option<char> = None;
        for ch in read.chars().filter(|c| !c.is_whitespace()) {
            if let Some(left) = before.and_then(|first| wanted.get_mut(&(first, ch))) {
                if *left > 0 {
                    *left -= 1;
                    found += 1;
                }
            }
            before = Some(ch);
        }
        found
    }

    /// How `read`, a reading of the line (its lines joined by a line feed),
    /// compares with the line's text.
    fn read_as(&self, read: &str) -> Read {""")
open(os.path.join(HERE, 'paint-A5.rs'), 'w').write(s)
print('A5 written')
