#!/usr/bin/env bash
# Lane F: run the kit's diag probe at a tree over a TSV in laneF/diag.
# usage: diag.sh TREE BUILD NAME OUTTAG [lines] [cs]
#   TREE: tip (lane F worktree) | 56 | 9297
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
S=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad
KIT=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  935) W=$L/base935; T=$L/base935-target ;;
  56) W=/home/user/tinker-pdf/.claude/worktrees/wf_26917f32-492-8; T=$W/target ;;
  9297) W=$S/k11r4/base; T=$S/k11r4/base-target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
B=$2; N=$3; O=$4; shift 4
export CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=$T CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
"$KIT/scripts/diag.sh" "$W" "$B" "$L/diag/$N.tsv" "$L/diag/$N-$O-$B.txt" "$@" > /dev/null 2>&1
code=$?
rm -f "$T"/debug/deps/zz_fx2dbg-*
echo "diag exit $code"
grep -E '^(V|exit|error)' "$L/diag/$N-$O-$B.txt" | cut -c1-260
