"""Lane F (run 5): the doc edits of each commit of the fold, applied to a
checkout's docs/ROADMAP.md and docs/features/epub.md.

usage: python3 -I docs6.py ROOT STEP    (STEP: fix | v2v3 | v4v5)
Numbers come from laneF/numbers6.json.
"""
import json
import sys

ROOT, STEP = sys.argv[1], sys.argv[2]
N = json.load(open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/numbers6.json'))


def edit(name, pairs):
    p = f'{ROOT}/{name}'
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        assert s.count(old) == 1, (name, s.count(old), old[:100])
        s = s.replace(old, new.format(**N))
    open(p, 'w', encoding='utf-8').write(s)


RM = 'docs/ROADMAP.md'
EP = 'docs/features/epub.md'

if STEP == 'fix':
    edit(RM, [
        # The fix, after the read-back's paragraph.
        ("where the font met ruling 14's sentence-end rule. On the probes of ROADMAP K-11",
         "where the font met ruling 14's sentence-end rule. **And each line is read back on the page it is drawn on** since round 6 "
         "(`paint::OnPage::matrix`, `paint::along_the_line`, `paint::Segment::read_as`, `paint::Words`, `paint::Fonts::reads_closer`, `paint::Fonts::reads_whole`, `paint::drawn_over`; "
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`, `a_line_is_read_back_as_the_pages_fonts_give_its_characters_back`, "
         "`a_reading_that_cuts_or_joins_a_word_is_not_taken_for_the_lines_text`, `a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`, "
         "`a_drawing_that_sets_more_glyphs_over_others_than_the_rules_is_not_taken`, `two_cells_are_read_back_as_a_reader_parts_them_on_the_page`, `a_line_a_reader_cuts_on_the_page_under_a_transform_is_searched_in_its_runs_space_too`, `epub::tests`' `a_line_a_reader_cuts_only_at_its_spacing_is_read_back_once`): "
         "the read-back fed `TextDevice` each glyph in its run's own space, but the page draws the run under the `cm` its CSS `transform` writes, and a reader's "
         "thresholds are in the glyphs' size on the page, against which a scale of one axis widens or narrows every gap — under `transform: scaleX(2)` at "
         "`word-spacing: 0.6em` a styled `?!` glued to a Hebrew or Arabic word was read with the word in the model, drawn turned for that reading, and read alone "
         "on the page, `שלום!? עולם.`, where 9297d2d and 56dfd93 read `שלום?! עולם.` (V1 of its review; of the books of its transforms and of the class's sweep that conserved at 56dfd93 and not at 935b077, {v1_all_d} ({v1_all_b}) conserve again); "
         "and two rules, whether a reader parts two text objects of a run (`paint::parted`) and which runs it reads as one line (`paint::page_lines`), asked in "
         "the run's ems, so that `25٪ <b>W</b>` in Arabic under `scaleX(1.4)`, which conserved at 56dfd93, read its number backwards since round 5. Each line "
         "is read back under the matrix the page draws each of its runs under, both rules ask in a reader's ems on the page (an em of a run's spacing is `√2` of "
         "them under `scaleX(2)`, one under a turn, a shift or `scale(2)`), and two more ways the model read another page went with it: each glyph is read back "
         "as the page's font gives it back, so that a standard face's NO-BREAK SPACE, drawn at `WinAnsiEncoding`'s `0xA0`, is the space a reader reads by its "
         "glyph name and not the `CS` that made `1 234` one number to UAX #9 in the model; and a reading is right where it holds the line's words, not only its "
         "letters (a drawing that lost a word space had been taken, and `שלום <b>?!</b> עולם.` at `word-spacing: 0.6em` no longer read whole), while a reading of the rules' drawing that only cuts a word where a reader parts the spacing, running none together, is searched no further, as 935b077 searched it no further (`paint::Read::Cut`: held to the words, every letter-spaced line spent the whole budget, and one of 3 528 characters letter-spaced by `0.6em` took {t_ls_a6} to open in debug against {t_ls_935} at 935b077; what searching on finds is below, the owner's to price). Under a transform, "
         "a line nothing tried reads right on the page is searched again in its runs' own space, and what that finds is drawn only where it holds more of the "
         "text's pairs of letters in order on the page than the rules' drawing; a line whose rules' drawing reads there with a word cut is searched in its "
         "runs' own space too, as 935b077 searched every line under a transform, and what that finds is drawn only where it reads the words right on the page "
         "(kept as the rules drew it, an Arabic paragraph of numbers letter-spaced, word-spaced and justified under `scaleX(2)`, `scaleY(0.5)` or a matrix of "
         "its own, which read whole at 935b077, lost its text); and no drawing that sets more glyphs over others than the rules' is taken. "
         "`paint::leading_mark_at`, which places a mark of no advance against half an em, keeps the run's ems: asked in the page's, it moved no book of the "
         "sweeps. On round 6's hunt and its sweep of the class (the kit's `v6`, `v6t`, `f6` and `v6pdf` families: {r6_books} books a build), and on every "
         "family before them ({all_books} books a build in all), it makes {gain_d} ({gain_b}) books read better than at 935b077 on some metric, {cons_gain_d} "
         "({cons_gain_b}) of them conserving, with none worse on any metric and no glyph drawn over another more often, in either build. On the probes of ROADMAP K-11"),
        # Left (4): the Persian digits read whole again.
        (", a right-to-left Hebrew paragraph with Persian digits letter-spaced by `0.1em`, word-spaced by `0.5em` and justified, `٢٠١٠. ۴۵`, which read whole at 9297d2d and conserves (a default build's, and its minimised twin), and with `bundled-fonts` two pointed-Hebrew lines",
         ", and with `bundled-fonts` two pointed-Hebrew lines"),
        (", the stops outside the rule's and the two pairs, and `a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`, the Persian digits; `epub_fallback.rs`'s",
         ", the stops outside the rule's and the two pairs; `epub_fallback.rs`'s"),
        # Left (5): the `;` reads whole again.
        ("a dir-less Arabic paragraph with an inline `word-spacing: 1em` span cutting a word (1 (1), conserved at 56dfd93); and, read whole at 56dfd93 only, an Arabic line with `;` glued to a word, letter-spaced by `0.25em` and justified, which conserves now (1 (1)) (pinned:",
         "and a dir-less Arabic paragraph with an inline `word-spacing: 1em` span cutting a word (1 (1), conserved at 56dfd93) (pinned:"),
        ("`a_styled_neutral_glued_to_a_word_under_spacing_reads_where_it_was_typed`, the span and the `;`). **Read so at every tree**",
         "`a_styled_neutral_glued_to_a_word_under_spacing_reads_where_it_was_typed`, the span); (6) `25٪ <b>W</b> ١٢٣ … 2010،` in an Arabic paragraph, "
         "with `dir` or without, turned by half a turn (`transform: rotate(180deg)`) at `word-spacing: 1em`: {left6_d} ({left6_b}) books of round 6's hunt and "
         "sweep that conserved at 56dfd93 only, where the overflow font's moved glyphs drew the bold word apart around its sign; at `0 Tw` no drawing tried reads "
         "the line right on the page, since `TextDevice` asks whether a glyph continues a line, or a text object's end parts it, along the page's `x`, which a "
         "half turn runs the other way — a reader that measures along a turned baseline is a change to every page with turned text (pinned: `epub_fallback.rs`'s "
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`). Read whole again since round 6, each with a test that holds it: the "
         "Persian digits of (4), `٢٠١٠. ۴۵` in a right-to-left Hebrew paragraph letter-spaced, word-spaced and justified, which read whole at 9297d2d "
         "(`a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`), and the `;` of (5), glued to an Arabic word, letter-spaced by `0.25em` and justified, "
         "which read whole at 56dfd93 (`a_styled_neutral_glued_to_a_word_under_spacing_reads_where_it_was_typed`). **Read so at every tree**"),
        ("a reader that resumes a line across a stretch past an em for (3), and K-11's reader for (4) — or the owner accepts them",
         "a reader that resumes a line across a stretch past an em for (3), K-11's reader for (4), and a reader that measures a gap along a turned baseline for (6) — or the owner accepts them"),
    ])
    edit(EP, [
        ("`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n**Measured, and what is left.**",
         "`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n"
         "**Each line is read back on the page it is drawn on** (round 6;\n"
         "`paint::OnPage::matrix`, `paint::along_the_line`, `paint::Segment::read_as`,\n"
         "`paint::Words`). The read-back fed `TextDevice` each glyph in its run's\n"
         "own space, but the page draws the run under the `cm` its CSS `transform`\n"
         "writes (`paint::OnPage::open`), and a reader's thresholds are in the\n"
         "glyphs' size on the page: a transform that scales one axis more than the\n"
         "other widens or narrows every gap against it. Under `transform: scaleX(2)`\n"
         "at `word-spacing: 0.6em` a styled `?!` glued to a Hebrew or Arabic word\n"
         "was read with the word in the model, drawn turned for that reading, and\n"
         "read alone on the page, turned: `שלום!? עולם.`, where 9297d2d and 56dfd93\n"
         "read `שלום?! עולם.` (of the books of round 6's hunt and of the class's\n"
         "sweep that conserved at 56dfd93 and not at 935b077, {v1_all_d} conserve again\n"
         "in a default build and {v1_all_b} with `bundled-fonts`). Two of the writer's rules asked in the\n"
         "run's ems too — whether a reader parts two text objects of a run\n"
         "(`paint::parted`) and which runs it reads as one line (`paint::page_lines`) —\n"
         "so that `25٪ <b>W</b>` in Arabic under `scaleX(1.4)`, which conserved at\n"
         "56dfd93, read its number backwards since round 5. Each line is read back\n"
         "now under the matrix the page draws each of its runs under, and both rules\n"
         "ask in a reader's ems on the page: an em of a run's own spacing is\n"
         "`along_the_line` of its matrix, the scale along the baseline over the\n"
         "square root of the determinant's magnitude, which is how `TextDevice`\n"
         "sizes a glyph — `√2` under `scaleX(2)`, one under a turn, a shift or\n"
         "`scale(2)`. Two more ways the model read another page than the one\n"
         "written went with it, found by taking parts of the fix out one at a time.\n"
         "Each glyph is read back as the page's font gives it back, not as typed: a\n"
         "standard face draws a NO-BREAK SPACE at `WinAnsiEncoding`'s `0xA0`, which a\n"
         "reader reads by its glyph name as a space, and read as typed it was a `CS`\n"
         "that made `1 234` one number to UAX #9, so that a drawing read right only\n"
         "in the model. And a reading is right where it holds the line's words, not\n"
         "only its letters: one that lost a word space was taken, and the block no\n"
         "longer read whole (`שלום <b>?!</b> עולם.` at `word-spacing: 0.6em` read\n"
         "`שלום?! עולם.`); where no drawing tried reads the words right, the first\n"
         "that reads the letters right is drawn, unless the rules' drawing reads\n"
         "them so itself; and a reading of the rules' drawing that only cuts a word\n"
         "where the reader parts the spacing, running none together, is searched\n"
         "no further, as 935b077 searched it no further (`paint::Read::Cut`): held\n"
         "to its words, every letter-spaced line spent the whole budget, and one\n"
         "line of 3 528 characters letter-spaced by `0.6em` took {t_ls_a6} to open in\n"
         "debug against {t_ls_935} at 935b077 (what searching on finds is the\n"
         "owner's to price; ROADMAP CD-19). Under a transform a line the rules'\n"
         "drawing reads on the page with a word cut is searched in its runs' own\n"
         "space too, as 935b077 searched every line under a transform, and what\n"
         "that finds is drawn only where it reads the words right on the page\n"
         "(`paint::Fonts::reads_whole`): kept as the rules drew it, an Arabic\n"
         "paragraph of numbers letter-spaced, word-spaced and justified under\n"
         "`scaleX(2)`, which read whole at 935b077, lost its text. Where nothing tried reads a line right on the page under a\n"
         "transform — glyphs the transform sets over others, whose letters no\n"
         "drawing reads in order — the line is searched again in its runs' own\n"
         "space, and what that finds is drawn only where, read back on the page, it\n"
         "holds more of the text's pairs of letters in order than the rules'\n"
         "drawing does there (`paint::Fonts::reads_closer`); taken as found, it\n"
         "turned a `?!` with no `dir` under `scaleX(2)` for a reading only that space\n"
         "has. And no drawing that sets more glyphs over others than the rules' is\n"
         "taken (`paint::drawn_over`). `paint::leading_mark_at`, which places a mark\n"
         "of no advance against half an em, keeps the run's ems: asked in the\n"
         "page's, it moved no book of the sweeps. On round 6's hunt and its sweep of\n"
         "the class ({r6_books} books a build) and every family before them\n"
         "({all_books} in all), {gain_d} books read better than at 935b077 in a default\n"
         "build and {gain_b} with `bundled-fonts`, {cons_gain_d} ({cons_gain_b}) of\n"
         "them conserving, and none reads worse on any metric or draws a glyph over\n"
         "another more often\n"
         "(`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`,\n"
         "`a_line_is_read_back_as_the_pages_fonts_give_its_characters_back`,\n"
         "`a_reading_that_cuts_or_joins_a_word_is_not_taken_for_the_lines_text`,\n"
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`,\n"
         "`a_drawing_that_sets_more_glyphs_over_others_than_the_rules_is_not_taken`,\n"
         "`two_cells_are_read_back_as_a_reader_parts_them_on_the_page`,\n"
         "`a_line_a_reader_cuts_on_the_page_under_a_transform_is_searched_in_its_runs_space_too`,\n"
         "and in `epub::tests`,\n"
         "`a_line_a_reader_cuts_only_at_its_spacing_is_read_back_once`).\n"
         "A half turn\n"
         "at `word-spacing: 1em` is left: `25٪ <b>W</b>` in an Arabic paragraph\n"
         "turned by `rotate(180deg)` conserved at 56dfd93 only, where the moved\n"
         "glyphs drew the bold word apart around its sign, and no drawing reads it\n"
         "right on the page now, since `TextDevice` asks whether a glyph continues a\n"
         "line along the page's `x`, which a half turn runs the other way\n"
         "({left6_d} ({left6_b}) books; ROADMAP CD-19, Left (6)).\n"
         "**Measured, and what is left.**"),
        ("two of the hunt's in each build,\n"
         "a paragraph of Arabic with no `dir` whose inline `word-spacing: 1em` span\n"
         "cuts a word (it conserved at 56dfd93) and a `;` glued to an Arabic word,\n"
         "letter-spaced by `0.25em` and justified, which conserves now and no longer\n"
         "reads whole.",
         "one of the hunt's in each build,\n"
         "a paragraph of Arabic with no `dir` whose inline `word-spacing: 1em` span\n"
         "cuts a word (it conserved at 56dfd93); a `;` glued to an Arabic word,\n"
         "letter-spaced by `0.25em` and justified, which conserved and no longer read\n"
         "whole at 935b077, reads whole again since round 6."),
    ])
elif STEP == 'v2v3':
    edit(RM, [
        ("does not take a line that opens with a number, so the stop is read first, whatever the writer draws",
         "does not take a line that opens with a number, so the stop is read first, whatever the writer draws; nor one whose left end is a closing bracket, "
         "which round 6's hunt found (V2): `W <b>W</b> W <i>W</i>, (W).` with no `dir`, letter-spaced (`0.15em` with `word-spacing: 0.3em`, `0.3em` with "
         "`-0.2em`) or at `word-spacing: 0.6em` under a transform or a tight line height, and `<p>שלום.<br/>בראשית (אלהים).</p>` minimised, "
         "{v2_d} ({v2_b}) books of the hunt and its sweep that conserved at 9297d2d and 56dfd93 and were lost when the overflow font was written at `0 Tw` "
         "(e7ca679), the bundled ones Arabic, which drew a glyph over another at both trees"),
        ("— a change to that tie-break, the owner's amendment of 10 October 2026, is the owner's to make (pinned: `epub_conservation.rs`'s `a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`)",
         "— a change to that tie-break, the owner's amendment of 10 October 2026, is the owner's to make (pinned: `epub_conservation.rs`'s `a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`, V2's three with it)"),
        ("`25، <b>W</b>` in a table cell with no `dir` at `word-spacing: 16px; letter-spacing: 1px` (2 (3)),",
         "`25، <b>W</b>` in a table cell with no `dir` at `word-spacing: 16px; letter-spacing: 1px` (2 (3)), two right-to-left cells with no `dir` touching "
         "at `word-spacing: 1em`, `<td><b>שלום</b> <i>עולם</i>،</td><td>מלחמה <i>(</i>ספר<i>)</i>.</td>`, which K-11's reader joins into one line whose left "
         "end is the second cell's `)`, so the stop is read first ({v3_d} ({v3_b}) of round 6's hunt that conserved at 9297d2d, V3; 56dfd93 wrote them byte for "
         "byte as 9297d2d did),"),
        ("`a_dirless_line_with_a_right_to_left_gloss`, the glosses and cells,",
         "`a_dirless_line_with_a_right_to_left_gloss`, the glosses and cells, V3's with them,"),
        # Left (7): the squeezed inline blocks, with bundled-fonts.
        ("`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`). Read whole again since round 6",
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`); (7) with `bundled-fonts`, a Hebrew paragraph with no `dir` of inline "
         "blocks squeezed by `scaleX(0.5)`, `W <span style=\"display: inline-block; transform: scaleX(0.5)\">W <b>?!</b> W</span> W 25٪ W.`, at "
         "`word-spacing: 0.6em`, with no transform on the paragraph or under one of fourteen: {left7_b} books of round 6's sweep, a word of which search "
         "found at 9297d2d only, not at 56dfd93 or 935b077 (the squeezed block draws glyphs over its neighbours at every tree; pinned: `epub_fallback.rs`'s "
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`). Read whole again since round 6"),
        ("and a reader that measures a gap along a turned baseline for (6) — or the owner accepts them",
         "a reader that measures a gap along a turned baseline for (6), and for (7) a cause not yet found — or the owner accepts them"),
    ])
    edit(EP, [
        ("Lines K-11's reader reads from the\nright whatever the writer draws — a Latin gloss before a bracketed\nright-to-left word, table cells,",
         "Lines K-11's reader reads from the\nright whatever the writer draws — a Latin gloss before a bracketed\nright-to-left word, table cells (two right-to-left cells with no `dir`\ntouching among them, {v3_d} ({v3_b}) of round 6's hunt that conserved at\n9297d2d),"),
        ("whose stop, alone at 9297d2d, now abuts the right-to-left\nrun and is read first, since the comma tie-break asks for a right-to-left\nletter at the line's left end;",
         "whose stop, alone at 9297d2d, now abuts the right-to-left\nrun and is read first, since the comma tie-break asks for a right-to-left\nletter at the line's left end, and so for a closing bracket there, `W <b>W</b>\nW <i>W</i>, (W).` with no `dir` letter-spaced or under a transform ({v2_d}\n({v2_b}) more of round 6's hunt and its sweep);"),
    ])
elif STEP == 'v4v5':
    edit(RM, [
        ("`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`). Read whole again since round 6",
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`); (8) a line whose right drawing lies past the read-back's budget: it tries "
         "each run's drawings, then two runs' at a time, and keeps the rules' drawing after 128 readings, and many of a run's drawings write what the rules' "
         "or another of its own does, so on a line of a few spaced runs the pair that reads it right comes after the budget: a right-to-left paragraph after a "
         "generated `§ ` at `word-spacing: 0.6em` or `1em` does not read whole, and a `<bdi>` of Latin with Hebrew in it does not conserve, {v5_d} ({v5_b}) "
         "books of round 6's hunt that no tree read so (V5 of its review); reading each drawing once reaches them and costs {v5_cost}, the owner's to price "
         "(pinned: `epub_fallback.rs`'s `a_line_whose_right_drawing_lies_past_the_budget_is_drawn_by_the_rules`). Read whole again since round 6"),
        ("and for (7) a cause not yet found — or the owner accepts them",
         "for (7) a cause not yet found, and the owner's word on the price of reading each drawing once for (8) — or the owner accepts them"),
        ("**Read so at every tree** since 9297d2d",
         "**What reading back costs**, the owner's to price: `Document::open` of a line no drawing reads right, which spends the whole budget, takes "
         "{t_h1_tip} ms where 56dfd93, with no read-back, takes {t_h1_56} and 935b077 {t_h1_935} (`h1-nowrap` of the kit's `zz_v6_time`, {t_h1_chars} "
         "characters on one line, in debug); plain right-to-left prose justified {t_prose_tip} against {t_prose_56} and {t_prose_935}, and prose with no `dir` "
         "{t_dirless_tip} against {t_dirless_56} and {t_dirless_935}. The cost is linear in the line ({t_growth} per doubling of it), and reading the text back "
         "costs what it did. Searching on past a reading of the rules' drawing that only cuts a word where a reader parts the spacing, as round 6's first "
         "fix did, makes {cut_gain_d} ({cut_gain_b}) more books read better than at 935b077 and none worse, and opens a line of {t_ls_chars} characters "
         "letter-spaced by `0.6em` in {t_ls_a8s} ms where the tip takes {t_ls_tip} and 935b077 {t_ls_935}: the owner's to price. "
         "**Read so at every tree** since 9297d2d"),
    ])
    edit(EP, [
        ("**Measured, and what is left.**",
         "**What reading back costs** is the owner's to price: in debug, opening a\n"
         "book of one line no drawing reads right, which spends the whole budget,\n"
         "takes {t_h1_tip} ms where 56dfd93, with no read-back, takes {t_h1_56} and\n"
         "935b077 {t_h1_935} ({t_h1_chars} characters); plain right-to-left prose,\n"
         "justified, {t_prose_tip} against {t_prose_56} and {t_prose_935}. It is linear in\n"
         "the line. A line whose right drawing comes after the budget is drawn by\n"
         "the rules: {v5_d} ({v5_b}) books of round 6's hunt, none read right at any\n"
         "tree, which reading each drawing once reaches at a cost (ROADMAP CD-19).\n"
         "**Measured, and what is left.**"),
    ])
else:
    raise SystemExit('step?')
print(STEP, 'applied to', ROOT)
