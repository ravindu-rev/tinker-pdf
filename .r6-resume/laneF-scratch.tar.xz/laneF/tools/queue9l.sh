#!/usr/bin/env bash
# Lane F: after queue9 (A9 optimised) ends: A9L optimised (owner3.sh), its
# tables, then zz_v6_time for A9L in debug twice on the quiet machine.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q 'queue9 done' "$L/out/queue9.out" 2>/dev/null; do sleep 20; done
echo "queue9l start $(date +%T)"
THREADS=4 JOBS=4 bash "$L/tools/owner3.sh" A9L
echo "owner3 A9L exit $? $(date +%T)"
bash "$L/tools/opt8.sh" A9L vsA8
export JOBS=4
for i in 1 2; do
  n=1
  while [ -e "$L/out/time8-snap-A9L-$n" ]; do n=$((n + 1)); done
  echo "== snap/A9L timing run $n $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  bash "$L/tools/runat.sh" snap/A9L default "time8-snap-A9L-$n" 'v6time/'
done
echo "queue9l done $(date +%T)"
