#!/usr/bin/env bash
# Lane F: counted injections of lane F's rules at the committed code (A8) in
# snap/INJ (a fresh copy of the worktree), both builds, each injection with
# its catalogue suites -> out/inj8/summary-{default,bundled}.txt. Each build
# runs only the names its summary does not hold complete (resumable); the
# snapshot is refreshed only when out/inj8 holds no summary yet.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=$L/snap/INJ
O=$L/out/inj8
mkdir -p "$O"
if [ ! -f "$O/summary-default.txt" ] && [ ! -f "$O/summary-bundled.txt" ]; then
  bash "$L/tools/snap.sh" INJ
fi
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/INJ-target
NAMES="control no-pairs lines-touching page/read-back-under-no-matrix page/rules-in-the-runs-ems page/along-inverted page/parted-in-the-runs-ems page/lines-cut-in-the-runs-ems page/read-as-typed page/letters-are-enough page/cut-searched page/cut-kept-under-a-transform page/whole-unchecked page/joins-are-cuts page/no-fallback-to-the-runs-space page/overprint-taken page/closer-unchecked"
cd "$W" || exit 2
for b in default bundled; do
  todo=""
  for n in $NAMES; do
    grep -q "^$n $b fires .* complete=True" "$O/summary-$b.txt" 2>/dev/null || todo="$todo $n"
  done
  if [ -z "$todo" ]; then echo "inject $b already done"; continue; fi
  # shellcheck disable=SC2086
  python3 -I tools/probes/rtl/scripts/inject.py run "$W" "$O" --build "$b" $todo >> "$O/run-$b.log" 2>&1
  echo "inject $b exit $?"
done
sha256sum "$W/crates/tinker-pdf/src/epub/paint.rs"
echo "inj done"
