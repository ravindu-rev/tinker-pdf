#!/usr/bin/env bash
# Lane F: the diag probe over diag/TSV.tsv at each variant of paint.rs, in the
# worktree, then paint-C4f.rs back.
# usage: varrun.sh TSV BUILD VARIANT...   -> diag/TSV-<VARIANT>-BUILD.txt
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
N=$1; B=$2; shift 2
for v in "$@"; do
  "$L/tools/swap.sh" "$v" || exit 1
  "$L/tools/diag.sh" tip "$B" "$N" "$v" > /dev/null
  echo "== $v $(tail -1 "$L/diag/$N-$v-$B.txt")"
done
"$L/tools/swap.sh" "${BACK:-C4f}"
