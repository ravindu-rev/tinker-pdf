#!/usr/bin/env bash
# Lane F: run one test (filter) of a test file at the worktree, in a build.
# usage: t.sh FILE FILTER [bundled] -> output to laneF/tlog/FILE-FILTER-BUILD.txt, prints summary
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=${TW:-/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4}
T=${TT:-$W/target}
F=$1; N=$2; B=${3:-default}
FEAT=""
[ "$B" = bundled ] && FEAT="--features bundled-fonts"
mkdir -p "$L/tlog"
O="$L/tlog/${TAG:-tip}-$F-$N-$B.txt"
cd "$W" || exit 2
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
# shellcheck disable=SC2086
cargo test -q -p tinker-pdf $FEAT --test "$F" "$N" -- --nocapture > "$O" 2>&1
echo "exit $?" >> "$O"
grep -E "^test result|cases read otherwise|^exit|panicked|^error" "$O" | head -5
grep -E "^    [^ ]|^[a-zA-Z].*: (does not hold|pinned at)" "$O" | head -40
