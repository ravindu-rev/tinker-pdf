"""Lane F: variant A9 of paint.rs: a reading of the rules' drawing that holds
the line's letters in order, with words cut or run together, ends the search
on the page, as 935b077 ended it (it compared letters only). The rules'
letters-only fallback (rules_letters) can then never be set: removed.

usage: python3 -I mkvar9.py   -> variants/paint-A9.rs
"""
L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
src = open(L + '/variants/paint-A8.rs').read()


def sub(old, new):
    global src
    assert src.count(old) == 1, old
    src = src.replace(old, new)


sub("            Some((Read::Cut, _)) => return Search::Cut,\n",
    "            Some((Read::Cut | Read::Letters, _)) => return Search::Cut,\n")
sub("""        // Where the rules' drawing reads the letters right, it is kept
        // unless another reads the words right too.
        let rules_letters = letters_only.borrow_mut().take().is_some();
""", "")
sub("""        if rules_letters {
            return Search::Nothing;
        }
""", "")
open(L + '/variants/paint-A9.rs', 'w').write(src)
print('variants/paint-A9.rs written')
