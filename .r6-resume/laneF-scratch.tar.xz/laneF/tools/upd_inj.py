"""Lane F: update the two stale injections (no-pairs, lines-touching) for the
moved code and add lane F's own to the kit's catalogue. Run from the worktree."""
import json

P = 'tools/probes/rtl/scripts/injections.json'
LF = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants/laneF-injections.json'
d = json.load(open(P))
inj = d['injections']
for x in inj:
    if x['name'] == 'no-pairs':
        x['edits'] = [{
            "file": "crates/tinker-pdf/src/epub/paint.rs",
            "old": "        for (at, &(first, one)) in options.iter().enumerate() {",
            "new": "        for (at, &(first, one)) in options.iter().enumerate().take(0) {",
            "count": 1,
        }]
    if x['name'] == 'lines-touching':
        x['edits'] = [{
            "file": "crates/tinker-pdf/src/epub/paint.rs",
            "old": "if !line.is_empty() && gap > size.max(run.font_size) * RESUMED_WITHIN {",
            "new": "if !line.is_empty() && run.x > end + 0.01 {",
            "count": 1,
        }]
have = {x['name'] for x in inj}
for x in json.load(open(LF)):
    if x['name'] in have:
        continue
    x['round'] = 'round 6 lane F: the read-back reads the page'
    inj.append(x)
with open(P, 'w') as f:
    json.dump(d, f, indent=1, ensure_ascii=False)
    f.write('\n')
print(len(inj), 'injections')
