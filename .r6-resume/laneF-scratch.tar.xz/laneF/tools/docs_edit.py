"""Lane F: the doc edits of each commit, applied in order to a docs directory
holding ROADMAP.md, epub.md (and HANDOFF.md).

usage: python3 -I docs_edit.py DIR STEP   (STEP: v6 | v1 | v2v3 | v4v5)
Numbers come from numbers.json beside this script's directory (laneF/numbers.json).
"""
import json
import os
import sys

D = sys.argv[1]
STEP = sys.argv[2]
N = json.load(open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/numbers.json'))


def edit(name, pairs):
    p = os.path.join(D, name)
    s = open(p).read()
    for old, new in pairs:
        assert s.count(old) == 1, (name, s.count(old), old[:100])
        s = s.replace(old, new)
    open(p, 'w').write(s)


if STEP == 'v6':
    edit('epub.md', [(
        "a run of `.!` or `!…` opening a right-to-left line before a styled pair\n"
        "(ruling 14 counts it with the price); and two of the hunt's in each build,",
        "a run of `.!` or `!…` opening a right-to-left line before a styled pair\n"
        "(the owner's decision of 12 October 2026 does not name it, and whether it\n"
        "is of ruling 14's price is the owner's to say: ROADMAP CD-19 keeps it); and\n"
        "two of the hunt's in each build,",
    )])
elif STEP in ('v1', 'v2v3', 'v4v5'):
    pairs = N[STEP]
    for name, plist in pairs.items():
        edit(name, [tuple(x) for x in plist])
else:
    raise SystemExit('step?')
print(STEP, 'applied to', D)
