"""Lane F: the doc comments of the read-back in the worktree's paint.rs
(A5f), brought up to what the code does. Run from anywhere; edits in place."""
import sys

P = sys.argv[1]
s = open(P).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""    /// So the line is drawn into the reader itself — the text objects
    /// [`plan_coded`] would write, each glyph where it would stand, fed to a
    /// `TextDevice` and read in logical order — and the text it reads is
    /// held to the line's own, its runs' text in the order written, white
    /// space aside. Where they differ, each run is drawn another way in turn:
    /// its neutrals in the other order ([`Drawing::level_order`]), or its
    /// slice cut otherwise into text objects ([`Cut`]); then two runs at a
    /// time, within [`READINGS_PER_LINE`]. The first drawing that reads the
    /// line right is the one drawn. A line the rules' drawing reads right, or
    /// that no drawing tried reads right, is drawn by the rules, byte for
    /// byte as before; and a line with no right-to-left character, or a run
    /// of a face of the book's own, which [`plan_coded`] does not draw, is
    /// not read.
    ///
    /// The work is linear in the line, once a reading, and a line is read at
    /// most [`READINGS_PER_LINE`] times.""", """    /// So the line is drawn into the reader itself — the text objects
    /// [`plan_coded`] would write, each glyph where the page has it, under
    /// the matrix the page draws its run under ([`OnPage::matrix`]), and read
    /// back as the page's font gives it back ([`Segment::read_as`]), fed to a
    /// `TextDevice` and read in logical order — and the text it reads is
    /// held to the line's own so read, its runs' text in the order written:
    /// its words ([`Words`]). Where they differ, each run is drawn another
    /// way in turn: its neutrals in the other order ([`Drawing::level_order`]),
    /// or its slice cut otherwise into text objects ([`Cut`]); then two runs
    /// at a time, within [`READINGS_PER_LINE`] ([`Fonts::search`]). The first
    /// drawing that reads the line's words right is the one drawn; where none
    /// does, the first that reads its letters in order, unless the rules'
    /// drawing reads them so itself; and none that sets more glyphs over
    /// others than the rules' ([`drawn_over`]). Under a transform, a line
    /// nothing tried reads right on the page is searched again in its runs'
    /// own space, and what that finds is drawn only where it reads closer to
    /// the line on the page than the rules' drawing ([`Fonts::reads_closer`]).
    /// A line the rules' drawing reads right, or that no drawing tried reads
    /// right, is drawn by the rules; and a line with no right-to-left
    /// character, or a run of a face of the book's own, which [`plan_coded`]
    /// does not draw, is not read.
    ///
    /// The work is linear in the line, once a reading, and a line is read at
    /// most [`READINGS_PER_LINE`] times, twice that and twice more under a
    /// transform. It is not free: a line that no drawing reads right spends
    /// the whole budget, and opening a book of such lines takes up to some
    /// eighty times as long as with no read-back (ROADMAP CD-19).""")

rep("""    /// [`Fonts::set_readings`]'s search for one line under `matrices`: the
    /// rules' drawing where it reads the line's words right; else the first
    /// drawing of one run, then of two, within [`READINGS_PER_LINE`]
    /// readings, that does; else, where the rules' drawing does not read the
    /// line's letters right, the first that does; else nothing.""", """    /// [`Fonts::set_readings`]'s search for one line under `matrices`: the
    /// rules' drawing where it reads the line's words right; else the first
    /// drawing of one run, then of two, within [`READINGS_PER_LINE`]
    /// readings, that does; else, where the rules' drawing does not read the
    /// line's letters right, the first that does; else nothing. A drawing
    /// that sets more glyphs over others than the rules' is never taken.""")
open(P, 'w').write(s)
print('doc patched')
