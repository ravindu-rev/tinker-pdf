#!/usr/bin/env bash
# Lane F: run tinker-pdf's lib unit tests matching FILTER in a tree.
# usage: libtest.sh TREE BUILD FILTER   (TREE: tip | snap/NAME)
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
FEAT=""
[ "$2" = bundled ] && FEAT="--features bundled-fonts"
cd "$W" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
# shellcheck disable=SC2086
cargo test -p tinker-pdf $FEAT --lib -- --nocapture "$3" 2>&1 | grep -v "^\s*Compiling" | tail -40
