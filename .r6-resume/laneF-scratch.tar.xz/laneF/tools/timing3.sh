#!/usr/bin/env bash
# Lane F: the read-back's cost at the committed code, on a machine running
# nothing else (start it only when no other lane F job runs; it refuses while
# a cargo, rustc or test binary of lane F is alive). zz_v6_time in debug at
# 56dfd93 (no read-back), at 05cea0b's code (snap/F935, 935b077's read-back),
# at the tip (A8) and with the owner's cut search (snap/A8s), twice each,
# interleaved. usage: timing3.sh   -> out/time8-<tree>-<i>/
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
if pgrep -f 'rtl_probes-|epub_conservation-|epub_fallback-|inject\.py|rsuite|owner3|queue6' > /dev/null; then
  echo "refusing: another lane F job runs"; pgrep -af 'rtl_probes-|epub_conservation-|epub_fallback-|inject\.py|rsuite|owner3|queue6' | head; exit 3
fi
export JOBS=4
# Build each tree's probe first (a run's first build is not timed, but the
# machine should be quiet when the timed runs start).
for t in 56 snap/F935 tip snap/A8s 56 snap/F935 tip snap/A8s; do
  n=$(echo "$t" | tr '/' '-')
  i=1
  while [ -e "$L/out/time8-$n-$i" ]; do i=$((i + 1)); done
  echo "== $t run $i $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  bash "$L/tools/runat.sh" "$t" default "time8-$n-$i" 'v6time/'
done
echo "timing3 done $(date +%T)"
