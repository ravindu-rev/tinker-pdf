"""Lane F: books worse than 9297d2d (strictly) or than 56dfd93 (conserving) at
935b077 and at a run, per family and build: how many the run fixes, and how
many it makes worse that 935b077 did not (which must be none).

usage: python3 -I older8.py TAG   (reads out/table-935-{build}.json, out/table-TAG-{build}.json)
"""
import json
import os
import sys

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
tag = sys.argv[1]
for build in ('default', 'bundled'):
    base = json.load(open(os.path.join(L, 'out', f'table-935-{build}.json')))
    run = json.load(open(os.path.join(L, 'out', f'table-{tag}-{build}.json')))
    tot_fixed = tot_new = 0
    lines = []
    for fam in sorted(set(base) | set(run)):
        if not fam.startswith(build + '/'):
            continue
        b = base.get(fam, {})
        r = run.get(fam, {})
        for key in ('worse_b', 'worse_m'):
            bs = set(map(tuple, (x if isinstance(x, list) else [x] for x in b.get(key, []))))
            rs = set(map(tuple, (x if isinstance(x, list) else [x] for x in r.get(key, []))))
            fixed, new = len(bs - rs), len(rs - bs)
            if key == 'worse_m':
                tot_fixed += fixed
                tot_new += new
            if fixed or new:
                lines.append(f'  {fam} {key}: 935b077 {len(bs)}, now {len(rs)}, fixed {fixed}, new {new}')
    print(f'{build}: worse than 56dfd93 in conserving, fixed {tot_fixed}, new {tot_new}')
    print('\n'.join(lines))
