"""Lane F (run 5): the case test files as the fix commit has them, cut from the
final ones in the worktree: no V2 or V3 cases (they come with their own
commit) and no V5 test (with the budget's commit).

usage: python3 -I stages6.py OUTDIR   -> OUTDIR/epub_conservation.rs, OUTDIR/epub_fallback.rs
"""
import os
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/tests'
out = sys.argv[1]
cons = open(os.path.join(W, 'epub_conservation.rs')).read()
fall = open(os.path.join(W, 'epub_fallback.rs')).read()


def drop(s, text):
    assert s.count(text) == 1, text[:80]
    return s.replace(text, '')


def cut(s, start, end_marker, keep_end=True):
    assert s.count(start) == 1, start[:80]
    i = s.index(start)
    j = s.index(end_marker, i)
    return s[:i] + (s[j:] if keep_end else s[j + len(end_marker):])


# V2: its sentence in the doc, its loop of cases.
cons = drop(cons, """ V2 of round
/// 6's hunt is the same tie-break at a closing bracket, which it refuses as
/// it does a number: `<p>שלום.<br/>בראשית (אלהים).</p>` letter-spaced, a
/// number at spacings the review did not name, and with `bundled-fonts`
/// Arabic, each conserving at 9297d2d and 56dfd93 and lost since e7ca679
/// wrote the overflow font at `0 Tw` (pinned).""")
cons = cut(cons, "    // V2 of round 6's lane V: the same class at a closing bracket and at\n",
           "    check(&cases);\n}\n")
# V3: its sentence in the doc, its two cases.
cons = drop(cons, """ And V3 of round 6's
/// hunt: two right-to-left cells of a table with no `dir`, touching, at
/// `word-spacing: 1em`, which K-11's reader joins into one line that holds
/// nothing left to right and whose left end is the second cell's `)`, so the
/// comma tie-break does not take it and the stop is read first: they
/// conserved at 9297d2d, and since 56dfd93, whose content stream is 9297d2d's
/// byte for byte, they read from the right (Left (4)), pinned.""")
cons = cut(cons, "        // With `bundled-fonts` the Hebrew book conserves at every tree: a\n",
           "    ]);\n}\n")
# Left (7): the squeezed blocks' bundled pin (Neither before it), and its sentence.
fall = drop(fall, """
/// With `bundled-fonts` the paragraph at
/// `0.6em` is pinned at what it reads: a word of it is not found by search,
/// as at 56dfd93 and 935b077, where 9297d2d found every one (15 books of the
/// sweep, with no transform and under fourteen; ROADMAP CD-19, Left (7)).""")
old = """            "a dir-less Hebrew paragraph with inline blocks under scaleX(0.5) at 0.6em (guard; pinned with bundled-fonts)",
            "he",
            at_06,
            body.clone(),
            Expect::Holds("logical"),
            Expect::Pinned("logical"),"""
assert fall.count(old) == 1
fall = fall.replace(old, old.replace(" (guard; pinned with bundled-fonts)", " (guard)").replace('Expect::Pinned("logical"),', "Expect::Neither,"))
# V5: the whole test.
start = "/// **A line whose right drawing lies past the read-back's budget is drawn by\n"
assert fall.count(start) == 1
i = fall.index(start)
j = fall.index("\n}\n", fall.index("fn a_line_whose_right_drawing_lies_past_the_budget_is_drawn_by_the_rules", i)) + 3
fall = fall[:i] + fall[j:].lstrip('\n')
os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'epub_conservation.rs'), 'w').write(cons)
open(os.path.join(out, 'epub_fallback.rs'), 'w').write(fall)
print('fix-commit test files written to', out)
