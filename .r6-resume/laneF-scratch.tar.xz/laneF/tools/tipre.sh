#!/usr/bin/env bash
# Lane F: the suites at the tip again (tag A8t), optimised, both builds, after
# reads_whole lost its unexercised overprint clause.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
export THREADS=${THREADS:-2} JOBS=${JOBS:-2} REL=1
bash "$L/tools/rsuite2.sh" tip default A8t
bash "$L/tools/rsuite2.sh" tip bundled A8t
echo "tipre done"
