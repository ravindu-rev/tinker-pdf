"""Lane F: zz_v6_time at four trees, best of the runs given for each:
56dfd93 (no read-back), 05cea0b's code (935b077's read-back), the tip, and the
tip with the cut search (A8s).

usage: python3 -I time8.py OUT   (reads OUT/time8-{56,snap-F935,tip,snap-A8s}-*/)
"""
import glob
import os
import re
import sys

out = sys.argv[1]
PAT = re.compile(r'SCALE\t(\S+)\tn=(\d+)\tbody=(\d+)\tpages=(\d+)\tchars=(\d+)\topen_ms=([\d.]+)\ttext_ms=([\d.]+)')


def best(tree):
    d = {}
    runs = 0
    for run in sorted(glob.glob(os.path.join(out, f'time8-{tree}-*'))):
        p = os.path.join(run, 'default', 'raw', 'zz_v6_time.txt')
        if not os.path.isfile(p):
            continue
        runs += 1
        for line in open(p, encoding='utf-8'):
            m = PAT.search(line)
            if not m:
                continue
            k = (m.group(1), int(m.group(2)))
            o, t, c = float(m.group(6)), float(m.group(7)), int(m.group(5))
            if k in d:
                d[k] = (c, min(d[k][1], o), min(d[k][2], t))
            else:
                d[k] = (c, o, t)
    return d, runs


trees = [('56', '56dfd93'), ('snap-F935', '935b077'), ('tip', 'tip'), ('snap-A8s', 'cut search')]
data = {}
for t, name in trees:
    data[t], n = best(t)
    print(f'{name}: {n} runs, {len(data[t])} points')
print('shape n chars | open_ms 56dfd93 / 935b077 / tip / cut-search | tip/56 tip/935 cut/tip | text_ms 56 / tip')
for k in sorted(data['tip']):
    if not all(k in data[t] for t, _ in trees):
        continue
    ch = data['tip'][k][0]
    o = [data[t][k][1] for t, _ in trees]
    tx = [data[t][k][2] for t, _ in trees]
    print(f'{k[0]} {k[1]} {ch} | {o[0]:.1f} / {o[1]:.1f} / {o[2]:.1f} / {o[3]:.1f} | {o[2] / max(o[0], .01):.1f}x {o[2] / max(o[1], .01):.2f}x {o[3] / max(o[2], .01):.1f}x | {tx[0]:.1f} / {tx[2]:.1f}')
