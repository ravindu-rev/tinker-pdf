"""Lane F: the suite modules imported from lane V and f6 made clippy-clean,
building the same books: the shapes' type is common.rs's `Shape`, `rep` takes
the shape itself, write! with a trailing newline is writeln!, `33..=126 | 32`
is `32..=126`."""
import re

D = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/tests/rtl_probes/'
for f in ['zz_f6_transform.rs', 'zz_v6_inline.rs', 'zz_v6_scripts2.rs', 'zz_v6_transform.rs', 'zz_v6_units.rs']:
    p = D + f
    s = open(p, encoding='utf-8').read()
    if 'let shapes: Vec<Shape> = vec![' in s:
        print(f, 'done before')
        continue
    assert s.count('let shapes: Vec<(&str, Box<dyn Fn(usize) -> String>)> = vec![') == 1, f
    s = s.replace('let shapes: Vec<(&str, Box<dyn Fn(usize) -> String>)> = vec![', 'let shapes: Vec<Shape> = vec![')
    s, k = re.subn(r'rep\((\d+), \|k\| shape\(k\)\)', r'rep(\1, shape)', s)
    assert k == 1, f
    m = re.search(r'use super::common::\{([^}]*)\};', s)
    items = [x.strip() for x in m.group(1).split(',')]
    items.append('Shape')
    items = sorted(set(items), key=lambda x: (x[0].isupper(), x.isupper() and len(x) > 1 and x == x.upper(), x))
    s = s[:m.start()] + 'use super::common::{' + ', '.join(items) + '};' + s[m.end():]
    open(p, 'w', encoding='utf-8').write(s)
    print(f, 'use super::common::{' + ', '.join(items) + '};')

p = D + 'zz_v6_pdf.rs'
s = open(p, encoding='utf-8').read()
assert s.count('33..=126 | 32 => out.push(code as char),') == 1
s = s.replace('33..=126 | 32 => out.push(code as char),', '32..=126 => out.push(code as char),')
n = 0


def fix(m):
    global n
    n += 1
    return m.group(1) + 'writeln!(' + m.group(2) + m.group(3)[:-2] + '"'


s = re.sub(r'(let _ = )write!\((\s*s,\s*)("(?:[^"\\]|\\.)*\\n")', fix, s)
open(p, 'w', encoding='utf-8').write(s)
print('zz_v6_pdf writeln fixes', n)
