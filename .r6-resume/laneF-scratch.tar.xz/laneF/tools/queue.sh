#!/usr/bin/env bash
# Lane F: after owner.sh H1 has finished, measure H6 and then A4d (the V5
# dedupe option), one after the other.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^owner H1 done' "$L/out/owner-H1.log" 2>/dev/null; do sleep 20; done
"$L/tools/owner.sh" H6 > "$L/out/owner-H6.log" 2>&1
"$L/tools/owner.sh" A4d > "$L/out/owner-A4d.log" 2>&1
echo "queue done"
