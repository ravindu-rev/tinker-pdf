#!/usr/bin/env bash
# Lane F: measure an owner's candidate in snap/NAME (a copy of the worktree with
# the candidate's file swapped in): both rtl_probes suites (and rtl_lines),
# bidi_conformance, and the case tests in both builds.
# usage: owner.sh NAME     -> out/suite-NAME-{default,bundled}.log(.lines),
#                             out/kit-NAME/, out/owner-NAME-*.log
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
N=$1
export THREADS=${THREADS:-2} JOBS=${JOBS:-2}
"$L/tools/suite.sh" "snap/$N" default "$N"
"$L/tools/suite.sh" "snap/$N" bundled "$N"
cd "$L/snap/$N" || exit 2
export CARGO_BUILD_JOBS=$JOBS CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/$N-target
cargo test -p tinker-pdf-shape --test bidi_conformance --test fingerprints > "$L/out/owner-$N-shape.log" 2>&1
echo "exit $?" >> "$L/out/owner-$N-shape.log"
cargo test --no-fail-fast -p tinker-pdf --test epub_conservation --test epub_fallback > "$L/out/owner-$N-cases-default.log" 2>&1
echo "exit $?" >> "$L/out/owner-$N-cases-default.log"
cargo test --no-fail-fast -p tinker-pdf --features bundled-fonts --test epub_conservation --test epub_fallback > "$L/out/owner-$N-cases-bundled.log" 2>&1
echo "exit $?" >> "$L/out/owner-$N-cases-bundled.log"
echo "owner $N done"
