"""Lane F: the f6_ems family (fam/f6_ems.rs) as a kit probe and a suite module.

Writes, in the lane F worktree:
  tools/probes/rtl/probes/pdf/zz_f6_ems.rs   zz_f6_transform.rs's prefix (its
      lines before `#[test]`), a probe over books(), then the family body;
  crates/tinker-pdf/tests/rtl_probes/zz_f6_ems.rs   the suite module.
"""
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'

body = open(L + '/fam/f6_ems.rs', encoding='utf-8').read()
src = open(W + '/tools/probes/rtl/probes/pdf/zz_f6_transform.rs', encoding='utf-8').read().split('\n')
cut = src.index('#[test]')
prefix = src[:cut]
assert prefix[0].startswith('//! Lane F probe (round 6 of ROADMAP CD-19): family f6_transform.'), prefix[0]
prefix[0] = '//! Lane F probe (round 6 of ROADMAP CD-19): family f6_ems. The rr3m prefix is'
assert prefix[1] == "//! zz_rr3m_h2_pages.rs's, byte for byte; the cases and styles below are new.", prefix[1]
prefix[1] = "//! zz_rr3m_h2_pages.rs's, byte for byte; the books below are new."
probe = r'''#[test]
fn probe() {
    let filter = std::env::var("RV_FILTER").unwrap_or_default();
    let mut n = 0usize;
    for (style, name, lang, body) in books() {
        if !filter.is_empty() && !format!("{style}|{name}").contains(&filter) {
            continue;
        }
        n += 1;
        let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| run_book(&style, &name, lang, &body)));
        if r.is_err() {
            println!("ROW\t{style}\t{name}\tm=0\ttext=0\tsearch=0/1\tltr=-\tcons=0\tlogical=0\tPANIC");
            println!("PANIC\t{style}\t{name}");
        }
    }
    println!("books={n}");
}



'''
open(W + '/tools/probes/rtl/probes/pdf/zz_f6_ems.rs', 'w', encoding='utf-8').write('\n'.join(prefix) + '\n' + probe + body)

module = r'''//! `zz_f6_ems` (f6, round 6 lane F (sweep)): the books of
//! `tools/probes/rtl/probes/pdf/zz_f6_ems.rs`, which is the probe as it ran.

use super::common::{run_book, AR, HE};

fn probe() {
    let mut n = 0usize;
    for (style, name, lang, body) in books() {
        n += 1;
        let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            run_book(&style, &name, lang, &body)
        }));
        if r.is_err() {
            emit!("ROW\t{style}\t{name}\tm=0\ttext=0\tsearch=0/1\tltr=-\tcons=0\tlogical=0\tPANIC");
            emit!("PANIC\t{style}\t{name}");
        }
    }
    emit!("books={n}");
}

/// Every book of the family, as its probe built them, in order.
pub(crate) fn run() {
    probe();
}

'''
open(W + '/crates/tinker-pdf/tests/rtl_probes/zz_f6_ems.rs', 'w', encoding='utf-8').write(module + body)
print('written')
