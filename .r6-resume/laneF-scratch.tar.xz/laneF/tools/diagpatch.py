"""Lane F: put a diagnostic print (TINKER_DIAG_READBACK) into a snapshot's paint.rs.
usage: python3 -I diagpatch.py SNAPDIR"""
import sys

p = sys.argv[1] + '/crates/tinker-pdf/src/epub/paint.rs'
s = open(p).read()
old = """        match reads_right(&BTreeMap::new(), over_by_rules) {"""
new = """        if std::env::var_os("TINKER_DIAG_READBACK").is_some() {
            let r = self.read_back(line, matrices, frame, &BTreeMap::new()).map(|(t, _)| t);
            eprintln!("DIAG written={:?}\\nDIAG rules  ={:?}", written.words, r);
        }
        match reads_right(&BTreeMap::new(), over_by_rules) {"""
assert s.count(old) == 1
s = s.replace(old, new)
old2 = """        if rules_letters {
            return Search::Nothing;
        }"""
new2 = """        if std::env::var_os("TINKER_DIAG_READBACK").is_some() {
            eprintln!("DIAG tried={} rules_letters={} letters_only={}", tried.get(), rules_letters, letters_only.borrow().is_some());
        }
        if rules_letters {
            return Search::Nothing;
        }"""
assert s.count(old2) == 1
s = s.replace(old2, new2)
open(p, 'w').write(s)
print('patched')
