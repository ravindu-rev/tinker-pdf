"""Lane F: one family's books whose key matches REGEX, their verdicts
(c=cons l=logical w=text s=search, then VOV) at 9297d2d, 56dfd93, 935b077 and
each RUN given.

usage: python3 -I verd.py FAMILY BUILD REGEX [RUN...]   (RUN: a dump dir, e.g. out/kit-A4)
"""
import importlib.util
import os
import re
import sys

KIT = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/rtlkit.py'
spec = importlib.util.spec_from_file_location('rtlkit', KIT)
K = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(K)

fam, build = sys.argv[1], sys.argv[2]
# REGEX, or @FILE.json:FIELD for the keys leftset.py --json listed for this
# family and build under FIELD (at935, now, new, fixed)
if sys.argv[3].startswith('@'):
    import json
    path, field = sys.argv[3][1:].rsplit(':', 1)
    wanted = set(json.load(open(path))[f'{build}\t{fam}'][field])

    class _Keys:
        def search(self, k):
            return k in wanted
    rx = _Keys()
else:
    rx = re.compile(sys.argv[3])
runs = [(t, K.resolve(t)) for t in ('9297d2d', '56dfd93', '935b077')]
runs += [(os.path.basename(r.rstrip('/')), r) for r in sys.argv[4:]]
L = {}
for name, root in runs:
    p = K.family_file(root, build, fam)
    L[name] = K.load(p) if p else None


def s(o, k):
    if o is None:
        return '----'
    v = o.rows.get(k)
    if v is None:
        return 'none'
    out = ''.join(ch if v.get(m) else '-' for ch, m in (('c', 'cons'), ('l', 'logical'), ('w', 'text'), ('s', 'search')))
    vv = o.vov.get(k)
    return out + (f'/{vv[0]}' if vv else '')


base = L['935b077'] or next(o for o in L.values() if o)
print('  '.join(n for n, _ in runs))
for k in base.rows:
    if rx.search(k):
        print('  '.join(s(L[n], k).ljust(7) for n, _ in runs), '|', k[:200].replace('\t', ' | '))
