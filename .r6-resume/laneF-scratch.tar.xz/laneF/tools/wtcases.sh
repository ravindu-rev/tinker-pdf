#!/usr/bin/env bash
# Lane F: the worktree's case tests (epub_conservation, epub_fallback,
# text_logical_order, and the lib's epub::tests) in one build, debug.
# usage: wtcases.sh BUILD TAG   -> out/wt-TAG-BUILD.log (ends in "exit N")
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
B=$1; TAG=$2
FEAT=""
[ "$B" = bundled ] && FEAT="--features bundled-fonts"
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$W/target
cd "$W" || exit 2
LOG=$L/out/wt-$TAG-$B.log
# shellcheck disable=SC2086
cargo test --no-fail-fast -p tinker-pdf $FEAT --test epub_conservation --test epub_fallback --test text_logical_order -- --nocapture > "$LOG" 2>&1
a=$?
# shellcheck disable=SC2086
cargo test --no-fail-fast -p tinker-pdf $FEAT --lib epub::tests -- --nocapture >> "$LOG" 2>&1
b=$?
echo "exit $a $b" >> "$LOG"
grep -E '^test result|FAILED|panicked' "$LOG" | head -30
