#!/usr/bin/env bash
# Lane F: after the A7 default suite, the A7 bundled suite (resumable), then
# A7d (the V5 option on A7) in both builds.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^rsuite A7 default done' "$L/out/rs-A7-default/progress.txt" 2>/dev/null; do sleep 20; done
THREADS=3 JOBS=2 bash "$L/tools/rsuite.sh" snap/A7 bundled A7
echo "a7b done"
