#!/usr/bin/env bash
# Lane F: the rtl_probes suite, resumable. Each family runs in its own process
# (the test binary with --exact), THREADS at a time, and writes its own log;
# a family whose log holds its RAN line and "1 passed" (or "1 failed": a
# finished run that found a book worse) is done and is not run again, so a
# restart re-runs only the families that had not finished.
# usage: rsuite.sh TREE BUILD TAG [FAMILY_REGEX]
#   TREE: tip | snap/<name>; BUILD: default | bundled
#   out/rs-TAG-BUILD/<family>.log, out/rs-TAG-BUILD/summary.txt,
#   kit dump in out/kit-TAG/ (TINKER_RTL_KIT_OUT); in the default build with no
#   regex, rtl_lines too (out/rs-TAG-default/rtl_lines.log).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
B=$2; TAG=$3; RX=${4:-.}
FEAT=""
[ "$B" = bundled ] && FEAT="--features bundled-fonts"
D=$L/out/rs-$TAG-$B
mkdir -p "$D" "$L/out/kit-$TAG"
cd "$W" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
# shellcheck disable=SC2086
cargo test -p tinker-pdf $FEAT --test rtl_probes --no-run > "$D/build.log" 2>&1 || { echo "build failed: $D/build.log"; exit 3; }
BIN=$(grep -o '([^)]*rtl_probes-[0-9a-f]*)' "$D/build.log" | tail -1 | tr -d '()')
case $BIN in /*) ;; *) BIN=$W/$BIN ;; esac
[ -x "$BIN" ] || { echo "no binary in $D/build.log"; exit 3; }
echo "binary $BIN" > "$D/binary.txt"
sha256sum "$W/crates/tinker-pdf/src/epub/paint.rs" "$W/crates/tinker-pdf-shape/src/bidi.rs" >> "$D/binary.txt"
"$BIN" --list --ignored 2>/dev/null | sed -n 's/: test$//p' | grep -E "$RX" > "$D/families.txt"
done_fam() {
  local f=$1 g=$D/$1.log
  [ -f "$g" ] && grep -q "RAN rtl_probes $f \[$B\]" "$g" && grep -qE '^test result: (ok|FAILED)\. [01] passed; [01] failed' "$g"
}
todo=()
while read -r f; do done_fam "$f" || todo+=("$f"); done < "$D/families.txt"
echo "$(date +%T) $TAG $B: $(wc -l < "$D/families.txt") families, ${#todo[@]} to run" >> "$D/progress.txt"
export TINKER_RTL_KIT_OUT=$L/out/kit-$TAG CARGO_MANIFEST_DIR=$W/crates/tinker-pdf BIN
cd "$W/crates/tinker-pdf" || exit 2
run_one() {
  local f=$1 s e
  s=$(date +%s)
  "$BIN" --ignored --exact --nocapture --test-threads=1 "$f" > "$D/$f.log.part" 2>&1
  echo "exit $? seconds $(( $(date +%s) - s ))" >> "$D/$f.log.part"
  mv "$D/$f.log.part" "$D/$f.log"
  echo "$(date +%T) $f $(grep -o 'exit [0-9]* seconds [0-9]*' "$D/$f.log")" >> "$D/progress.txt"
}
export -f run_one
export D B
if [ ${#todo[@]} -gt 0 ]; then
  printf '%s\n' "${todo[@]}" | xargs -P "${THREADS:-2}" -I{} bash -c 'run_one "$@"' _ {}
fi
# summary
: > "$D/summary.txt"
n=0; ok=0
while read -r f; do
  n=$((n + 1))
  if done_fam "$f"; then
    grep -o "RAN rtl_probes $f \[$B\].*" "$D/$f.log" >> "$D/summary.txt"
    grep -qE '^test result: ok\. 1 passed' "$D/$f.log" && ok=$((ok + 1))
  else
    echo "MISSING $f" >> "$D/summary.txt"
  fi
done < "$D/families.txt"
echo "$(date +%T) $TAG $B: $n families, $ok passed, $(grep -c '^RAN' "$D/summary.txt") RAN" >> "$D/progress.txt"
if [ "$B" = default ] && [ "$RX" = . ]; then
  cd "$W" || exit 2
  if ! grep -q '^exit 0' "$D/rtl_lines.log" 2>/dev/null; then
    cargo test -p tinker-pdf-shape --test rtl_lines -- --ignored --nocapture > "$D/rtl_lines.log" 2>&1
    echo "exit $?" >> "$D/rtl_lines.log"
  fi
  echo "$(date +%T) rtl_lines: $(grep -c '^RAN rtl_lines' "$D/rtl_lines.log") RAN, $(tail -1 "$D/rtl_lines.log")" >> "$D/progress.txt"
fi
echo "rsuite $TAG $B done: $n families, $ok passed" >> "$D/progress.txt"
tail -3 "$D/progress.txt"
