"""Lane F: variants/paint-A8-<name>.rs, A8 (variants/paint-A8.rs) with one
catalogue-style injection applied, for quick looks in snap/Z.
usage: python3 -I mkinj8.py NAME..."""
import os
import sys

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
BASE = open(os.path.join(HERE, 'paint-A8.rs')).read()
INJ = {
    # The Cut arm under a transform not searched in the runs' space.
    'cut-kept-under-a-transform': ("                Search::Cut if transformed => {",
                                   "                Search::Cut if false && transformed => {"),
    # What the runs' space search finds taken without reading it on the page.
    'whole-unchecked': ("            .is_some_and(|(read, _)| written.read_as(&read) == Read::Words)",
                        "            .is_some_and(|(read, _)| true || written.read_as(&read) == Read::Words)"),
    'cut-searched': ("            Some((Read::Cut, _)) => return Search::Cut,\n", ""),
    'read-as-typed': [
        ("                .flat_map(|run| run.text.chars().filter_map(|ch| self.read_as(run, ch)))",
         "                .flat_map(|run| run.text.chars())"),
        ("                            text: segment.read_as(ch, code).to_string(),",
         "                            text: ch.to_string(),"),
    ],
    'closer-unchecked': ("        written.pairs_in(&read) > written.pairs_in(&rules)", "        true"),
}
for name in sys.argv[1:]:
    s = BASE
    edits = INJ[name]
    if isinstance(edits, tuple):
        edits = [edits]
    for old, new in edits:
        assert s.count(old) == 1, (name, old[:60])
        s = s.replace(old, new)
    open(os.path.join(HERE, f'paint-A8-{name}.rs'), 'w').write(s)
    print('written', name)
