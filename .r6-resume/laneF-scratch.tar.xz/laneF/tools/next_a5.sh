#!/usr/bin/env bash
# Lane F: once A4's default suite has finished, stop its bundled phase, then
# run the full suites at A5 (the verified fallback), both builds.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
"$L/tools/stopafter.sh" A4
sleep 3
"$L/tools/both.sh" A5f A5 > "$L/out/both-A5.log" 2>&1
echo "next_a5 done"
