"""Lane F: variants/paint-A7c-<name>.rs, A7c with one catalogue-style injection
applied, for quick looks in snap/Z.
usage: python3 -I mkinj7.py NAME   (NAME: lines-cut | cut-searched | joins-are-cuts | letters-are-enough)"""
import os
import sys

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A7c.rs')).read()
INJ = {
    'lines-cut': ("            let gap = (run.x - end) * along(run).max(line.last().map_or(1.0, |last| along(last)));",
                  "            let gap = (run.x - end) * along(run).max(line.last().map_or(1.0, |last| along(last))).min(1.0).max(1.0);"),
    'cut-searched': ("            None | Some((Read::Words | Read::Cut, _)) => return Search::Rules,",
                     "            None | Some((Read::Words, _)) => return Search::Rules,"),
    'joins-are-cuts': ("            .all(|end| read_ends.binary_search(end).is_ok())",
                       "            .all(|end| true || read_ends.binary_search(end).is_ok())"),
    'letters-are-enough': ("        if read.split_whitespace().eq(self.words.split_whitespace()) {\n            return Read::Words;",
                           "        if true || read.split_whitespace().eq(self.words.split_whitespace()) {\n            return Read::Words;"),
}
INJ['read-as-typed'] = [
    ("                .flat_map(|run| run.text.chars().filter_map(|ch| self.read_as(run, ch)))",
     "                .flat_map(|run| run.text.chars())"),
    ("                            text: segment.read_as(ch, code).to_string(),",
     "                            text: ch.to_string(),"),
]
INJ['closer-unchecked'] = ("        written.pairs_in(&read) > written.pairs_in(&rules)", "        true")
edits = INJ[sys.argv[1]]
if isinstance(edits, tuple):
    edits = [edits]
for old, new in edits:
    assert s.count(old) == 1, (sys.argv[1], old[:60])
    s = s.replace(old, new)
open(os.path.join(HERE, f'paint-A7c-{sys.argv[1]}.rs'), 'w').write(s)
print('written', sys.argv[1])
