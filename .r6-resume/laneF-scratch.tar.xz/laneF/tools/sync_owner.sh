#!/usr/bin/env bash
# Lane F: bring the owner snapshots to the final paint.rs (A5g; A4d keeps
# A5 + dedupe) and the worktree's current case tests.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
for s in H1 H6 A4d; do
  cp "$W/crates/tinker-pdf/tests/epub_fallback.rs" "$W/crates/tinker-pdf/tests/epub_conservation.rs" "$L/snap/$s/crates/tinker-pdf/tests/"
done
cp "$L/variants/paint-A5g.rs" "$L/snap/H1/crates/tinker-pdf/src/epub/paint.rs"
cp "$L/variants/paint-A5g.rs" "$L/snap/H6/crates/tinker-pdf/src/epub/paint.rs"
cd "$L" || exit 2
sha256sum snap/H1/crates/tinker-pdf/src/epub/paint.rs snap/H6/crates/tinker-pdf/src/epub/paint.rs snap/A4d/crates/tinker-pdf/src/epub/paint.rs snap/H1/crates/tinker-pdf-shape/src/bidi.rs snap/H6/crates/tinker-pdf-shape/src/bidi.rs snap/A4d/crates/tinker-pdf-shape/src/bidi.rs
