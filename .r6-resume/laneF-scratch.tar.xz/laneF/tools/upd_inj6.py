"""Lane F: the catalogue for A6: the two rules A6 takes out lose their
injections, and page/closer-unchecked's old text is A6's."""
import json

p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/injections.json'
raw = open(p, encoding='utf-8').read()
d = json.loads(raw)
key = next(iter(d))
items = d[key]
before = len(items)
items = [e for e in items if e['name'] not in ('page/closer-overprint-unchecked', 'page/mark-in-the-runs-ems')]
for e in items:
    if e['name'] == 'page/closer-unchecked':
        assert len(e['edits']) == 1
        e['edits'][0]['old'] = '        written.pairs_in(&read) > written.pairs_in(&rules)'
d[key] = items
indent = 1
out = json.dumps(d, ensure_ascii=False, indent=indent)
if raw.endswith('\n'):
    out += '\n'
open(p, 'w', encoding='utf-8').write(out)
print(key, before, '->', len(items))
