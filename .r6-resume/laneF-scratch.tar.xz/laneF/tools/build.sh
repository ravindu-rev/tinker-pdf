#!/usr/bin/env bash
# Lane F: build the worktree's tinker-pdf lib (and optionally features) and show errors.
set -u
cd /home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4 || exit 2
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cargo build -p tinker-pdf "$@" 2>&1 | grep -E "^(error|warning)" -A 9 | head -80
echo "build done ${PIPESTATUS[0]}"
