"""Lane F (A9L): the doc edits of each commit of the fold, applied to a
checkout's docs/ROADMAP.md and docs/features/epub.md.

usage: python3 -I docs9.py ROOT STEP    (STEP: fix | v2v3 | v4v5)
Numbers come from laneF/numbers9.json.
"""
import json
import sys

ROOT, STEP = sys.argv[1], sys.argv[2]
N = json.load(open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/numbers9.json'))


def edit(name, pairs):
    p = f'{ROOT}/{name}'
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        assert s.count(old) == 1, (name, s.count(old), old[:100])
        s = s.replace(old, new.format(**N))
    open(p, 'w', encoding='utf-8').write(s)


RM = 'docs/ROADMAP.md'
EP = 'docs/features/epub.md'

if STEP == 'fix':
    edit(RM, [
        # The fix, after the read-back's paragraph.
        ("where the font met ruling 14's sentence-end rule. On the probes of ROADMAP K-11",
         "where the font met ruling 14's sentence-end rule. **And each line is read back on the page it is drawn on** since round 6 "
         "(`paint::OnPage::matrix`, `paint::along_the_line`, `paint::Segment::read_as`, `paint::Words`, `paint::Fonts::reads_closer`, `paint::Fonts::reads_whole`, `paint::drawn_over`; "
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`, `a_line_is_read_back_as_the_pages_fonts_give_its_characters_back`, "
         "`a_reading_that_cuts_or_joins_a_word_is_taken_as_935b077_took_it`, `a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`, "
         "`a_drawing_that_sets_more_glyphs_over_others_than_the_rules_is_not_taken`, `two_cells_are_read_back_as_a_reader_parts_them_on_the_page`, "
         "`a_line_a_reader_cuts_on_the_page_under_a_transform_is_searched_in_its_runs_space_too`, `epub::tests`' "
         "`a_line_whose_rules_drawing_reads_its_letters_in_order_is_read_back_once`): "
         "the read-back fed `TextDevice` each glyph in its run's own space, but the page draws the run under the `cm` its CSS `transform` writes, and a reader's "
         "thresholds are in the glyphs' size on the page, against which a scale of one axis widens or narrows every gap — under `transform: scaleX(2)` at "
         "`word-spacing: 0.6em` a styled `?!` glued to a Hebrew or Arabic word was read with the word in the model, drawn turned for that reading, and read alone "
         "on the page, `שלום!? עולם.`, where 9297d2d and 56dfd93 read `שלום?! עולם.` (V1 of its review; of the books of its transforms and of the class's sweep that conserved at 56dfd93 and not at 935b077, {v1_all_d} ({v1_all_b}) conserve again); "
         "and two rules, whether a reader parts two text objects of a run (`paint::parted`) and which runs it reads as one line (`paint::page_lines`), asked in "
         "the run's ems, so that `25٪ <b>W</b>` in Arabic under `scaleX(1.4)`, which conserved at 56dfd93, read its number backwards since round 5. Each line "
         "is read back under the matrix the page draws each of its runs under, both rules ask in a reader's ems on the page (an em of a run's spacing is `√2` of "
         "them under `scaleX(2)`, one under a turn, a shift or `scale(2)`), and each glyph is read back as the page's font gives it back, so that a standard "
         "face's NO-BREAK SPACE, drawn at `WinAnsiEncoding`'s `0xA0`, is the space a reader reads by its glyph name and not the `CS` that made `1 234` one "
         "number to UAX #9 in the model. A reading is held to the line's letters in order, white space aside, as at 935b077 (`paint::Words`, "
         "`paint::Read::Letters`): a drawing tried that reads them so is taken, though a reader cut a word of it or ran two together, and a line whose rules' "
         "drawing reads them so is searched no further on the page; holding a drawing to the line's words, and searching on past such a reading of the rules', "
         "read more books whole at a cost in time that is the owner's to price (below). Under a transform, "
         "a line nothing tried reads right on the page is searched again in its runs' own space, and what that finds is drawn only where it holds more of the "
         "text's pairs of letters in order on the page than the rules' drawing; a line whose rules' drawing reads there with its letters in order and not its "
         "words is searched in its runs' own space too, as 935b077 searched every line under a transform, and what that finds is drawn only where it reads the "
         "words right on the page (kept as the rules drew it, an Arabic paragraph of numbers letter-spaced, word-spaced and justified under `scaleX(2)`, "
         "`scaleY(0.5)` or a matrix of its own, which read whole at 935b077, lost its text); and no drawing that sets more glyphs over others than the rules' is taken. "
         "`paint::leading_mark_at`, which places a mark of no advance against half an em, keeps the run's ems: asked in the page's, it moved no book of the "
         "sweeps. On round 6's hunt and its sweep of the class (the kit's `v6`, `v6t`, `f6` and `v6pdf` families: {r6_books} books a build), and on every "
         "family before them ({all_books} books a build in all), it makes {gain_d} ({gain_b}) books read better than at 935b077 on some metric, {cons_gain_d} "
         "({cons_gain_b}) of them conserving, with none worse on any metric and no glyph drawn over another more often, in either build. On the probes of ROADMAP K-11"),
        # Left (6), after Left (5).
        ("`a_styled_neutral_glued_to_a_word_under_spacing_reads_where_it_was_typed`, the span and the `;`). **Read so at every tree**",
         "`a_styled_neutral_glued_to_a_word_under_spacing_reads_where_it_was_typed`, the span and the `;`); (6) `25٪ <b>W</b> ١٢٣ … 2010،` in an Arabic paragraph, "
         "with `dir` or without, turned by half a turn (`transform: rotate(180deg)`) at `word-spacing: 1em`: {left6_d} ({left6_b}) books of round 6's hunt and "
         "sweep that conserved at 56dfd93 only, where the overflow font's moved glyphs drew the bold word apart around its sign; at `0 Tw` no drawing tried reads "
         "the line right on the page, since `TextDevice` asks whether a glyph continues a line, or a text object's end parts it, along the page's `x`, which a "
         "half turn runs the other way — a reader that measures along a turned baseline is a change to every page with turned text (pinned: `epub_fallback.rs`'s "
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`). **Read so at every tree**"),
        ("a reader that resumes a line across a stretch past an em for (3), and K-11's reader for (4) — or the owner accepts them",
         "a reader that resumes a line across a stretch past an em for (3), K-11's reader for (4), and a reader that measures a gap along a turned baseline for (6) — or the owner accepts them"),
    ])
    edit(EP, [
        ("`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n**Measured, and what is left.**",
         "`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n"
         "**Each line is read back on the page it is drawn on** (round 6;\n"
         "`paint::OnPage::matrix`, `paint::along_the_line`, `paint::Segment::read_as`,\n"
         "`paint::Words`). The read-back fed `TextDevice` each glyph in its run's\n"
         "own space, but the page draws the run under the `cm` its CSS `transform`\n"
         "writes (`paint::OnPage::open`), and a reader's thresholds are in the\n"
         "glyphs' size on the page: a transform that scales one axis more than the\n"
         "other widens or narrows every gap against it. Under `transform: scaleX(2)`\n"
         "at `word-spacing: 0.6em` a styled `?!` glued to a Hebrew or Arabic word\n"
         "was read with the word in the model, drawn turned for that reading, and\n"
         "read alone on the page, turned: `שלום!? עולם.`, where 9297d2d and 56dfd93\n"
         "read `שלום?! עולם.` (of the books of round 6's hunt and of the class's\n"
         "sweep that conserved at 56dfd93 and not at 935b077, {v1_all_d} conserve again\n"
         "in a default build and {v1_all_b} with `bundled-fonts`). Two of the writer's\n"
         "rules asked in the run's ems too — whether a reader parts two text objects\n"
         "of a run (`paint::parted`) and which runs it reads as one line\n"
         "(`paint::page_lines`) — so that `25٪ <b>W</b>` in Arabic under\n"
         "`scaleX(1.4)`, which conserved at 56dfd93, read its number backwards since\n"
         "round 5. Each line is read back now under the matrix the page draws each\n"
         "of its runs under, and both rules ask in a reader's ems on the page: an em\n"
         "of a run's own spacing is `along_the_line` of its matrix, the scale along\n"
         "the baseline over the square root of the determinant's magnitude, which is\n"
         "how `TextDevice` sizes a glyph — `√2` under `scaleX(2)`, one under a turn,\n"
         "a shift or `scale(2)`. And each glyph is read back as the page's font\n"
         "gives it back, not as typed: a standard face draws a NO-BREAK SPACE at\n"
         "`WinAnsiEncoding`'s `0xA0`, which a reader reads by its glyph name as a\n"
         "space, and read as typed it was a `CS` that made `1 234` one number to\n"
         "UAX #9 in the model. A reading is held to the line's letters in order,\n"
         "white space aside, as at 935b077 (`paint::Read::Letters`): a drawing\n"
         "tried that reads them so is taken, though a reader cut a word of it or ran\n"
         "two together, and a line whose rules' drawing reads them so is searched no\n"
         "further on the page. Holding a drawing to the line's words, and searching\n"
         "on past such a reading of the rules', read more books whole, at a cost in\n"
         "time that is the owner's to price (below; ROADMAP CD-19). Under a\n"
         "transform a line the rules' drawing reads on the page with its letters in\n"
         "order and not its words is searched in its runs' own space too, as\n"
         "935b077 searched every line under a transform, and what that finds is\n"
         "drawn only where it reads the words right on the page\n"
         "(`paint::Fonts::reads_whole`): kept as the rules drew it, an Arabic\n"
         "paragraph of numbers letter-spaced, word-spaced and justified under\n"
         "`scaleX(2)`, which read whole at 935b077, lost its text. Where nothing\n"
         "tried reads a line right on the page under a transform — glyphs the\n"
         "transform sets over others, whose letters no drawing reads in order — the\n"
         "line is searched again in its runs' own space, and what that finds is\n"
         "drawn only where, read back on the page, it holds more of the text's pairs\n"
         "of letters in order than the rules' drawing does there\n"
         "(`paint::Fonts::reads_closer`); taken as found, it turned a `?!` with no\n"
         "`dir` under `scaleX(2)` for a reading only that space has. And no drawing\n"
         "that sets more glyphs over others than the rules' is taken\n"
         "(`paint::drawn_over`). `paint::leading_mark_at`, which places a mark of no\n"
         "advance against half an em, keeps the run's ems: asked in the page's, it\n"
         "moved no book of the sweeps. On round 6's hunt and its sweep of the class\n"
         "({r6_books} books a build) and every family before them ({all_books} in\n"
         "all), {gain_d} books read better than at 935b077 in a default build and\n"
         "{gain_b} with `bundled-fonts`, {cons_gain_d} ({cons_gain_b}) of them\n"
         "conserving, and none reads worse on any metric or draws a glyph over\n"
         "another more often\n"
         "(`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`,\n"
         "`a_line_is_read_back_as_the_pages_fonts_give_its_characters_back`,\n"
         "`a_reading_that_cuts_or_joins_a_word_is_taken_as_935b077_took_it`,\n"
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`,\n"
         "`a_drawing_that_sets_more_glyphs_over_others_than_the_rules_is_not_taken`,\n"
         "`two_cells_are_read_back_as_a_reader_parts_them_on_the_page`,\n"
         "`a_line_a_reader_cuts_on_the_page_under_a_transform_is_searched_in_its_runs_space_too`,\n"
         "and in `epub::tests`,\n"
         "`a_line_whose_rules_drawing_reads_its_letters_in_order_is_read_back_once`).\n"
         "A half turn\n"
         "at `word-spacing: 1em` is left: `25٪ <b>W</b>` in an Arabic paragraph\n"
         "turned by `rotate(180deg)` conserved at 56dfd93 only, where the moved\n"
         "glyphs drew the bold word apart around its sign, and no drawing reads it\n"
         "right on the page now, since `TextDevice` asks whether a glyph continues a\n"
         "line along the page's `x`, which a half turn runs the other way\n"
         "({left6_d} ({left6_b}) books; ROADMAP CD-19, Left (6)).\n"
         "**Measured, and what is left.**"),
    ])
elif STEP == 'v2v3':
    edit(RM, [
        ("does not take a line that opens with a number, so the stop is read first, whatever the writer draws",
         "does not take a line that opens with a number, so the stop is read first, whatever the writer draws; nor one whose left end is a closing bracket, "
         "which round 6's hunt found (V2): `W <b>W</b> W <i>W</i>, (W).` with no `dir`, letter-spaced (`0.15em` with `word-spacing: 0.3em`, `0.3em` with "
         "`-0.2em`) or at `word-spacing: 0.6em` under a transform or a tight line height, and `<p>שלום.<br/>בראשית (אלהים).</p>` minimised, "
         "{v2_d} ({v2_b}) books of the hunt and its sweep that conserved at 9297d2d and 56dfd93 and were lost when the overflow font was written at `0 Tw` "
         "(e7ca679), the bundled ones Arabic, which drew a glyph over another at both trees"),
        ("— a change to that tie-break, the owner's amendment of 10 October 2026, is the owner's to make (pinned: `epub_conservation.rs`'s `a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`)",
         "— a change to that tie-break, the owner's amendment of 10 October 2026, is the owner's to make (pinned: `epub_conservation.rs`'s `a_left_to_right_hebrew_paragraph_ending_a_number_and_a_stop`, V2's three with it)"),
        ("`25، <b>W</b>` in a table cell with no `dir` at `word-spacing: 16px; letter-spacing: 1px` (2 (3)),",
         "`25، <b>W</b>` in a table cell with no `dir` at `word-spacing: 16px; letter-spacing: 1px` (2 (3)), two right-to-left cells with no `dir` touching "
         "at `word-spacing: 1em`, `<td><b>שלום</b> <i>עולם</i>،</td><td>מלחמה <i>(</i>ספר<i>)</i>.</td>`, which K-11's reader joins into one line whose left "
         "end is the second cell's `)`, so the stop is read first ({v3_d} ({v3_b}) of round 6's hunt that conserved at 9297d2d, V3; 56dfd93 wrote them byte for "
         "byte as 9297d2d did),"),
        ("`a_dirless_line_with_a_right_to_left_gloss`, the glosses and cells,",
         "`a_dirless_line_with_a_right_to_left_gloss`, the glosses and cells, V3's with them,"),
        # Left (7): the squeezed inline blocks, with bundled-fonts.
        ("`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`). **Read so at every tree**",
         "`a_line_drawn_under_a_transform_is_read_back_on_the_page_it_is_drawn_on`); (7) with `bundled-fonts`, a Hebrew paragraph with no `dir` of inline "
         "blocks squeezed by `scaleX(0.5)`, `W <span style=\"display: inline-block; transform: scaleX(0.5)\">W <b>?!</b> W</span> W 25٪ W.`, at "
         "`word-spacing: 0.6em`, with no transform on the paragraph or under one of fourteen: {left7_b} books of round 6's sweep, a word of which search "
         "found at 9297d2d only, not at 56dfd93 or 935b077 (the squeezed block draws glyphs over its neighbours at every tree; pinned: `epub_fallback.rs`'s "
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`). **Read so at every tree**"),
        ("and a reader that measures a gap along a turned baseline for (6) — or the owner accepts them",
         "a reader that measures a gap along a turned baseline for (6), and for (7) a cause not yet found — or the owner accepts them"),
    ])
    edit(EP, [
        ("Lines K-11's reader reads from the\nright whatever the writer draws — a Latin gloss before a bracketed\nright-to-left word, table cells,",
         "Lines K-11's reader reads from the\nright whatever the writer draws — a Latin gloss before a bracketed\nright-to-left word, table cells (two right-to-left cells with no `dir`\ntouching among them, {v3_d} ({v3_b}) of round 6's hunt that conserved at\n9297d2d),"),
        ("whose stop, alone at 9297d2d, now abuts the right-to-left\nrun and is read first, since the comma tie-break asks for a right-to-left\nletter at the line's left end;",
         "whose stop, alone at 9297d2d, now abuts the right-to-left\nrun and is read first, since the comma tie-break asks for a right-to-left\nletter at the line's left end, and so for a closing bracket there, `W <b>W</b>\nW <i>W</i>, (W).` with no `dir` letter-spaced or under a transform ({v2_d}\n({v2_b}) more of round 6's hunt and its sweep);"),
    ])
elif STEP == 'v4v5':
    edit(RM, [
        ("`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`). **Read so at every tree**",
         "`a_line_nothing_reads_right_on_the_page_is_searched_in_its_runs_space`); (8) a line whose right drawing lies past the read-back's budget: it tries "
         "each run's drawings, then two runs' at a time, and keeps the rules' drawing after 128 readings, and many of a run's drawings write what the rules' "
         "or another of its own does, so on a line of a few spaced runs the pair that reads it right comes after the budget: a right-to-left paragraph after a "
         "generated `§ ` at `word-spacing: 0.6em` or `1em` does not read whole, and a `<bdi>` of Latin with Hebrew in it does not conserve, {v5_d} ({v5_b}) "
         "books of round 6's hunt that no tree read so (V5 of its review); reading each drawing once reaches them and costs {v5_cost}, the owner's to price "
         "(pinned: `epub_fallback.rs`'s `a_line_whose_right_drawing_lies_past_the_budget_is_drawn_by_the_rules`). "
         "**What reading back costs**, the owner's to price (V4 of round 6's review): `Document::open` in debug of a line no drawing reads right, which spends "
         "the whole budget, takes {t_h1_tip} ms where 56dfd93, with no read-back, takes {t_h1_56} and 935b077 {t_h1_935} (`h1-nowrap` of the kit's "
         "`zz_v6_time`, {t_h1_chars} characters on one line); plain right-to-left prose justified {t_prose_tip} against {t_prose_56} and {t_prose_935}; prose "
         "with no `dir` {t_dirless_tip} against {t_dirless_56} and {t_dirless_935}; a letter-spaced line under `scaleX(2)`, read on the page and again in its "
         "runs' space, {t_lss_tip} against {t_lss_935}. It is linear in the line. Three searches round 6 measured and does not make read more books right "
         "at a cost in time, each against this tip, none reading a book worse or drawing a glyph over another more often: holding each drawing tried to the "
         "line's words, {w_gain_d} ({w_gain_b}) books, and a justified paragraph of styled stops and brackets, letter-spaced by `0.1em` (`rtl-justified`, "
         "{t_rj_chars} characters), opens in {t_rj_w} ms where the tip takes {t_rj_tip} and 935b077 {t_rj_935}; with it, searching on where the rules' "
         "drawing runs two words together, {j_gain_d} ({j_gain_b}), the Persian digits of (4) among them, at {t_rj_j} ms there and {t_rjs_j} under "
         "`scaleX(2)` where the tip takes {t_rjs_tip}; and searching on where it cuts a word at the spacing as well, {c_gain_d} ({c_gain_b}), at "
         "{t_ls_c} ms for a line of {t_ls_chars} characters letter-spaced by `0.6em` where the tip takes {t_ls_tip} and 935b077 {t_ls_935}. "
         "**Read so at every tree**"),
        ("and for (7) a cause not yet found — or the owner accepts them",
         "for (7) a cause not yet found, and the owner's word on the price of reading each drawing once for (8) — or the owner accepts them"),
    ])
    edit(EP, [
        ("**Measured, and what is left.**",
         "**What reading back costs** is the owner's to price: in debug, opening a\n"
         "book of one line no drawing reads right, which spends the whole budget,\n"
         "takes {t_h1_tip} ms where 56dfd93, with no read-back, takes {t_h1_56} and\n"
         "935b077 {t_h1_935} ({t_h1_chars} characters); plain right-to-left prose,\n"
         "justified, {t_prose_tip} against {t_prose_56} and {t_prose_935}. It is linear in\n"
         "the line. Holding each drawing tried to the line's words, and searching on\n"
         "past a reading of the rules' drawing that runs two words together or cuts\n"
         "one, read up to {c_gain_d} ({c_gain_b}) more books right and take a\n"
         "justified paragraph of styled stops up to {t_rj_j} ms to open where the tip\n"
         "takes {t_rj_tip} (ROADMAP CD-19). A line whose right drawing comes after\n"
         "the budget is drawn by the rules: {v5_d} ({v5_b}) books of round 6's hunt,\n"
         "none read right at any tree, which reading each drawing once reaches at a\n"
         "cost (ROADMAP CD-19).\n"
         "**Measured, and what is left.**"),
    ])
else:
    raise SystemExit('step?')
print(STEP, 'applied to', ROOT)
