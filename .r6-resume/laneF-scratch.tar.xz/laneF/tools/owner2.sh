#!/usr/bin/env bash
# Lane F: measure an owner's candidate in snap/NAME (a copy of the worktree with
# the candidate's file swapped in), resumably: both rtl_probes suites (each
# family once, rsuite.sh), rtl_lines, bidi_conformance and fingerprints, and the
# case tests in both builds. A step whose log ends in its exit line is not run
# again.
# usage: owner2.sh NAME   -> out/rs-NAME-{default,bundled}/, out/kit-NAME/,
#                            out/owner-NAME-{shape,cases-default,cases-bundled}.log
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
N=$1
export THREADS=${THREADS:-2} JOBS=${JOBS:-2}
bash "$L/tools/rsuite.sh" "snap/$N" default "$N"
bash "$L/tools/rsuite.sh" "snap/$N" bundled "$N"
cd "$L/snap/$N" || exit 2
export CARGO_BUILD_JOBS=$JOBS CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/$N-target
step() {
  local log=$1; shift
  if tail -1 "$log" 2>/dev/null | grep -q '^exit '; then return; fi
  "$@" > "$log" 2>&1
  echo "exit $?" >> "$log"
}
step "$L/out/owner-$N-shape.log" cargo test -p tinker-pdf-shape --test bidi_conformance --test fingerprints
step "$L/out/owner-$N-cases-default.log" cargo test --no-fail-fast -p tinker-pdf --test epub_conservation --test epub_fallback --test text_logical_order
step "$L/out/owner-$N-cases-bundled.log" cargo test --no-fail-fast -p tinker-pdf --features bundled-fonts --test epub_conservation --test epub_fallback --test text_logical_order
echo "owner $N done"
