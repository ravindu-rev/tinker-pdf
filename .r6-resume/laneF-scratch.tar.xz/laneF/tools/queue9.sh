#!/usr/bin/env bash
# Lane F: after timing9.sh ends, measure A9 optimised (owner3.sh: both suites,
# rtl_lines, shape, cases), alone in rel-target, then its tables (opt8.sh A9
# vsA8). Resumable: owner3.sh skips what finished.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q 'timing9 done' "$L/out/timing9.out" 2>/dev/null; do sleep 20; done
echo "queue9 start $(date +%T)"
THREADS=4 JOBS=4 bash "$L/tools/owner3.sh" A9
echo "owner3 A9 exit $? $(date +%T)"
bash "$L/tools/opt8.sh" A9 vsA8
echo "queue9 done $(date +%T)"
