#!/usr/bin/env bash
# Lane F: counted injections of lane F's rules (and the two moved ones) in
# snap/INJ, both builds -> out/inj/summary-{default,bundled}.txt
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=$L/snap/INJ
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/INJ-target
NAMES="control no-pairs lines-touching page/read-back-under-no-matrix page/rules-in-the-runs-ems page/along-inverted page/parted-in-the-runs-ems page/lines-cut-in-the-runs-ems page/read-as-typed page/letters-are-enough page/no-fallback-to-the-runs-space page/overprint-taken page/closer-unchecked page/closer-overprint-unchecked page/mark-in-the-runs-ems"
mkdir -p "$L/out/inj"
cd "$W" || exit 2
for b in default bundled; do
  # shellcheck disable=SC2086
  python3 -I tools/probes/rtl/scripts/inject.py run "$W" "$L/out/inj" --build "$b" \
    --suite 'cargo test --no-fail-fast -p tinker-pdf --test epub_conservation --test epub_fallback' $NAMES \
    > "$L/out/inj/run-$b.log" 2>&1
  echo "inject $b exit $?"
done
echo "inj done"
