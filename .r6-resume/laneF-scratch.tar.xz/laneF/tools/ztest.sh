#!/usr/bin/env bash
# Lane F: run one test file of snap/Z (default build) with the read-back diagnostics.
# usage: ztest.sh TESTFILE [BUILD] [FILTER]
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
cd "$L/snap/Z" || exit 2
FEAT=""
[ "${2:-default}" = bundled ] && FEAT="--features bundled-fonts"
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/Z-target
export TINKER_DIAG_READBACK=1
# shellcheck disable=SC2086
cargo test -p tinker-pdf $FEAT --test "$1" -- --nocapture --test-threads=1 ${3:-} 2>&1 | grep -v "^\s*Compiling" | tail -${LINES_OUT:-60}
