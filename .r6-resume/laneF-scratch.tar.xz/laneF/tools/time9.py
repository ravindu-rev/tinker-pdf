"""Lane F: zz_v6_time at five trees, best of the runs given for each:
56dfd93 (no read-back), 05cea0b's code (935b077's read-back), A9 (the rules'
letters reading ends the search, as at 935b077), the A8 tip (a joined
reading searched on) and the cut search (A8s).

usage: python3 -I time9.py OUT   (reads OUT/time8-{56,snap-F935,snap-A9,tip,snap-A8s}-*/)
"""
import glob
import os
import re
import sys

out = sys.argv[1]
PAT = re.compile(r'SCALE\t(\S+)\tn=(\d+)\tbody=(\d+)\tpages=(\d+)\tchars=(\d+)\topen_ms=([\d.]+)\ttext_ms=([\d.]+)')


def best(tree):
    d = {}
    runs = 0
    for run in sorted(glob.glob(os.path.join(out, f'time8-{tree}-*'))):
        p = os.path.join(run, 'default', 'raw', 'zz_v6_time.txt')
        if not os.path.isfile(p):
            continue
        runs += 1
        for line in open(p, encoding='utf-8'):
            m = PAT.search(line)
            if not m:
                continue
            k = (m.group(1), int(m.group(2)))
            o, t, c = float(m.group(6)), float(m.group(7)), int(m.group(5))
            if k in d:
                d[k] = (c, min(d[k][1], o), min(d[k][2], t))
            else:
                d[k] = (c, o, t)
    return d, runs


trees = [('56', '56dfd93'), ('snap-F935', '935b077'), ('snap-A9', 'A9'), ('tip', 'A8 (joined searched)'), ('snap-A8s', 'A8s (cut searched)')]
data = {}
for t, name in trees:
    data[t], n = best(t)
    print(f'{name}: {n} runs, {len(data[t])} points')
only = sys.argv[2] if len(sys.argv) > 2 else None
print('shape n chars | open_ms 56dfd93 / 935b077 / A9 / A8 / A8s | A9/56 A9/935 A8/A9 A8s/A9')
for k in sorted(data['snap-A9']):
    if only and k[1] != int(only):
        continue
    if not all(k in data[t] for t, _ in trees):
        continue
    ch = data['snap-A9'][k][0]
    o = [data[t][k][1] for t, _ in trees]
    r = lambda a, b: a / max(b, .01)
    print(f'{k[0]} {k[1]} {ch} | {o[0]:.1f} / {o[1]:.1f} / {o[2]:.1f} / {o[3]:.1f} / {o[4]:.1f} | {r(o[2], o[0]):.1f}x {r(o[2], o[1]):.2f}x {r(o[3], o[2]):.2f}x {r(o[4], o[2]):.1f}x')
