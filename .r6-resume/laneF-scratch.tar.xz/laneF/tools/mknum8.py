"""Lane F: the numbers the fold's docs and messages quote, from the final runs.

usage: python3 -I mknum8.py   -> laneF/numbers6.json (merged), and a report on stdout

Reads out/rs-A8t-{default,bundled}/ (RAN lines), out/table-A8t-{build}.json and
out/table-935-{build}.json (table.py --json of the tip run, and of the
baselines alone), through classes.py for the Left classes.
"""
import json
import os
import re
import subprocess
import sys

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
P = os.path.join(L, 'numbers6.json')
N = json.load(open(P)) if os.path.exists(P) else {}
R6 = re.compile(r'^zz_(v6|f6)_')


def fmt(n):
    return f'{n:,}'.replace(',', ' ') if n >= 10000 else str(n)


RAN = re.compile(r'RAN rtl_probes (\S+) \[(\w+)\] against \w+: (\d+) rows \(the baseline has (\d+)\), (\d+) books worse, (\d+) books better, (\d+) changed')
tot = {}
for build in ('default', 'bundled'):
    d = os.path.join(L, 'out', f'rs-A8t-{build}')
    rows = r6 = better = worse = fams = 0
    per = {}
    for f in open(os.path.join(d, 'families.txt')):
        f = f.strip()
        text = open(os.path.join(d, f + '.log'), encoding='utf-8', errors='replace').read()
        m = RAN.search(text)
        fams += 1
        r = int(m.group(3))
        rows += r
        if R6.match(m.group(1)):
            r6 += r
        worse += int(m.group(5))
        better += int(m.group(6))
        per[m.group(1)] = (int(m.group(6)), int(m.group(5)), int(m.group(7)))
    tot[build] = dict(rows=rows, r6=r6, better=better, worse=worse, fams=fams, per=per)
    print(build, {k: v for k, v in tot[build].items() if k != 'per'})
N['all_books'] = fmt(tot['default']['rows'])
N['r6_books'] = fmt(tot['default']['r6'])
N['gain_d'] = fmt(tot['default']['better'])
N['gain_b'] = fmt(tot['bundled']['better'])

# Books conserving now and not at 935b077 (+T), per build.
for build, key in (('default', 'cons_gain_d'), ('bundled', 'cons_gain_b')):
    t = json.load(open(os.path.join(L, 'out', f'table-A8t-{build}.json')))
    gain = sum(len(v.get('gain_t', [])) for k, v in t.items() if k.startswith(build + '/'))
    N[key] = fmt(gain)
    print(build, 'conserving gains', gain)

# The Left classes now.
cls = {}
for build in ('default', 'bundled'):
    out = subprocess.run([sys.executable, '-I', os.path.join(W, 'tools/probes/rtl/scripts/classes.py'),
                          os.path.join(L, 'out', f'table-A8t-{build}.json'), '--builds', build],
                         capture_output=True, text=True).stdout
    for line in out.splitlines():
        m = re.match(r'^(.+?)\tbooks (\d+),', line)
        if m:
            cls.setdefault(build, {})[m.group(1)] = int(m.group(2))
print(json.dumps(cls, indent=1))
for key, name in (('left6', 'Left (6) half turn'), ('v2', 'V2 closing bracket at the left end'),
                  ('v3', 'V3 touching right-to-left cells'), ('left7', 'Left (7) squeezed inline blocks')):
    N[key + '_d'] = str(cls.get('default', {}).get(name, 0))
    N[key + '_b'] = str(cls.get('bundled', {}).get(name, 0))
json.dump(N, open(P, 'w'), ensure_ascii=False, indent=1)
print('numbers6.json:', json.dumps(N, ensure_ascii=False))
