"""Lane F: zz_v6_time at three trees, best of the runs given for each.

usage: python3 -I time3.py OUT   (reads OUT/time6-56-*/, OUT/time6-snap-F935-*/, OUT/time6-tip-*/)
Per shape and size: open_ms at 56dfd93, 935b077 and the tip (best of runs),
the tip over each, and the tip's growth per doubling; text_ms the same way.
"""
import glob
import os
import re
import sys

out = sys.argv[1]
PAT = re.compile(r'SCALE\t(\S+)\tn=(\d+)\tbody=(\d+)\tpages=(\d+)\tchars=(\d+)\topen_ms=([\d.]+)\ttext_ms=([\d.]+)')


def best(tree):
    d = {}
    for run in sorted(glob.glob(os.path.join(out, f'time6-{tree}-*'))):
        p = os.path.join(run, 'default', 'raw', 'zz_v6_time.txt')
        if not os.path.isfile(p):
            continue
        for line in open(p, encoding='utf-8'):
            m = PAT.search(line)
            if not m:
                continue
            k = (m.group(1), int(m.group(2)))
            o, t, c = float(m.group(6)), float(m.group(7)), int(m.group(5))
            if k in d:
                d[k] = (c, min(d[k][1], o), min(d[k][2], t))
            else:
                d[k] = (c, o, t)
    return d


a, b, c = best('56'), best('snap-F935'), best('tip')
print('shape n chars | open_ms 56dfd93 / 935b077 / tip | tip/56 tip/935 | tip growth | text_ms 56 / 935 / tip')
prev = {}
for k in sorted(c):
    if k not in a or k not in b:
        continue
    ch, oc, tc = c[k]
    _, oa, ta = a[k]
    _, ob, tb = b[k]
    g = oc / prev[k[0]] if k[0] in prev else float('nan')
    prev[k[0]] = oc
    print(f'{k[0]} {k[1]} {ch} | {oa:.1f} / {ob:.1f} / {oc:.1f} | {oc / max(oa, 0.01):.1f}x {oc / max(ob, 0.01):.2f}x | x{g:.2f} | {ta:.1f} / {tb:.1f} / {tc:.1f}')
