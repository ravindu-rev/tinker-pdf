"""Lane F: variants/paint-A8-diag.rs = A8 with stderr lines (DIAGRULE ...) where
the rules no case test moves when broken decide something: where the page's
fonts give a line's characters back otherwise than typed (page/read-as-typed;
Segment::read_as maps each character as Fonts::read_as does, so a line whose
typed text is unchanged reads every glyph as typed too), and what
Fonts::reads_closer and Fonts::reads_whole find (page/closer-unchecked,
page/whole-unchecked, page/whole-over-unchecked). Behaviour is A8's."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A8.rs')).read()


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:70]
    s = s.replace(old, new)


sub("""            let written = Words::of(&typed);
""", """            let written = Words::of(&typed);
            {
                let raw: String = line.iter().flat_map(|run| run.text.chars()).collect();
                if raw != typed {
                    eprintln!("DIAGRULE readas-typed {:?} -> {:?}", raw, typed);
                }
            }
""")
sub("""        written.pairs_in(&read) > written.pairs_in(&rules)
    }""", """        let closer = written.pairs_in(&read) > written.pairs_in(&rules);
        eprintln!("DIAGRULE closer {closer} found={} rules={}", written.pairs_in(&read), written.pairs_in(&rules));
        closer
    }""")
sub("""        self.read_back(line, matrices, frame, found)
            .is_some_and(|(read, over)| {
                over <= over_by_rules && written.read_as(&read) == Read::Words
            })""", """        let got = self.read_back(line, matrices, frame, found);
        if let Some((read, over)) = &got {
            eprintln!(
                "DIAGRULE whole words={} over={} rules_over={}",
                written.read_as(read) == Read::Words,
                over,
                over_by_rules
            );
        } else {
            eprintln!("DIAGRULE whole none");
        }
        got.is_some_and(|(read, over)| {
            over <= over_by_rules && written.read_as(&read) == Read::Words
        })""")
open(os.path.join(HERE, 'paint-A8-diag.rs'), 'w').write(s)
print('A8-diag written')
