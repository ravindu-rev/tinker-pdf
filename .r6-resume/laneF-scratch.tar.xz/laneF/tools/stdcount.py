"""Lane F: the standard's books per run: books strictly worse than 9297d2d
(worse_b) and books worse than 56dfd93 in conserving (worse_m), per build,
for each run tag given (out/table-TAG-BUILD.json), and the books each run
leaves that another does not.

usage: python3 -I stdcount.py TAG [TAG ...]
"""
import json
import os
import sys

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
tags = sys.argv[1:]


def books(tag, build, key):
    t = json.load(open(os.path.join(L, 'out', f'table-{tag}-{build}.json')))
    s = set()
    for fam, v in t.items():
        if not fam.startswith(build + '/'):
            continue
        for x in v.get(key, []):
            s.add((fam, tuple(x) if isinstance(x, list) else (x,)))
    return s


for build in ('default', 'bundled'):
    sets = {}
    for tag in tags:
        sets[tag] = {k: books(tag, build, k) for k in ('worse_b', 'worse_m')}
        print(f'{build} {tag}: worse than 9297d2d {len(sets[tag]["worse_b"])}, worse than 56dfd93 in conserving {len(sets[tag]["worse_m"])}')
    for a in tags:
        for b in tags:
            if a == b:
                continue
            for k in ('worse_b', 'worse_m'):
                only = sets[a][k] - sets[b][k]
                if only:
                    fams = {}
                    for fam, _ in only:
                        fams[fam] = fams.get(fam, 0) + 1
                    print(f'  {build} {k}: {len(only)} at {a} not at {b}: ' + ', '.join(f'{f.split("/", 1)[1]} {n}' for f, n in sorted(fams.items())))
