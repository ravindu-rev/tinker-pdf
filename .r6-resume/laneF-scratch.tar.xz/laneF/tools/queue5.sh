#!/usr/bin/env bash
# Lane F: after queue4's diagnostics, the page's fonts' reading broken
# (snap/ZR, read-as-typed) on round 6's families and scripts, optimised.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^q4 diag done' "$L/out/queue4.out" 2>/dev/null; do sleep 20; done
RX='^zz_((f6|v6)_|rr3m_hunt_scripts$|rr3m_h1_ofscripts$|rr3m_hunt_numbers$)'
THREADS=2 JOBS=2 REL=1 bash "$L/tools/rsuite2.sh" snap/ZR default ZR "$RX"
echo "q5 done"
