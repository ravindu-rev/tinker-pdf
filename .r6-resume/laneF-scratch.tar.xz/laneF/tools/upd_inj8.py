"""Lane F: the catalogue for A8: page/cut-searched's text is A8's (the Cut arm
of Fonts::search), and the search of a cut line under a transform gets three
injections: page/cut-kept-under-a-transform (no search in the runs' space for
a cut line), page/whole-unchecked (what that search finds taken without
reading it on the page) and page/whole-over-unchecked (taken however many
glyphs it sets over others)."""
import json

p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/injections.json'
raw = open(p, encoding='utf-8').read()
d = json.loads(raw)
key = next(iter(d))
items = d[key]
before = len(items)
ROUND = 'round 6 lane F: the read-back reads the page'
CASES = ['cargo', 'test', '--no-fail-fast', '-p', 'tinker-pdf', '--test', 'epub_conservation', '--test', 'epub_fallback']
PAINT = 'crates/tinker-pdf/src/epub/paint.rs'
names = [e['name'] for e in items]
assert 'page/cut-kept-under-a-transform' not in names
for e in items:
    if e['name'] == 'page/cut-searched':
        e['edits'] = [{
            'file': PAINT,
            'old': '            Some((Read::Cut, _)) => return Search::Cut,\n',
            'new': '',
            'count': 1,
        }]
WHOLE = '                over <= over_by_rules && written.read_as(&read) == Read::Words'
at = names.index('page/cut-searched') + 1
items[at:at] = [
    {
        'name': 'page/cut-kept-under-a-transform',
        'round': ROUND,
        'edits': [{
            'file': PAINT,
            'old': '                Search::Cut if transformed => {',
            'new': '                Search::Cut if false && transformed => {',
            'count': 1,
        }],
        'suites': [CASES],
    },
    {
        'name': 'page/whole-unchecked',
        'round': ROUND,
        'edits': [{'file': PAINT, 'old': WHOLE, 'new': WHOLE.replace('over <=', 'true || over <='), 'count': 1}],
        'suites': [CASES],
    },
    {
        'name': 'page/whole-over-unchecked',
        'round': ROUND,
        'edits': [{'file': PAINT, 'old': WHOLE, 'new': WHOLE.replace('over <= over_by_rules', '(true || over <= over_by_rules)'), 'count': 1}],
        'suites': [CASES],
    },
]
d[key] = items
out = json.dumps(d, ensure_ascii=False, indent=1)
if raw.endswith('\n'):
    out += '\n'
open(p, 'w', encoding='utf-8').write(out)
print(key, before, '->', len(items))
