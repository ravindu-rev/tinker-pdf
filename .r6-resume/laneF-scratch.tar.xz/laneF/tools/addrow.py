"""Lane F: add the zz_f6_ems row to the kit's families.tsv (once)."""
p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/families.tsv'
s = open(p, encoding='utf-8').read()
row = ('zz_f6_ems\ttinker-pdf\tprobes/pdf/zz_f6_ems.rs\tf6\t2\trows\tround 6 lane F (sweep)\t'
       'the edges of the fix of V1: two cells whose gap is near half an em, inline blocks of about half '
       'an em between words, marks of no advance opening a styled run, letter-spaced; under no transform, '
       'a scale of one axis and a skew\n')
if 'zz_f6_ems\t' not in s:
    assert s.endswith('\n')
    open(p, 'w', encoding='utf-8').write(s + row)
    print('row added')
else:
    print('row there')
