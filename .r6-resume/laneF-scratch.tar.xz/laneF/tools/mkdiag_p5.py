"""Lane F: diag/p5.tsv, the f6 punct/none Hebrew books under a transform."""
HE = ["שלום", "עולם", "מלחמה", "ספר", "בית", "גדול", "אור", "יום", "בראשית", "ברא", "אלהים", "את"]


def s(i):
    return HE[i % len(HE)]


def punct(i):
    return f"{s(i)} <b>?!</b> {s(i + 1)} {s(i + 2)}. <i>(</i>{s(i + 3)}<i>)</i> {s(i + 4)}!"


text = " ".join(punct(k * 3) for k in range(3))
body = f'<div class="w"><p>{text}</p></div>'
rows = [
    ("p5-sx2", "p { margin: 0 30%; transform: scaleX(2); word-spacing: 0.6em } .w { transform: none }"),
    ("p5-none", "p { margin: 0 30%; transform: none; word-spacing: 0.6em } .w { transform: none }"),
    ("p5-sy05", "p { margin: 0 30%; transform: scaleY(0.5); word-spacing: 0.6em } .w { transform: none }"),
]
with open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/p5.tsv', 'w') as f:
    for name, style in rows:
        f.write(f"{name}\the\t{style}\t{body}\n")
print(body)
