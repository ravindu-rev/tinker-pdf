#!/usr/bin/env bash
# Lane F: diag/zero.tsv in snap/Y at A5g and with each of the three
# zero-fire injections, one after the other (paint.rs swapped in snap/Y).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
P=$L/snap/Y/crates/tinker-pdf/src/epub/paint.rs
cp "$L/variants/paint-A5g.rs" "$P"
"$L/tools/diag.sh" snap/Y default zero A5g > /dev/null
for n in page/lines-cut-in-the-runs-ems page/mark-in-the-runs-ems page/closer-overprint-unchecked; do
  python3 -I "$L/tools/mkinjvar.py" "$n" "$P"
  "$L/tools/diag.sh" snap/Y default zero "$(basename "$n")" > /dev/null
done
cp "$L/variants/paint-A5g.rs" "$P"
echo "diag4 done"
