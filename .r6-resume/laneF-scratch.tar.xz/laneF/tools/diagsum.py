"""Lane F: the DIAGRULE lines of a run directory, per family: reads_closer's
verdicts, reads_whole's (and where its overprint clause decided), and the
lines whose typed text the page's fonts give back otherwise.

usage: python3 -I diagsum.py out/rs-ZD-default
"""
import collections
import glob
import os
import re
import sys

d = sys.argv[1]
tot = collections.Counter()
typed = collections.Counter()
for p in sorted(glob.glob(os.path.join(d, '*.log'))):
    fam = os.path.basename(p)[:-4]
    c = collections.Counter()
    for line in open(p, encoding='utf-8', errors='replace'):
        if 'DIAGRULE' not in line:
            continue
        line = line[line.index('DIAGRULE'):].strip()
        if line.startswith('DIAGRULE closer'):
            c['closer ' + line.split()[2]] += 1
        elif line.startswith('DIAGRULE whole'):
            m = re.match(r'DIAGRULE whole words=(\w+) over=(\d+) rules_over=(\d+)', line)
            if not m:
                c['whole none'] += 1
                continue
            words, over, rules = m.group(1) == 'true', int(m.group(2)), int(m.group(3))
            c['whole words=' + str(words).lower()] += 1
            if words and over > rules:
                c['whole decided by overprint'] += 1
            if over > rules:
                c['whole over>rules'] += 1
        elif line.startswith('DIAGRULE readas-typed'):
            c['readas-typed'] += 1
            typed[line[len('DIAGRULE readas-typed '):][:160]] += 1
    if c:
        print(fam, dict(c))
    tot.update(c)
print('TOTAL', dict(tot))
print('distinct readas-typed lines:', len(typed))
for t, n in typed.most_common(12):
    print(f'  {n:5} {t}')
