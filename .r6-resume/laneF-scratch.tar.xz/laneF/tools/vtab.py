"""Lane F: one row a diag case, its verdict (c l w s and ov) at each tag.
usage: python3 -I vtab.py NAME BUILD TAG...   (reads diag/NAME-TAG-BUILD.txt)"""
import os
import sys

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'diag')
name, build, tags = sys.argv[1], sys.argv[2], sys.argv[3:]
cols = {}
order = []
for t in tags:
    p = os.path.join(D, '%s-%s-%s.txt' % (name, t, build))
    for line in open(p, encoding='utf-8'):
        if not line.startswith('V\t'):
            continue
        f = line.rstrip('\n').split('\t')
        key = f[1]
        verdict = f[2].split(' miss=')[0]
        if key not in cols:
            cols[key] = {}
            order.append(key)
        cols[key][t] = verdict
w = max(len(k) for k in order)
print(' ' * w, *['%-20s' % t for t in tags])
for k in order:
    row = [cols[k].get(t, '-') for t in tags]
    mark = '' if len(set(r.split(' ')[0] for r in row)) == 1 else '  *'
    print(k.ljust(w), *['%-20s' % r for r in row], mark)
