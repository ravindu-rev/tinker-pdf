#!/usr/bin/env bash
# Lane F: run the kit (the lane F worktree's copy) at a tree.
# usage: runat.sh TREE BUILD OUTNAME FILTER
#   TREE: tip (lane F worktree) | 935 (laneF/base935, 05cea0b's archive) | 56 | 9297
#         | snap/<name> (laneF/snap/<name>, a copy of the worktree, target laneF/snap/<name>-target)
#   output in laneF/out/OUTNAME
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
S=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad
KIT=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl
GIT=1
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  935) W=$L/base935; T=$L/base935-target; GIT=0 ;;
  56) W=/home/user/tinker-pdf/.claude/worktrees/wf_26917f32-492-8; T=$W/target ;;
  9297) W=$S/k11r4/base; T=$S/k11r4/base-target ;;
  snap/*) W=$L/$1; T=$L/$1-target; GIT=0 ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_TARGET_DIR=$T RUN_GIT=$GIT
mkdir -p "$L/out"
"$KIT/scripts/run.sh" "$W" "$2" "$L/out/$3" "$4" > "$L/out/$3.log" 2>&1
code=$?
echo "run exit $code"
cat "$L/out/$3/progress" 2>/dev/null | tail -5
ls "$L/out/$3"
