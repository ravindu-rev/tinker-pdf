#!/usr/bin/env bash
# Lane F: put variants/paint-NAME.rs in the worktree's paint.rs (after checking
# that the worktree's current paint.rs is saved as some variant), and say which.
# usage: swap.sh NAME
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
P=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/src/epub/paint.rs
cur=$(sha256sum "$P" | cut -d' ' -f1)
saved=""
for v in "$L"/variants/paint-*.rs; do
  if [ "$(sha256sum "$v" | cut -d' ' -f1)" = "$cur" ]; then saved=$v; fi
done
if [ -z "$saved" ]; then
  echo "the worktree's paint.rs ($cur) is not saved as a variant: refusing" >&2
  exit 1
fi
src="$L/variants/paint-$1.rs"
[ -f "$src" ] || { echo "no $src" >&2; exit 1; }
cp "$src" "$P"
echo "paint.rs: $(basename "$saved") -> paint-$1.rs ($(sha256sum "$P" | cut -c1-12))"
