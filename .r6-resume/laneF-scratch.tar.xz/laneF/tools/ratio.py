"""Lane F: per-family seconds of two rsuite runs, and their ratio on the
families both finished (exit 0 or 101).

usage: python3 -I ratio.py out/rs-A-default out/rs-B-default
"""
import re
import sys


def secs(d):
    out = {}
    for line in open(d + '/progress.txt'):
        m = re.match(r'\S+ (\S+) exit (\d+) seconds (\d+)', line)
        if m and m.group(2) in ('0', '101'):
            out[m.group(1)] = int(m.group(3))
    return out


a, b = secs(sys.argv[1]), secs(sys.argv[2])
common = sorted(set(a) & set(b))
sa = sum(a[f] for f in common)
sb = sum(b[f] for f in common)
print(f'{len(common)} families: {sa} s vs {sb} s, ratio {sa / max(sb, 1):.1f}')
print(f'all of A: {sum(a.values())} s over {len(a)}; all of B: {sum(b.values())} s over {len(b)}')
