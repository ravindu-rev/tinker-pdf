"""Lane F: epub_fallback.rs as the pins' commit (C4) has it: the final file
without the V5 test, which comes with the budget's commit (C5).

usage: python3 -I stage4.py OUTDIR   -> OUTDIR/epub_fallback.rs
"""
import os
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/tests'
out = sys.argv[1]
fall = open(os.path.join(W, 'epub_fallback.rs')).read()
start = "/// **A line whose right drawing lies past the read-back's budget is drawn by\n"
assert fall.count(start) == 1
i = fall.index(start)
j = fall.index("\n}\n", fall.index("fn a_line_whose_right_drawing_lies_past_the_budget_is_drawn_by_the_rules", i)) + 3
fall = fall[:i] + fall[j:].lstrip('\n')
os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'epub_fallback.rs'), 'w').write(fall)
print('C4 epub_fallback.rs written to', out)
