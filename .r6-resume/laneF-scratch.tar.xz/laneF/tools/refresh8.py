"""Lane F: the new baseline, `tools/probes/rtl/baselines/<COMMIT>/`, moved only
where books got better: a family whose suite run at COMMIT read a book better
than at 935b077 in a build takes COMMIT's output in that build (packed by
pack.py --suites, its note naming COMMIT); every other family, the td
probe's TSVs and the line families keep 935b077's files, byte for byte (their
notes still name 935b077, which is where they ran).

usage: python3 -I refresh8.py COMMIT KITDIR RUN_DEFAULT RUN_BUNDLED
  KITDIR: the suites' TINKER_RTL_KIT_OUT at COMMIT (complete, both builds and lines)
  RUN_*: rsuite run directories at COMMIT, whose RAN lines say which families gained
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
K = os.path.join(W, 'tools/probes/rtl')
commit, kit, run_d, run_b = sys.argv[1:5]
RAN = re.compile(r'RAN rtl_probes (\S+) \[(\w+)\] against \w+: .*?(\d+) books worse, (\d+) books better')


def gained(run):
    out = set()
    for name in os.listdir(run):
        if not name.endswith('.log') or not name.startswith('zz_'):
            continue
        m = RAN.search(open(os.path.join(run, name), encoding='utf-8', errors='replace').read())
        if m and int(m.group(4)) > 0:
            assert int(m.group(3)) == 0, name
            out.add(m.group(1))
    return out


gains = {'default': gained(run_d), 'bundled': gained(run_b)}
old = os.path.join(K, 'baselines', '935b077')
dest = os.path.join(K, 'baselines', commit)
assert not os.path.exists(dest), dest
tmp = tempfile.mkdtemp(prefix='refresh8-', dir='/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF')
packed = os.path.join(tmp, 'packed')
r = subprocess.run([sys.executable, '-I', os.path.join(K, 'scripts/pack.py'), kit, packed, '--suites',
                    '--note', '{family} at ' + commit + ", {build}: the suites' run"], capture_output=True, text=True)
print(r.stdout[-2000:], r.stderr[-2000:])
assert r.returncode == 0
moved = {'default': [], 'bundled': []}
for build in ('default', 'bundled', 'lines'):
    os.makedirs(os.path.join(dest, build))
    for name in sorted(os.listdir(os.path.join(old, build))):
        fam = name.split('.')[0]
        src = os.path.join(old, build, name)
        if build != 'lines' and name.endswith('.txt.xz') and fam in gains[build]:
            src = os.path.join(packed, build, name)
            assert os.path.exists(src), src
            moved[build].append(fam)
        shutil.copyfile(src, os.path.join(dest, build, name))
    extra = set(os.listdir(os.path.join(packed, build))) - set(os.listdir(os.path.join(old, build)))
    assert not extra, (build, extra)
shutil.rmtree(tmp)
for build in ('default', 'bundled'):
    print(build, len(moved[build]), 'families moved:', ' '.join(moved[build]))
    missing = gains[build] - set(moved[build])
    assert not missing, missing
