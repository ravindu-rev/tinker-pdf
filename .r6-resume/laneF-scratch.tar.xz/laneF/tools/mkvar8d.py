"""Lane F: paint-A8d.rs = paint-A8.rs with each drawing read once (the V5
option, the owner's: A5d's change carried over to the committed base)."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A8.rs')).read()
old = """            let options: Vec<(RunKey, Drawing)> = line
                .iter()
                .flat_map(|run| drawings_of(run, self.along(run)))
                .collect();
"""
new = """            let mut options: Vec<(RunKey, Drawing)> = Vec::new();
            for run in &line {
                let mut planned: Vec<Vec<Vec<Segment>>> =
                    vec![self.plan_run(run, Drawing::default()).unwrap_or_default()];
                for (key, drawing) in drawings_of(run, self.along(run)) {
                    let plan = self.plan_run(run, drawing).unwrap_or_default();
                    if !planned.contains(&plan) {
                        planned.push(plan);
                        options.push((key, drawing));
                    }
                }
            }
"""
assert s.count(old) == 1
s = s.replace(old, new)
open(os.path.join(HERE, 'paint-A8d.rs'), 'w').write(s)
print('A8d written')
