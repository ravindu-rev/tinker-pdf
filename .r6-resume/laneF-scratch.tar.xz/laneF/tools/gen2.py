"""Lane F: a suite module of rtl_probes from a family body (cases(), styles() and
its own items), importing from common.rs only what the body names.

usage: python3 -I gen2.py BODY.rs FAMILY 'GROUP' 'ORIGIN' [--probe PROBE.rs]
  writes crates/tinker-pdf/tests/rtl_probes/<FAMILY>.rs in the lane F worktree.
  With --probe, also copies PROBE.rs to tools/probes/rtl/probes/pdf/<FAMILY>.rs
  (the probe as it ran, byte for byte).
"""
import re
import shutil
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
body_path, family, group, origin = sys.argv[1:5]
probe = sys.argv[sys.argv.index('--probe') + 1] if '--probe' in sys.argv else None

body = open(body_path, encoding='utf-8').read()
# Strip any lane-local header comment lines that precede the family's own comment? Keep as is.
names = ['AR', 'ARP', 'HE', 'HEP', 'GR', 'CY', 'rep', 'hash', 'esc', 'strip_marks', 'halves']
own = set(re.findall(r'^(?:const|fn|static)\s+([A-Za-z_][A-Za-z0-9_]*)', body, re.M))
used = ['Case', 'run_book']
for n in names:
    if n in own:
        continue
    if re.search(r'(?<![A-Za-z0-9_"])' + re.escape(n) + r'(?![A-Za-z0-9_"])', body):
        used.append(n)
items = ', '.join(sorted(set(used), key=lambda s: (s.lower(), s)))
module = (
    f'//! `{family}` ({group}, {origin}): the books of\n'
    f'//! `tools/probes/rtl/probes/pdf/{family}.rs`, which is the probe as it ran.\n'
    '\n'
    f'use super::common::{{{items}}};\n'
    '\n'
    'fn probe() {\n'
    '    let mut n = 0usize;\n'
    '    for style in styles() {\n'
    '        for (name, lang, body) in cases() {\n'
    '            n += 1;\n'
    '            let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {\n'
    '                run_book(&style, &name, lang, &body)\n'
    '            }));\n'
    '            if r.is_err() {\n'
    '                emit!("ROW\\t{style}\\t{name}\\tm=0\\ttext=0\\tsearch=0/1\\tltr=-\\tcons=0\\tlogical=0\\tPANIC");\n'
    '                emit!("PANIC\\t{style}\\t{name}");\n'
    '            }\n'
    '        }\n'
    '    }\n'
    '    emit!("books={n}");\n'
    '}\n'
    '\n'
    '/// Every book of the family, as its probe built them, in order.\n'
    'pub(crate) fn run() {\n'
    '    probe();\n'
    '}\n'
    '\n'
)
out = f'{W}/crates/tinker-pdf/tests/rtl_probes/{family}.rs'
open(out, 'w', encoding='utf-8').write(module + body)
print(out, 'uses', items)
if probe:
    dst = f'{W}/tools/probes/rtl/probes/pdf/{family}.rs'
    shutil.copyfile(probe, dst)
    print(dst)
