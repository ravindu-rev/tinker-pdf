#!/usr/bin/env bash
# Lane F: the owner's options on the committed base A9L, optimised, one at a
# time in rel-target (owner3.sh is resumable): H1n, H6n, A9Ld; then each
# option's summary (optsum.sh against kit-A8t is the old tip; the A9L
# comparison is made by cmp.py against kit-A9L below).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
echo "queue10 start $(date +%T)"
[ -d "$L/snap/A9Ld" ] || bash "$L/tools/setup9.sh"
for n in H1n H6n A9Ld; do
  THREADS=${THREADS:-4} JOBS=${JOBS:-4} bash "$L/tools/owner3.sh" "$n"
  echo "owner3 $n exit $? $(date +%T)"
  bash "$L/tools/opt8.sh" "$n"
  for b in default bundled lines; do
    [ -d "$L/out/kit-$n/$b" ] || continue
    python3 -I "$W/tools/probes/rtl/scripts/table.py" "$L/out/kit-$n" --tip "$L/out/kit-A9L" --builds "$b" --show 8 \
      > "$L/out/vsA9L-$n-$b.txt" 2>&1
  done
done
echo "queue10 done $(date +%T)"
