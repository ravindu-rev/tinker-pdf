#!/usr/bin/env bash
# Lane F: wtcases.sh in both builds, one after the other.
# usage: wtboth.sh TAG
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
for b in default bundled; do
  echo "== $b"
  JOBS=${JOBS:-4} bash "$L/tools/wtcases.sh" "$b" "$1"
  tail -1 "$L/out/wt-$1-$b.log"
done
echo "wtboth $1 done"
