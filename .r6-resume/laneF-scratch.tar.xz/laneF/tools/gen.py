"""Lane F: builds a family from laneF/fam/<name>.rs (its cases() and styles(), and
any constants), as the kit's probe (the rr3m prefix of zz_rr3m_h2_pages.rs, lines
2-296, byte for byte, then the body) and as a suite module of rtl_probes.

usage: python3 -I gen.py NAME 'ORIGIN' 'GROUP' [USES]
  writes tools/probes/rtl/probes/pdf/zz_<NAME>.rs and
  crates/tinker-pdf/tests/rtl_probes/zz_<NAME>.rs in the lane F worktree.
  USES: the names the module takes from common.rs, comma-separated
  (default rep,run_book,Case,AR,ARP,HE,HEP).
"""
import os
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
LANE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
KIT_SRC = os.path.join(W, 'tools/probes/rtl/probes/pdf/zz_rr3m_h2_pages.rs')

name, origin, group = sys.argv[1], sys.argv[2], sys.argv[3]
uses = sys.argv[4] if len(sys.argv) > 4 else 'rep,run_book,Case,AR,ARP,HE,HEP'

src = open(KIT_SRC, encoding='utf-8').read().split('\n')
assert src[265].startswith('fn para3'), src[265]
assert src[275] == '#[test]', src[275]
assert src[296].startswith('// Family pages'), src[296]
prefix = '\n'.join(src[1:296]) + '\n'

body = open(os.path.join(LANE, 'fam', f'{name}.rs'), encoding='utf-8').read()
head = (f'//! Lane F probe (round 6 of ROADMAP CD-19): family {name}. The rr3m prefix is\n'
        '//! zz_rr3m_h2_pages.rs\'s, byte for byte; the cases and styles below are new.\n')
out = os.path.join(W, 'tools/probes/rtl/probes/pdf', f'zz_{name}.rs')
with open(out, 'w', encoding='utf-8') as f:
    f.write(head + prefix + '\n' + body)
print(out)

items = ', '.join(sorted(u.strip() for u in uses.split(',')))
module = (
    f'//! `zz_{name}` ({group}, {origin}): the books of\n'
    f'//! `tools/probes/rtl/probes/pdf/zz_{name}.rs`, which is the probe as it ran.\n'
    '\n'
    f'use super::common::{{{items}}};\n'
    '\n'
    'fn probe() {\n'
    '    let mut n = 0usize;\n'
    '    for style in styles() {\n'
    '        for (name, lang, body) in cases() {\n'
    '            n += 1;\n'
    '            let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {\n'
    '                run_book(&style, &name, lang, &body)\n'
    '            }));\n'
    '            if r.is_err() {\n'
    '                emit!("ROW\\t{style}\\t{name}\\tm=0\\ttext=0\\tsearch=0/1\\tltr=-\\tcons=0\\tlogical=0\\tPANIC");\n'
    '                emit!("PANIC\\t{style}\\t{name}");\n'
    '            }\n'
    '        }\n'
    '    }\n'
    '    emit!("books={n}");\n'
    '}\n'
    '\n'
    'pub(crate) fn run() {\n'
    '    probe();\n'
    '}\n'
    '\n'
)
out = os.path.join(W, 'crates/tinker-pdf/tests/rtl_probes', f'zz_{name}.rs')
with open(out, 'w', encoding='utf-8') as f:
    f.write(module + body)
print(out)
