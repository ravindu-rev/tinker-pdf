"""Lane F: paint-A5g with one catalogued injection applied, for a suite run.

usage: python3 -I mkinjvar.py NAME OUT.rs
"""
import json
import sys

CAT = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/injections.json'
BASE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants/paint-A5g.rs'
name, out = sys.argv[1], sys.argv[2]
inj = {x['name']: x for x in json.load(open(CAT))['injections']}[name]
s = open(BASE).read()
for e in inj['edits']:
    assert e['file'].endswith('paint.rs')
    assert s.count(e['old']) == e['count'], (s.count(e['old']), e['old'][:80])
    s = s.replace(e['old'], e['new'])
open(out, 'w').write(s)
print(name, '->', out)
