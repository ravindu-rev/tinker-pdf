#!/usr/bin/env bash
# Lane F: one integration test of tinker-pdf in a tree, both builds or one.
# usage: onetest.sh TREE TESTFILE FILTER [BUILD...]   (TREE: tip | snap/NAME)
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
TREE=$1; F=$2; X=$3; shift 3
builds=${*:-default bundled}
cd "$W" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
for b in $builds; do
  FEAT=""
  [ "$b" = bundled ] && FEAT="--features bundled-fonts"
  # shellcheck disable=SC2086
  out=$(cargo test -p tinker-pdf $FEAT --test "$F" -- --test-threads=2 "$X" 2>&1)
  echo "== $TREE $b: $(echo "$out" | grep -E '^test result' | tr '\n' ' ')"
  echo "$out" | grep -E "^(he|ar), |panicked|read back|FAILED" | head -12
done
