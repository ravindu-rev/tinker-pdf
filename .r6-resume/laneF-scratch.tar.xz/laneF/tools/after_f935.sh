#!/usr/bin/env bash
# Lane F: after after_inj.sh (the F935 families), the counted injections at A7.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^after_inj done' "$L/out/after_inj.out" 2>/dev/null; do sleep 20; done
JOBS=2 bash "$L/tools/inj7.sh"
echo "after_f935 done"
