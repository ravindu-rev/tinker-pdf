"""Lane F: check every edit of the injection catalogue matches the worktree
(the old text occurs as often as the entry counts)."""
import json

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
d = json.load(open(W + '/tools/probes/rtl/scripts/injections.json', encoding='utf-8'))
src = {}
bad = 0
for e in d['injections']:
    for ed in e['edits']:
        f = ed['file']
        if f not in src:
            src[f] = open(W + '/' + f, encoding='utf-8').read()
        c = src[f].count(ed['old'])
        if c != ed.get('count', 1):
            bad += 1
            print('MISMATCH', e['name'], f, c, repr(ed['old'][:80]))
print(len(d['injections']), 'injections;', bad, 'mismatches')
print([e['name'] for e in d['injections'] if e['name'].startswith('page/')])
