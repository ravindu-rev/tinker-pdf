#!/usr/bin/env bash
# Lane F: the owner's options on the committed base (A8): snap/H1 and snap/H6
# (the worktree with bidi-H1.rs / bidi-H6.rs), snap/A8d (the worktree with
# paint-A8d.rs). Earlier H1 outputs (on A6) are kept as *-H1onA6*. Targets are
# reused where they exist (H1-target; A7d-target -> A8d-target; H6-target
# copied from H1-target).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
O=$L/out
[ -d "$O/rs-H1-default" ] && [ ! -d "$O/rs-H1onA6-default" ] && mv "$O/rs-H1-default" "$O/rs-H1onA6-default"
[ -d "$O/kit-H1" ] && [ ! -d "$O/kit-H1onA6" ] && mv "$O/kit-H1" "$O/kit-H1onA6"
for f in owner2-H1.out owner-H1-shape.log owner-H1-cases-default.log owner-H1-cases-bundled.log; do
  [ -f "$O/$f" ] && mv "$O/$f" "$O/${f/H1/H1onA6}"
done
bash "$L/tools/snap.sh" H1
cp "$L/variants/bidi-H1.rs" "$L/snap/H1/crates/tinker-pdf-shape/src/bidi.rs"
bash "$L/tools/snap.sh" H6
cp "$L/variants/bidi-H6.rs" "$L/snap/H6/crates/tinker-pdf-shape/src/bidi.rs"
[ -d "$L/snap/H6-target" ] || cp -r "$L/snap/H1-target" "$L/snap/H6-target"
rm -rf "$L/snap/A7d"
[ -d "$L/snap/A7d-target" ] && [ ! -d "$L/snap/A8d-target" ] && mv "$L/snap/A7d-target" "$L/snap/A8d-target"
bash "$L/tools/snap.sh" A8d
cp "$L/variants/paint-A8d.rs" "$L/snap/A8d/crates/tinker-pdf/src/epub/paint.rs"
sha256sum "$L/snap/H1/crates/tinker-pdf-shape/src/bidi.rs" "$L/snap/H6/crates/tinker-pdf-shape/src/bidi.rs" "$L/snap/A8d/crates/tinker-pdf/src/epub/paint.rs"
echo "setup8 done"
