"""Lane F: the injection catalogue for A9 (a rules' reading that holds the
letters in order ends the search; Read::Cut folded into Read::Letters):
cut-searched becomes letters-searched, cut-kept-under-a-transform becomes
letters-kept-under-a-transform, joins-are-cuts goes (no cut and join are told
apart any more). Checks every edit's old text occurs as counted in paint.rs.

usage: python3 -I upd_inj9.py
"""
import json

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
P = W + '/tools/probes/rtl/scripts/injections.json'
raw = open(P, encoding='utf-8').read()
d = json.loads(raw)
inj = d['injections']
out = []
for e in inj:
    n = e['name']
    if n == 'page/joins-are-cuts':
        continue
    if n == 'page/cut-searched':
        e['name'] = 'page/letters-searched'
        e['edits'][0]['old'] = "            Some((Read::Letters, _)) => return Search::Letters,\n"
    if n == 'page/cut-kept-under-a-transform':
        e['name'] = 'page/letters-kept-under-a-transform'
        e['edits'][0]['old'] = "                Search::Letters if transformed => {"
        e['edits'][0]['new'] = "                Search::Letters if false && transformed => {"
    out.append(e)
d['injections'] = out
src = {}
bad = 0
for e in out:
    for ed in e['edits']:
        f = ed['file']
        if f not in src:
            src[f] = open(W + '/' + f, encoding='utf-8').read()
        c = src[f].count(ed['old'])
        if c != ed.get('count', 1):
            bad += 1
            print('MISMATCH', e['name'], f, c, repr(ed['old'][:80]))
indent = 1 if '\n "injections"' in raw[:40] else 2
text = json.dumps(d, ensure_ascii=False, indent=indent) + '\n'
open(P, 'w', encoding='utf-8').write(text)
print(len(inj), '->', len(out), 'injections;', bad, 'mismatches')
