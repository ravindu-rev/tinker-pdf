"""Lane F: add (on) or remove (off) temporary LANEF_DBG prints in set_readings."""
import sys
p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/src/epub/paint.rs'
s = open(p).read()
A_OLD = """            let rules_letters = letters_only.borrow_mut().take().is_some();
"""
A_NEW = """            let rules_letters = letters_only.borrow_mut().take().is_some();
            if std::env::var_os("LANEF_DBG").is_some() { eprintln!("DBGRB written={:?} default={:?} rules_letters={}", line.iter().map(|r| r.text.as_str()).collect::<Vec<_>>(), self.read_back(&line, &matrices, frame, &BTreeMap::new()), rules_letters); }
"""
B_OLD = """            if let Some(found) = found {
                drawings.extend(found);"""
B_NEW = """            if std::env::var_os("LANEF_DBG").is_some() { eprintln!("DBGRB chosen={:?} tried={} read={:?}", found, tried.get(), found.as_ref().map(|f| self.read_back(&line, &matrices, frame, f))); }
            if let Some(found) = found {
                drawings.extend(found);"""
if sys.argv[1] == 'on':
    assert s.count(A_OLD) == 1 and s.count(B_OLD) == 1
    s = s.replace(A_OLD, A_NEW).replace(B_OLD, B_NEW)
else:
    assert s.count(A_NEW) == 1 and s.count(B_NEW) == 1
    s = s.replace(A_NEW, A_OLD).replace(B_NEW, B_OLD)
open(p, 'w').write(s)
print('dbg', sys.argv[1])
