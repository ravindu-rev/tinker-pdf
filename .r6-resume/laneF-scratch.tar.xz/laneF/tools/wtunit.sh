#!/usr/bin/env bash
# Lane F: one lib test of the worktree's epub::tests, debug, one build.
# usage: wtunit.sh BUILD FILTER
set -u
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
FEAT=""
[ "$1" = bundled ] && FEAT="--features bundled-fonts"
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$W/target
cd "$W" || exit 2
# shellcheck disable=SC2086
cargo test -p tinker-pdf $FEAT --lib "$2" -- --nocapture 2>&1 | grep -E "^test |panicked|left:|right:|assertion|test result" | head -20
