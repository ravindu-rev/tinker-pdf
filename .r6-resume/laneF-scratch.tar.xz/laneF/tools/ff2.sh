#!/usr/bin/env bash
# Lane F: failing-first. The case tests of the worktree as it stands, run in
# snap/NAME, a copy of the worktree with PAINT (a variants/paint-*.rs, e.g.
# 935 = 05cea0b's) in place of paint.rs; both builds, every case printed.
# usage: ff2.sh NAME PAINT   -> out/ff-NAME-{default,bundled}.log
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
N=$1; P=$2
bash "$L/tools/snap.sh" "$N" > /dev/null
cp "$L/variants/paint-$P.rs" "$L/snap/$N/crates/tinker-pdf/src/epub/paint.rs"
cd "$L/snap/$N" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/$N-target
for b in default bundled; do
  FEAT=""
  [ "$b" = bundled ] && FEAT="--features bundled-fonts"
  O="$L/out/ff-$N-$b.log"
  # shellcheck disable=SC2086
  cargo test --no-fail-fast -p tinker-pdf $FEAT --test epub_fallback --test epub_conservation -- --nocapture --test-threads=2 > "$O" 2>&1
  echo "exit $?" >> "$O"
  echo "== $N ($P) $b: $(grep -E '^test result' "$O" | tr '\n' ' ') $(tail -1 "$O")"
done
