#!/usr/bin/env bash
# Lane F: does an optimised build read every book as a debug one does? A few
# families of snap/A8d in both profiles, the kit dumps compared byte for byte.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
RX='^zz_(f6_ems|v6_pdf|v6_cells|vx_k11rv_neutral|rr3m_hunt_ws|v6_transform)$'
THREADS=1 JOBS=2 REL=1 bash "$L/tools/rsuite2.sh" snap/A8d default A8dR "$RX"
THREADS=1 JOBS=2 bash "$L/tools/rsuite2.sh" snap/A8d default A8dD "$RX"
python3 -I "$L/tools/cmpdirs.py" "$L/out/kit-A8dD" "$L/out/kit-A8dR" default
grep -h 'exit' "$L/out/rs-A8dR-default/progress.txt" "$L/out/rs-A8dD-default/progress.txt"
echo "val done"
