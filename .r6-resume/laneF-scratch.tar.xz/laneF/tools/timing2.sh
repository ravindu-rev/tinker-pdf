#!/usr/bin/env bash
# Lane F: the read-back's cost (V4) on a quiet machine. Stops (SIGSTOP) every
# process of lane F's other jobs, runs zz_v6_time at 56dfd93 (no read-back),
# at 05cea0b's code (snap/F935, 935b077's read-back) and at the tip (the fix),
# twice each, interleaved, and continues the stopped processes on any exit.
# usage: timing2.sh   -> out/time6-<tree>-<i>/, out/timing2.log
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
me=$$
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
# A cargo stopped while it holds the lock of a target the timing builds in
# would hold the timing up for ever: wait until none builds in those trees.
busy() {
  for p in $(pgrep -x cargo; pgrep -x rustc); do
    c=$(readlink "/proc/$p/cwd" 2>/dev/null)
    case $c in "$W"*|"$L/snap/F935"*) return 0 ;; esac
  done
  return 1
}
while busy; do sleep 10; done
pids=$(ps -eo pid=,args= | grep -E 'rsuite\.sh|owner2\.sh|inj2\.sh|after_inj\.sh|a6b\.sh|queue2\.sh|inject\.py|xargs -P|cargo |rustc |rtl_probes-|epub_conservation-|epub_fallback-|text_logical_order-|bidi_conformance-|rtl_lines-' \
  | grep -v grep | awk -v me="$me" '$1 != me {print $1}')
cont() { [ -n "$pids" ] && kill -CONT $pids 2>/dev/null; echo "continued: $(echo $pids | wc -w) processes $(date +%T)"; }
trap cont EXIT
[ -n "$pids" ] && kill -STOP $pids 2>/dev/null
echo "stopped: $(echo $pids | wc -w) processes $(date +%T)"
sleep 5
export JOBS=2
for t in 56 snap/F935 tip 56 snap/F935 tip; do
  n=$(echo "$t" | tr '/' '-')
  i=1
  while [ -e "$L/out/time6-$n-$i" ]; do i=$((i + 1)); done
  echo "== $t run $i $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  bash "$L/tools/runat.sh" "$t" default "time6-$n-$i" 'v6time/'
done
echo "timing2 done $(date +%T)"
