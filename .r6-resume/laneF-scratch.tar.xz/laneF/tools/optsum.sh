#!/usr/bin/env bash
# Lane F: everything measured of an owner's option TAG, in one file:
# the suites' banners against 935b077 (ransum), its books against the tip
# kit-A8t (cmp.py, both ways), its tables against the three baselines and the
# tip (opt8.sh), the Left classes and the books worse than 9297d2d/56dfd93
# that the tip does not leave (older8.py), and the shape and case logs.
# usage: optsum.sh TAG   -> out/optsum-TAG.txt
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
T=$1
O=$L/out/optsum-$T.txt
{
  echo "== banners against 935b077"
  python3 -I "$L/tools/ransum.py" "$L/out/rs-$T-default" "$L/out/rs-$T-bundled"
  echo "== against the tip (A = tip, B = $T: 'worse' is $T worse than the tip)"
  python3 -I "$W/tools/probes/rtl/scripts/cmp.py" "$L/out/kit-A8t" "$L/out/kit-$T" --show 40 2>&1 | grep -vE '^\s*$|families only in'
  echo "== the tip against $T ('worse' is the tip worse than $T: $T's gains)"
  python3 -I "$W/tools/probes/rtl/scripts/cmp.py" "$L/out/kit-$T" "$L/out/kit-A8t" --show 40 2>&1 | grep -vE '^\s*$|families only in'
  echo "== tables"
  bash "$L/tools/opt8.sh" "$T" vsA8
  for b in default bundled; do
    echo "== classes $b"
    python3 -I "$W/tools/probes/rtl/scripts/classes.py" "$L/out/table-$T-$b.json" --builds "$b"
  done
  echo "== against 9297d2d and 56dfd93, against 935b077's"
  python3 -I "$L/tools/older8.py" "$T"
  for s in shape cases-default cases-bundled; do
    echo "== $s"
    grep -E '^test result|FAILED|panicked|^exit' "$L/out/owner-$T-$s.log" 2>/dev/null | head -30
  done
} > "$O" 2>&1
echo "optsum $T -> $O"
