"""Lane F: diag/zero.tsv, a targeted sweep for the three rules no case test
caught (page_lines' gap, leading_mark_at's near edge and reads_closer's
overprint check, each in the page's ems): tables and inline blocks whose gaps
are near half an em, marks of no advance opening a styled run, and skewed or
squeezed lines, under transforms of one axis."""
HE = ["שלום", "עולם", "מלחמה", "ספר", "בית", "גדול", "אור", "יום"]
AR = ["كتاب", "مدرسة", "الطالب", "جميل", "بيت", "كبير", "نور", "يوم"]
rows = []
scales = ["scaleX(0.5)", "scaleX(0.7)", "scaleX(2)", "scaleX(3)", "skewX(-15deg)"]
# tables: a Latin cell and a right-to-left one, and two right-to-left ones
for lang, w in (("he", HE), ("ar", AR)):
    for sp in ("4px", "6px", "8px", "10px"):
        for s in scales:
            for shape, cells in (
                ("lat", f"<td>abc (x).</td><td>{w[0]} {w[1]}</td>"),
                ("rtl", f"<td><b>{w[2]}</b> {w[3]}،</td><td>{w[4]} <i>(</i>{w[5]}<i>)</i>.</td>"),
            ):
                style = f"table {{ border-spacing: {sp}; transform: {s} }} td {{ padding: 0; word-spacing: 1em }}"
                rows.append((f"t-{lang}-{shape}-{sp}-{s}", lang, style, f"<table><tr>{cells}</tr></table>"))
# inline blocks of about half an em between words
for lang, w in (("he", HE), ("ar", AR)):
    for width in ("0.3em", "0.4em", "0.6em", "0.8em"):
        for s in scales:
            for d in ("", ' dir="rtl"'):
                body = (f"<p{d}>{w[0]} <b>?!</b><span style=\"display: inline-block; width: {width}\"></span>{w[1]} "
                        f"{w[2]}<span style=\"display: inline-block; width: {width}\"></span>{w[3]}.</p>")
                style = f"p {{ transform: {s}; word-spacing: 0.6em }}"
                rows.append((f"ib-{lang}-{width}-{s}-{'rtl' if d else 'none'}", lang, style, body))
# marks of no advance opening a styled run, letter-spaced
for ls in ("0.2em", "0.3em", "0.4em", "0.6em"):
    for s in scales:
        for name, lang, body in (
            ("lat", "en", "<p>The word cafe<b>́</b> means שלום here.</p>"),
            ("heb", "he", "<p dir=\"rtl\">של<b>ָ</b>ום עולם abc<i>́</i>def.</p>"),
            ("ltr-in-rtl", "he", "<p dir=\"rtl\">שלום abc<b>́d</b>ef עולם.</p>"),
        ):
            style = f"p {{ transform: {s}; letter-spacing: {ls} }}"
            rows.append((f"mk-{name}-{ls}-{s}", lang, style, body))
with open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/zero.tsv', 'w') as f:
    for r in rows:
        f.write('\t'.join(r) + '\n')
print(len(rows), 'books')
