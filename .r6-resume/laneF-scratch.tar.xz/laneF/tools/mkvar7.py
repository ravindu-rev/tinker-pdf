"""Lane F: paint-A7.rs from paint-A6f.rs: a reading of the rules' drawing that
holds the line's letters in order and cuts a word, but runs no two together
(`Read::Cut`), is kept as 935b077 kept it, with no search: a reader parts
letter-spaced text at its spacing, and searching for a drawing it reads whole
spent the whole budget of every such line (`ls-nowrap` of zz_v6_time: 216 ms
at 935b077, 11 897 ms at A6, for 3 528 characters)."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A6f.rs')).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""enum Read {
    /// Its words, each where it was written, and so its letters.
    Words,
    /// Its letters in the order written, with a word cut or two run together.
    Letters,
    /// Anything else.
    Otherwise,
}""", """enum Read {
    /// Its words, each where it was written, and so its letters.
    Words,
    /// Its letters in the order written, with a word cut where the reader
    /// parts it and no two run together.
    Cut,
    /// Its letters in the order written, with two words run together.
    Letters,
    /// Anything else.
    Otherwise,
}""")
rep("""        if read.split_whitespace().eq(self.words.split_whitespace()) {
            Read::Words
        } else {
            Read::Letters
        }
    }""", """        if read.split_whitespace().eq(self.words.split_whitespace()) {
            return Read::Words;
        }
        // Where each word of the line ends, counted in letters: a reading
        // that ends a word at every one of them, and somewhere more, cuts a
        // word and runs none together.
        let ends = |text: &str| -> Vec<usize> {
            text.split_whitespace()
                .scan(0usize, |at, word| {
                    *at += word.chars().count();
                    Some(*at)
                })
                .collect()
        };
        let read_ends = ends(read);
        if ends(&self.words)
            .iter()
            .all(|end| read_ends.binary_search(end).is_ok())
        {
            Read::Cut
        } else {
            Read::Letters
        }
    }""")
rep("""        let reads_right = |chosen: &BTreeMap<RunKey, Drawing>, over_by_rules: usize| {
            tried.set(tried.get() + 1);
            self.read_back(line, matrices, frame, chosen)
                .map(|(read, over)| {
                    if over > over_by_rules {
                        return (false, over);
                    }
                    let right = match written.read_as(&read) {
                        Read::Words => true,
                        Read::Letters => {
                            letters_only
                                .borrow_mut()
                                .get_or_insert_with(|| chosen.clone());
                            false
                        }
                        Read::Otherwise => false,
                    };
                    (right, over)
                })
        };
        match reads_right(&BTreeMap::new(), over_by_rules) {
            Some((false, over)) => over_by_rules = over,
            None | Some((true, _)) => return Search::Rules,
        }""", """        let reads_right = |chosen: &BTreeMap<RunKey, Drawing>, over_by_rules: usize| {
            tried.set(tried.get() + 1);
            self.read_back(line, matrices, frame, chosen)
                .map(|(read, over)| {
                    if over > over_by_rules {
                        return (Read::Otherwise, over);
                    }
                    let how = written.read_as(&read);
                    if matches!(how, Read::Cut | Read::Letters) {
                        letters_only
                            .borrow_mut()
                            .get_or_insert_with(|| chosen.clone());
                    }
                    (how, over)
                })
        };
        match reads_right(&BTreeMap::new(), over_by_rules) {
            // A reading of the rules' drawing that only cuts a word where a
            // reader parts the spacing is kept, as 935b077 kept it: searching
            // for a drawing that reads such a line whole spent the whole
            // budget of every letter-spaced line, to no end on the probes.
            None | Some((Read::Words | Read::Cut, _)) => return Search::Rules,
            Some((_, over)) => over_by_rules = over,
        }""")
rep("""            let one = BTreeMap::from([(key, drawing)]);
            if reads_right(&one, over_by_rules).is_some_and(|(right, _)| right) {
                return Search::Found(one);
            }""", """            let one = BTreeMap::from([(key, drawing)]);
            if reads_right(&one, over_by_rules).is_some_and(|(how, _)| how == Read::Words) {
                return Search::Found(one);
            }""")
rep("""                let two = BTreeMap::from([(first, one), (second, other)]);
                if reads_right(&two, over_by_rules).is_some_and(|(right, _)| right) {
                    return Search::Found(two);
                }""", """                let two = BTreeMap::from([(first, one), (second, other)]);
                if reads_right(&two, over_by_rules).is_some_and(|(how, _)| how == Read::Words) {
                    return Search::Found(two);
                }""")
open(os.path.join(HERE, 'paint-A7.rs'), 'w').write(s)
print('A7 written')
