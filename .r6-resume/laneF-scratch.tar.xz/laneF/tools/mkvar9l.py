"""Lane F: variant A9L of paint.rs: A9, with a drawing the search tries taken
where it reads the line's letters in order, words cut or joined, as 935b077
took it, instead of only where it reads the words: what holding a found
drawing to the line's words buys, and what it costs in time. The rules'
letters reading still ends the search (and is searched in the runs' space
under a transform, taken only where it reads the words on the page).

usage: python3 -I mkvar9l.py   -> variants/paint-A9L.rs
"""
L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
src = open(L + '/variants/paint-A9.rs').read()
old = ".is_some_and(|(how, _)| how == Read::Words) {"
assert src.count(old) == 2, src.count(old)
src = src.replace(old, ".is_some_and(|(how, _)| how != Read::Otherwise) {")
open(L + '/variants/paint-A9L.rs', 'w').write(src)
print('variants/paint-A9L.rs written')
