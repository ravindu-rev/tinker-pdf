#!/usr/bin/env bash
# Lane F: after inj2.sh, the round-6 families at 05cea0b's code (snap/F935:
# the worktree's tests with 05cea0b's paint.rs), both builds: commit 1's claim
# that they read their 935b077 outputs 0/0/0.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^inj done' "$L/out/inj6.out" 2>/dev/null; do sleep 20; done
THREADS=2 bash "$L/tools/rsuite.sh" snap/F935 default F935 '^zz_(v6|f6)_'
THREADS=2 bash "$L/tools/rsuite.sh" snap/F935 bundled F935 '^zz_(v6|f6)_'
echo "after_inj done"
