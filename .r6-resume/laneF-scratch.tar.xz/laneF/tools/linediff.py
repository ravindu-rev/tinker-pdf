"""Lane F: how many data lines of each family dump differ between two runs
(sorted), and up to N of them.

usage: python3 -I linediff.py RUN_A RUN_B BUILD [N]
"""
import os
import sys

a, b, build = sys.argv[1], sys.argv[2], sys.argv[3]
n = int(sys.argv[4]) if len(sys.argv) > 4 else 0
da, db = os.path.join(a, build), os.path.join(b, build)
for f in sorted(os.listdir(db)):
    if not f.endswith('.txt') or not os.path.exists(os.path.join(da, f)):
        continue
    la = set(open(os.path.join(da, f), encoding='utf-8').read().splitlines())
    lb = set(open(os.path.join(db, f), encoding='utf-8').read().splitlines())
    only_a, only_b = sorted(la - lb), sorted(lb - la)
    print(f'{f}: {len(only_a)} lines only in A, {len(only_b)} only in B')
    for x in only_a[:n]:
        print('  A', x[:260])
    for x in only_b[:n]:
        print('  B', x[:260])
