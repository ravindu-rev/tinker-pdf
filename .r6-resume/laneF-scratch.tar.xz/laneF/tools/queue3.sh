#!/usr/bin/env bash
# Lane F: after the A8 suite of BUILD at tip is done, measure the owner's
# options NAMES in turn (owner2.sh, resumable), on the A8 base.
# usage: queue3.sh BUILD NAME...
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
B=$1; shift
until grep -q "^rsuite A8 $B done" "$L/out/rs-A8-$B/progress.txt" 2>/dev/null; do sleep 30; done
for n in "$@"; do
  THREADS=2 JOBS=2 bash "$L/tools/owner2.sh" "$n" > "$L/out/owner2-$n.out" 2>&1
  echo "owner2 $n exit $?"
done
echo "queue3 $B done"
