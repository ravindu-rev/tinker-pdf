#!/usr/bin/env bash
# Lane F: copy the lane F worktree (no target, no .git) to laneF/snap/NAME, for runs while the worktree moves on.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
rm -rf "$L/snap/$1"
mkdir -p "$L/snap/$1"
( cd "$W" && tar --exclude=./target --exclude=./.git -cf - . ) | ( cd "$L/snap/$1" && tar -xf - )
echo "snap $1: $(find "$L/snap/$1" -type f | wc -l) files"
sha256sum "$L/snap/$1/crates/tinker-pdf/src/epub/paint.rs"
