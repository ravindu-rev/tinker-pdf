"""Lane F: add the A5 rules' injections to variants/laneF-injections.json."""
import json

P = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants/laneF-injections.json'
SUITE = [["cargo", "test", "--no-fail-fast", "-p", "tinker-pdf", "--test", "epub_conservation", "--test", "epub_fallback"]]
d = json.load(open(P))
have = {x['name'] for x in d}
new = [
    ("page/closer-unchecked",
     "        over <= over_by_rules && written.pairs_in(&read) > written.pairs_in(&rules)",
     "        true"),
    ("page/closer-overprint-unchecked",
     "        over <= over_by_rules && written.pairs_in(&read) > written.pairs_in(&rules)",
     "        written.pairs_in(&read) > written.pairs_in(&rules)"),
    ("page/mark-in-the-runs-ems",
     "font_size * RESUMED_WITHIN / along",
     "font_size * RESUMED_WITHIN"),
]
for name, old, rep in new:
    if name in have:
        continue
    d.append({
        "name": name,
        "round": "the read-back's page (lane F, round 6)",
        "edits": [{"file": "crates/tinker-pdf/src/epub/paint.rs", "old": old, "new": rep, "count": 1}],
        "suites": SUITE,
    })
json.dump(d, open(P, 'w'), indent=1, ensure_ascii=False)
print(len(d), 'lane F injections')
