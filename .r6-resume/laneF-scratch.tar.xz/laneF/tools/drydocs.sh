#!/usr/bin/env bash
# Lane F: apply docs6.py's steps to copies of the worktree's docs (dry run).
# usage: drydocs.sh [placeholders]   (with "placeholders", numbers6.json is
# written with <name> values first)
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
rm -rf "$L/dry"
mkdir -p "$L/dry/docs/features"
cp "$W/docs/ROADMAP.md" "$L/dry/docs/"
cp "$W/docs/features/epub.md" "$L/dry/docs/features/"
if [ "${1:-}" = placeholders ]; then
  python3 -I - "$L/numbers6.json" <<'EOF'
import json, sys
keys = ('v1_hunt_d v1_hunt_b r6_books all_books gain_d gain_b cons_gain_d cons_gain_b left6_d left6_b '
        'v2_d v2_b v3_d v3_b t_h1_tip t_h1_56 t_h1_935 t_h1_chars t_prose_tip t_prose_56 t_prose_935 '
        't_dirless_tip t_dirless_56 t_dirless_935 t_growth v5_d v5_b v5_cost').split()
json.dump({k: '<' + k + '>' for k in keys}, open(sys.argv[1], 'w'))
EOF
fi
for s in fix v2v3 v4v5; do
  python3 -I "$L/tools/docs6.py" "$L/dry" "$s" || exit 1
done
