"""Lane F: cmp.py of kit B against kit A, totalled per build: books worse and
better, overprint rises, and the families with gains.

usage: python3 -I cmptot.py KIT_A KIT_B
"""
import re
import subprocess
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
out = subprocess.run(['python3', '-I', W + '/tools/probes/rtl/scripts/cmp.py', sys.argv[1], sys.argv[2], '--show', '0'],
                     capture_output=True, text=True).stdout
R = re.compile(r'^(\w+) (\S+): rows (\d+)/(\d+) missing (\d+): worse (\d+), better (\d+), overprint rose (\d+)')
tot = {}
for line in out.splitlines():
    m = R.match(line)
    if not m:
        continue
    b = m.group(1)
    t = tot.setdefault(b, dict(rows=0, miss=0, worse=0, better=0, rose=0, fams={}))
    t['rows'] += int(m.group(3))
    t['miss'] += int(m.group(5))
    t['worse'] += int(m.group(6))
    t['better'] += int(m.group(7))
    t['rose'] += int(m.group(8))
    if int(m.group(7)) or int(m.group(6)):
        t['fams'][m.group(2)] = (int(m.group(7)), int(m.group(6)))
for b, t in tot.items():
    fams = ', '.join(f'{f} +{g}' + (f'/-{w}' if w else '') for f, (g, w) in sorted(t['fams'].items(), key=lambda x: -x[1][0]))
    print(f"{b}: rows {t['rows']} missing {t['miss']} worse {t['worse']} better {t['better']} overprint rose {t['rose']}")
    print(f"   {fams}")
