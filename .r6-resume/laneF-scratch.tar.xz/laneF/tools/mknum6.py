"""Lane F: the numbers the docs of the fold quote, from the final runs.

usage: python3 -I mknum6.py   -> laneF/numbers6.json (merged with what is there)

Reads out/rs-A7-{default,bundled}/summary.txt (RAN lines), out/table-A7-{build}.json
(table.py --json of kit-A7 against the three baselines) through classes.py, and
out/time3-A7.txt (time3.py). Keys it cannot fill keep their old value.
"""
import json
import os
import re
import subprocess
import sys

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
P = os.path.join(L, 'numbers6.json')
N = json.load(open(P)) if os.path.exists(P) else {}


def fmt(n):
    return f'{n:,}'.replace(',', ' ') if n >= 10000 else str(n)


RAN = re.compile(r'RAN rtl_probes (\S+) \[(\w+)\] against \w+: (\d+) rows \(the baseline has (\d+)\), (\d+) books worse, (\d+) books better')
tot = {}
for build in ('default', 'bundled'):
    p = os.path.join(L, 'out', f'rs-A7-{build}', 'summary.txt')
    if not os.path.exists(p):
        continue
    rows = r6 = better = worse = fams = 0
    for line in open(p):
        m = RAN.search(line)
        if not m:
            continue
        fams += 1
        r = int(m.group(3))
        rows += r
        if re.match(r'zz_(v6|f6)_', m.group(1)):
            r6 += r
        worse += int(m.group(5))
        better += int(m.group(6))
    tot[build] = dict(rows=rows, r6=r6, better=better, worse=worse, fams=fams)
print(tot)
if 'default' in tot:
    N['all_books'] = fmt(tot['default']['rows'])
    N['r6_books'] = fmt(tot['default']['r6'])
    N['gain_d'] = fmt(tot['default']['better'])
if 'bundled' in tot:
    N['gain_b'] = fmt(tot['bundled']['better'])

# classes per build
cls = {}
for build in ('default', 'bundled'):
    tj = os.path.join(L, 'out', f'table-A7-{build}.json')
    if not os.path.exists(tj):
        continue
    out = subprocess.run([sys.executable, '-I', os.path.join(W, 'tools/probes/rtl/scripts/classes.py'), tj, '--builds', build],
                         capture_output=True, text=True).stdout
    for line in out.splitlines():
        m = re.match(r'^(.+?)\tbooks (\d+),', line)
        if m:
            cls.setdefault(build, {})[m.group(1)] = int(m.group(2))
print(json.dumps(cls, indent=1))
for key, name in (('left6', 'Left (6) half turn'), ('v2', 'V2 closing bracket at the left end'), ('v3', 'V3 touching right-to-left cells')):
    if 'default' in cls:
        N[key + '_d'] = str(cls['default'].get(name, 0))
    if 'bundled' in cls:
        N[key + '_b'] = str(cls['bundled'].get(name, 0))
json.dump(N, open(P, 'w'), ensure_ascii=False, indent=1)
print('numbers6.json:', json.dumps(N, ensure_ascii=False))
