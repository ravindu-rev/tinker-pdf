#!/usr/bin/env bash
# Lane F: zz_v6_time in debug at snap/A9 (the rules' letters reading ends the
# search, as at 935b077), twice, on a quiet machine, to set beside timing3's
# runs of 56dfd93, 05cea0b's code, the tip (A8) and the cut search.
# usage: timing9.sh   -> out/time8-snap-A9-<i>/
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
if pgrep -f 'rtl_probes-|epub_conservation-|epub_fallback-|inject\.py|rsuite|owner3|queue6' > /dev/null; then
  echo "refusing: another lane F job runs"; exit 3
fi
export JOBS=4
for t in snap/A9 snap/A9; do
  n=$(echo "$t" | tr '/' '-')
  i=1
  while [ -e "$L/out/time8-$n-$i" ]; do i=$((i + 1)); done
  echo "== $t run $i $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  bash "$L/tools/runat.sh" "$t" default "time8-$n-$i" 'v6time/'
done
echo "timing9 done $(date +%T)"
