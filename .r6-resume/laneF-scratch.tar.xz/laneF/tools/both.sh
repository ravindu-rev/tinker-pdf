#!/usr/bin/env bash
# Lane F: put variant VARIANT in paint.rs and run the whole suite in both
# builds, with the kit dump in out/kit-TAG. Leaves VARIANT in place.
# usage: both.sh VARIANT TAG
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
"$L/tools/swap.sh" "$1" || exit 1
rm -rf "$L/out/kit-$2"
"$L/tools/suite.sh" tip default "$2"
"$L/tools/suite.sh" tip bundled "$2"
echo "both $1 $2 done"
