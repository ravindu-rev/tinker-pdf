"""Lane F: write numbers.json, the doc edits of each commit, from the measured
values in values.json (laneF/values.json)."""
import json

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
V = json.load(open(L + '/values.json'))
EPUB_V1 = open(L + '/draft-epub-v1.md').read().rstrip('\n')
EPUB_V1 = EPUB_V1.replace('MEASURED: ...\nCOST: ...', V['epub_v1_measured'])

ANCHOR_RB = "`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n"

v1 = {
    'epub.md': [
        [ANCHOR_RB, ANCHOR_RB + EPUB_V1 + '\n'],
    ] + V['epub_v1_extra'],
    'ROADMAP.md': V['roadmap_v1'],
}
v2v3 = {'ROADMAP.md': V['roadmap_v2v3'], 'epub.md': V['epub_v2v3']}
v4v5 = {'ROADMAP.md': V['roadmap_v4v5'], 'epub.md': V['epub_v4v5']}
json.dump({'v1': v1, 'v2v3': v2v3, 'v4v5': v4v5}, open(L + '/numbers.json', 'w'), indent=1, ensure_ascii=False)
print('numbers.json written')
