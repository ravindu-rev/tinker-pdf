"""Lane F: group the books leftset.py --json found worse than 9297d2d or
56dfd93 (field: now, at935, new or fixed) by family and shape, per build.

usage: python3 -I leftgroups.py LEFT.json FIELD [--families REGEX]
"""
import collections
import json
import re
import sys

d = json.load(open(sys.argv[1]))
field = sys.argv[2]
rx = re.compile(sys.argv[4]) if len(sys.argv) > 4 and sys.argv[3] == '--families' else None
out = collections.defaultdict(lambda: collections.Counter())
for key, v in d.items():
    build, fam = key.split('\t')
    if rx and not rx.search(fam):
        continue
    for k in v[field]:
        parts = k.split('\t')
        name = parts[1] if len(parts) > 1 else parts[0]
        shape = '/'.join(p for i, p in enumerate(name.split('/')) if not (i == 0 and p in ('ar', 'he', 'fa', 'ur', 'yi', 'syr', 'en')))
        out[(fam, shape)][build] += 1
tot = collections.Counter()
for (fam, shape), c in sorted(out.items()):
    print(f"{fam:28} {shape[:60]:60} {c['default']:>5} ({c['bundled']})")
    tot.update(c)
print(f"{'TOTAL':28} {'':60} {tot['default']:>5} ({tot['bundled']})")
