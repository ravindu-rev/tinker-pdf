"""Lane F: paint.rs variants of paint-A4f.rs, one rule each.

A4nf: no fallback to the runs' space (Search::Nothing under a transform is Nothing)
A4vf: the fallback's drawing is taken only where, read back on the page, it
      reads the line's letters in the order written (or its words), as no
      drawing the page search tried did, so never where it reads otherwise on the page
"""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
BASE = open(os.path.join(HERE, 'paint-A4f.rs')).read()


def rep(s, old, new):
    assert s.count(old) == 1, (s.count(old), old[:120])
    return s.replace(old, new)


nf = rep(BASE, "                Search::Nothing if matrices.iter().any(|matrix| *matrix != IDENTITY) => {",
         "                Search::Nothing if false => {")
open(os.path.join(HERE, 'paint-A4nf.rs'), 'w').write(nf)
print('A4nf written')
