"""Lane F: insert the V1 paragraph (draft-epub-v1.md) into epub.md after the
read-back paragraph. Idempotent: refuses if already there."""
P = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/docs/features/epub.md'
D = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/draft-epub-v1.md'
s = open(P).read()
para = open(D).read().rstrip('\n') + '\n'
anchor = "`a_line_a_reader_cuts_where_it_is_spaced_apart_is_drawn_to_read_whole`).\n"
assert s.count(anchor) == 1
assert 'read back on the page it is drawn on' not in s
s = s.replace(anchor, anchor + para)
open(P, 'w').write(s)
print('inserted')
