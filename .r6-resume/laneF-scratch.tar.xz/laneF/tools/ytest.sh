#!/usr/bin/env bash
# Lane F: in snap/Y, the worktree's tests and variants/paint-VARIANT.rs; run
# one test of epub_fallback in the default build (and bundled with B=1).
# usage: ytest.sh VARIANT TESTNAME TAG
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
Y=$L/snap/Y
rm -rf "$Y/crates/tinker-pdf/tests"
cp -r "$W/crates/tinker-pdf/tests" "$Y/crates/tinker-pdf/tests"
cp "$L/variants/paint-$1.rs" "$Y/crates/tinker-pdf/src/epub/paint.rs"
cd "$Y" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/Y-target
builds="default"
[ "${B:-0}" = 1 ] && builds="default bundled"
for b in $builds; do
  FEAT=""
  [ "$b" = bundled ] && FEAT="--features bundled-fonts"
  O="$L/tlog/$3-$b.txt"
  # shellcheck disable=SC2086
  cargo test -p tinker-pdf $FEAT --test epub_fallback -- --exact "$2" > "$O" 2>&1
  echo "exit $?" >> "$O"
  echo "== $3 $b: $(grep -E '^test result' "$O" | tr '\n' ' ') $(tail -1 "$O")"
done
