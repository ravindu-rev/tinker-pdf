"""Lane F: epub_fallback.rs's cuts-or-joins test for A9L: a drawing that reads
the line's letters in order is taken, as 935b077 took it; the shapes that
holding a drawing to the words, or searching past the rules' joined reading,
reads whole are pinned for the owner."""
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
P = W + '/crates/tinker-pdf/tests/epub_fallback.rs'
s = open(P, encoding='utf-8').read()
start = s.index("/// **A reading that cuts a word or runs two together is not the line's\n")
end = s.index("/// **A line whose right drawing lies past the read-back's budget is drawn by\n")
new = '''/// **A reading that cuts a word or runs two together is taken for the line's
/// text, as 935b077 took it** (round 6's lane F, the sweep of V1's class),
/// pinned.
///
/// The read-back holds a reading to the line's letters, white space aside,
/// as 935b077 held it: a drawing that a reader reads with a word run into
/// the next, or cut, is taken for the line's text (`paint::Read::Letters`).
/// A styled `?!` glued to a Hebrew word at `word-spacing: 0.6em` conserves
/// and reads `שלום?! עולם.`, its word space gone, in a default build, as at
/// 935b077; a sign after European digits before a bold word at
/// `word-spacing: 1em`, which a reader runs into the word before it on the
/// rules' drawing, reads `كتاب25٪`; and so does an Arabic paragraph of styled
/// stops and brackets at `line-height: 0.6`. Holding each drawing tried to
/// the line's words reads the first and the last whole, and searching on
/// past the rules' drawing where it runs two words together reads the
/// second whole; each costs a justified paragraph of such lines some times
/// its time to open, the owner's to price (ROADMAP CD-19). Under
/// `scaleY(2)`, letter-spaced and justified, three such number sentences
/// read whole (a guard).
#[test]
fn a_reading_that_cuts_or_joins_a_word_is_taken_as_935b077_took_it() {
    let joined = Expect::Pinned("cons logical found apart");
    check(&[
        Case::each(
            "a styled ?! glued to a Hebrew word at 0.6em",
            "he",
            "p { word-spacing: 0.6em }",
            "<p dir=\\"rtl\\">שלום <b>?!</b> עולם.</p>",
            joined,
            Expect::Holds("cons logical whole found apart"),
        ),
        Case::each(
            "the same under scale(2)",
            "he",
            "p { transform: scale(2); word-spacing: 0.6em }",
            "<p dir=\\"rtl\\">שלום <b>?!</b> עולם.</p>",
            joined,
            Expect::Holds("cons logical whole found apart"),
        ),
        Case::both("a sign after European digits before a bold word at 1em", "ar", "p { margin: 0 30%; word-spacing: 1em }", format!("<p dir=\\"rtl\\">{}</p>", signs_and_numbers(1)), joined),
        Case::both("two such sentences at 1em", "ar", "p { margin: 0 30%; word-spacing: 1em }", format!("<p dir=\\"rtl\\">{}</p>", signs_and_numbers(2)), joined),
        Case::both("the punctuation shape at line-height 0.6", "ar", "p { margin: 0 30%; line-height: 0.6; word-spacing: 0.6em }", format!("<p dir=\\"rtl\\">{}</p>", styled_marks(&AR)), joined),
        Case::both(
            "three number sentences under scaleY(2), letter-spaced and justified (guard)",
            "ar",
            "p { margin: 0 30%; transform: scaleY(2); letter-spacing: 0.1em; word-spacing: 0.5em; text-align: justify }",
            format!("<p dir=\\"rtl\\">{}</p>", signs_and_numbers(3)),
            Expect::Holds("cons logical whole found"),
        ),
    ]);
}

'''
s = s[:start] + new + s[end:]
open(P, 'w', encoding='utf-8').write(s)
print('cuts-or-joins test rewritten for A9L')
