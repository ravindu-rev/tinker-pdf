"""Lane F: paint-A9Ld.rs = the worktree's paint.rs (A9L) with each drawing read
once (the V5 option, the owner's: A8d's change carried over to the committed
base). Also saves the worktree's paint.rs as variants/paint-A9Lf.rs."""
import os

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
s = open(os.path.join(W, 'crates/tinker-pdf/src/epub/paint.rs')).read()
open(os.path.join(L, 'variants', 'paint-A9Lf.rs'), 'w').write(s)
old = """            let options: Vec<(RunKey, Drawing)> = line
                .iter()
                .flat_map(|run| drawings_of(run, self.along(run)))
                .collect();
"""
new = """            let mut options: Vec<(RunKey, Drawing)> = Vec::new();
            for run in &line {
                let mut planned: Vec<Vec<Vec<Segment>>> =
                    vec![self.plan_run(run, Drawing::default()).unwrap_or_default()];
                for (key, drawing) in drawings_of(run, self.along(run)) {
                    let plan = self.plan_run(run, drawing).unwrap_or_default();
                    if !planned.contains(&plan) {
                        planned.push(plan);
                        options.push((key, drawing));
                    }
                }
            }
"""
assert s.count(old) == 1
s = s.replace(old, new)
open(os.path.join(L, 'variants', 'paint-A9Ld.rs'), 'w').write(s)
print('paint-A9Lf.rs and paint-A9Ld.rs written')
