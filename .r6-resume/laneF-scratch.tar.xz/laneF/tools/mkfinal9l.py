"""Lane F: the worktree's paint.rs from A9 to A9L in its final form: a drawing
the search tries is taken where it reads the line's letters in order, as
935b077 took it (the letters-only fallback, never reached then, goes).

usage: python3 -I mkfinal9l.py
"""
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
P = W + '/crates/tinker-pdf/src/epub/paint.rs'
s = open(P, encoding='utf-8').read()


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:120]
    s = s.replace(old, new)


sub("""    /// [`Fonts::set_readings`]'s search for one line under `matrices`: the
    /// rules' drawing where it reads the line's words right, and
    /// [`Search::Letters`] where it reads its letters in order; else the
    /// first drawing of one run, then of two, within [`READINGS_PER_LINE`]
    /// readings, that reads the words right; else the first that reads the
    /// letters in order; else nothing. A drawing that sets more glyphs over
    /// others than the rules' is never taken.
""", """    /// [`Fonts::set_readings`]'s search for one line under `matrices`: the
    /// rules' drawing where it reads the line's words right, and
    /// [`Search::Letters`] where it reads its letters in order; else the
    /// first drawing of one run, then of two, within [`READINGS_PER_LINE`]
    /// readings, that reads the letters in order, as 935b077 took it; else
    /// nothing. A drawing that sets more glyphs over others than the rules'
    /// is never taken.
""")
sub("""        let tried = std::cell::Cell::new(0usize);
        // The first drawing that reads the line's letters right but not
        // its words, kept where none reads both.
        let letters_only: std::cell::RefCell<Option<BTreeMap<RunKey, Drawing>>> =
            std::cell::RefCell::new(None);
        // How many glyphs""", """        let tried = std::cell::Cell::new(0usize);
        // How many glyphs""")
sub("""                    if over > over_by_rules {
                        return (Read::Otherwise, over);
                    }
                    let how = written.read_as(&read);
                    if how == Read::Letters {
                        letters_only
                            .borrow_mut()
                            .get_or_insert_with(|| chosen.clone());
                    }
                    (how, over)
                })
        };""", """                    if over > over_by_rules {
                        return (Read::Otherwise, over);
                    }
                    (written.read_as(&read), over)
                })
        };""")
old_one = """            if reads_right(&one, over_by_rules).is_some_and(|(how, _)| how == Read::Words) {
                return Search::Found(one);
            }"""
new_one = """            // A drawing that reads the line's letters in order is taken, as
            // 935b077 took it, though a reader cut a word of it or ran two
            // together: holding it to the words spends the whole budget of
            // many a line no drawing reads whole, a cost in time that is the
            // owner's to price (ROADMAP CD-19).
            if reads_right(&one, over_by_rules).is_some_and(|(how, _)| how != Read::Otherwise) {
                return Search::Found(one);
            }"""
sub(old_one, new_one)
sub("""                if reads_right(&two, over_by_rules).is_some_and(|(how, _)| how == Read::Words) {
                    return Search::Found(two);
                }
            }
        }
        let first = letters_only.borrow_mut().take();
        first.map_or(Search::Nothing, Search::Found)
    }""", """                if reads_right(&two, over_by_rules).is_some_and(|(how, _)| how != Read::Otherwise) {
                    return Search::Found(two);
                }
            }
        }
        Search::Nothing
    }""")
open(P, 'w', encoding='utf-8').write(s)
print('paint.rs: A9L final form written')
