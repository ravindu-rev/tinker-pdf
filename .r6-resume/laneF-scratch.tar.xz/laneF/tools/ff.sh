#!/usr/bin/env bash
# Lane F: a test at the tip and at base935 (failing first), in the builds asked.
# usage: ff.sh FILE FILTER BUILDS...   (copies the tip's FILE into base935 first)
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
F=$1; N=$2; shift 2
cp "$W/crates/tinker-pdf/tests/$F.rs" "$L/base935/crates/tinker-pdf/tests/$F.rs"
for b in "$@"; do
  echo "== tip $b"
  "$L/tools/t.sh" "$F" "$N" "$b"
  echo "== 935 $b"
  TAG=935 TW=$L/base935 TT=$L/base935-target "$L/tools/t.sh" "$F" "$N" "$b"
done
