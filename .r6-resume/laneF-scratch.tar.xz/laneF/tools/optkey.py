"""Lane F: the key figures of an owner's option TAG against the tip (A8t),
per build: books worse and better than the tip (cmp.py), the RAN totals
against 935b077, the Left classes that grew or shrank, the books worse than
9297d2d or 56dfd93 that 935b077 did not leave, the line suites, and the
shape and case tests.

usage: python3 -I optkey.py TAG   (after optsum.sh TAG)
"""
import json
import os
import re
import subprocess
import sys

L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4'
tag = sys.argv[1]
text = open(os.path.join(L, 'out', f'optsum-{tag}.txt'), encoding='utf-8').read()
part = text.split('== the tip against')[0]
for build in ('default', 'bundled', 'lines'):
    worse = better = 0
    fams_w, fams_b = [], []
    for m in re.finditer(rf'^{build} (\S+): .*?worse (\d+), better (\d+)', part, re.M):
        w, b = int(m.group(2)), int(m.group(3))
        worse += w
        better += b
        if w:
            fams_w.append(f'{m.group(1)} {w}')
        if b:
            fams_b.append(f'{m.group(1)} {b}')
    print(f'{build}: against the tip, worse {worse}, better {better}')
    print(f'   worse in: {", ".join(fams_w)}')
    print(f'   better in: {", ".join(fams_b)}')


def classes(t, build):
    out = subprocess.run([sys.executable, '-I', os.path.join(W, 'tools/probes/rtl/scripts/classes.py'),
                          os.path.join(L, 'out', f'table-{t}-{build}.json'), '--builds', build],
                         capture_output=True, text=True).stdout
    c = {}
    for line in out.splitlines():
        m = re.match(r'^(.+?)\tbooks (\d+),', line)
        if m:
            c[m.group(1)] = int(m.group(2))
    return c


for build in ('default', 'bundled'):
    a, b = classes('A8t', build), classes(tag, build)
    moved = [f'{k} {a.get(k, 0)} -> {b.get(k, 0)}' for k in sorted(set(a) | set(b)) if a.get(k, 0) != b.get(k, 0)]
    print(f'{build} classes moved: ' + '; '.join(moved))
m = re.search(r'== banners against 935b077\n(.*?)\n==', text, re.S)
print(m.group(1) if m else '')
m = re.search(r'== against 9297d2d and 56dfd93.*?\n(.*?)\n== shape', text, re.S)
print('\n'.join(l for l in (m.group(1) if m else '').splitlines() if l.startswith(('default', 'bundled'))))
for s in ('shape', 'cases-default', 'cases-bundled'):
    p = os.path.join(L, 'out', f'owner-{tag}-{s}.log')
    if not os.path.exists(p):
        continue
    t = open(p, encoding='utf-8', errors='replace').read()
    failed = re.findall(r'^test (\S+) \.\.\. FAILED', t, re.M)
    res = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed', t, re.M)
    print(f'{s}: results {res}; failed {sorted(set(failed))}')
