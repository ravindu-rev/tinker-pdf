#!/usr/bin/env bash
# Lane F: measure an owner's option in snap/NAME (a copy of the worktree with
# the option's file swapped in), resumably, optimised (rsuite2.sh REL=1; an
# optimised build reads every book as a debug one does, tools/val.sh): both
# rtl_probes suites, rtl_lines, bidi_conformance and fingerprints, and the case
# tests in both builds. A step whose log ends in its exit line is not run again.
# usage: owner3.sh NAME   -> out/rs-NAME-{default,bundled}/, out/kit-NAME/,
#                            out/owner-NAME-{shape,cases-default,cases-bundled}.log
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
N=$1
export THREADS=${THREADS:-2} JOBS=${JOBS:-2} REL=1
bash "$L/tools/rsuite2.sh" "snap/$N" default "$N"
bash "$L/tools/rsuite2.sh" "snap/$N" bundled "$N"
cd "$L/snap/$N" || exit 2
export CARGO_BUILD_JOBS=$JOBS CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=$L/rel-target
export CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16
step() {
  local log=$1; shift
  if tail -1 "$log" 2>/dev/null | grep -q '^exit '; then return; fi
  "$@" > "$log" 2>&1
  echo "exit $?" >> "$log"
}
step "$L/out/owner-$N-shape.log" cargo test --release -p tinker-pdf-shape --test bidi_conformance --test fingerprints
step "$L/out/owner-$N-cases-default.log" cargo test --release --no-fail-fast -p tinker-pdf --test epub_conservation --test epub_fallback --test text_logical_order
step "$L/out/owner-$N-cases-bundled.log" cargo test --release --no-fail-fast -p tinker-pdf --features bundled-fonts --test epub_conservation --test epub_fallback --test text_logical_order
echo "owner $N done"
