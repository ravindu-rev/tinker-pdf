#!/usr/bin/env bash
# Lane F: the f6_ems family at the three baselines, both builds, one after the other.
set -u
T=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/tools
"$T/runat.sh" snap/F935 both ems-935 'zz_f6_ems$'
"$T/runat.sh" 56 both ems-56 'zz_f6_ems$'
"$T/runat.sh" 9297 both ems-9297 'zz_f6_ems$'
echo "emsbases done"
