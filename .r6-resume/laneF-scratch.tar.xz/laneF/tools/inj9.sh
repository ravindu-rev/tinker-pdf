#!/usr/bin/env bash
# Lane F: failing-first, then counted injections, at the committed code (A9L).
# 1. ff2.sh F935 935: the worktree's case tests with 05cea0b's paint.rs.
# 2. snap/INJ (a fresh copy of the worktree; F935-target becomes INJ-target),
#    the control and every rule lane F adds (catalogue names below), each
#    with its catalogue suites, both builds -> out/inj9/summary-{build}.txt.
# Resumable: inject.py's summaries name what is complete.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
O=$L/out/inj9
echo "inj9 start $(date +%T)"
if [ ! -f "$L/out/ff-F935-bundled.log" ] || ! tail -1 "$L/out/ff-F935-bundled.log" | grep -q '^exit' || [ "${FF:-1}" = 1 ]; then
  JOBS=${JOBS:-2} bash "$L/tools/ff2.sh" F935 935
fi
mkdir -p "$O"
if [ ! -f "$O/summary-default.txt" ] && [ ! -f "$O/summary-bundled.txt" ]; then
  rm -rf "$L/snap/INJ"
  bash "$L/tools/snap.sh" INJ
  [ -d "$L/snap/INJ-target" ] || mv "$L/snap/F935-target" "$L/snap/INJ-target"
fi
W=$L/snap/INJ
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$L/snap/INJ-target
NAMES="control no-pairs lines-touching page/read-back-under-no-matrix page/rules-in-the-runs-ems page/along-inverted page/parted-in-the-runs-ems page/lines-cut-in-the-runs-ems page/read-as-typed page/letters-are-enough page/letters-searched page/letters-kept-under-a-transform page/whole-unchecked page/no-fallback-to-the-runs-space page/overprint-taken page/closer-unchecked"
cd "$W" || exit 2
for b in default bundled; do
  todo=""
  for n in $NAMES; do
    grep -q "^$n $b fires .* complete=True" "$O/summary-$b.txt" 2>/dev/null || todo="$todo $n"
  done
  if [ -z "$todo" ]; then echo "inject $b already done"; continue; fi
  # shellcheck disable=SC2086
  python3 -I tools/probes/rtl/scripts/inject.py run "$W" "$O" --build "$b" $todo >> "$O/run-$b.log" 2>&1
  echo "inject $b exit $?"
done
sha256sum "$W/crates/tinker-pdf/src/epub/paint.rs"
echo "inj9 done $(date +%T)"
