#!/usr/bin/env bash
# Lane F: pack the assembled new-family runs at 9297d2d and 56dfd93 into the kit's baselines.
set -u
R=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6
A=$R/laneF/asm
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
cd "$W" || exit 2
for t in 9297d2d 56dfd93; do
  rm -rf "$R/laneF/pack/$t"
  python3 -I tools/probes/rtl/scripts/pack.py "$A/$t" "$R/laneF/pack/$t" \
    --note "{family} at $t, {build}: run with scripts/run.sh on 16 October 2026 (round 6)" || exit 1
  cp "$R/laneF/pack/$t"/default/*.xz "tools/probes/rtl/baselines/$t/default/"
  cp "$R/laneF/pack/$t"/bundled/*.xz "tools/probes/rtl/baselines/$t/bundled/"
done
du -sh tools/probes/rtl/baselines/*
