#!/usr/bin/env bash
# Lane F: the rtl_probes suite (and, default build with no filter, rtl_lines)
# at a tree, with the kit dump.
# usage: suite.sh TREE BUILD TAG [FILTER...]
#   TREE: tip | 935 | snap/<name>; BUILD: default | bundled
#   writes laneF/out/suite-TAG-BUILD.log and the kit dump laneF/out/kit-TAG/
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  935) W=$L/base935; T=$L/base935-target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
B=$2; TAG=$3; shift 3
FEAT=""
[ "$B" = bundled ] && FEAT="--features bundled-fonts"
mkdir -p "$L/out/kit-$TAG"
O="$L/out/suite-$TAG-$B.log"
cd "$W" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
export TINKER_RTL_KIT_OUT=$L/out/kit-$TAG
start=$(date +%s)
# shellcheck disable=SC2086
cargo test -p tinker-pdf $FEAT --test rtl_probes -- --ignored --nocapture --test-threads=${THREADS:-3} "$@" > "$O" 2>&1
code=$?
end=$(date +%s)
echo "exit $code seconds $((end - start))" >> "$O"
if [ "$B" = default ] && [ $# -eq 0 ]; then
  cargo test -p tinker-pdf-shape --test rtl_lines -- --ignored --nocapture > "$O.lines" 2>&1
  echo "exit $?" >> "$O.lines"
fi
echo "suite $TAG $B: exit $code, $((end - start)) s, RAN $(grep -c '^RAN rtl_probes' "$O")"
grep '^RAN rtl_probes' "$O" | grep -v ' 0 books worse, 0 books better, 0 changed' | cut -c1-220
