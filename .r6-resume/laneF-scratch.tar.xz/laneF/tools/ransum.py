"""Lane F: the RAN lines of an rsuite run directory, totalled, with every family
whose banner is missing or says a book is worse, and the test results.

usage: python3 -I ransum.py out/rs-TAG-BUILD [...]
"""
import glob
import os
import re
import sys

RAN = re.compile(r'RAN rtl_probes (\S+) \[(\w+)\] against (\w+): (\d+) rows \(the baseline has (\d+)\), (\d+) books worse, (\d+) books better, (\d+) changed without a verdict')
for d in sys.argv[1:]:
    fams = [l.strip() for l in open(os.path.join(d, 'families.txt')) if l.strip()]
    rows = base = worse = better = changed = 0
    ran = 0
    bad = []
    for f in fams:
        p = os.path.join(d, f + '.log')
        if not os.path.exists(p):
            bad.append(f + ' (no log)')
            continue
        text = open(p, encoding='utf-8', errors='replace').read()
        m = RAN.search(text)
        ok = re.search(r'^test result: ok\. 1 passed', text, re.M)
        if not m:
            bad.append(f + ' (no RAN)')
            continue
        ran += 1
        r, b, w, g, c = (int(m.group(i)) for i in (4, 5, 6, 7, 8))
        rows += r
        base += b
        worse += w
        better += g
        changed += c
        if w or not ok or r != b:
            bad.append(f'{f} rows {r}/{b} worse {w} ok {bool(ok)}')
    print(f'{d}: {len(fams)} families, {ran} RAN, rows {rows} (baseline {base}), worse {worse}, better {better}, changed {changed}')
    for b in bad:
        print('   ', b)
    lines = os.path.join(d, 'rtl_lines.log')
    if os.path.exists(lines):
        t = open(lines, encoding='utf-8', errors='replace').read()
        n = len(re.findall(r'^RAN rtl_lines', t, re.M))
        print(f'    rtl_lines: {n} RAN, last line {t.strip().splitlines()[-1]!r}')
