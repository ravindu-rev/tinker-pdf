#!/usr/bin/env bash
# Lane F: the gates at the tip, lane K's (laneK/gates.sh: fmt, clippy, clippy
# with bundled-fonts, tinker-pdf's tests in the default, bundled-fonts and
# no-default-features builds, tinker-pdf-shape's, xtask check, clippy on the
# 1.99.0 toolchain in both builds), then tinker-pdf-font with no default
# features and the determinism suite on wasm32-wasip1.
# usage: gates8.sh   -> out/gates8/
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
K=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneK
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
O=$L/out/gates8
bash "$K/gates.sh" "$W" "$O" fmt clippy clippy-bundled test-default test-bundled test-nodefault test-shape xtask clippy199 clippy199-bundled
rm -f "$O/done"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$W/target
cd "$W" || exit 2
step() {
  local name=$1; shift
  echo "$(date -u +%FT%TZ) start $name" >> "$O/progress"
  "$@" > "$O/$name.log" 2>&1
  echo $? > "$O/$name.exit"
  echo "$(date -u +%FT%TZ) end $name exit $(cat "$O/$name.exit")" >> "$O/progress"
}
step test-font-nodefault cargo test --no-fail-fast -p tinker-pdf-font --no-default-features
find "$W/target/debug/deps" -maxdepth 1 -type f -perm -u+x -delete 2>/dev/null
step test-wasm-determinism env CARGO_TARGET_WASM32_WASIP1_RUNNER=/root/.local/bin/wasmtime cargo test -p tinker-pdf --test determinism --target wasm32-wasip1
rm -rf "$W/target/wasm32-wasip1"
echo done > "$O/done"
