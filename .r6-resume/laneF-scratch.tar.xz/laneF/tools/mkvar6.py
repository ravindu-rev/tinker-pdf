"""Lane F: paint-A6.rs from paint-A5g.rs: the two rules no book of the
probes or of a targeted sweep moves (their injections change no line of the
f6 and v6 dumps, content hashes included) are taken out: leading_mark_at is
935b077's again, and reads_closer compares the readings alone."""
import os

HERE = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/variants'
s = open(os.path.join(HERE, 'paint-A5g.rs')).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""fn leading_mark_at(start: f64, letter_spacing: f64, font_size: f64, along: f64) -> f64 {
    let end = start - letter_spacing;
    // Half an em on the page, in a reader's ems ([`along_the_line`]).
    let near = start - letter_spacing.max(font_size * RESUMED_WITHIN / along);""",
    """fn leading_mark_at(start: f64, letter_spacing: f64, font_size: f64) -> f64 {
    let end = start - letter_spacing;
    let near = start - letter_spacing.max(font_size * RESUMED_WITHIN);""")
rep("""            (true, false) if leading => Some(leading_mark_at(
                start,
                run.letter_spacing,
                run.font_size,
                along,
            )),""", """            (true, false) if leading => {
                Some(leading_mark_at(start, run.letter_spacing, run.font_size))
            }""")
rep("""/// Every rule that asks whether a reader parts two text objects of a run
/// asks it in these ems ([`parted`], [`page_lines`], [`leading_mark_at`]):""",
    """/// The rules that ask whether a reader parts two text objects of a run, or
/// two runs, ask it in these ems ([`parted`], [`page_lines`]):""")
rep("""    /// letters in order ([`Words::pairs_in`]) — and sets no more glyphs over
    /// others there. A drawing found right in a space that is not the page's""",
    """    /// letters in order ([`Words::pairs_in`]). A drawing found right in a
    /// space that is not the page's""")
rep("""        let Some((rules, over_by_rules)) = self.read_back(line, matrices, frame, &BTreeMap::new())
        else {
            return false;
        };
        let Some((read, over)) = self.read_back(line, matrices, frame, found) else {
            return false;
        };
        over <= over_by_rules && written.pairs_in(&read) > written.pairs_in(&rules)""",
    """        let Some((rules, _)) = self.read_back(line, matrices, frame, &BTreeMap::new()) else {
            return false;
        };
        let Some((read, _)) = self.read_back(line, matrices, frame, found) else {
            return false;
        };
        written.pairs_in(&read) > written.pairs_in(&rules)""")
open(os.path.join(HERE, 'paint-A6.rs'), 'w').write(s)
print('A6 written')
