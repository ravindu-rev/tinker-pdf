#!/usr/bin/env bash
# Lane F: pack lane V's zz_v6_pdf runs at the three trees into the kit's baselines.
set -u
R=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
cd "$W" || exit 2
for t in 9297d2d 56dfd93 935b077; do
  for b in default bundled; do
    cat "$R/laneV/out/pdf-$t/$b/zz_v6_pdf.exit"
    tail -1 "$R/laneV/out/pdf-$t/$b/zz_v6_pdf.txt"
  done
  note="{family} at $t, {build}: run with scripts/run.sh on 16 October 2026 (round 6)"
  [ "$t" = 935b077 ] && note="{family} at 935b077, {build}: run with scripts/run.sh on 16 October 2026 (round 6) at d1c32cd, whose crates/ tree is 935b077's"
  rm -rf "$R/laneF/pack/pdf-$t"
  python3 -I tools/probes/rtl/scripts/pack.py "$R/laneV/out/pdf-$t" "$R/laneF/pack/pdf-$t" --note "$note" || exit 1
  ls "$R/laneF/pack/pdf-$t"/*
  cp "$R/laneF/pack/pdf-$t"/default/zz_v6_pdf.txt.xz "tools/probes/rtl/baselines/$t/default/"
  cp "$R/laneF/pack/pdf-$t"/bundled/zz_v6_pdf.txt.xz "tools/probes/rtl/baselines/$t/bundled/"
done
