"""Lane F: append the text of note.txt to NOTES.md (then empty note.txt).
usage: python3 -I addnote.py
"""
L = '/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF'
text = open(L + '/note.txt').read()
if text.strip():
    with open(L + '/NOTES.md', 'a') as f:
        f.write(text if text.endswith('\n') else text + '\n')
    open(L + '/note.txt', 'w').close()
    print('appended', len(text.splitlines()), 'lines')
else:
    print('nothing to append')
