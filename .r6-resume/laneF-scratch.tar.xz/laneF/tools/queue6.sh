#!/usr/bin/env bash
# Lane F: every optimised run, ONE AT A TIME. Every tree builds into the one
# laneF/rel-target, and cargo names a test binary the same for every tree
# (rtl_probes-<hash> does not hash the tree's path), so two runs at once
# execute each other's binaries; queue4 + queue5 + tipre did, and their H1,
# A8t and ZR outputs were thrown away. Each step is resumable.
#   1. the suites at the tip (A8t), both builds, and rtl_lines;
#   2. the page fonts' reading broken (snap/ZR) on round 6's families and scripts;
#   3. the owner's options H1, H6, A8d, A8s (owner3.sh).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
export THREADS=${THREADS:-4} JOBS=${JOBS:-4} REL=1
bash "$L/tools/rsuite2.sh" tip default A8t
bash "$L/tools/rsuite2.sh" tip bundled A8t
echo "q6 tip done"
bash "$L/tools/rsuite2.sh" snap/ZR default ZR '^zz_((f6|v6)_|rr3m_hunt_scripts$|rr3m_h1_ofscripts$|rr3m_hunt_numbers$)'
echo "q6 ZR done"
for n in H1 H6 A8d A8s; do
  bash "$L/tools/owner3.sh" "$n" > "$L/out/owner3-$n.out" 2>&1
  echo "q6 owner $n exit $?"
done
echo "q6 done"
