#!/usr/bin/env bash
# Lane F: the scratch read-as probe in snap/Z (A8) and snap/ZR (read-as-typed), optimised.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
cp "$L/variants/paint-A8.rs" "$L/snap/Z/crates/tinker-pdf/src/epub/paint.rs"
cp "$L/fam/zz_scratch_readas.rs" "$L/snap/Z/crates/tinker-pdf/tests/"
cp "$L/fam/zz_scratch_readas.rs" "$L/snap/ZR/crates/tinker-pdf/tests/"
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=$L/rel-target CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16
for s in Z ZR; do
  cd "$L/snap/$s" || exit 2
  cargo test --release -p tinker-pdf --test zz_scratch_readas -- --nocapture > "$L/out/scratchra-$s.log" 2>&1
  echo "$s exit $?"
done
