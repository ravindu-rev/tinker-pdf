"""Lane F: the catalogue for A7: page/letters-are-enough's text is A7's
(Words::read_as), and the Cut rule gets two injections, page/cut-searched (the
rules' cut-only reading searched on, as A6 did) and page/joins-are-cuts (a
reading that runs two words together taken for one that only cuts). The Cut
rule's own test is a unit test, so its suites name the lib's epub tests."""
import json

p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/injections.json'
raw = open(p, encoding='utf-8').read()
d = json.loads(raw)
key = next(iter(d))
items = d[key]
before = len(items)
ROUND = 'round 6 lane F: the read-back reads the page'
CASES = ['cargo', 'test', '--no-fail-fast', '-p', 'tinker-pdf', '--test', 'epub_conservation', '--test', 'epub_fallback']
LIB = ['cargo', 'test', '--no-fail-fast', '-p', 'tinker-pdf', '--lib', 'epub::tests']
names = [e['name'] for e in items]
assert 'page/cut-searched' not in names and 'page/joins-are-cuts' not in names
for e in items:
    if e['name'] == 'page/letters-are-enough':
        e['edits'] = [{
            'file': 'crates/tinker-pdf/src/epub/paint.rs',
            'old': '        if read.split_whitespace().eq(self.words.split_whitespace()) {\n            return Read::Words;',
            'new': '        if true || read.split_whitespace().eq(self.words.split_whitespace()) {\n            return Read::Words;',
            'count': 1,
        }]
at = names.index('page/letters-are-enough') + 1
items[at:at] = [
    {
        'name': 'page/cut-searched',
        'round': ROUND,
        'edits': [{
            'file': 'crates/tinker-pdf/src/epub/paint.rs',
            'old': '            None | Some((Read::Words | Read::Cut, _)) => return Search::Rules,',
            'new': '            None | Some((Read::Words, _)) => return Search::Rules,',
            'count': 1,
        }],
        'suites': [CASES, LIB],
    },
    {
        'name': 'page/joins-are-cuts',
        'round': ROUND,
        'edits': [{
            'file': 'crates/tinker-pdf/src/epub/paint.rs',
            'old': '            .all(|end| read_ends.binary_search(end).is_ok())',
            'new': '            .all(|end| true || read_ends.binary_search(end).is_ok())',
            'count': 1,
        }],
        'suites': [CASES, LIB],
    },
]
d[key] = items
out = json.dumps(d, ensure_ascii=False, indent=1)
if raw.endswith('\n'):
    out += '\n'
open(p, 'w', encoding='utf-8').write(out)
print(key, before, '->', len(items))
