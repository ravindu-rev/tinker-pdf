#!/usr/bin/env bash
# Lane F: bring lane V's rows families into the kit and the suites, and f6 too.
set -u
R=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
cd "$R" || exit 2
for n in inline lists units scripts2 numsep cells measure auto transform; do
  g=v6
  [ "$n" = transform ] && g=v6t
  python3 -I laneF/tools/gen2.py "laneV/tools/fam_$n.rs" "zz_v6_$n" "$g" 'round 6 lane V (hunt)' --probe "laneV/kit/probes/pdf/zz_v6_$n.rs" || exit 1
  if diff <(sed -n '3,297p' "$W/tools/probes/rtl/probes/pdf/zz_v6_$n.rs") <(sed -n '2,296p' "$W/tools/probes/rtl/probes/pdf/zz_rr3m_h2_pages.rs") > /dev/null; then
    echo "$n prefix ok"
  else
    echo "$n PREFIX DIFFERS"
  fi
done
python3 -I laneF/tools/gen2.py laneF/fam/f6_transform.rs zz_f6_transform f6 'round 6 lane F (sweep)' || exit 1
