#!/usr/bin/env bash
# Lane F: the read-back's cost (V4): zz_v6_time at 56dfd93 (no read-back),
# at 05cea0b's paint.rs (935b077's read-back) and at the fix (snap/Y = A6f),
# one after the other, default build. Run it with nothing else running.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
export JOBS=2
for t in snap/Y snap/F935 56 snap/Y snap/F935 56; do
  n=$(echo "$t" | tr '/' '-')
  i=1
  while [ -e "$L/out/time-$n-$i" ]; do i=$((i + 1)); done
  echo "== $t run $i $(date +%T) load $(cut -d' ' -f1 /proc/loadavg)"
  "$L/tools/runat.sh" "$t" default "time-$n-$i" 'v6time/'
done
echo "timing done"
