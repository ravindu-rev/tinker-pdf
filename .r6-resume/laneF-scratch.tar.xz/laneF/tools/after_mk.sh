#!/usr/bin/env bash
# Lane F: after the MK run, the closer-overprint-unchecked injection over the
# transform families in snap/X.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^after_lc done' "$L/out/after_lc.log" 2>/dev/null; do sleep 20; done
python3 -I "$L/tools/mkinjvar.py" page/closer-overprint-unchecked "$L/snap/X/crates/tinker-pdf/src/epub/paint.rs"
THREADS=2 "$L/tools/suite.sh" snap/X default CO zz_f6_transform zz_v6_transform
echo "after_mk done"
