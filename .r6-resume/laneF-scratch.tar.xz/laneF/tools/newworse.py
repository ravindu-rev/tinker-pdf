"""Lane F: per family and build, the books a run reads worse than each of the
three baselines (any metric), and how many of those 935b077 did not already
read worse than that baseline; gains over 935b077; conserving at each tree;
visible overprint (the rr3m second overlap number / TWROW vov / VOV) that rose
over 935b077 under word spacing or justification, and anywhere.

usage: python3 -I newworse.py RUN [--builds default,bundled] [--families REGEX] [--show N] [--json OUT]
"""
import importlib.util
import json
import os
import re
import sys

KIT = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts'
spec = importlib.util.spec_from_file_location('rtlkit', os.path.join(KIT, 'rtlkit.py'))
K = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(K)

args = sys.argv[1:]
run = args[0]
builds = ['default', 'bundled']
fam_re = None
show = 0
out_json = None
i = 1
while i < len(args):
    if args[i] == '--builds':
        builds = args[i + 1].split(','); i += 2
    elif args[i] == '--families':
        fam_re = re.compile(args[i + 1]); i += 2
    elif args[i] == '--show':
        show = int(args[i + 1]); i += 2
    elif args[i] == '--json':
        out_json = args[i + 1]; i += 2
    else:
        raise SystemExit('unknown ' + args[i])

trees = {'B': K.resolve('9297d2d'), 'M': K.resolve('56dfd93'), 'T': K.resolve('935b077')}
result = {}
for build in builds:
    fams = sorted(K.families_in(run, build))
    print(f'## {build}')
    print(f"{'family':32} {'rows':>6}  {'conserving B/M/T/N':24} {'>B new':>9} {'>M new':>9} {'>T':>5} {'+T':>5}  over-ws rose/any rose")
    tot = {'B': 0, 'M': 0, 'T': 0, 'newB': 0, 'newM': 0, 'gain': 0, 'ovws': 0, 'ov': 0}
    for fam in fams:
        if fam_re and not fam_re.search(fam):
            continue
        n_path = K.family_file(run, build, fam)
        if not n_path:
            continue
        N = K.load(n_path)
        O = {}
        for t, root in trees.items():
            p = K.family_file(root, build, fam)
            O[t] = K.load(p) if p else None
        if not N.rows:
            continue
        cons = []
        for t in ('B', 'M', 'T'):
            o = O[t]
            cons.append(str(sum(1 for v in o.rows.values() if K.conserve(v))) if o else '-')
        cons.append(str(sum(1 for v in N.rows.values() if K.conserve(v))))
        row = {'rows': len(N.rows), 'cons': '/'.join(cons)}
        listing = []
        for t in ('B', 'M', 'T'):
            o = O[t]
            if o is None:
                row[t] = '-'
                row['new' + t] = '-'
                continue
            worse_now = {k for k, v in o.rows.items() if K.lost(v, N.rows.get(k))}
            if t == 'T':
                worse_then = set()
            else:
                worse_then = {k for k, v in o.rows.items() if O['T'] and K.lost(v, O['T'].rows.get(k))}
            # new: worse now and not then, or losing a metric now it did not lose then
            new = set()
            for k in worse_now:
                now = set(K.lost(o.rows[k], N.rows.get(k)))
                then = set(K.lost(o.rows[k], O['T'].rows.get(k))) if (t != 'T' and O['T']) else set()
                if not now <= then:
                    new.add(k)
            row[t] = len(worse_now)
            row['new' + t] = len(new) if t != 'T' else len(worse_now)
            tot[t] += len(worse_now)
            if t != 'T':
                tot['new' + t] += len(new)
            for k in sorted(new)[:show]:
                listing.append(f'    new>{t}\t{",".join(sorted(set(K.lost(o.rows[k], N.rows.get(k)))))}\t{k[:200]!r}')
        T = O['T']
        gain = 0
        ovws = ov = 0
        if T:
            gain = sum(1 for k, v in N.rows.items() if k in T.rows and K.lost(v, T.rows[k]))
            for k, n in N.over.items():
                if n > T.over.get(k, 0):
                    ov += 1
                    if K.style_class(k) in ('ws', 'neg+ws'):
                        ovws += 1
            for k, (n, _) in N.vov.items():
                if n > T.vov.get(k, (0, ''))[0] and k not in N.over:
                    ov += 1
                    if K.style_class(k) in ('ws', 'neg+ws'):
                        ovws += 1
        tot['gain'] += gain
        tot['ovws'] += ovws
        tot['ov'] += ov
        row.update({'gain': gain, 'ovws': ovws, 'ov': ov})
        result[(build, fam)] = row
        nb = f"{row['B']}/{row['newB']}"
        nm = f"{row['M']}/{row['newM']}"
        print(f"{fam:32} {row['rows']:>6}  {row['cons']:24} {nb:>9} {nm:>9} {row['T']:>5} {gain:>5}  {ovws}/{ov}")
        for l in listing:
            print(l)
    print(f"{'TOTAL':32} {'':>6}  {'':24} {str(tot['B'])+'/'+str(tot['newB']):>9} {str(tot['M'])+'/'+str(tot['newM']):>9} {tot['T']:>5} {tot['gain']:>5}  {tot['ovws']}/{tot['ov']}")
    print()
if out_json:
    json.dump({f'{b}\t{f}': r for (b, f), r in result.items()}, open(out_json, 'w'), indent=1)
