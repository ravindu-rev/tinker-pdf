#!/usr/bin/env bash
# Lane F: everything left to measure, optimised, one after another (each step
# resumable; a rerun skips what finished):
#   1. the suites at the tip (A8r), both builds, and rtl_lines;
#   2. the rule diagnostics in snap/Z (ZD) on round 6's families and scripts;
#   3. reads_closer broken (snap/ZC) on the same families;
#   4. the owner's options H1, H6, A8d, A8s (owner3.sh).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
export THREADS=${THREADS:-4} JOBS=${JOBS:-4} REL=1
RX='^zz_((f6|v6)_|rr3m_hunt_scripts$|rr3m_h1_ofscripts$)'
bash "$L/tools/rsuite2.sh" tip default A8r
bash "$L/tools/rsuite2.sh" tip bundled A8r
echo "q4 tip done"
bash "$L/tools/rsuite2.sh" snap/Z default ZD "$RX"
bash "$L/tools/rsuite2.sh" snap/ZC default ZC "$RX"
echo "q4 diag done"
for n in H1 H6 A8d A8s; do
  bash "$L/tools/owner3.sh" "$n" > "$L/out/owner3-$n.out" 2>&1
  echo "q4 owner $n exit $?"
done
echo "q4 done"
