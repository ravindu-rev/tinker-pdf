#!/usr/bin/env bash
# Lane F: after the A6 default suite, the A6 bundled suite (resumable).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^rsuite A6 default done' "$L/out/rs-A6-default/progress.txt" 2>/dev/null; do sleep 20; done
THREADS=3 bash "$L/tools/rsuite.sh" tip bundled A6
echo "a6b done"
