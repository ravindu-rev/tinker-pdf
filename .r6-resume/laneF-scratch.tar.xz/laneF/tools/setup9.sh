#!/usr/bin/env bash
# Lane F: the owner's options on the committed base A9 (the worktree at the
# A9 checkpoint): snap/H1n and snap/H6n (the worktree with bidi-H1.rs /
# bidi-H6.rs), snap/A9Ld (the worktree's paint.rs with each drawing read once,
# variants/paint-A9Ld.rs). Optimised runs only (owner3.sh, rel-target): no
# debug targets are made.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
python3 -I "$L/tools/mkvar9d.py" || exit 2
bash "$L/tools/snap.sh" H1n
cp "$L/variants/bidi-H1.rs" "$L/snap/H1n/crates/tinker-pdf-shape/src/bidi.rs"
bash "$L/tools/snap.sh" H6n
cp "$L/variants/bidi-H6.rs" "$L/snap/H6n/crates/tinker-pdf-shape/src/bidi.rs"
bash "$L/tools/snap.sh" A9Ld
cp "$L/variants/paint-A9Ld.rs" "$L/snap/A9Ld/crates/tinker-pdf/src/epub/paint.rs"
sha256sum "$W/crates/tinker-pdf/src/epub/paint.rs" "$W/crates/tinker-pdf-shape/src/bidi.rs" \
  "$L/snap/H1n/crates/tinker-pdf/src/epub/paint.rs" "$L/snap/H1n/crates/tinker-pdf-shape/src/bidi.rs" \
  "$L/snap/H6n/crates/tinker-pdf-shape/src/bidi.rs" "$L/snap/A9Ld/crates/tinker-pdf/src/epub/paint.rs"
echo "setup9 done"
