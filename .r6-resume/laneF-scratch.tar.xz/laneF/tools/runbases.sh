#!/usr/bin/env bash
# Lane F: run a family filter at 56dfd93 and 9297d2d (shared trees), both builds, one after the other.
# usage: runbases.sh TAG FILTER   -> out/TAG-56, out/TAG-9297
set -u
T=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/tools
"$T/runat.sh" 56 both "$1-56" "$2"
"$T/runat.sh" 9297 both "$1-9297" "$2"
