#!/usr/bin/env bash
# Lane F: append the scratch readings probe to the worktree's epub/tests.rs,
# run it in both builds, and restore the file (checked by sha).
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
F=$W/crates/tinker-pdf/src/epub/tests.rs
cp "$F" "$L/out/tests.rs.saved"
before=$(sha256sum < "$F")
cat "$L/tools/probe_reads.rs.txt" >> "$F"
for b in default bundled; do
  echo "== $b"
  JOBS=4 bash "$L/tools/wtunit.sh" "$b" zz_scratch_readings_probe > /dev/null
  FEAT=""
  [ "$b" = bundled ] && FEAT="--features bundled-fonts"
  cd "$W" || exit 2
  # shellcheck disable=SC2086
  CARGO_BUILD_JOBS=4 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$W/target \
    cargo test -p tinker-pdf $FEAT --lib zz_scratch_readings_probe -- --nocapture 2>&1 | grep -E "PROBE|test result"
done
cp "$L/out/tests.rs.saved" "$F"
after=$(sha256sum < "$F")
[ "$before" = "$after" ] && echo "restored" || echo "NOT RESTORED"
