"""Lane F: diag/p6.tsv, the five f6 punct/none Hebrew books A4's fallback lost."""
HE = ["שלום", "עולם", "מלחמה", "ספר", "בית", "גדול", "אור", "יום", "בראשית", "ברא", "אלהים", "הארץ"]


def s(i):
    return HE[i % len(HE)]


def punct(i):
    return f"{s(i)} <b>?!</b> {s(i + 1)} {s(i + 2)}. <i>(</i>{s(i + 3)}<i>)</i> {s(i + 4)}!"


text = " ".join(punct(k * 3) for k in range(3))
body = f'<div class="w"><p>{text}</p></div>'
rows = [
    ("p6-matrix", "matrix(1.6, 0, 0, 0.8, 0, 0)", "none"),
    ("p6-w-sx2", "none", "scaleX(2)"),
    ("p6-sx2", "scaleX(2)", "none"),
    ("p6-sx3", "scaleX(3)", "none"),
    ("p6-sy05", "scaleY(0.5)", "none"),
]
with open('/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF/diag/p6.tsv', 'w') as f:
    for name, p, w in rows:
        style = f"p {{ margin: 0 30%; transform: {p}; word-spacing: 0.6em }} .w {{ transform: {w} }}"
        f.write(f"{name}\the\t{style}\t{body}\n")
print('p6 written')
