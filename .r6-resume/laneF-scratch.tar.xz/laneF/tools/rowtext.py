"""Lane F: the text field of one book in two (or more) kit dumps, decoded, line by line.

usage: python3 -I rowtext.py BUILD FAMILY STYLE_SUBSTR BOOK DUMP_DIR...
"""
import sys

build, fam, style, book = sys.argv[1:5]
dirs = sys.argv[5:]


def dec(s):
    out = []
    i = 0
    while i < len(s):
        if s.startswith('\\u{', i):
            j = s.index('}', i)
            out.append(chr(int(s[i + 3:j], 16)))
            i = j + 1
        elif s.startswith('\\n', i):
            out.append('\n')
            i += 2
        else:
            out.append(s[i])
            i += 1
    return ''.join(out)


for d in dirs:
    for line in open(f'{d}/{build}/{fam}.txt', encoding='utf-8'):
        f = line.rstrip('\n').split('\t')
        if f[0] == 'ROW' and style in f[1] and f[2] == book:
            meta = [x for x in f[3:] if '=' in x and len(x) < 40]
            print('==', d.rsplit('/', 1)[-1], ' '.join(meta))
            text = dec(max(f[3:], key=len))
            for n, l in enumerate(text.split('\n')):
                print(f'{n:3} {l!r}')
            break
