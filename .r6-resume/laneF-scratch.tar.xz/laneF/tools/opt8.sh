#!/usr/bin/env bash
# Lane F: the tables of a run kit-TAG: against the three committed baselines
# (out/table-TAG-BUILD.{txt,json}), and, for an owner's option, against the
# committed base kit-A8t as its tip (out/vsA8-TAG-BUILD.txt, --show 8).
# usage: opt8.sh TAG [vsA8]
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
T=$1
for b in default bundled lines; do
  [ -d "$L/out/kit-$T/$b" ] || continue
  python3 -I "$W/tools/probes/rtl/scripts/table.py" "$L/out/kit-$T" --builds "$b" --show 6 \
    --json "$L/out/table-$T-$b.json" > "$L/out/table-$T-$b.txt" 2>&1
  echo "table $T $b exit $?"
  if [ "${2:-}" = vsA8 ]; then
    python3 -I "$W/tools/probes/rtl/scripts/table.py" "$L/out/kit-$T" --tip "$L/out/kit-A8t" --builds "$b" --show 8 \
      > "$L/out/vsA8-$T-$b.txt" 2>&1
    echo "vsA8 $T $b exit $?"
  fi
done
