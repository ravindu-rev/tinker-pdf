"""Lane F: byte-compare two kit dumps family by family.

usage: python3 -I cmpdirs.py A B [BUILD...]
Prints each file present in both that differs, and a count.
"""
import os
import sys

a, b = sys.argv[1], sys.argv[2]
builds = sys.argv[3:] or ['default', 'bundled', 'lines']
n = d = 0
for build in builds:
    da, db = os.path.join(a, build), os.path.join(b, build)
    if not (os.path.isdir(da) and os.path.isdir(db)):
        continue
    for name in sorted(os.listdir(da)):
        pa, pb = os.path.join(da, name), os.path.join(db, name)
        if not os.path.isfile(pb):
            continue
        n += 1
        if open(pa, 'rb').read() != open(pb, 'rb').read():
            d += 1
            print('DIFF', build, name)
print(f'compared {n}, differ {d}')
