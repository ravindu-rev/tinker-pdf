#!/usr/bin/env bash
# Lane F: after the LC run, the mark-in-the-runs-ems injection over the
# transform families in snap/X.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^exit ' "$L/out/suite-LC-default.log" 2>/dev/null; do sleep 20; done
python3 -I "$L/tools/mkinjvar.py" page/mark-in-the-runs-ems "$L/snap/X/crates/tinker-pdf/src/epub/paint.rs"
THREADS=2 "$L/tools/suite.sh" snap/X default MK zz_f6_transform zz_v6_transform
echo "after_lc done"
