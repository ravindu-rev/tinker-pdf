"""Lane F: the books of one family whose ROW line differs between two kit dumps,
with the fields that differ (thash, chash, text, metrics).

usage: python3 -I rowdiff.py A B BUILD FAMILY [N]
"""
import sys

a, b, build, fam = sys.argv[1:5]
n = int(sys.argv[5]) if len(sys.argv) > 5 else 20


def rows(root):
    out = {}
    for line in open(f'{root}/{build}/{fam}.txt', encoding='utf-8'):
        if not line.startswith('ROW\t'):
            continue
        f = line.rstrip('\n').split('\t')
        out[(f[1], f[2])] = f
    return out


ra, rb = rows(a), rows(b)
shown = 0
diff = 0
for k in sorted(ra):
    if k not in rb or ra[k] == rb[k]:
        continue
    diff += 1
    if shown < n:
        shown += 1
        print('##', k[0], '|', k[1])
        for i, (x, y) in enumerate(zip(ra[k], rb[k])):
            if x != y:
                print(f'   field {i}: {x[:160]!r}\n        -> {y[:160]!r}')
print('books differing:', diff)
