#!/usr/bin/env bash
# Lane F: pack the f6_ems runs at the three baselines into the kit's baselines.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
cd "$W" || exit 2
pack() {
  rm -rf "$L/pack/ems-$1"
  python3 -I tools/probes/rtl/scripts/pack.py "$L/out/ems-$2" "$L/pack/ems-$1" --note "$3" || exit 1
  cp "$L/pack/ems-$1"/default/*.xz "tools/probes/rtl/baselines/$1/default/"
  cp "$L/pack/ems-$1"/bundled/*.xz "tools/probes/rtl/baselines/$1/bundled/"
}
pack 9297d2d 9297 "{family} at 9297d2d, {build}: run with scripts/run.sh on 16 October 2026 (round 6)"
pack 56dfd93 56 "{family} at 56dfd93, {build}: run with scripts/run.sh on 16 October 2026 (round 6)"
pack 935b077 935 "{family} at 935b077, {build}: run with scripts/run.sh on a copy of 05cea0b's tree, whose crates/*/src is 935b077's (the two differ in tests, tools and docs only), on 16 October 2026"
ls -la tools/probes/rtl/baselines/*/*/zz_f6_ems*
