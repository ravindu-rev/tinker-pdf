"""Lane F: the books worse than 9297d2d or 56dfd93 (any metric) at 935b077 and
in a run, per family and build: how many at each, how many the run adds (new)
and how many it no longer has (fixed), with up to N of each listed.

usage: python3 -I leftset.py RUN [--builds default,bundled] [--families REGEX] [--show N] [--json OUT]
"""
import importlib.util
import json
import re
import sys

KIT = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/tools/probes/rtl/scripts/rtlkit.py'
spec = importlib.util.spec_from_file_location('rtlkit', KIT)
K = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(K)

args = sys.argv[1:]
run = args[0]
builds = ['default', 'bundled']
fam_re = None
show = 0
out_json = None
i = 1
while i < len(args):
    if args[i] == '--builds':
        builds = args[i + 1].split(','); i += 2
    elif args[i] == '--families':
        fam_re = re.compile(args[i + 1]); i += 2
    elif args[i] == '--show':
        show = int(args[i + 1]); i += 2
    elif args[i] == '--json':
        out_json = args[i + 1]; i += 2
    else:
        raise SystemExit('unknown ' + args[i])

B, M, T = K.resolve('9297d2d'), K.resolve('56dfd93'), K.resolve('935b077')
dump = {}
for build in builds:
    tot = [0, 0, 0, 0]
    print(f'## {build}')
    print(f"{'family':32} {'at 935':>7} {'now':>5} {'new':>5} {'fixed':>6}")
    for fam in sorted(K.families_in(run, build)):
        if fam_re and not fam_re.search(fam):
            continue
        p = K.family_file(run, build, fam)
        pb, pm, pt = (K.family_file(x, build, fam) for x in (B, M, T))
        if not (p and pt):
            continue
        N, Tt = K.load(p), K.load(pt)
        olds = [K.load(x) for x in (pb, pm) if x]

        def worse(o_rows, now):
            out = {}
            for o in olds:
                for k, v in o.rows.items():
                    lost = K.lost(v, now.get(k))
                    if lost:
                        out.setdefault(k, set()).update(lost)
            return out
        wt = worse(None, Tt.rows)
        wn = worse(None, N.rows)
        new = {k: v for k, v in wn.items() if k not in wt or not v <= wt[k]}
        fixed = {k: v for k, v in wt.items() if k not in wn}
        tot[0] += len(wt); tot[1] += len(wn); tot[2] += len(new); tot[3] += len(fixed)
        if wt or wn:
            print(f'{fam:32} {len(wt):>7} {len(wn):>5} {len(new):>5} {len(fixed):>6}')
        for k in sorted(new)[:show]:
            print(f'    new\t{",".join(sorted(new[k]))}\t{k[:220]!r}')
        for k in sorted(fixed)[:show]:
            print(f'    fixed\t{",".join(sorted(fixed[k]))}\t{k[:220]!r}')
        dump[f'{build}\t{fam}'] = {'at935': sorted(wt), 'now': sorted(wn), 'new': sorted(new), 'fixed': sorted(fixed)}
    print(f"{'TOTAL':32} {tot[0]:>7} {tot[1]:>5} {tot[2]:>5} {tot[3]:>6}")
    print()
if out_json:
    json.dump(dump, open(out_json, 'w'), indent=1, ensure_ascii=False)
