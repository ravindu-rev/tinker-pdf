#!/usr/bin/env bash
# Lane F: snap/Y at A6f: the page_lines guard test (both builds), then the
# f6_ems family (both builds), then the same test under the lines-cut injection.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
B=1 "$L/tools/ytest.sh" A6f two_cells_a_reader_parts_on_the_page_are_read_back_apart A6-cells
"$L/tools/runat.sh" snap/Y both ems-A6 'zz_f6_ems$'
echo "y_a6 done"
