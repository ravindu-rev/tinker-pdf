#!/usr/bin/env bash
# Lane F: the case tests (epub_fallback, epub_conservation) in a tree, both builds.
# usage: cases.sh TREE TAG   (TREE: tip | snap/NAME)  -> tlog/TAG-cases-{default,bundled}.txt
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
case $1 in
  tip) W=/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4; T=$W/target ;;
  snap/*) W=$L/$1; T=$L/$1-target ;;
  *) echo "tree?" >&2; exit 2 ;;
esac
cd "$W" || exit 2
export CARGO_BUILD_JOBS=${JOBS:-2} CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_TARGET_DIR=$T
for b in default bundled; do
  FEAT=""
  [ "$b" = bundled ] && FEAT="--features bundled-fonts"
  O="$L/tlog/$2-cases-$b.txt"
  # shellcheck disable=SC2086
  cargo test --no-fail-fast -p tinker-pdf $FEAT --test epub_fallback --test epub_conservation -- --test-threads=2 > "$O" 2>&1
  echo "exit $?" >> "$O"
  echo "== $2 $b: $(grep -E '^test result' "$O" | tr '\n' ' ') $(tail -1 "$O")"
done
