#!/usr/bin/env bash
# Lane F: once both.sh's default suite of TAG has finished, stop both.sh and
# its bundled suite (the processes are matched by their own command lines).
# usage: stopafter.sh TAG
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q "^suite $1 default" "$L/out/both-$1.log"; do sleep 5; done
for pid in $(pgrep -f "^bash $L/tools/both.sh "); do kill "$pid"; done
sleep 2
for pid in $(pgrep -f "^bash $L/tools/suite.sh tip bundled $1"); do kill "$pid"; done
sleep 2
for pid in $(pgrep -f "cargo test -p tinker-pdf --features bundled-fonts --test rtl_probes"); do kill "$pid"; done
for pid in $(pgrep -f "rtl_probes-[0-9a-f]* --ignored"); do kill "$pid"; done
sleep 2
echo "stopped after $1 default"
pgrep -af "rtl_probes|both.sh|suite.sh" | cut -c1-120
