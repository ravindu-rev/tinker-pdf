#!/usr/bin/env bash
# Lane F: after owner2.sh H1, measure H6, resumable (owner2.sh skips what finished); A6d runs on its own.
set -u
L=/tmp/claude-0/-home-user-tinker-pdf/14e5c5a7-848b-5101-b07a-814074112597/scratchpad/r6/laneF
until grep -q '^owner H1 done' "$L/out/owner2-H1.out" 2>/dev/null; do sleep 30; done
THREADS=2 JOBS=2 bash "$L/tools/owner2.sh" H6 > "$L/out/owner2-H6.out" 2>&1
echo "queue2 done"
