"""Lane F: the case test files as each commit of the fold has them, cut from
the final ones in the worktree.

usage: python3 -I stages.py OUTDIR
  OUTDIR/c2/epub_conservation.rs  the fix's: no V2, no V3 cases
  OUTDIR/c2/epub_fallback.rs      the fix's: no V5 test
  OUTDIR/c3/epub_conservation.rs  = final (V2, V3 pinned)
  OUTDIR/c4/epub_fallback.rs      = final (V5 pinned)
"""
import os
import sys

W = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/tests'
out = sys.argv[1]
cons = open(os.path.join(W, 'epub_conservation.rs')).read()
fall = open(os.path.join(W, 'epub_fallback.rs')).read()


def cut(s, start, end_marker, keep_end=False):
    i = s.index(start)
    j = s.index(end_marker, i)
    if keep_end:
        return s[:i] + s[j:]
    return s[:i] + s[j + len(end_marker):]


# V2: the comment and loop added after H4(2)'s case, before `check(&cases);`
v2_start = "    // V2 of round 6's lane V: the same class at a closing bracket and at\n"
assert cons.count(v2_start) == 1
c2_cons = cut(cons, v2_start, "    check(&cases);\n}\n", keep_end=True)
# V3: the two cases at the end of a_dirless_line_with_a_right_to_left_gloss
v3_start = "        // With `bundled-fonts` the Hebrew book conserves at every tree: a\n"
assert c2_cons.count(v3_start) == 1
c2_cons = cut(c2_cons, v3_start, "    ]);\n}\n", keep_end=True)

v5_start = "/// **A line whose right drawing lies past the read-back's budget is drawn by\n"
assert fall.count(v5_start) == 1
i = fall.index(v5_start)
j = fall.index("\n}\n", fall.index("fn a_line_whose_right_drawing_lies_past_the_budget_is_drawn_by_the_rules", i)) + 3
c2_fall = fall[:i] + fall[j:].lstrip('\n')
for d, files in (('c2', {'epub_conservation.rs': c2_cons, 'epub_fallback.rs': c2_fall}),
                 ('c3', {'epub_conservation.rs': cons}),
                 ('c4', {'epub_fallback.rs': fall})):
    os.makedirs(os.path.join(out, d), exist_ok=True)
    for name, text in files.items():
        open(os.path.join(out, d, name), 'w').write(text)
print('stages written')
