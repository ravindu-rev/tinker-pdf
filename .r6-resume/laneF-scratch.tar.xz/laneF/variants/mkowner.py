"""Lane F, step 4: the owner's candidates, as bidi.rs variants (never committed).

bidi-H1.rs: the comma tie-break's shape takes a line whose left end is a
            number (EN, AN) or a closing bracket, as well as a right-to-left
            letter (Left (1), V2).
bidi-H6.rs: a sentence's end is one kind of stop: one mark repeated, a run of
            `!` and `?`, or an ellipsis (full stops and the ellipsis
            characters); a run that mixes kinds, `.!` or `!...`, is not one
            (Left (5), H6).
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = open(os.path.join(HERE, 'bidi-orig.rs')).read()


def rep(s, old, new):
    assert s.count(old) == 1, (s.count(old), old[:100])
    return s.replace(old, new)


def h1(s):
    old = """    matches!(
        leftmost.map(unicode::bidi_class),
        Some(BidiClass::R | BidiClass::AL)
    ) && rightmost.is_some_and(|c| {"""
    new = """    leftmost.is_some_and(|c| {
        matches!(
            unicode::bidi_class(c),
            BidiClass::R | BidiClass::AL | BidiClass::EN | BidiClass::AN
        ) || matches!(unicode::bracket(c), Some((_, BracketKind::Close)))
    }) && rightmost.is_some_and(|c| {"""
    return rep(s, old, new)


def h6(s):
    old = """        let mut stops = 0usize;
        while drawing.next_if(|(_, c)| ENDS_A_LINE.contains(c)).is_some() {
            stops += 1;
        }
        let (edge, _) = drawing.next()?;
        (stops > 0).then_some(OpenedBefore { edge, ltr: true })"""
    new = """        let mut stops: Vec<char> = Vec::new();
        while let Some((_, c)) = drawing.next_if(|(_, c)| ENDS_A_LINE.contains(c)) {
            stops.push(c);
        }
        let one_kind = stops.windows(2).all(|pair| pair[0] == pair[1])
            || stops.iter().all(|c| matches!(c, '!' | '?'))
            || stops
                .iter()
                .all(|c| matches!(c, '.' | '\\u{2024}' | '\\u{2025}' | '\\u{2026}' | '\\u{FE19}'));
        let (edge, _) = drawing.next()?;
        (!stops.is_empty() && one_kind).then_some(OpenedBefore { edge, ltr: true })"""
    return rep(s, old, new)


for name, f in [('H1', h1), ('H6', h6)]:
    open(os.path.join(HERE, 'bidi-%s.rs' % name), 'w').write(f(BASE))
    print(name, 'written')
