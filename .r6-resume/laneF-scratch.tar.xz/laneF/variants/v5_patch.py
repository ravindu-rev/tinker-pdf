"""Lane F, V5: the read-back reads each distinct drawing once (a drawing that
writes what another already read is not read again), and takes the first
drawing that reads the line's words right, falling back to the first that reads
its letters right where none does within the budget."""
import sys
p = '/home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4/crates/tinker-pdf/src/epub/paint.rs'
s = open(p).read()
STRICT = '--strict' in sys.argv
DEDUPE = '--dedupe' in sys.argv


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:100])
    s = s.replace(old, new)


if DEDUPE:
    # Segment comparable.
    rep("""/// One stretch of a run sharing a font resource, one string of codes from one
/// position: a text object of its own, or a piece of one that holds a mark
/// ([`flush`]).
struct Segment {""", """/// One stretch of a run sharing a font resource, one string of codes from one
/// position: a text object of its own, or a piece of one that holds a mark
/// ([`flush`]). Two plans of the same segments are written byte for byte alike
/// ([`Fonts::plan_run`]).
#[derive(PartialEq)]
struct Segment {""")
    # options built after the default reading, deduplicated.
    rep("""            let matrices: Vec<[f64; 6]> = line.iter().map(|run| effects.matrix(run.anchor)).collect();
            let options: Vec<(RunKey, Drawing)> =
                line.iter().flat_map(|run| drawings_of(run, self.along(run))).collect();
            if options.is_empty() {
                continue;
            }
""", """            let matrices: Vec<[f64; 6]> = line.iter().map(|run| effects.matrix(run.anchor)).collect();
            // Each run's drawings that write something other than the rules'
            // and than each other: a drawing that writes the bytes another
            // wrote reads as that one did, and is not read again.
            let mut options: Vec<(RunKey, Drawing)> = Vec::new();
            for run in &line {
                let mut written: Vec<Vec<Vec<Segment>>> =
                    vec![self.plan_run(run, Drawing::default()).unwrap_or_default()];
                for (key, drawing) in drawings_of(run, self.along(run)) {
                    let plan = self.plan_run(run, drawing).unwrap_or_default();
                    if !written.contains(&plan) {
                        written.push(plan);
                        options.push((key, drawing));
                    }
                }
            }
            if options.is_empty() {
                continue;
            }
""")
    # plan_run helper, used by read_back too.
    rep("""    /// What a reader of the page reads off `line`, one line's runs in the""", """    /// The text objects [`plan_coded`] writes for the whole of `run` drawn as
    /// `drawing` says, each face segment's in the order drawn: what
    /// [`Fonts::read_back`] reads and [`draw_run`] writes. `None` for a run
    /// with a character in a face of the book's own, which [`draw_shaped`]
    /// draws.
    fn plan_run(&self, run: &TextRun, drawing: Drawing) -> Option<Vec<Vec<Segment>>> {
        let font = request(run);
        let mut segments = face_runs(self.faces, &font, &run.text);
        if segments
            .iter()
            .any(|(_, chosen)| matches!(chosen, Chosen::Embedded(_)))
        {
            return None;
        }
        if reads_right_to_left(run) {
            segments.reverse();
        }
        let mut x = run.x;
        let mut out = Vec::new();
        for (range, _) in segments {
            let slice = run.text.get(range).unwrap_or("");
            let (objects, end) = plan_coded(run, self, slice, x, drawing);
            x = end;
            out.extend(objects);
        }
        Some(out)
    }

    /// What a reader of the page reads off `line`, one line's runs in the""")
    rep("""        for (at, run) in line.iter().enumerate() {
            // The `cm`s [`OnPage::open`] writes before the run's text object.
            let [a, b, c, d, e, f] = matrices.get(at).copied().unwrap_or(IDENTITY);
            let page = tinker_pdf_content::Matrix { a, b, c, d, e, f };
            let font = request(run);
            let mut segments = face_runs(self.faces, &font, &run.text);
            if segments
                .iter()
                .any(|(_, chosen)| matches!(chosen, Chosen::Embedded(_)))
            {
                return None;
            }
            if reads_right_to_left(run) {
                segments.reverse();
            }
            let drawing = drawings.get(&run_key(run)).copied().unwrap_or_default();
            let size = run.font_size * PX_TO_PT;
            let y = frame.y(run.y);
            let letters = run.letter_spacing * PX_TO_PT;
            let words = run.word_spacing * PX_TO_PT;
            let mut x = run.x;
            for (range, _) in segments {
                let slice = run.text.get(range).unwrap_or("");
                let (objects, end) = plan_coded(run, self, slice, x, drawing);
                x = end;
                for object in objects {""", """        for (at, run) in line.iter().enumerate() {
            // The `cm`s [`OnPage::open`] writes before the run's text object.
            let [a, b, c, d, e, f] = matrices.get(at).copied().unwrap_or(IDENTITY);
            let page = tinker_pdf_content::Matrix { a, b, c, d, e, f };
            let font = request(run);
            let drawing = drawings.get(&run_key(run)).copied().unwrap_or_default();
            let size = run.font_size * PX_TO_PT;
            let y = frame.y(run.y);
            let letters = run.letter_spacing * PX_TO_PT;
            let words = run.word_spacing * PX_TO_PT;
            {
                for object in self.plan_run(run, drawing)? {""")

if STRICT:
    rep("""            let written: String = line
                .iter()
                .flat_map(|run| run.text.chars())
                .filter(|c| !c.is_whitespace())
                .collect();
            let tried = std::cell::Cell::new(0usize);
            let reads_right = |chosen: &BTreeMap<RunKey, Drawing>| {
                tried.set(tried.get() + 1);
                self.read_back(&line, &matrices, frame, chosen).map(|read| {
                    read.chars()
                        .filter(|c| !c.is_whitespace())
                        .eq(written.chars())
                })
            };
            match reads_right(&BTreeMap::new()) {
                Some(false) => {}
                None | Some(true) => continue,
            }""", """            let typed: String = line.iter().map(|run| run.text.as_str()).collect();
            let written = Words::of(&typed);
            let tried = std::cell::Cell::new(0usize);
            // The first drawing that reads the line's letters right but not
            // its words, kept where none reads both.
            let letters_only: std::cell::RefCell<Option<BTreeMap<RunKey, Drawing>>> =
                std::cell::RefCell::new(None);
            let reads_right = |chosen: &BTreeMap<RunKey, Drawing>| {
                tried.set(tried.get() + 1);
                self.read_back(&line, &matrices, frame, chosen).map(|read| {
                    match written.read_as(&read) {
                        Read::Words => true,
                        Read::Letters => {
                            letters_only.borrow_mut().get_or_insert_with(|| chosen.clone());
                            false
                        }
                        Read::Otherwise => false,
                    }
                })
            };
            match reads_right(&BTreeMap::new()) {
                Some(false) => {}
                None | Some(true) => continue,
            }
            // Where the rules' drawing reads the letters right, it is kept
            // unless another reads the words right too.
            let rules_letters = letters_only.borrow_mut().take().is_some();""")
    rep("""            if let Some(found) = found {
                drawings.extend(found);
            }
        }
        *self.drawings.borrow_mut() = drawings;""", """            let found = found.or_else(|| {
                if rules_letters {
                    None
                } else {
                    letters_only.borrow_mut().take()
                }
            });
            if let Some(found) = found {
                drawings.extend(found);
            }
        }
        *self.drawings.borrow_mut() = drawings;""")
    rep("""/// How many drawings [`Fonts::set_readings`] reads one line back in before""", """/// A line's text as [`Fonts::set_readings`] holds a reading to it: its
/// letters, white space aside, and its words, each run of white space one
/// space and none at either end.
struct Words {
    letters: String,
    words: String,
}

/// How a reading of a line compares with its text ([`Words::read_as`]).
#[derive(Clone, Copy, PartialEq, Eq)]
enum Read {
    /// Its words, each where it was written, and so its letters.
    Words,
    /// Its letters in the order written, with a word cut or two run together.
    Letters,
    /// Anything else.
    Otherwise,
}

impl Words {
    fn of(text: &str) -> Words {
        Words {
            letters: text.chars().filter(|c| !c.is_whitespace()).collect(),
            words: text.split_whitespace().collect::<Vec<_>>().join(" "),
        }
    }

    /// How `read`, a reading of the line (its lines joined by a line feed),
    /// compares with the line's text.
    fn read_as(&self, read: &str) -> Read {
        if !read
            .chars()
            .filter(|c| !c.is_whitespace())
            .eq(self.letters.chars())
        {
            return Read::Otherwise;
        }
        if read.split_whitespace().eq(self.words.split(' ')) {
            Read::Words
        } else {
            Read::Letters
        }
    }
}

/// How many drawings [`Fonts::set_readings`] reads one line back in before""")

open(p, 'w').write(s)
print('patched', 'dedupe' if DEDUPE else '', 'strict' if STRICT else '')
