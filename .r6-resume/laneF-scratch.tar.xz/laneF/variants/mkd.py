"""Lane F: variants of paint-C4f.rs with one part taken out each.

D1: no dedupe (every drawing of drawings_of is read)
D2: no words criterion (a reading is right when its letters are)
D3: no decoding (the read-back reads each character as typed)
D4: no row chaining (page_lines groups a row by its first run, as 935b077)
D5: no matrix (the read-back reads under the identity, and every gate in the run's ems)
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = open(os.path.join(HERE, 'paint-C4f.rs')).read()


def rep(s, old, new, count=1):
    assert s.count(old) == count, (s.count(old), old[:160])
    return s.replace(old, new)


def d1(s):
    old = """            let mut options: Vec<(RunKey, Drawing)> = Vec::new();
            for run in &line {
                let mut planned: Vec<Vec<Vec<Segment>>> =
                    vec![self.plan_run(run, Drawing::default()).unwrap_or_default()];
                for (key, drawing) in drawings_of(run, self.along(run)) {
                    let plan = self.plan_run(run, drawing).unwrap_or_default();
                    if !planned.contains(&plan) {
                        planned.push(plan);
                        options.push((key, drawing));
                    }
                }
            }
"""
    new = """            let options: Vec<(RunKey, Drawing)> = line
                .iter()
                .flat_map(|run| drawings_of(run, self.along(run)))
                .collect();
"""
    return rep(s, old, new)


def d2(s):
    old = """                    match written.read_as(&read) {
                        Read::Words => true,
                        Read::Letters => {
                            letters_only
                                .borrow_mut()
                                .get_or_insert_with(|| chosen.clone());
                            false
                        }
                        Read::Otherwise => false,
                    }"""
    new = """                    written.read_as(&read) != Read::Otherwise"""
    return rep(s, old, new)


def d3(s):
    old = """            let typed: String = line
                .iter()
                .flat_map(|run| run.text.chars().filter_map(|ch| self.read_as(run, ch)))
                .collect();"""
    new = """            let typed: String = line.iter().map(|run| run.text.as_str()).collect();"""
    s = rep(s, old, new)
    old = """                            text: segment.read_as(ch, code).to_string(),"""
    new = """                            text: ch.to_string(),"""
    return rep(s, old, new)


def d4(s):
    old = """                if row.last().is_some_and(|last| {
                    (last.y - run.y).abs() <= last.font_size.max(run.font_size) * 0.5
                }) =>"""
    new = """                if row.first().is_some_and(|first| {
                    (first.y - run.y).abs() <= first.font_size.max(run.font_size) * 0.5
                }) =>"""
    return rep(s, old, new)


def d5(s):
    old = """            let matrices: Vec<[f64; 6]> =
                line.iter().map(|run| effects.matrix(run.anchor)).collect();"""
    new = """            let matrices: Vec<[f64; 6]> = line.iter().map(|_| IDENTITY).collect();"""
    s = rep(s, old, new)
    old = """            .map(|run| (run_key(run), along_the_line(effects.matrix(run.anchor))))"""
    new = """            .map(|run| (run_key(run), along_the_line(IDENTITY)))"""
    return rep(s, old, new)


for name, f in [('D1', d1), ('D2', d2), ('D3', d3), ('D4', d4), ('D5', d5)]:
    out = f(BASE)
    open(os.path.join(HERE, 'paint-%s.rs' % name), 'w').write(out)
    print(name, 'written')
