"""Lane F: page_lines chains rows by the run above (as TextDevice asks each glyph of the one before)."""
import sys
p = sys.argv[1]
s = open(p).read()
old = """    // Rows of one baseline, then each row by `x`.
    let mut rows: Vec<Vec<&TextRun>> = Vec::new();
    for run in order {
        match rows.last_mut() {
            Some(row)
                if row.first().is_some_and(|first| {
                    (first.y - run.y).abs() <= first.font_size.max(run.font_size) * 0.5
                }) =>
            {
                row.push(run);
            }
            _ => rows.push(vec![run]),
        }
    }"""
new = """    // Rows of one baseline, then each row by `x`. A run is on the row of the
    // run above it within half an em, as `TextDevice` asks each glyph of the
    // one before it: under a `line-height` of half an em or less every line
    // of a paragraph is within that of the next, and a reader runs them all
    // together, so they are one row.
    let mut rows: Vec<Vec<&TextRun>> = Vec::new();
    for run in order {
        match rows.last_mut() {
            Some(row)
                if row.last().is_some_and(|last| {
                    (last.y - run.y).abs() <= last.font_size.max(run.font_size) * 0.5
                }) =>
            {
                row.push(run);
            }
            _ => rows.push(vec![run]),
        }
    }"""
assert s.count(old) == 1
s = s.replace(old, new)
open(p, 'w').write(s)
print('chain patched', p)
