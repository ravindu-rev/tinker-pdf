"""Lane F: under a transform, a line no drawing reads right on the page is
read back again in its runs' own space, as before.

usage: python3 -I mkfallback.py IN.rs OUT.rs   (IN is A's set_readings, no dedupe)
"""
import sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src).read()

OLD = """            let written = Words::of(&typed);
            let tried = std::cell::Cell::new(0usize);
            // The first drawing that reads the line's letters right but not
            // its words, kept where none reads both.
            let letters_only: std::cell::RefCell<Option<BTreeMap<RunKey, Drawing>>> =
                std::cell::RefCell::new(None);
            let reads_right = |chosen: &BTreeMap<RunKey, Drawing>| {
                tried.set(tried.get() + 1);
                self.read_back(&line, &matrices, frame, chosen).map(|read| {
                    match written.read_as(&read) {
                        Read::Words => true,
                        Read::Letters => {
                            letters_only
                                .borrow_mut()
                                .get_or_insert_with(|| chosen.clone());
                            false
                        }
                        Read::Otherwise => false,
                    }
                })
            };
            match reads_right(&BTreeMap::new()) {
                Some(false) => {}
                None | Some(true) => continue,
            }
"""
NEW = """            let written = Words::of(&typed);
            // Each run's drawings other than the rules'.
            let options: Vec<(RunKey, Drawing)> = line
                .iter()
                .flat_map(|run| drawings_of(run, self.along(run)))
                .collect();
            let page = self.search(&line, &matrices, frame, &written, &options);
            // Under a transform, where nothing tried reads the line right on
            // the page — glyphs the transform sets over others, whose letters
            // no drawing reads in order — the line is read back in its runs'
            // own space, as it was before the page's matrix was modelled.
            let found = match page {
                Search::Rules => continue,
                Search::Found(found) => Some(found),
                Search::Nothing if matrices.iter().any(|matrix| *matrix != IDENTITY) => {
                    let own = vec![IDENTITY; line.len()];
                    match self.search(&line, &own, frame, &written, &options) {
                        Search::Found(found) => Some(found),
                        Search::Rules | Search::Nothing => None,
                    }
                }
                Search::Nothing => None,
            };
            if let Some(found) = found {
                drawings.extend(found);
            }
        }
        *self.drawings.borrow_mut() = drawings;
    }

    /// [`Fonts::set_readings`]'s search for one line under `matrices`: the
    /// rules' drawing where it reads the line's words right; else the first
    /// drawing of one run, then of two, within [`READINGS_PER_LINE`]
    /// readings, that does; else, where the rules' drawing does not read the
    /// line's letters right, the first that does; else nothing.
    fn search(
        &self,
        line: &[&TextRun],
        matrices: &[[f64; 6]],
        frame: &Frame,
        written: &Words,
        options: &[(RunKey, Drawing)],
    ) -> Search {
        let tried = std::cell::Cell::new(0usize);
        // The first drawing that reads the line's letters right but not
        // its words, kept where none reads both.
        let letters_only: std::cell::RefCell<Option<BTreeMap<RunKey, Drawing>>> =
            std::cell::RefCell::new(None);
        let reads_right = |chosen: &BTreeMap<RunKey, Drawing>| {
            tried.set(tried.get() + 1);
            self.read_back(line, matrices, frame, chosen).map(|read| {
                match written.read_as(&read) {
                    Read::Words => true,
                    Read::Letters => {
                        letters_only
                            .borrow_mut()
                            .get_or_insert_with(|| chosen.clone());
                        false
                    }
                    Read::Otherwise => false,
                }
            })
        };
        match reads_right(&BTreeMap::new()) {
            Some(false) => {}
            None | Some(true) => return Search::Rules,
        }
"""
assert s.count(OLD) == 1
s = s.replace(OLD, NEW)

OLD2 = """            // Where the rules' drawing reads the letters right, it is kept
            // unless another reads the words right too.
            let rules_letters = letters_only.borrow_mut().take().is_some();
            // Each run's drawings that write something other than the rules'
            // and than each other's: a drawing that writes what another wrote
            // reads as that one did, and is not read again.
            let options: Vec<(RunKey, Drawing)> = line
                .iter()
                .flat_map(|run| drawings_of(run, self.along(run)))
                .collect();
            let mut found: Option<BTreeMap<RunKey, Drawing>> = None;
            for &(key, drawing) in &options {
                if tried.get() >= READINGS_PER_LINE {
                    break;
                }
                let one = BTreeMap::from([(key, drawing)]);
                if reads_right(&one) == Some(true) {
                    found = Some(one);
                    break;
                }
            }
            if found.is_none() {
                'pairs: for (at, &(first, one)) in options.iter().enumerate() {
                    for &(second, other) in options.get(at + 1..).unwrap_or_default() {
                        if second == first {
                            continue;
                        }
                        if tried.get() >= READINGS_PER_LINE {
                            break 'pairs;
                        }
                        let two = BTreeMap::from([(first, one), (second, other)]);
                        if reads_right(&two) == Some(true) {
                            found = Some(two);
                            break 'pairs;
                        }
                    }
                }
            }
            let found = found.or_else(|| {
                if rules_letters {
                    None
                } else {
                    letters_only.borrow_mut().take()
                }
            });
            if let Some(found) = found {
                drawings.extend(found);
            }
        }
        *self.drawings.borrow_mut() = drawings;
    }
"""
NEW2 = """        // Where the rules' drawing reads the letters right, it is kept
        // unless another reads the words right too.
        let rules_letters = letters_only.borrow_mut().take().is_some();
        for &(key, drawing) in options {
            if tried.get() >= READINGS_PER_LINE {
                break;
            }
            let one = BTreeMap::from([(key, drawing)]);
            if reads_right(&one) == Some(true) {
                return Search::Found(one);
            }
        }
        for (at, &(first, one)) in options.iter().enumerate() {
            for &(second, other) in options.get(at + 1..).unwrap_or_default() {
                if second == first {
                    continue;
                }
                if tried.get() >= READINGS_PER_LINE {
                    break;
                }
                let two = BTreeMap::from([(first, one), (second, other)]);
                if reads_right(&two) == Some(true) {
                    return Search::Found(two);
                }
            }
        }
        if rules_letters {
            return Search::Nothing;
        }
        let first = letters_only.borrow_mut().take();
        first.map_or(Search::Nothing, Search::Found)
    }
"""
assert s.count(OLD2) == 1
s = s.replace(OLD2, NEW2)

OLD3 = """/// How a reading of a line compares with its text ([`Words::read_as`])."""
NEW3 = """/// What [`Fonts::search`] found for a line.
enum Search {
    /// The rules' drawing reads the line right, or the line is not read back.
    Rules,
    /// Draw the line so.
    Found(BTreeMap<RunKey, Drawing>),
    /// Nothing tried reads the line right.
    Nothing,
}

/// How a reading of a line compares with its text ([`Words::read_as`])."""
assert s.count(OLD3) == 1
s = s.replace(OLD3, NEW3)
open(dst, 'w').write(s)
print('fallback', dst)
