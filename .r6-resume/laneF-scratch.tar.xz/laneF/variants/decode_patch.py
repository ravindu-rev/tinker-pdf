"""Lane F: the read-back reads each character as the page's fonts decode it.
usage: decode_patch.py PAINT.rs [--loose]  (--loose: the 935/B criterion, letters only)"""
import sys
p = sys.argv[1]
s = open(p).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("use tinker_pdf_font::encoding::{base_char, glyph_name_for_char, BaseEncoding};",
    "use tinker_pdf_font::encoding::{base_char, glyph_name_for_char, glyph_name_to_char, BaseEncoding};")

if '--loose' in sys.argv:
    rep("""            let written: String = line
                .iter()
                .flat_map(|run| run.text.chars())
                .filter(|c| !c.is_whitespace())
                .collect();""", """            // The line's text as the page's fonts give it back.
            let written: String = line
                .iter()
                .flat_map(|run| run.text.chars().filter_map(|ch| self.read_as(run, ch)))
                .filter(|c| !c.is_whitespace())
                .collect();""")
else:
    rep("""            let typed: String = line.iter().map(|run| run.text.as_str()).collect();""",
        """            // The line's text as the page's fonts give it back.
            let typed: String = line
                .iter()
                .flat_map(|run| run.text.chars().filter_map(|ch| self.read_as(run, ch)))
                .collect();""")

rep("""                            text: ch.to_string(),""", """                            // As the page's font gives it back.
                            text: segment.read_as(ch, code).to_string(),""")

# Fonts::read_as, before read_back's doc.
rep("""    /// What a reader of the page reads off `line`, one line's runs in the""", """    /// The character a reader of the page reads where `run` draws `ch`, as
    /// the font this registry draws it in gives it back ([`Segment::read_as`]),
    /// or `None` where it has no code and is not drawn ([`Fonts::encode`]).
    fn read_as(&self, run: &TextRun, ch: char) -> Option<char> {
        let chosen = choose(self.faces, &request(run), Some(ch));
        match self.encode(chosen, ch)? {
            Coded::Composite { .. } => Some(ch),
            Coded::Simple { resource, code } => Some(match chosen {
                Chosen::Standard(face) if resource == face.overflow_resource() => {
                    overflow_reads_as(ch)
                }
                _ => base_char(BaseEncoding::WinAnsi, code).unwrap_or(ch),
            }),
        }
    }

    /// What a reader of the page reads off `line`, one line's runs in the""")

# Segment::read_as after the Segment struct.
rep("""/// How [`plan_coded`] draws a run whose line, as the rules draw it, a reader""", """impl Segment {
    /// The character a reader of the page reads for `ch`, drawn at `code` in
    /// this segment, as its font gives it back: a composite font by the
    /// `/ToUnicode` written from the characters drawn, so `ch`; the overflow
    /// font by its `/Differences` name ([`overflow_reads_as`]); and a
    /// standard face by `WinAnsiEncoding`, which 9.6.5 reads by glyph name,
    /// so that its NO-BREAK SPACE is a space and its SOFT HYPHEN a hyphen
    /// (`base_char`). Read back as typed, a NO-BREAK SPACE between two digits,
    /// `CS` and so part of one number to UAX #9, was read where the page has
    /// a word space, and a drawing that read right in the model read the
    /// number's halves the other way round on the page (round 6, lane F).
    fn read_as(&self, ch: char, code: u32) -> char {
        if self.composite {
            ch
        } else if self.unspaced {
            overflow_reads_as(ch)
        } else {
            u8::try_from(code)
                .ok()
                .and_then(|code| base_char(BaseEncoding::WinAnsi, code))
                .unwrap_or(ch)
        }
    }
}

/// The character a reader reads for `ch` drawn in the overflow font: the one
/// its glyph name in the font's `/Differences` names, as
/// [`Fonts::register`] writes it — `space` for a character with no name.
fn overflow_reads_as(ch: char) -> char {
    glyph_name_to_char(&glyph_name_for_char(ch).unwrap_or_else(|| "space".to_owned()))
        .unwrap_or(ch)
}

/// How [`plan_coded`] draws a run whose line, as the rules draw it, a reader""")
open(p, 'w').write(s)
print('decode patched', p)
