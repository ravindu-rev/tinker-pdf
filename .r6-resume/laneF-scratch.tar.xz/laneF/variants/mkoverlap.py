"""Lane F: a drawing the read-back reads right is taken only where it sets no
more glyphs over others than the rules' drawing does.

usage: python3 -I mkoverlap.py IN.rs OUT.rs   (IN is A3f)
"""
import sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""        let reads_right = |chosen: &BTreeMap<RunKey, Drawing>| {
            tried.set(tried.get() + 1);
            self.read_back(line, matrices, frame, chosen)
                .map(|read| match written.read_as(&read) {
                    Read::Words => true,
                    Read::Letters => {
                        letters_only
                            .borrow_mut()
                            .get_or_insert_with(|| chosen.clone());
                        false
                    }
                    Read::Otherwise => false,
                })
        };
        match reads_right(&BTreeMap::new()) {
            Some(false) => {}
            None | Some(true) => return Search::Rules,
        }
""", """        // How many glyphs the rules' drawing sets over another: a drawing
        // that sets more is not taken, however it reads.
        let mut over_by_rules = usize::MAX;
        let reads_right = |chosen: &BTreeMap<RunKey, Drawing>, over_by_rules: usize| {
            tried.set(tried.get() + 1);
            self.read_back(line, matrices, frame, chosen)
                .map(|(read, over)| {
                    if over > over_by_rules {
                        return (false, over);
                    }
                    let right = match written.read_as(&read) {
                        Read::Words => true,
                        Read::Letters => {
                            letters_only
                                .borrow_mut()
                                .get_or_insert_with(|| chosen.clone());
                            false
                        }
                        Read::Otherwise => false,
                    };
                    (right, over)
                })
        };
        match reads_right(&BTreeMap::new(), over_by_rules) {
            Some((false, over)) => over_by_rules = over,
            None | Some((true, _)) => return Search::Rules,
        }
""")
rep("""            let one = BTreeMap::from([(key, drawing)]);
            if reads_right(&one) == Some(true) {
                return Search::Found(one);
            }""", """            let one = BTreeMap::from([(key, drawing)]);
            if reads_right(&one, over_by_rules).is_some_and(|(right, _)| right) {
                return Search::Found(one);
            }""")
rep("""                let two = BTreeMap::from([(first, one), (second, other)]);
                if reads_right(&two) == Some(true) {
                    return Search::Found(two);
                }""", """                let two = BTreeMap::from([(first, one), (second, other)]);
                if reads_right(&two, over_by_rules).is_some_and(|(right, _)| right) {
                    return Search::Found(two);
                }""")
# read_back returns the overlap count too
rep("""        drawings: &BTreeMap<RunKey, Drawing>,
    ) -> Option<String> {
        let metrics = BookMetrics::with(self.faces);""", """        drawings: &BTreeMap<RunKey, Drawing>,
    ) -> Option<(String, usize)> {
        let metrics = BookMetrics::with(self.faces);""")
rep("""        let mut page = device.finish();
        crate::text_order::into_logical_order(&mut page);
        Some(
            page.blocks
                .iter()
                .flat_map(|block| &block.lines)
                .map(|line| line.text.as_str())
                .collect::<Vec<_>>()
                .join("\\n"),
        )
    }""", """        let mut page = device.finish();
        let over = drawn_over(&page);
        crate::text_order::into_logical_order(&mut page);
        Some((
            page.blocks
                .iter()
                .flat_map(|block| &block.lines)
                .map(|line| line.text.as_str())
                .collect::<Vec<_>>()
                .join("\\n"),
            over,
        ))
    }""")
rep("""/// What [`Fonts::search`] found for a line.""", """/// How many glyphs of `page` stand over the one before them on their
/// baseline, as a reader of the page sees them: each glyph that draws
/// something but a nonspacing mark, which rides on its letter, by its box,
/// rows of one baseline to a tenth of a point, a glyph over another where it
/// starts more than a fiftieth of its size inside the one left of it.
fn drawn_over(page: &tinker_pdf_content::TextPage) -> usize {
    let mut boxes: Vec<(i64, f64, f64, f64)> = page
        .blocks
        .iter()
        .flat_map(|block| &block.lines)
        .flat_map(|line| &line.chars)
        .filter(|c| {
            !c.text.trim().is_empty()
                && c.text
                    .chars()
                    .next()
                    .is_none_or(|first| tinker_pdf_shape::unicode::bidi_class(first) != tinker_pdf_shape::unicode::BidiClass::NSM)
        })
        .map(|c| {
            let (x0, _, x1, _) = c.quad.bounds();
            ((c.origin.1 * 10.0).round() as i64, x0, x1, c.size)
        })
        .collect();
    boxes.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.total_cmp(&b.1)));
    boxes
        .windows(2)
        .filter(|pair| pair[0].0 == pair[1].0 && pair[1].1 < pair[0].2 - 0.02 * pair[1].3)
        .count()
}

/// What [`Fonts::search`] found for a line.""")
open(dst, 'w').write(s)
print('overlap', dst)
