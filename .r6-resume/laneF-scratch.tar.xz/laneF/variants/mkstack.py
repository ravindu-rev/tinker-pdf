"""Lane F: page_lines reads a row whose runs stand over one another, lines a
reader runs together under a tight line height, as one line.

usage: python3 -I mkstack.py IN.rs OUT.rs   (IN has the first-run rows of 935b077)
"""
import sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src).read()


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:120])
    s = s.replace(old, new)


rep("""    // Rows of one baseline, then each row by `x`. A run is on the row of the
    // run above it within half an em, as `TextDevice` asks each glyph of the
    // one before it: under a `line-height` of half an em or less every line
    // of a paragraph is within that of the next, and a reader runs them all
    // together, so they are one row.
""", """    // Rows of one baseline, then each row by `x`.
""")
rep("""    for mut row in rows {
        row.sort_by(|a, b| a.x.total_cmp(&b.x));
        let mut line: Vec<&TextRun> = Vec::new();""", """    for mut row in rows {
        row.sort_by(|a, b| a.x.total_cmp(&b.x));
        // A row whose runs stand over one another is lines of layout that a
        // reader runs together: `TextDevice` holds a glyph on the line whose
        // first glyph's baseline is within half an em of its own, so under a
        // `line-height` of half an em or less the next line of a paragraph,
        // drawn after this one, goes on the same line. Cut by `x` its runs
        // would be read back in pieces that interleave the two; read whole
        // they are what the reader reads.
        if stacked(&row) {
            lines.push(row);
            continue;
        }
        let mut line: Vec<&TextRun> = Vec::new();""")
rep("""/// A line's text as [`Fonts::set_readings`] holds a reading to it: its""", """/// Whether some run of `row`, sorted by `x`, starts more than half an em
/// before an earlier one ends: two lines of layout in one row
/// ([`page_lines`]). Runs on one line of layout abut or leave a gap, give or
/// take a rounding.
fn stacked(row: &[&TextRun]) -> bool {
    let mut end = f64::NEG_INFINITY;
    row.iter().any(|run| {
        let over = run.x < end - run.font_size * RESUMED_WITHIN;
        end = end.max(run.x + run.width);
        over
    })
}

/// A line's text as [`Fonts::set_readings`] holds a reading to it: its""")
open(dst, 'w').write(s)
print('stacked', dst)
