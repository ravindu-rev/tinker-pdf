# Lane F (round 6), notes for a restart

Third resumption started 10:59 on 16 Oct (container restarted ~10:56).
Worktree: /home/user/tinker-pdf/.claude/worktrees/wf_db942488-334-4
Branch head at start: r6-laneF-wip = 9ec1b17 (WIP over 4af61f0 over 05cea0b).
Earlier runs' transcripts, extracted: prev1.txt (run 1), prev3.txt / prev3-short.txt (run 2).

## State of the code at 9ec1b17 (paint.rs = variants/paint-A4f.rs, sha 94db30c5)
"A4" = the read-back models the page:
- OnPage::matrix(anchor): product of the cm's Effects::open writes.
- read_back draws each glyph under that matrix; text decoded as the page's fonts give it back
  (Segment::read_as: WinAnsi by glyph name, overflow by /Differences name).
- along_the_line(matrix) = |baseline scale| / sqrt|det|; every rule that asks whether a reader
  parts two objects asks in page ems: parted(), page_lines() gap, leading_mark_at().
- search(): Words criterion (letters AND words must match; a letters-only drawing is kept as a
  fallback only where the rules' drawing does not read the letters right).
- Under a transform where nothing reads right on the page, fall back to run-space (identity) model.
- Overlap guard: a drawing that sets more glyphs over others (drawn_over) than the rules' is refused.
- Rows not chained (run 2 found chaining broke line-height num books).
Variants: variants/paint-*.rs (935 = 05cea0b's, A3f, A4f = HEAD). swap.sh NAME swaps.

## Decided by run 2
- V5 dedupe (each drawing read once) regresses lh04 punct books' logical vs 935: owner option, not
  committed; V5 cases committed as pins.
- V3 cases pinned (Left (4) class, K-11's reader). V2 = Left (1) tie-break (owner's).
- bidi-H1.rs, bidi-H6.rs variants exist for owner options (variants/).

## Jobs
- 11:03 both.sh A4f A4 (worktree): full suites, both builds -> out/suite-A4-*.log, out/kit-A4. Default f6: 0 worse, 402 better.
- 11:12 owner.sh H1 (snap/H1 = worktree copy + variants/bidi-H1.rs): suites both builds, bidi_conformance, cases -> out/suite-H1-*, out/owner-H1-*.
  (snap target is ~0.3-1 GB only: disk is not the constraint, CPU is.)
- 11:20 queue.sh: after H1, owner.sh H6 (snap/H6, bidi-H6.rs) then owner.sh A4d (snap/A4d, paint-A4d.rs = A4 + dedupe, the V5 option).
- 11:18 WIP fc66e3c: guard tests (fallback, overprint guard) in epub_fallback.rs; injections.json updated (93 apply).
- Scripts must be run as `bash /abs/path/script args` (the harness refuses variables/chains around bash).

## Found in run 3
- A4's fallback (run-space search when nothing reads right on the page) brings V1 back on 5 (default) f6
  he/punct/none books (scaleX(2), scaleX(3), scaleY(0.5), matrix, .w scaleX(2) at 0.6em): it turns a ?! that reads
  right by the rules on the page. Without the fallback (A4nf) they conserve; but the fallback is what keeps 34 f6
  ib books' logical (935's). A5 = A4 + reads_closer(): the run-space drawing is taken only where, read back on the
  page, it holds more of the text's letter pairs in order than the rules' drawing does there, and sets no more glyphs
  over others there (variants/paint-A5f.rs, tools/mkvar5.py). Diag p5ib: all right.
- Failing-first at 05cea0b paint (snap/F935): default fails 1 (cons H4(2)) + 3 tests (transform 11 cases, words 5, ; 1);
  bundled 3 tests + the V3 he pin reads cons at 935 bundled (pinned without cons): check A5 bundled for V3 he.
- 11:3x both.sh A5f A5 queued (next_a5.sh) after A4 default. Snaps H6, A4d rebased onto A5 (A4d = A5 + dedupe).
  H1 snap is on A4 (only transform-fallback lines differ).

- 11:35 variants/paint-A5g.rs = A5f + doc patch (tools/docpatch.py): the FINAL paint.rs (doc-only diff from A5f).
- 11:36 inj.sh (snap/INJ = worktree copy + A5g): control + 14 injections, both builds -> out/inj/summary-*.txt.
- epub_conservation.rs: V3 he case is Case::each (default pinned, bundled Holds cons: conserves at every tree in bundled).
- Catalogue now 96 (3 new: page/closer-unchecked, page/closer-overprint-unchecked, page/mark-in-the-runs-ems).

## 11:33 RESTART OF JOBS: background jobs die at their timeout (default 30 min)! Always pass timeout 7200000.
- A4 suite was killed at 66/74 default (all 0 worse; partial dump out/kit-A4). H1 killed at 49/74 (partial out/kit-H1).
- 11:34 both.sh A5g A5 (worktree paint.rs = A5g, the final) 2h timeout -> out/suite-A5-*, out/kit-A5.
- 11:34 inj.sh (snap/INJ, A5g + current tests) 2h timeout -> out/inj/summary-*.txt.
- TODO after: owner H1 (snap/H1 is on A4: refresh its paint.rs to A5g), H6, A4d(=A5+dedupe) each with 2h timeout;
  timing (zz_v6_time) at 56/935/tip with no other load; gates; final tip suites; fold commits.
- epub_fallback.rs: transform test gained 5 dir-less punct cases (Holds cons logical found) for reads_closer.

- 11:40 injection default results so far: lines-cut fires 0 -> suite.sh snap/X default LC (A5g + lines-cut injection) on
  f6/v6_transform/v6_cells/v6_inline/v6_measure to find a book that catches it (compare to out/kit-A5).
- Fold plan: msg1.txt (sweeps), V6 doc commit, msg2.txt (fix), V2/V3 pins, V4/V5, HANDOFF; tools/stages.py cuts test
  files per commit (stage/c2, c3, c4); tools/docs_edit.py applies doc steps (numbers.json to write) to docs0 copies.

- 11:41 after_lc.sh queued: mark-in-the-runs-ems injection variant over f6/v6_transform in snap/X (MK).
- tools/timing.sh ready (needs snap/T5 = copy with A5g); run when nothing else runs.
- H1 preliminary (kit-H1 partial vs kit-A4): big gains (h1_breadth +516, v3b +148, ofscripts +138, f6 +114) and
  costs (h1_v1 12, h2_v1b 12, h1min 10, rtlpunct 8, code32 2: the H6/opens class and ar minus/pct).

- 11:46 injections default done (out/inj/summary-default.txt): zero fires for lines-cut, mark, closer-overprint.
  LC variant over f6: 0 changes vs A5 (others pending A5 dump). diag4.sh (snap/Y): targeted sweep diag/zero.tsv
  (220 books: tables near 0.5em gaps, inline blocks, marks opening styled runs) at A5g + the 3 injections ->
  diag/zero-{A5g,page-*}-default.txt. MK and CO family runs queued in snap/X.
- Left (6) mechanism found: TextDevice's gap tests compare page x (disjoint: origin.0 > pen + slack; backwards),
  so under a half turn no gap along the baseline is seen. Reader change for rotated text; not attempted (corpus risk).

## Next
1. Build; run full suites at A4 both builds (both.sh A4f A4); case tests at A4.
2. Compare A4 vs 3 baselines (tools/newworse.py out/kit-A4).
3. Failing-first of new tests at 05cea0b; injections (variants/laneF-injections.json).
4. Docs: V6 fix, V4 cost, V1, V2/V3 counts in ROADMAP CD-19 / epub.md.
5. Owner options H1/H6/H2-3 measured on scratch.
6. Fold WIP into one commit per mechanism.

## 12:00 (run 4, after context reset)
- diag4: lines-cut, mark, closer-overprint injections: f6/v6 dumps byte-identical; mark & closer-overprint
  rules never exercised -> A6 = A5g minus leading_mark_at's along (935's again) minus reads_closer's overprint
  check (variants/paint-A6.rs, paint-A6f.rs via tools/mkvar6.py). page_lines' along kept: add a text test
  (two touching RTL cells, border-spacing 6px, scaleX(3), td word-spacing 1em: first cell reads on one line).
- A5g suite run (both.sh A5g A5): default 64/74 at 11:59, 0 worse so far. Bundled after.
- After A5: swap A6f, add test, injections.json: drop page/mark-in-the-runs-ems + page/closer-overprint-unchecked,
  closer-unchecked old text = `        written.pairs_in(&read) > written.pairs_in(&rules)`.

## 12:20 RUN 5 (fourth restart at 12:14; worktree reset to r6-laneF-wip = 7fa1e40, paint.rs = A6f 1346d80f)
- Found: the A5g default suite had FINISHED (74/74 RAN, 0 worse, exit 0, 12:10, out/suite-A5-default.log);
  run 4 itself stopped A5 bundled at 12:10 to swap A6 in. A5g bundled never ran. Timing job died.
- NEW resumable runner tools/rsuite.sh TREE BUILD TAG [REGEX]: each family its own process (xargs -P THREADS),
  out/rs-TAG-BUILD/<family>.log (+ progress.txt, summary.txt); rerun skips finished families. USE THIS.
- 12:22 job: rsuite.sh tip default A6 (THREADS=3, 2h timeout) -> out/rs-A6-default/, kit dump out/kit-A6.
- 12:28 rsuite.sh fixed (RAN line is on the "test X ... " line: unanchored). Restarted: rsuite tip default A6 (THREADS=3).
- Removed snaps X, Y, A4d (+targets). Snaps refreshed from worktree 7fa1e40: H1 (bidi-H1.rs), H6 (bidi-H6.rs),
  A6d (paint-A6d.rs = A6 + each drawing read once, the V5 option).
- NEW tools/owner2.sh NAME: rsuite default+bundled, shape (bidi_conformance, fingerprints), cases both builds
  (+text_logical_order), each step resumable. 12:29 job: owner2.sh H1 (THREADS=2).
- TODO noticed: epub_fallback.rs transform test doc and msg2.txt still name leading_mark_at among the page-ems
  rules: A6 took that out; fix the wording. README kit table lacks the zz_f6_ems row.
- 12:35 failing-first DONE: tools/ff2.sh F935 935 (snap/F935 = worktree tests + 05cea0b paint) -> out/ff-F935-{default,bundled}.log.
  Default fails: H4(2) whole (Persian digits), transform test 16/23, words test 5/6, ; whole 1/54, cells guard (8 rows).
  Bundled: transform 8/23 (incl. scaleY(2): it is V1 class in bundled -> relabelled, not a control), words 3/6, ; 1/54, cells 8.
  Guards pass at 935: read_as test, fallback-search test, overprint test, budget pins, V2/V3 pins.
- 12:36 tip cases (cases.sh tip A6): default 36+53 ok, bundled 36+53 ok.
- classes.py: round-6 classes added (V2 closing bracket, V3 touching cells, Left (6) half turn); on kit-A5 default no "others".
- epub_fallback.rs: transform test doc no longer names leading_mark_at; scaleY(2) case relabelled (V1 with bundled-fonts).
- 12:38 job: inj2.sh (snap/INJ refreshed = worktree A6 + tests) -> out/inj6/summary-*.txt, control + 12, both builds.
- DOC TODO (C1 sweeps commit): README f6 row (+zz_f6_ems 264) DONE, "63 in all"->75 DONE, "63, 63 and 4"->75 DONE,
  verification.md 1744 75 DONE; README line ~211 and verification.md "13 and 15 minutes": re-time (75 families);
  verification.md "244 in each build" -> CASE lines now 293 default / 292 bundled (05cea0b had 245 = 244 + control).
  verification.md:10 "6 819 passed, 0 failed, 63 ignored ... 289 suites" -> re-measure at gates.
- DECIDED: no reader change in this lane (Left (3), (4), (6) are TextDevice/ruling-14 changes: every PDF, corpus not
  measurable locally, rotated-text fingerprints may move). Mechanisms named, pinned, open items.
- H2-3: no candidate keeps glyphs where layout put them (ActualText not substituted by the reader; the gap is real).
- queue2.sh (H6 then A6d) written; START IT ONLY WHEN H1 IS NEAR DONE (2h timeout applies from start).
- 12:45 job: after_inj.sh (waits for inj6 "inj done", then rsuite snap/F935 default+bundled '^zz_(v6|f6)_' tag F935)
  = commit 1's claim (round-6 families read 935b077 outputs 0/0/0 at 05cea0b's code). Out: out/rs-F935-*/.
- PLAN after A6 default: start rsuite tip bundled A6 (THREADS=3). After H1: queue2.sh (H6, A6d).
  Then: timing (quiet), gates, docs with numbers, fold, baseline refresh commit, final suites at tip.
- 12:44 jobs running: rs A6 default (41/75), a6b.sh (A6 bundled after default), owner2 H1 (default 28/75),
  inj2.sh (default 9/13), after_inj.sh (F935 round-6 families after inj), owner2 A6d (started 12:44).
  queue2.sh now = H6 only after H1: START IT when H1 bundled is under way (2h timeout).
- tools/docs6.py (+ drydocs.sh): the doc edits of steps fix / v2v3 / v4v5 with numbers6.json placeholders;
  dry run applies cleanly. Numbers needed: v1_hunt (12/6 lane V), r6_books 14050, all_books, gains (A6 runs),
  left6/v2/v3 (classes.py on table json), timings (timing2.sh, SIGSTOPs other jobs), v5 (A6d vs A6).
- msgs/c2-v6.txt written (the V6 docs commit message).
- 12:47 timing2.sh started (SIGSTOPs all other lane F jobs, times zz_v6_time at 56, snap/F935, tip x2, CONTs on exit)
  -> out/time6-*/, out/timing2.log. IF A RESTART HITS DURING IT, nothing is left stopped (processes die anyway).
- A6 vs A5g default dumps: 43 families compared, 0 differ (the two removed rules change no output).
- 12:46 WIP 1477c11 (README/verification counts, test docs V2/V3/Persian digits).
- msgs/c3-fix.txt drafted (fix commit message; the "5 books"/"34 books" numbers are A4-era: rephrase or remeasure).
- 12:55 TIMING DONE (out/time3.txt via tools/time3.py out): tip vs 935b077 ~1.0-1.2x on h1/prose shapes, BUT
  ls-nowrap 216 -> 11 897 ms (55x over 935, 102x over 56) and rtl-justified 3 740 -> 21 823 ms (5.8x over 935):
  letter-spaced lines now spend the whole budget (Words criterion: rules read letters, not words?). Investigating
  with snap/Z (A6 + TINKER_DIAG_READBACK prints, tests/zz_diag_ls.rs; tools/ztest.sh) -> out/zdiag1.log.
- LESSON: SIGSTOP killed the owner2 H1 and inj2 background jobs (exit 147): never stop jobs again. Both resumed
  12:57 (inj2.sh now resumable per name; default 12/13 kept). A6 default, a6b, after_inj, A6d survived.
- 13:05 DIAG (out/zdiag1.log, zdiag2.log): ls-nowrap's rules reading only CUTS a word (`٦٠.` -> `٦٠ .`), letters right;
  A6's Words criterion then searches 128 readings for nothing. The words test's cases are JOINS or order errors.
  A7 = A6 + Read::Cut (rules' reading that only cuts, no join, is kept as 935 kept it): variants/paint-A7.rs via
  tools/mkvar7.py. snap/A7 (worktree + A7; target copied from Z-target). 13:06 cases.sh snap/A7 A7 running.
- KILLED a6b.sh (A6 bundled queue): if A7 is adopted the final suites are A7's. Plan: when A6 default done,
  swap A7 into the worktree, run rsuite tip default A7 + bundled A7; compare A7 vs A6 default (cost-free check).
- 13:15 A7 cases: default 1 test fails = two_cells_a_reader_parts_on_the_page_are_read_back_apart (A6's gain over all
  baselines: its rules reading is cut-only). So A7 trades A6's cut-only gains for 935's speed on letter-spaced lines.
  Reasoning: A6's time cost (55x on ls-nowrap vs 935) is a price on something that used to work -> owner's; A7 costs
  nothing that worked at a baseline (to confirm by the full run) -> commit A7, offer A6's cut-search as an owner option.
- variants/paint-A7c.rs = A7 + READINGS counter (cfg(test)); fam/unit_cut_test.rs = unit test (epub/tests.rs) holding
  "read back once" by count + a join guard. Both in snap/A7. 13:16 job: rsuite snap/A7 default A7 (THREADS=2).
- 13:25 unit test a_line_a_reader_cuts_only_at_its_spacing_is_read_back_once: A7c passes (1 reading); A6c fails
  (128 readings) = failing first without the Cut rule. variants/paint-A6c.rs, mkvar6c.py.
- A7 + lines-cut injection: the cells test reads identically to A7 (out/cells-A7*.txt) -> page_lines' along may be
  unexercised at A7. 13:26 job: rsuite snap/Z default ZLC '^zz_(f6|v6)_' (snap/Z = A7c + lines-cut injection);
  compare kit-ZLC with kit-A7 on those families when A7 default is done. Injection variants: variants/paint-A7c-*.rs.
- inj6 (A6) finished both builds (out/inj6) but A7 changes the code: rerun injections at A7 (catalogue updates:
  letters-are-enough text changed; add cut-searched, joins-are-cuts; drop lines-cut if unexercised).
- 13:18 WIP 0fe72db: worktree = A7c (paint) + unit test (epub/tests.rs, rustfmt'd); worktree == snap/A7 (crates, tools).
  snap/A7d = snap/A7 + variants/paint-A7d.rs (target moved from A6d-target). A6d run discarded (A6 base).
- Jobs: rs A6 default (worktree binary, 62/79), rs A7 default (snap/A7), owner2 H1, after_inj (F935), rs ZLC (snap/Z).
- NEXT: when A6 default done -> compare A7 vs A6 default (cmpdirs + cmp.py); ZLC vs A7 on f6/v6 families
  (page_lines along exercised?). Then A7 bundled, A7d both, H6 (queue2 after H1), injections at A7 (refresh snap/INJ),
  timing at A7 tip (quiet), docs numbers, gates, fold.
- 13:40 cells test REPLACED: two_cells_are_read_back_as_a_reader_parts_them_on_the_page (scaleX(0.5), 10px, Latin + RTL
  cell: the RTL cell's words not read together; + pins of the scaleX(2) 6px RTL cells at A7's reading, per build).
  Passes A7 both builds; fails at 05cea0b both builds; fails with lines-cut injection (snap/Z). WIP committed.
  (f6_ems at A7: lines-cut injection changes text of t/{he,ar}/lat/10px under scaleX(0.5): rule exercised.)
- 13:22 (real clock; earlier NOTES times ran ~20 min ahead) paint.rs set_readings doc names Read::Cut (doc only).
  tools/stages6.py OUT: the fix commit's epub_conservation.rs (no V2/V3) and epub_fallback.rs (no V5 test).
  tools/docs6.py updated for Cut + new test names (+ t_ls_a6/t_ls_935 numbers); dry run OK.
- 13:30 F935 default: the 12 round-6 families read their 935b077 outputs 0/0/0 at 05cea0b's code (commit 1's claim).
- catalogue now 96 (A7: letters-are-enough text, page/cut-searched, page/joins-are-cuts with lib suite); WIP 1502834.
- snap/INJ refreshed = worktree A7 (paint sha c8ed493f, doc-only diff from A7c). tools/inj7.sh (catalogue suites,
  resumable) queued by after_f935.sh (job) -> out/inj7/summary-*.txt.
- 13:50 F935 bundled: 12 round-6 families 0/0/0 at 05cea0b (commit 1's claim, both builds).
- ZLC (A7 + lines-cut injection): f6_transform 4 worse, v6_transform 1 worse -> page_lines' page ems exercised at A7.
  ALSO: vs A6, A7 gives up many gains (ZLC numbers suggest v6_lists 183->0, numsep 330->6, inline 224->92): A6's
  Words search on cut-only rules readings. DECISION: commit A7 (no time price); A6's cut-search = owner option
  (gains N books vs up to 55x open time on letter-spaced lines). Quantify with cmp(kit-A6, kit-A7) both builds.
- jobs: a7b.sh (A7 bundled after A7 default), inj7 (via after_f935, now running), H1, A6 default (finishing).
- 13:50 A6 default DONE: 75 families + 4 lines, 0 books worse vs 935 everywhere (rs-A6-default).
- !! A7 default zz_f6_transform: 4 books WORSE vs 935 (ar/num/rtl, letter-spacing 0.1em + ws 0.5em + justify, under
  matrix(1.6,0,0,0.8)/scaleX(2)/scaleY(0.5) on p, and scaleX(2) on .w): lost text (text=1 -> 0): the rules' page reading
  cuts '25|٪' (Read::Cut) -> A7 keeps rules; 935 read the line in its runs' own space, where the rules did not read
  right, and found a drawing that reads whole on the page; A6 found it on the page. So A7 alone is not committable.
  PLAN A8 = A7 + : rules' page reading Cut under a transform -> search in the runs' own space (935's search) and take
  what it finds where it reads the line's words right on the page (and sets no more glyphs over others). Cost = 935's.
  tools/rowtext.py prints a book's text from kit dumps.
- 13:52 STOPPED A7 default (53/79), a7b (A7 bundled queue), inj7 (bundled 6/15; snap/INJ restored, sha c8ed493f).
  A8 written in the worktree (Search::Cut; set_readings: Cut under a transform -> own-space search, taken if
  Fonts::reads_whole: page reading Words and over <= rules' over). variants/paint-A8.rs; snap/Z = worktree (A8).
  New guard test epub_fallback a_line_a_reader_cuts_on_the_page_under_a_transform_is_searched_in_its_runs_space_too
  (4 styles of the f6 num/rtl book, Case::both Holds cons logical whole found). tools/mkinj8.py -> variants/paint-A8-*.rs
  (cut-kept-under-a-transform, whole-unchecked, whole-over-unchecked, cut-searched, read-as-typed, closer-unchecked).
  Job: rsuite snap/Z default A8q '^zz_(f6_transform|v6_transform|f6_ems)$'.
- 14:05 A8q (snap/Z = A8): f6_ems 0 worse/22 better, v6_transform 0/124 (A6 144), f6_transform 0/349 (A6 411): the 4 A7
  books fixed. Guard test passes A8 both builds, FAILS at A7 both builds (snap/A7 deleted after).
- WIP d70aaf6 (A8 + guard test + zz_v6_time shapes ls-scaled, rtl-justified-scaled).
- STOPPED owner2 H1 (A6 base; default 73/75). Owner options re-based on A8: tools/setup8.sh -> snap/H1, snap/H6, snap/A8d
  (variants/paint-A8d.rs via mkvar8d.py); old H1 outputs renamed *H1onA6*. queue3.sh default H1 A8d (after A8 default),
  queue3.sh bundled H6 (after A8 bundled). Jobs: rs A8 default + bundled at tip (THREADS=2 each).
- catalogue 99 (tools/upd_inj8.py): cut-searched text = A8's Cut arm; + page/cut-kept-under-a-transform,
  page/whole-unchecked, page/whole-over-unchecked; no-fallback text fixed ('Search::Nothing if transformed'). 99/99 apply.
- diag (variants/paint-A8-diag.rs, mkdiag8.py) in snap/Z: case tests -> reads_whole called 6x, all words=false (Words check
  decisive), over never decisive (0/0); reads_closer 3x all true (closer-unchecked not decisive in cases); readas-typed
  only NBSP (whitespace either way) and Adlam (no letters either way) -> read_as not decisive in cases.
  Job: rsuite snap/Z default ZD (round-6 + hunt_scripts + h1_ofscripts) THREADS=1 -> grep DIAGRULE per family.
- 14:10 tools/rsuite2.sh = rsuite.sh + REL=1 (optimised, LTO off, shared target laneF/rel-target). tools/val.sh: snap/A8d 6
  families debug vs release, kit dumps compared (job). If identical -> owner options in release (queue3 uses owner2.sh;
  switch owner2 to rsuite2 REL=1 before it starts).
- snap/A8s = worktree + variants/paint-A8s.rs (= paint-A8-cut-searched: the rules' cut-only reading searched on, A6's
  gains; owner option). docs6.py fix step updated for A8 (reads_whole, guard test, 'searched no further'; backup
  docs6.py.bak7); drydocs OK.
- 14:16 val: release == debug byte for byte on 6 families of snap/A8d (cmpdirs 6, differ 0); release ~6x faster.
  STOPPED the debug A8 tip suites (default 25/75, bundled 21/75 in out/rs-A8-*, kit-A8: keep to compare with release),
  queue3 jobs, ZD debug. Deleted debug targets H1/H6/A8d/Z. tools/owner3.sh = owner2 optimised (rel-target).
  JOB queue4.sh (THREADS=4 JOBS=4, REL=1): tip A8r default+bundled(+rtl_lines) -> ZD diag (snap/Z) -> ZC (snap/ZC =
  closer-unchecked) on round-6+scripts families -> owner3 H1, H6, A8d, A8s. Resumable; rerun queue4.sh after a restart.
- f6_transform diag (debug, before stop): closer 74 false/56 true (decisive -> need a test: ZC vs A8r); whole 22 false/8
  true (Words check decisive; guard test); over never decisive (over<=rules_over always); readas-typed: none in f6.
- tools/inj8.sh written (catalogue 99 at A8 in snap/INJ, refreshed). msgs/c3-fix8.txt = fix commit draft for A8.
- 14:20 TIP A8r (release): default 75 RAN 136967 rows 0 worse 2386 better; lines 4 RAN 0 worse; bundled 75 RAN 0 worse 2051 better.
  debug kit-A8 (partial) == kit-A8r on 83 family files. classes: default no others; bundled 15 others = f6 he/ib/none
  (found at 9297d2d only, s1 -> s0 since 56dfd93) -> NEW class 'Left (7) squeezed inline blocks' (classes.py), pinned in
  a_line_nothing_reads_right... bundled Pinned(logical) (stages6 reverts it for the fix commit: lives in C4). V5 = Left (8)
  (V5 test doc renumbered). docs6 v2v3 adds (7), v4v5 adds (8) + A8s cut-search option sentence (numbers cut_gain_*, t_ls_*).
- ZD diag (14 fams): reads_whole overprint clause NEVER decisive -> REMOVED (reads_whole = page reading is Words). catalogue 98
  (whole-over-unchecked dropped; whole-unchecked text new). Variants regenerated (paint-A8.rs = worktree; A8d, A8s, inj).
  Owner snaps H1/H6/A8d/A8s refreshed with this paint. tipre.sh: tip suites again (tag A8t) - running.
- ZC (closer unchecked) vs A8r: 35 books change in f6_transform, 1 verdict worse: he/ib/none rotate(90deg) 0.6em logical 1->0
  -> new case 'the same at 0.6em turned a quarter (guard)' in a_line_nothing_reads_right... (default Holds logical, bundled
  Holds found). Passes tip both builds.
- readas: numsep NBSP lines (96), scripts2 non-BMP (594): ZR run queued (queue5) to see if any book changes.
- 14:45 !! SHARED rel-target: every tree's rtl_probes binary has the SAME path (rtl_probes-52242a2c default, -3541175d bundled):
  concurrent release runs executed each other's binaries. Contaminated and DELETED: rs-A8t-*, kit-A8t, rs-ZR, kit-ZR, rs-H1-*,
  kit-H1 (also old debug H1 bundled logs from the A6-based run were there). Clean: A8r (both), ZD, ZC, A8dR/A8dD val.
  queue6.sh runs everything optimised ONE AT A TIME: tip A8t both -> ZR -> owner3 H1 H6 A8d A8s. NEVER run two rel-target
  jobs at once. inj8 (debug, snap/INJ-target) runs alongside: own target.
- inj8 default done: every page rule fires >=1 except page/read-as-typed 0 (closer 1, cut-kept 1, whole 1, cut-searched 2...).
- read_as: scratch grid of NBSP lines (fam/zz_scratch_readas.rs, 192 books, snap Z vs ZR): 0 verdicts change, 22 texts change;
  v6_scripts2: 40 texts change (non-BMP letters drawn as spaces), 0 verdicts. DECISION: keep read_as (models the page), report
  0 fires with this evidence; open item.
- 14:58 FINAL TIP A8t (release, queue6, alone in rel-target): default 75 RAN 136967 rows 0 worse 2386 better 3379 changed;
  lines 4 RAN 0 worse; bundled 75 RAN 0 worse 2051 better 2810 changed. kit-A8t == kit-A8r on all 160 files.
  (A8t default 14:52:10-~14:55, bundled 14:56:05-~14:59, with inj8 running alongside).
- inj8 DONE (catalogue 98, A8 paint 21f92080): default/bundled fires: control 0/0, no-pairs 2/2, lines-touching 2/3,
  read-back-under-no-matrix 2/2, rules-in-the-runs-ems 2/2, along-inverted 2/2, parted 1/1, lines-cut 1/1, read-as-typed 0/0,
  letters-are-enough 4/3, cut-searched 2/2, cut-kept-under-a-transform 1/1, whole-unchecked 1/0, joins-are-cuts 4/3,
  no-fallback 1/1, overprint-taken 1/1, closer-unchecked 1/0.
- ff2 F935 (final tests vs 05cea0b paint): default fails 6 tests, bundled 5 (list in out/ff-F935-*.log). The quarter-turn
  case FAILS at 05cea0b (logical lost at 935b077, held at 9297/56) -> it is a case, not a guard: renamed (WIP 899b5a8).
- gates8.sh started 14:59 (laneK gates + font nodefault + wasm determinism) -> out/gates8/ (NOT harness-tracked; rerun if lost).
- 15:20 H1 (owner3, release, A8 base) measured: out/optsum-H1.txt, out/optkey-H1.txt. vs tip: default worse 1075 (laneR 1021),
  better 927; bundled worse 1775 (laneR 1672), better 942. Classes: H1 56->0, V2 32->1 (8->1 b), V3 2->0, price 4478->5461
  (3742->5372 b), H6 8->16, others 0->24 (51 b). New worse than 56dfd93 vs 935's: 1014 (1698 b). Lines: laneR 526 worse,
  k11rv_bidi 143 worse/513 gains, sent 27 gains. Shape (bidi_conformance, fingerprints) ok. Cases fail 6 tests both builds.
- 15:30 H6 measured (optkey-H6.txt): vs tip worse 8 (6 b) = h1_v1 dotex-paren/exell-paren opens/rtl (no spacing and ls 0.5em
  justified) lose cons+text; better 12 (10 b) = dotex-none/exell-none (8) + h1min g-dotex/g-exell (4). H6 class 8->0 both.
  New worse vs 56dfd93 beyond 935's: 0 both. Lines 0/0. Shape ok. Cases: a_line_opening_with_a_bracket_pair... fails both.
- gates8: fmt, clippy, clippy-bundled, test-default (398s), test-bundled (435s), test-nodefault (411s), test-shape all exit 0.
- 15:35 GATES8 ALL GREEN (done marker): fmt, clippy, clippy-bundled, clippy199 x2, xtask; tinker-pdf default 158 suites 2733
  passed/119 ignored, bundled 2733/119, nodefault 2727/119; shape 151; font nodefault 165; determinism 7+3 ok each build;
  wasm32-wasip1 determinism 7 ok. (Code = WIP 899b5a8.)
- A8d (dedupe, V5 option): vs tip worse 2 (3 b) v6_transform, better 348 (259); vs 935 worse 5 (6): f6_transform 3 + v6t 2(3).
  Cases: FAILS a_drawing_that_sets_more_glyphs_over_others (overprint guard!) and the V5 pin test, both builds.
- 15:40 A8s (cut readings searched on, = A6's gains on A8): vs tip worse 0, better 1726 (1913 b); vs 935 worse 0, better
  4072 (3939 b); new worse vs 56dfd93: 0. Cases: two_cells... fails (its cut-only cells pin flips: a gain). Price = time.
- queue6 done. Cleanup: rel-target, INJ snap+target, Z/ZC/ZR/H1/H6/A8d snaps deleted. 15:41 timing3.sh started (quiet!):
  56, snap/F935, tip, snap/A8s x2 -> out/time8-*. DO NOT start heavy jobs until it ends.
- 16:02 TIMING (time8.py -> out/time8.txt; debug, quiet, best of 2): tip vs 935b077 at n=256: rtl-justified 20964 vs 3327 ms
  (6.3x!), rtl-justified-scaled 6893 vs 3266 (2.1x), ls-scaled 294 vs 208 (1.4x), h1-wrapped 27127 vs 23749 (1.14x), others
  ~1.0-1.15x. Cut search (A8s): ls-nowrap 10923 vs tip 209 (52x), ls-scaled 22393 vs 294 (76x).
  => the tip's Words search on lines whose rules' reading JOINS (Read::Letters) costs up to 6.3x of 935b077: a time price on
  something that worked -> owner's (A7 reasoning). Investigating A9 = rules' Letters reading kept like a cut (935's stop).
- 16:08 A9 = variants/paint-A9.rs (tools/mkvar9.py; sha 345df2de): rules' reading Cut|Letters -> Search::Cut (935b077 compared
  letters only, so stopped at both); rules_letters removed (never set). snap/A9 (fresh from worktree + A9 paint), snap/A9-target
  (= old A8s debug target, renamed; snap/A8s deleted). timing9.sh (debug, quiet) -> out/time8-snap-A9-{1,2}. NEXT: owner3.sh A9
  (release, alone) -> compare vs kit-A8t (losses) and 935 (0 worse?); then decide: A9 committed + A8's joined search an option.
  Notes appended with tools/addnote.py (note.txt) since the sandbox refuses heredocs here.
- 16:12 A9 TIMING (time9.py; debug, best of 2, n=256, 56/935/A9/A8tip/A8s): rtl-justified 345/3327/8547/20964/20420 -> A9 is
  2.57x 935b077 (A8 2.45x more); rtl-justified-scaled A9 3115 = 0.95x 935; ls-scaled A9 306 = 1.47x 935 (2 readings under a
  transform); h1-* 1.09-1.12x; prose 1.05x. A9's remaining rtl-justified cost = found drawings held to the WORDS (a line whose
  first letters-only drawing 935b077 took spends the budget looking for a words one).
  => A9L = A9 + a found drawing taken at letters (935b077's acceptance), rules' letters still searched in runs' space under a
  transform (variants/paint-A9L.rs, tools/mkvar9l.py, snap/A9L + snap/A9L-target). queue9.sh (A9 release) then queue9l.sh
  (A9L release + debug timing x2). Decide after: committed = the one with no new price beyond what fixes need; the
  others are owner options with gains (vs it) and time.
- 16:20 A9 (release): 0 worse vs 935 both builds; better 601 (630); vs A8t worse 1803 (1451), better 0. Standard counts
  (stdcount.py: worse than 9297d2d / worse than 56dfd93 in conserving) A9 = A8t except 2 default books (Persian digits,
  worse_b) -> the joined search buys almost no standard books. A9 cases: Persian digits, signs at 1em x2, ';' fail (=pins).
- 16:30 A9L (release): 0 worse vs 935 both builds; better 272 (349); standard counts == A9. Cases: ?! 0.6em and scale(2)
  (default only), signs at 1em, punctuation at line-height 0.6 not whole. TIMING (time10.py, out/time10.txt) n=256 vs 935b077:
  A9L rtl-justified 1.09x, ls-scaled 1.71x (1.34x at n=64; the second reading under a transform, needed for the 4 f6 books),
  h1-* 1.05-1.15x, prose 1.04-1.20x; A9 rtl-justified 2.57x; A8 6.30x; A8s ls-nowrap 52x.
- DECISION 16:37: commit A9L (no time beyond what the standard and V1's class need); owner options measured against A9L:
  W = found drawings held to the words (A9: kit-A9), W+J = rules' joined reading searched too (A8: kit-A8t), W+J+C = cut
  searched too (A8s: kit-A8s), D = each drawing read once on A9L (A9Ld, to run), H1 and H6 on A9L (H1n, H6n, to run).
  Worktree: tools/mkfinal9l.py (search takes a found drawing at Letters, letters_only gone), docs in paint.rs, tests:
  cuts-or-joins test renamed a_reading_that_cuts_or_joins_a_word_is_taken_as_935b077_took_it (pins), unit test
  a_line_whose_rules_drawing_reads_its_letters_in_order_is_read_back_once (joined nowrap ==1, guard Arabic ?! >1),
  Persian digits and ';' pinned as at 05cea0b. Catalogue 97 (chkinj.py 0 mismatches). WIP 86fde67 = A9 (not A9L yet).
