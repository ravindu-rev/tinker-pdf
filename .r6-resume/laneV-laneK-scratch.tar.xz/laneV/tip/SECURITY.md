# Security

## Reporting a vulnerability

Report privately through GitHub's **Report a vulnerability** button on the
Security tab of this repository. Please do not open a public issue for
anything exploitable. Include the input file or byte sequence that triggers
the behavior if you can share it — a reproducer is worth more than a
description, and PDF bugs are almost always input-shaped.

Expect an acknowledgement within a few days. Fixes ship in a patch release
with credit unless you prefer otherwise.

## What counts

tinker-pdf parses hostile input by design: a PDF is an attacker-controlled
byte stream with an object graph, embedded programs, compression bombs and
thirty years of malformed producers behind it. So the following are all
security issues here, not merely bugs:

- **Any panic on untrusted input.** Ruling 1 of the project's consistency
  rules makes never-panicking a contract, and the per-format fuzzers enforce
  it. A crash reachable from document bytes is a denial of service in every
  embedder.
- **Unbounded memory or time** from a small input — decompression bombs, xref
  or object-stream recursion, hostile `/Size`, degenerate shadings. Every
  limit that exists is a named constant; a path that escapes those limits is
  a defect.
- **Incorrect security semantics**: reporting a document as unrestricted when
  its `/P` restricts, accepting a wrong password, confusing owner
  authentication with user authentication, or decrypting with a key derived
  incorrectly.
- **Reading outside the document buffer**, in any form.

The engine contains no `unsafe` in its parsing and rendering crates, so
memory-safety issues should be impossible by construction. If you find one,
that is a very interesting report.

## The hand-rolled crypto, stated plainly

This project implements MD5, RC4, SHA-2, AES-CBC and DES-EDE3-CBC itself, along
with the PDF standard security handler and — for signature verification —
big-integer modular arithmetic, RSASSA-PKCS1-v1_5 and ECDSA over P-256 and
P-384, because
the project's design mandate is that no third-party crate implements engine
functionality. That is an unusual choice and it deserves an unusual amount of
scrutiny, so here is the honest framing:

- **Scope is document decryption, encryption-on-save, and signature
  verification.** No TLS, no key exchange, no long-term secret storage, no
  protocol implementation.
- **No private-key operation exists.** The signature code verifies and cannot
  sign: no key generation, no signing, no PKCS#8 or PKCS#12 parsing. That is
  what lets `bignum` skip constant-time discipline — every value it handles is
  published in the document being checked — and it is a boundary a future
  signing feature would have to cross deliberately, not drift across.
  The owner crossed it deliberately on 9 October 2026: signing with a private key
  in the engine is scheduled as [ROADMAP](docs/ROADMAP.md) rows SG-01 to
  SG-09, and from SG-01 on every secret operand takes a constant-time path.
  Until SG-01 lands, the sentences above describe the code.
- **Correctness is checked against published vectors** — RFC 1321 for MD5,
  RFC 6229 for RC4, worked examples for SHA-2, and known-answer tests for AES.

  Stated precisely, because the previous wording here claimed more than was
  true: for *most* of the cipher and hash primitives the full NIST CAVP suites
  are **not** wired in, and there is no CBC-AES-256 vector even though that is
  the mode the fixtures use. AES-256 in CBC is exercised end to end by
  decrypting a mutool-written R6 fixture and by an independent Python
  reimplementation of Algorithm 2.B in the test suite, which is real evidence
  and is not the same thing as CAVP. Wiring the suites is tracked in
  [`docs/features/encryption.md`](docs/features/encryption.md).

  **Triple DES is the one cipher that is gated on CAVP**, and it was built that
  way from the start: 500 known answers across seven committed files, the
  FIPS 46-3 tables read twice, and a counted-injection campaign recorded in
  [`docs/design/pubsec.md`](docs/design/pubsec.md) that measures which vectors
  catch which defect — including the one that caught nothing until a seventh
  file was committed for it.

  The *signature* primitives are the other exception, and they are gated on
  CAVP itself: 360 `SigVer15` vectors for RSA (moduli of 1024 to 4096 bits
  crossed with SHA-1/256/384/512, 60 valid and 300 that must be refused, 150 of
  those being forged paddings), 120 `SigVer` vectors and 24 `PKV` points for
  ECDSA, and RFC 6979's sixteen appendix A.2 signatures. The vector files are
  committed under `crates/tinker-pdf-crypto/tests/data/cavp/` with their
  provenance in each file's header.
- **Password comparison is constant-time.**

  Decrypt paths **are** fuzzed: `crypt` drives the security handler and
  `crypt_ciphers` the ciphers themselves, both with committed seed corpora.
  This paragraph said the opposite — "a `tinker-pdf-crypto` fuzz target does
  not exist" — for as long as the two targets have existed, which is a
  reminder that a security page is exactly where a stale sentence does the
  most harm. The `cos_document` target additionally reaches the decryptor for
  inputs that carry an `/Encrypt` dictionary, and the stable hostile-input
  sweep authenticates with several passwords against every mutated fixture.
- **PDF encryption is weak by design in its older revisions** (RC4-40 exists
  because the spec has it, not because it protects anything), and the format's
  permission flags are advisory — a document that says "printing denied" is
  asking, not enforcing. Nothing this engine does changes that, and no
  embedder should treat PDF permissions as a security boundary.
- **Triple DES is here to read old documents and nothing else.** Its 64-bit
  block is Sweet32's whole premise and two-key EDE is below 112 bits of
  security. It exists because `openssl cms -encrypt` still chooses
  `des-ede3-cbc` by default for older recipients, so public-key-encrypted PDFs
  in the wild carry it. The module decrypts only: there is no way to reach a
  DES *encryption* from any public API, and nothing in this engine will ever
  write such an envelope.

Review of the crypto crate is actively welcomed, and a finding there is worth
reporting even if you cannot demonstrate an exploit.

## Supported versions

Pre-1.0: fixes land on `main` and in the next release. There are no
maintained release branches yet.
