//! Which constructs survive `tpdf probe`'s relations, and which cannot.
//!
//! The corpus's fourth axis asks a relation of two renders of one file and
//! records how many files hold it. What it cannot say is **why** a file broke
//! one, because it has no ground truth and no ablation: 181 files fail
//! `rotate`, 43 `crop` and 51 `dpi`, and until this file they were a number.
//!
//! `docs/design/image-edges.md` attributes one class — anti-aliased image edges
//! — by the method this file copies: isolate on a synthetic case, ablate the
//! one thing that is suspected, and give the numbers. What isolation buys over
//! the corpus is that a synthetic page has exactly one construct in it, so a
//! relation that breaks names the construct rather than the document.
//!
//! # The answer, in one table
//!
//! Seven constructs, each alone on a page, each put through all three
//! relations. Every figure is measured by this file; the zeros are asserted.
//!
//! | Construct | `dpi` | `rotate` | `crop` |
//! | --- | ---: | ---: | ---: |
//! | a rectangle on integers | 0 | 0 | 0 |
//! | diagonal path edges | 0 | **2.81 %** | 0 |
//! | the same, in an isolated group at half alpha | 0 | 1.90 % | 0 |
//! | an axial shading | 0 | 0 | 0 |
//! | an image at a non-integer scale | 0 | 0 | 0 |
//! | text | 0 | **2.64 %** | 0 |
//! | **a tiling pattern off the grid** | **27.00 %** | **22.05 %** | **2.05 %** |
//!
//! Two classes, and they are different classes:
//!
//! **A tiling pattern fails all three.** The renderer rasterises a cell once
//! and blits the copies at *rounded* device offsets, which is what makes a
//! thousand-cell page affordable — so any change to the grid or to the page's
//! origin moves every cell's rounding. That is why it is the only construct
//! that fails `crop`, which changes no sampling grid at all and carries no
//! budget: the lattice is placed relative to the page, and the page moved.
//!
//! **Anti-aliased edges that are not axis-aligned fail `rotate` alone.** A
//! quarter turn puts every mark on a transposed grid; a rectangle on integers
//! transposes exactly and a diagonal does not. Glyph outlines are the same
//! case — 2.64 % for a page of text — which is `image-edges.md`'s class
//! arriving for paths and glyphs rather than images.
//!
//! **And two percent was out by a factor of four.** `ROTATE_BUDGET` was 2%,
//! raised from 1% in August 2026 on two qpdf scans measuring 1.0% hard and
//! 1.7% soft. The figures above are 2.64% and 2.81% — over it, which is what
//! the roadmap row said. What the row could not know is that **those figures
//! are properties of these fixtures rather than of these constructs**: the
//! pages are 64 points square with the construct in a corner, and a budget is
//! a share of a page.
//!
//! Measured on pages the construct covers, at sizes a document has
//! (`where_the_rotate_budget_goes`, which re-measures every figure it prints):
//!
//! | Page | `rotate` when the budget was sited | `rotate` today |
//! | --- | ---: | ---: |
//! | two triangles in a corner of 64 pt | 2.81 % | 0.22 % |
//! | the same two triangles on 595 pt | 0.03 % | 0.00 % |
//! | 11-point text filling 200 pt | 7.74 % | 3.38 % |
//! | 11-point text filling 595 pt | **8.77 %** | **3.63 %** |
//! | 11-point text filling 842 pt | **8.74 %** | **3.66 %** |
//! | diagonal edges covering 595 pt | 23.52 % | 0.20 % |
//!
//! **The right column is 15 September 2026**, after `fill` stopped truncating
//! an edge's slope to a whole 1/256 pixel per sub-scanline. A quarter turn
//! makes a steep edge shallow, and a shallow slope was precisely the case that
//! truncation flattened to vertical — so most of what this relation was
//! measuring was the rasterizer's own quantisation rather than anything about
//! the document. Every figure more than halved. `ROTATE_BUDGET` is left at
//! 10 % all the same: the 181-files-to-15 corpus counts that sited it were
//! measured on the old arithmetic, and re-siting a budget wants a corpus run
//! rather than this file's six fixtures.
//!
//! **A page of text costs 8.8%, and stays there as the page grows** — the
//! corner fixture's cost fell with page size because its shapes stayed put,
//! and a document's text does not. So the budget is **10%** from 5 September
//! 2026: above the widest legitimate construct measured, below the tiling
//! class at 22% and far below a rotation applied to the geometry and not the
//! clip.
//!
//! It costs signal, and the cost is paid rather than waved away: 181 corpus
//! files broke at 2% and 15 break at 10%. The same measurement is therefore
//! judged a second time at 3% and recorded as **`rotate-tight`**, a relation
//! the ratchet holds and no run fails on, so the 107 files between the two
//! lines stay counted.
//!
//! **And the limitation that has gone.** A page saturated with diagonal edge
//! used to cost 23.5% at 595 points and 46.8% at 64 — the tiling class's own
//! range — so at no budget did this relation separate a saturated vector page
//! from a lattice rounded wrongly. That was asserted rather than written down,
//! so the day it stopped being true would be a failing run and not a
//! discovery; the day was 15 September 2026. The same page now costs 0.20% at
//! 595 points and 2.05% at 64 against the tiling class's 22%, and the
//! assertion is the other way round: the saturated page must stay inside the
//! budget and under the defect class, which fails if the slope arithmetic ever
//! goes back.
//!
//! # What the corpus said first
//!
//! Grouping the 51 `dpi` failures by the directory they sit in put 14 of them
//! in transparency clauses, and four *identical* differing-pixel counts —
//! 50 325, 52 503, 105 735 and 18 183 of 250 000 — covered 25 of the 51
//! between them, which is one veraPDF document reissued per clause rather than
//! 25 causes. Reading `/Pattern` out of the raw bytes settles it:
//!
//! | Relation | Failures carrying `/Pattern` | Files that *held* it, carrying `/Pattern` |
//! | --- | ---: | ---: |
//! | `dpi` | **25 of 51 (49 %)** | 98 of 4 388 (2.2 %) |
//! | `crop` | **13 of 43 (30 %)** | 100 of 4 148 (2.4 %) |
//! | `rotate` | **17 of 181 (9.4 %)** | 96 of 4 030 (2.4 %) |
//!
//! A twenty-two-fold enrichment on `dpi` against a base rate the same three
//! ways. The base rate is the half that makes this an attribution rather than
//! an observation: without it, "half the failures have patterns" would be
//! equally consistent with half of everything having patterns.
//!
//! And the residue the pattern class does not explain lands where the second
//! class predicts. `rotate` is the relation with 164 unexplained files, and
//! 121 of its 181 failures sit in the 2–5 % bucket — which is exactly where a
//! page of glyphs (2.64 %) and a page of diagonals (2.81 %) sit.
//!
//! # The first draft was wrong, and the record is kept
//!
//! It asserted that a transparency group was the `dpi` class, on the strength
//! of the directory grouping, and that diagonal edges were the residue. Both
//! are zero under `dpi`. The ablation is what said so, and the negative
//! results are asserted below rather than deleted, because the day one of them
//! starts moving pixels is a rasteriser change worth knowing about.
//!
use tinker_pdf::{
    Bitmap, DeviceSpace, Document, DocumentBuilder, ExtGState, FormXObject, Function, ImageData,
    PixelFormat, RenderOptions, Shading, TilingPattern, TilingType, TransparencyGroup,
    WriteOptions,
};

mod render_support;
use render_support::curvy_font;

/// The relation's own budget, from `tools/tpdf/src/main.rs`.
const DPI_BUDGET: f64 = 0.02;
/// And the quarter turn's, which this file's own measurement moved from 2%
/// to 10%.
const ROTATE_BUDGET: f64 = 0.10;
/// The line the same measurement is watched against, which decides nothing.
const ROTATE_WATCH: f64 = 0.03;
/// And its own per-channel tolerance.
const CHANNEL_TOLERANCE: i32 = 8;

const SIZE: f64 = 64.0;

fn channels(bitmap: &Bitmap, x: u32, y: u32) -> (i32, i32, i32) {
    let at = (y as usize) * bitmap.stride + (x as usize) * bitmap.components();
    let p = bitmap.data.get(at..at + 3).unwrap_or(&[0, 0, 0]);
    (i32::from(p[0]), i32::from(p[1]), i32::from(p[2]))
}

/// `tpdf probe`'s `dpi` relation, transcribed rather than called.
///
/// The probe is a binary and this is a test; ruling 13 forbids a test spawning
/// a program, and a relation copied from the source is a relation this file can
/// be wrong about on its own. The arithmetic is the same: render at twice the
/// scale, box-filter the four pixels down to one, and count the pixels that
/// move by more than the tolerance on any channel.
fn dpi_relation(bytes: Vec<u8>) -> (u64, u64) {
    let document = Document::open(bytes).expect("it opens");
    let page = document.page(0).expect("a page");
    let options = RenderOptions {
        scale: 1.0,
        format: PixelFormat::Rgb8,
        cancel: None,
        annotations: true,
        region: None,
        ..RenderOptions::default()
    };
    let base = page.render(&options);
    let doubled = page.render(&RenderOptions {
        scale: 2.0,
        ..options
    });

    let across = base.width.min(doubled.width / 2);
    let down = base.height.min(doubled.height / 2);
    let mut moved = 0u64;
    for y in 0..down {
        for x in 0..across {
            let mut sum = (0i32, 0i32, 0i32);
            for dy in 0..2 {
                for dx in 0..2 {
                    let p = channels(&doubled, x * 2 + dx, y * 2 + dy);
                    sum = (sum.0 + p.0, sum.1 + p.1, sum.2 + p.2);
                }
            }
            let filtered = (sum.0 / 4, sum.1 / 4, sum.2 / 4);
            let here = channels(&base, x, y);
            if (filtered.0 - here.0).abs() > CHANNEL_TOLERANCE
                || (filtered.1 - here.1).abs() > CHANNEL_TOLERANCE
                || (filtered.2 - here.2).abs() > CHANNEL_TOLERANCE
            {
                moved += 1;
            }
        }
    }
    (moved, u64::from(across) * u64::from(down))
}

fn share(moved: u64, total: u64) -> f64 {
    if total == 0 {
        0.0
    } else {
        moved as f64 / total as f64
    }
}

/// Two overlapping circles' worth of curve, so the page has soft edges to
/// resample and is not a rectangle on integers.
const SHAPES: &str = "0.2 0.4 0.9 rg 8 8 m 40 8 l 24 44 l h f \
                      0.9 0.4 0.2 rg 20 20 m 56 20 l 38 52 l h f";

/// The page without the construct: the same two shapes, drawn plainly.
fn plain_page() -> Vec<u8> {
    plain_page_at(SIZE)
}

/// The same page at any size, for the one question a fixed size cannot
/// answer: whether 64 points is the worst case or a special one.
///
/// The shapes keep their coordinates, so a larger page is the same amount of
/// edge over more pixels. That is the point: the budget is a *share* of a
/// page, and this construct's cost in pixels does not grow with the page.
fn plain_page_at(size: f64) -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    builder.add_page(size, size, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(format!("0 0 {size} {size} re f\n").as_bytes());
        page.raw(SHAPES.as_bytes());
    });
    builder.finish()
}

/// Diagonal edges over a *whole* page, at any size.
///
/// **This is the fair worst case, and that is why it is here.**
/// `plain_page_at` draws two triangles whose coordinates are fixed, so
/// enlarging the page only dilutes them, and a budget sited on that would be
/// sited on a page mostly empty. A document whose whole page is diagonal
/// edges — a map, a chart, a page of drawn figures — is denser at every size,
/// and a budget either admits it or admits that the relation does not hold
/// there.
fn covered_page_at(size: f64) -> Vec<u8> {
    let mut content = format!("0.95 0.95 0.6 rg 0 0 {size} {size} re f\n");
    let step = size / 12.0;
    for index in 0..12 {
        let base = f64::from(index) * step;
        content.push_str(&format!(
            "0.2 0.4 0.9 rg {base:.3} 0 m {:.3} {:.3} l {:.3} {size:.3} l h f\n",
            base + step * 0.87,
            size * 0.5,
            base + step * 0.31,
        ));
    }
    let mut builder = DocumentBuilder::new();
    builder.add_page(size, size, |page| page.raw(content.as_bytes()));
    builder.finish()
}

/// The same two shapes inside an isolated transparency group at half alpha.
fn group_page() -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    assert!(builder.add_ext_gstate(
        b"GS0",
        &ExtGState {
            fill_alpha: Some(0.5),
            ..ExtGState::default()
        }
    ));
    assert!(builder.add_form(
        b"Fm0",
        &FormXObject {
            bbox: [0.0, 0.0, SIZE, SIZE],
            matrix: None,
            group: Some(TransparencyGroup {
                color_space: DeviceSpace::Rgb,
                isolated: true,
                knockout: false,
            }),
            content: SHAPES.as_bytes(),
        }
    ));
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(format!("0 0 {SIZE} {SIZE} re f\n").as_bytes());
        page.raw(b"q ");
        assert!(page.set_ext_gstate(b"GS0"));
        assert!(page.form(b"Fm0"));
        page.raw(b"Q\n");
    });
    builder.finish()
}

/// **The `dpi` relation is an edge measurement, and a transparency group is
/// not why it fails.**
///
/// The ablation is the point: the two pages draw the same two shapes over the
/// same backdrop, and differ only in whether the shapes go through an isolated
/// group at half alpha. If a group were the cause of the corpus's largest
/// coherent `dpi` class, this pair would separate — and it does not. Both stay
/// inside the relation's own budget, and the group's residue is within a
/// hair of the plain page's.
///
/// So the transparency directories are where those files *live*, not what
/// breaks them: they are one veraPDF document reissued per clause, and four
/// identical pixel counts across 25 files say so. What the relation actually
/// measures is what `image-edges.md` already named — a soft edge does not
/// survive a change of sampling grid to the byte — and a page whose edges are
/// diagonal has more of them.
#[test]
fn a_transparency_group_is_not_why_the_dpi_relation_breaks() {
    let (plain_moved, plain_total) = dpi_relation(plain_page());
    let (group_moved, group_total) = dpi_relation(group_page());
    println!(
        "  plain {plain_moved} of {plain_total} ({:.2}%), group {group_moved} of {group_total} ({:.2}%)",
        share(plain_moved, plain_total) * 100.0,
        share(group_moved, group_total) * 100.0
    );

    assert!(
        share(plain_moved, plain_total) <= DPI_BUDGET,
        "the plain page holds the relation: {plain_moved} of {plain_total}"
    );
    assert!(
        share(group_moved, group_total) <= DPI_BUDGET,
        "and so does the same page inside a transparency group: \
         {group_moved} of {group_total} -- if this ever fails, the group *is* a \
         class and this file's conclusion has to be rewritten"
    );
}

/// A backdrop and one rectangle whose every edge is an integer.
fn rectangle_page() -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(
            format!(
                "0 0 {SIZE} {SIZE} re f
"
            )
            .as_bytes(),
        );
        page.set_fill_rgb(0.2, 0.4, 0.9);
        page.raw(
            b"8 8 32 32 re f
",
        );
    });
    builder.finish()
}

/// An axial shading, which is evaluated at each pixel's own centre -- and the
/// centres of a doubled grid are not the centres of this one.
fn shading_page() -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    assert!(builder.add_shading(
        b"Sh0",
        &Shading::Axial {
            color_space: DeviceSpace::Rgb,
            coords: [0.0, 0.0, SIZE, SIZE],
            function: Function::Exponential {
                domain: [0.0, 1.0],
                c0: vec![0.9, 0.2, 0.1],
                c1: vec![0.1, 0.2, 0.9],
                n: 1.0,
            },
            extend: (true, true),
        }
    ));
    builder.add_page(SIZE, SIZE, |page| {
        page.raw(format!("q 0 0 {SIZE} {SIZE} re W n").as_bytes());
        assert!(page.shading(b"Sh0"));
        page.raw(b"Q");
    });
    builder.finish()
}

/// A small image at a scale that is not a whole number of source pixels per
/// device pixel, which is the case `image-edges.md` is about.
fn image_page() -> Vec<u8> {
    let mut data = Vec::new();
    for row in 0..5u32 {
        for column in 0..5u32 {
            let on = (row + column) % 2 == 0;
            let (r, g, b) = if on { (20, 40, 160) } else { (240, 200, 60) };
            data.extend_from_slice(&[r, g, b]);
        }
    }
    let mut builder = DocumentBuilder::new();
    assert!(builder.add_image(
        b"Im0",
        &ImageData::Rgb8 {
            width: 5,
            height: 5,
            data: &data,
        }
    ));
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(
            format!(
                "0 0 {SIZE} {SIZE} re f
"
            )
            .as_bytes(),
        );
        // 37 points over five samples: 7.4 device pixels a sample at one
        // scale and 14.8 at two, so neither grid lands on a sample boundary.
        page.image(b"Im0", 9.0, 9.0, 37.0, 37.0);
    });
    builder.finish()
}

/// Text in the face this repository writes for itself. A glyph outline is
/// flattened to a tolerance in *device* space, so the curve a doubled render
/// draws is not the curve this one draws scaled up.
fn text_page() -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    builder.set_subset_fonts(false);
    assert!(builder.add_embedded_font(b"F0", b"Curvy", &curvy_font()));
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(
            format!(
                "0 0 {SIZE} {SIZE} re f
"
            )
            .as_bytes(),
        );
        page.set_fill_rgb(0.1, 0.1, 0.1);
        page.text(b"F0", 13.0, 4.0, 40.0, "Abcde");
        page.text(b"F0", 9.0, 4.0, 20.0, "fghijkl");
    });
    builder.finish()
}

/// A page *filled* with 11-point text, at any size.
///
/// The two-line fixture above is text in a corner; this is a document. Which
/// matters for exactly one question — where a budget goes — because a share of
/// a page is not a property of a construct until the construct covers the
/// page.
fn text_filled_page_at(size: f64) -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    builder.set_subset_fonts(false);
    assert!(builder.add_embedded_font(b"F0", b"Curvy", &curvy_font()));
    builder.add_page(size, size, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(format!("0 0 {size} {size} re f\n").as_bytes());
        page.set_fill_rgb(0.1, 0.1, 0.1);
        // Enough characters to reach the right edge at any size, so that a
        // larger page is *more text* rather than the same line with more
        // margin. The first fixture's figures fell with page size for exactly
        // that reason, which made them a measurement of the fixture.
        let leading = 14.0;
        let columns = (size / 6.0).ceil() as usize;
        let line: String = "abcdefghijklmnopqrstuvwxyz"
            .chars()
            .cycle()
            .take(columns)
            .collect();
        let mut y = size - leading;
        while y > 4.0 {
            page.text(b"F0", 11.0, 4.0, y, &line);
            y -= leading;
        }
    });
    builder.finish()
}

/// `tpdf probe`'s `rotate` relation, transcribed for the same reason.
///
/// A quarter turn puts every mark on a different sampling grid, which is why
/// this one carries a budget where `crop` does not. Two per cent, from
/// `ROTATE_BUDGET`.
fn rotate_relation(bytes: Vec<u8>) -> (u64, u64) {
    let document = Document::open(bytes).expect("it opens");
    let options = RenderOptions {
        scale: 1.0,
        format: PixelFormat::Rgb8,
        cancel: None,
        annotations: true,
        region: None,
        ..RenderOptions::default()
    };
    let base = document.page(0).expect("a page").render(&options);

    let mut editor = document.editor();
    assert!(editor.rotate_page(0, 90), "the fixture rotates");
    let turned = Document::open(editor.save(&WriteOptions::default())).expect("it reopens");
    let rotated = turned.page(0).expect("a page").render(&options);
    assert_eq!(
        (rotated.width, rotated.height),
        (base.height, base.width),
        "a quarter turn transposes the page"
    );

    let mut moved = 0u64;
    for y in 0..rotated.height {
        for x in 0..rotated.width {
            let there = channels(&base, y, base.height - 1 - x);
            let here = channels(&rotated, x, y);
            if (here.0 - there.0).abs() > CHANNEL_TOLERANCE
                || (here.1 - there.1).abs() > CHANNEL_TOLERANCE
                || (here.2 - there.2).abs() > CHANNEL_TOLERANCE
            {
                moved += 1;
            }
        }
    }
    (moved, u64::from(rotated.width) * u64::from(rotated.height))
}

/// `tpdf probe`'s `crop` relation, transcribed.
///
/// A quarter in from each edge, snapped to whole pixels so the sub-rectangle
/// lands on pixel boundaries. **No budget**: moving the page box changes no
/// sampling grid, so the cropped render must be the sub-rectangle exactly.
fn crop_relation(bytes: Vec<u8>) -> (u64, u64) {
    let document = Document::open(bytes).expect("it opens");
    let options = RenderOptions {
        scale: 1.0,
        format: PixelFormat::Rgb8,
        cancel: None,
        annotations: true,
        region: None,
        ..RenderOptions::default()
    };
    let page = document.page(0).expect("a page");
    let base = page.render(&options);
    let (x0, y0, x1, y1) = page.crop_box();
    let inset = ((x1 - x0) / 4.0).floor();

    let mut editor = document.editor();
    assert!(
        editor.set_crop_box(0, x0 + inset, y0 + inset, x1 - inset, y1 - inset),
        "the fixture crops"
    );
    let cropped = Document::open(editor.save(&WriteOptions::default())).expect("it reopens");
    let small = cropped.page(0).expect("a page").render(&options);

    let (left, top) = (inset as u32, inset as u32);
    let mut moved = 0u64;
    for y in 0..small.height {
        for x in 0..small.width {
            let here = channels(&small, x, y);
            let there = channels(&base, left + x, top + y);
            if (here.0 - there.0).abs() > CHANNEL_TOLERANCE
                || (here.1 - there.1).abs() > CHANNEL_TOLERANCE
                || (here.2 - there.2).abs() > CHANNEL_TOLERANCE
            {
                moved += 1;
            }
        }
    }
    (moved, u64::from(small.width) * u64::from(small.height))
}

/// A tiling pattern whose cell is not a whole number of device pixels.
///
/// The renderer rasterises a cell **once** and blits the copies at rounded
/// device offsets, which is what makes a thousand-cell page affordable. A
/// rounding is a function of the grid, so at one scale and at two the lattice
/// does not land in the same places relative to the page.
fn tiling_page() -> Vec<u8> {
    let mut builder = DocumentBuilder::new();
    assert!(builder.add_tiling_pattern(
        b"P0",
        &TilingPattern {
            bbox: [0.0, 0.0, 3.5, 3.5],
            x_step: 4.5,
            y_step: 4.5,
            matrix: None,
            tiling_type: TilingType::NoDistortion,
            content: b"0.2 0.3 0.8 rg 0 0 2.5 2.5 re f",
        }
    ));
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(
            format!(
                "0 0 {SIZE} {SIZE} re f
"
            )
            .as_bytes(),
        );
        assert!(page.set_fill_pattern(b"P0"));
        page.raw(
            format!(
                "0 0 {SIZE} {SIZE} re f
"
            )
            .as_bytes(),
        );
    });
    builder.finish()
}

/// **What a quarter turn moves, which is not what a change of scale moves.**
///
/// The `dpi` sweep below found six of seven constructs at zero. `rotate` is a
/// different relation — every mark lands on a transposed sampling grid rather
/// than a finer one — and the corpus says it is a different population too:
/// 164 of its 181 failures carry no pattern, against 26 of `dpi`'s 51.
///
/// So the same seven pages, put through the turn. The table is printed and the
/// shape is asserted, for the reason the `dpi` one is.
#[test]
fn what_moves_under_a_quarter_turn() {
    let mut moves = Vec::new();
    for (name, bytes) in [
        ("a rectangle on integers", rectangle_page()),
        ("diagonal edges", plain_page()),
        ("the same, in a transparency group", group_page()),
        ("an axial shading", shading_page()),
        ("an image at a non-integer scale", image_page()),
        ("text", text_page()),
        ("a tiling pattern off the grid", tiling_page()),
    ] {
        let (moved, total) = rotate_relation(bytes);
        let share_moved = share(moved, total);
        println!(
            "  {name:<36} {moved:>6} of {total} ({:.2}%)",
            share_moved * 100.0
        );
        if moved > 0 {
            moves.push((name, share_moved));
        }
    }
    assert!(
        !moves.is_empty(),
        "if a quarter turn moved nothing at all, 181 corpus files would not be          failing this relation"
    );
}

/// **Where `ROTATE_BUDGET` goes, measured the way the last raise was.**
///
/// The last raise — one percent to two, August 2026 — did not pick a number.
/// It named a class whose cost had changed (image edges became soft), ablated
/// it on real files (1.0% hard against 1.7% soft), and put the line above what
/// it measured. This is the same procedure for the class *this file* found,
/// and it needs one thing the seven-construct sweep above cannot give.
///
/// **The sweep's pages are 64 points square with the construct in a corner,
/// and a budget is a share of a page.** So the sweep's 2.81% for diagonals and
/// 2.64% for text are measurements of those fixtures, not of those constructs,
/// and the difference is not small: the same two triangles on a 595-point page
/// cost 0.03%, and a page *filled* with 11-point text costs 8.77%. The first
/// number falls with page size because the shapes stay where they are; the
/// second does not, because a document's text grows with its page. Only the
/// second is a property of a construct.
///
/// That is the measurement this test exists to keep, and the figures below are
/// re-measured on every run rather than quoted.
///
/// **What it settles.** Two percent was not slightly tight. A page of text
/// costs four times it, so every text-heavy document in the corpus was failing
/// `rotate` for arithmetic — 181 files broke at two percent and 166 of them
/// stop breaking at ten. Ten sits above the widest legitimate construct
/// measured here and below the defects the relation is for: the tiling
/// pattern's 22%, and a rotation applied to the geometry and not the clip,
/// which moves whole regions.
///
/// **What it costs, and what pays for it.** A relation that breaks on 15 files
/// where it broke on 181 sees less. The 107 files between three and ten
/// percent are not defects — this file's own ablation is the reason for
/// believing that — but they are a population whose size is worth watching.
/// `ROTATE_WATCH` is that: the probe judges the same measurement a second time
/// at three percent and records it as `rotate-tight`, which the ratchet holds
/// like any other relation and which no run fails on.
///
/// **And the limitation that the assertion below caught going away.** A page
/// that is nothing but diagonal edge — twelve wedges spanning it — cost 23.5%
/// at 595 points and 46.8% at 64, the same range as the tiling-pattern
/// *defect* this file attributes at 22%. The two populations overlapped, so at
/// no budget did this relation separate a saturated vector page from a lattice
/// rounded wrongly, and this paragraph said so with an assertion under it
/// rather than a sentence alone: *the day a rasteriser change makes a
/// saturated page cheap, the assertion fails and this paragraph gets
/// rewritten.*
///
/// It failed on 15 September 2026, and this is the rewrite. `fill` had been
/// storing an edge's slope as a whole number of 1/256 pixel per sub-scanline,
/// which truncated every slope below one pixel of x per sixteen of y to zero;
/// a quarter turn is what makes a page's steep edges shallow, so the relation
/// was reading that quantisation back as disagreement. Twelve wedges now cost
/// **2.05% at 64 points, 0.59% at 200 and 0.20% at 595**, and the assertion is
/// inverted: the saturated class has to stay inside the budget *and* under the
/// tiling class, so the separation this paragraph used to deny is now a claim
/// a regression would break.
#[test]
fn where_the_rotate_budget_goes() {
    // What the budget must admit: pages a producer emits. The construct in a
    // corner is kept for continuity with the sweep above; the filled pages are
    // the measurement.
    let mut worst_document: f64 = 0.0;
    for (name, bytes) in [
        ("two triangles on 64 pt", plain_page_at(SIZE)),
        ("two triangles on 595 pt", plain_page_at(595.0)),
        ("text in a corner of 64 pt", text_page()),
        ("text filling 200 pt", text_filled_page_at(200.0)),
        ("text filling 595 pt", text_filled_page_at(595.0)),
        ("text filling 842 pt", text_filled_page_at(842.0)),
    ] {
        let (moved, total) = rotate_relation(bytes);
        let share_moved = share(moved, total);
        println!(
            "  {name:<34} {moved:>7} of {total:>7} ({:.2}%)",
            share_moved * 100.0
        );
        worst_document = worst_document.max(share_moved);
    }

    // And the class that used to sit outside every budget: a page that is
    // nothing *but* diagonal edge. It sits inside now, which is the whole of
    // what the slope fix bought this relation.
    let mut worst_saturated: f64 = 0.0;
    for (name, bytes) in [
        ("diagonal edges covering 64 pt", covered_page_at(SIZE)),
        ("diagonal edges covering 200 pt", covered_page_at(200.0)),
        ("diagonal edges covering 595 pt", covered_page_at(595.0)),
    ] {
        let (moved, total) = rotate_relation(bytes);
        let share_moved = share(moved, total);
        println!(
            "  {name:<34} {moved:>7} of {total:>7} ({:.2}%)  [the saturated class]",
            share_moved * 100.0
        );
        worst_saturated = worst_saturated.max(share_moved);
    }

    assert!(
        worst_document > ROTATE_WATCH,
        "the class this budget was raised for costs {:.2}%, inside the watch \
         line itself -- if this ever passes, the raise has no measurement \
         behind it any more and the budget should go back down",
        worst_document * 100.0
    );
    assert!(
        worst_document <= ROTATE_BUDGET,
        "a page of text costs {:.2}% and the budget admits {:.2}%; a budget \
         below its own measured class fails documents on arithmetic, which is \
         the thing it exists to prevent",
        worst_document * 100.0,
        ROTATE_BUDGET * 100.0
    );
    // The distance the original figure was chosen for, kept -- and measured
    // rather than written as a constant, because a constant compared against a
    // constant is a sentence about today's numbers that no run can falsify.
    // The tiling class is the defect this relation must go on catching, so the
    // budget has to sit below what that class actually costs.
    let (tiling_moved, tiling_total) = rotate_relation(tiling_page());
    let tiling = share(tiling_moved, tiling_total);
    println!(
        "  {:<34} {tiling_moved:>7} of {tiling_total:>7} ({:.2}%)  [the defect class]",
        "a tiling pattern off the grid",
        tiling * 100.0
    );
    assert!(
        ROTATE_BUDGET < tiling,
        "a budget of {:.2}% could not see the tiling class, which costs \
         {:.2}% -- and that class is what this relation is for",
        ROTATE_BUDGET * 100.0,
        tiling * 100.0
    );
    // The inversion of the assertion this test carried until 15 September
    // 2026. Both halves matter: inside the budget is what makes a saturated
    // vector page a page rather than a failure, and under the tiling class is
    // what makes the two populations separable at all. A slope truncated back
    // to a whole 1/256 unit per sub-scanline puts this at 46.8% and fails
    // both.
    assert!(
        worst_saturated <= ROTATE_BUDGET,
        "a page saturated with diagonal edges costs {:.2}% and the budget \
         admits {:.2}% -- this class was outside every budget until the slope \
         arithmetic was fixed, so a regression here is a rasteriser change and \
         not a reason to raise the budget",
        worst_saturated * 100.0,
        ROTATE_BUDGET * 100.0
    );
    assert!(
        worst_saturated < tiling,
        "a saturated vector page costs {:.2}% and the tiling *defect* costs \
         {:.2}%: the two populations have merged again, and this relation no \
         longer separates a page that is hard to rotate from a lattice rounded \
         wrongly",
        worst_saturated * 100.0,
        tiling * 100.0
    );
}

/// **What moving the page box moves**, which should be nothing at all.
///
/// `crop` carries no budget, and that is a measurement rather than an
/// oversight: moving the page box changes no sampling grid, so every pixel of
/// the cropped render must be the pixel that was under it. Six of the seven
/// constructs hold that exactly. The seventh is the tiling pattern, and for
/// the same reason it fails the other two: the lattice is placed relative to
/// the page, so moving the page moves every cell's rounding.
#[test]
fn what_moves_when_the_page_box_moves() {
    let mut moves = Vec::new();
    for (name, bytes) in [
        ("a rectangle on integers", rectangle_page()),
        ("diagonal edges", plain_page()),
        ("the same, in a transparency group", group_page()),
        ("an axial shading", shading_page()),
        ("an image at a non-integer scale", image_page()),
        ("text", text_page()),
        ("a tiling pattern off the grid", tiling_page()),
    ] {
        let (moved, total) = crop_relation(bytes);
        println!(
            "  {name:<36} {moved:>6} of {total} ({:.2}%)",
            share(moved, total) * 100.0
        );
        if moved > 0 {
            moves.push(name);
        }
    }
    assert_eq!(
        moves,
        vec!["a tiling pattern off the grid"],
        "a crop moves the page box and nothing else, so only a construct          placed relative to the page may move"
    );
}

/// **A tiling pattern is the class, and it is the only construct that moves.**
///
/// Seven constructs, each alone on a page over the same backdrop, each put
/// through the relation. Six move **zero** pixels — a rectangle on integers,
/// diagonal path edges, the same inside an isolated transparency group at half
/// alpha, an axial shading, an image at a scale that lands on no sample
/// boundary at either resolution, and text whose outlines are flattened in
/// device space. The seventh, a tiling pattern whose cell and step are not
/// whole device pixels, moves **27 %**.
///
/// The mechanism is not mysterious once it is isolated. `fill_with_tiles`
/// rasterises the cell **once** and blits the copies at *rounded* device
/// offsets, which is what makes a thousand-cell page affordable — and a
/// rounding is a function of the grid, so at one scale and at two the lattice
/// does not land in the same places relative to the page. The same mechanism is
/// why `render_differential.rs`'s tiling pair has to run at scale 1 on integer
/// steps to be byte-equal at all; this test is that constraint seen from the
/// other side.
///
/// # It is the corpus's class too, and by how much
///
/// | Relation | Failures carrying `/Pattern` | Files that *held* it, carrying `/Pattern` |
/// | --- | ---: | ---: |
/// | `dpi` | **25 of 51 (49 %)** | 98 of 4 388 (2.2 %) |
/// | `crop` | **13 of 43 (30 %)** | 100 of 4 148 (2.4 %) |
/// | `rotate` | **17 of 181 (9.4 %)** | 96 of 4 030 (2.4 %) |
///
/// A twenty-two-fold enrichment on `dpi`, twelve on `crop`, four on `rotate`,
/// against a base rate the same three ways. And the 25 `dpi` files are the same
/// 25 the four repeated differing-pixel counts cover, which is two independent
/// routes to one set.
///
/// The base rate is the half that makes this an attribution rather than an
/// observation: without it, "half the failures have patterns" would be equally
/// consistent with half of everything having patterns.
///
/// # What this does not explain
///
/// Twenty-six `dpi` files, thirty `crop` and a hundred and sixty-four `rotate`
/// carry no pattern at all, and nothing here says what moves them. The six
/// zeros above rule out the constructs that were suspected; the next witness
/// has to come from the files themselves, as this one did.
///
/// The zeros are asserted rather than printed, because they are a claim: the
/// day one of those six starts moving pixels under a change of sampling grid,
/// that is a rasteriser change, and this is the only test that would say so.
#[test]
fn what_moves_under_a_change_of_sampling_grid() {
    let mut zero = Vec::new();
    let mut moves = Vec::new();
    for (name, bytes) in [
        ("a rectangle on integers", rectangle_page()),
        ("diagonal edges", plain_page()),
        ("the same, in a transparency group", group_page()),
        ("an axial shading", shading_page()),
        ("an image at a non-integer scale", image_page()),
        ("text", text_page()),
        ("a tiling pattern off the grid", tiling_page()),
    ] {
        let (moved, total) = dpi_relation(bytes);
        println!(
            "  {name:<36} {moved:>6} of {total} ({:.2}%)",
            share(moved, total) * 100.0
        );
        if moved == 0 {
            zero.push(name);
        } else {
            moves.push((name, share(moved, total)));
        }
    }
    assert!(
        moves.len() <= 1,
        "one of these constructs has started moving pixels under a change of          sampling grid, which it did not on 4 September 2026: {moves:?}"
    );
    assert_eq!(
        zero.len() + moves.len(),
        7,
        "and all seven are still measured"
    );
}

/// **A page of diagonal edges is not where the residue is** -- kept as the
/// negative result it turned out to be.
///
/// The first draft of this file asserted the opposite, on the strength of
/// `image-edges.md` naming anti-aliased edges as a class. Measured, a diagonal
/// path edge moves **nothing**: the box-filtered doubled render agrees with the
/// direct one everywhere, within the relation's own eight-level tolerance. So
/// coverage anti-aliasing survives a change of sampling grid, and whatever the
/// 51 corpus files are failing on, it is not that.
///
/// Old doc comment, for the record, which is the class
/// `image-edges.md` named for images arriving for glyphs and paths too.
///
/// Not an assertion that the relation fails — it holds on this page — but a
/// measurement of where its residue comes from: the pixels that move are the
/// edges, and a page with more edge per unit area moves more of them. The
/// count is printed rather than pinned, because pinning it would make an
/// ordinary rasteriser change look like a regression in a document about why
/// files fail.
#[test]
fn the_dpi_residue_is_edges_and_not_area() {
    let (edges_moved, edges_total) = dpi_relation(plain_page());

    // The same page with one axis-aligned rectangle instead of two triangles:
    // the same ink, almost none of the edge.
    let mut builder = DocumentBuilder::new();
    builder.add_page(SIZE, SIZE, |page| {
        page.set_fill_rgb(0.95, 0.95, 0.6);
        page.raw(format!("0 0 {SIZE} {SIZE} re f\n").as_bytes());
        page.set_fill_rgb(0.2, 0.4, 0.9);
        page.raw(b"8 8 32 32 re f\n");
    });
    let (flat_moved, flat_total) = dpi_relation(builder.finish());

    println!(
        "  diagonal edges {edges_moved} of {edges_total}, axis-aligned {flat_moved} of {flat_total}"
    );
    assert_eq!(
        flat_moved, 0,
        "a rectangle on integers resamples exactly, at any scale"
    );
    assert_eq!(
        edges_moved, 0,
        "and neither does a diagonal one -- which is the negative result this          test exists to keep: {edges_moved} moved"
    );
}
