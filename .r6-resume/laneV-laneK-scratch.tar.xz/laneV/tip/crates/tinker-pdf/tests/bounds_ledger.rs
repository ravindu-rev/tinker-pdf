//! Gap 29's seven bounds, gap 30's and gap 31's, swept in one place.
//!
//! *Amended, October 2026, the `jbig2` fuzz sweep.* **One more row,
//! `MAX_JBIG2_WORK_MULTIPLE`, the second ratio here and the first that bounds a
//! whole decode rather than one thing inside it.** Every other JBIG2 row caps
//! an item — a dictionary's count, its pixels, one symbol against its page, a
//! region's instances — and the sweep's two timeouts were what the items
//! multiply to: 257 bytes deciding 38 730 symbols on a page of 37 by 56, every
//! one of them inside every per-item cap. The budget is a multiple of the
//! pixels the caller's own ceiling holds, so its currency is a *multiple*, as
//! `MAX_JBIG2_SYMBOL_PAGE_MULTIPLE`'s is, and its parameter — the ceiling —
//! is fixed in the row by [`SCAN_WORK_MULTIPLE`]: the tightest a caller can
//! pass and still receive its page. Its `fixtures` is every committed seed under
//! the fuzz target's 64 KiB, a hundredth of one rounded up; its comic and
//! fixed-document columns carry the bilevel scan, as every JBIG2 row's do; its
//! book is a zero; and its corpus figure is owed, because the census that
//! reports it was written where the corpora are not.
//!
//! *Amended, October 2026, the review of lane 8C.* **One more row,
//! `MAX_EMBEDDING_DEPTH`, a cap on copies.** Every text run an EPUB lays out
//! carries the bidi levels its inline boxes open, and the cap is UAX #9's own
//! `max_depth`, past which the algorithm ignores a level anyway. The runs now
//! share one stack rather than a copy each — a copy each was a kilobyte and a
//! half on every line inside 125 isolating spans — so the cap bounds one
//! stack, made once for each box that opens a level. Its `fixtures` is the cap
//! — two hundred nested spans cut at it — its comic and fixed-document
//! yardsticks are zeros, since neither lays out an inline box, and its book
//! yardstick is two, a `<bdi>` inside a `dir="rtl"` span, since no committed
//! book has a `dir`, a `<bdi>` or a `unicode-bidi`. What stands in front of it
//! is `MAX_BOX_DEPTH`: an inline box at each level opens one.
//!
//! *Amended, 9 October 2026, the review of tier 5's formats lane.* **Two more
//! rows, both HTML's own, and the first of them a bound the lane had written
//! and not recorded.** `MAX_HTML_ACTIVE_FORMATTING` bounds the list of active
//! formatting elements, which the tree builder walks on every formatting tag
//! and which table cells' markers let grow past the stack of open elements;
//! the lane held it at four times the depth cap and reported crossing it as
//! the depth cap, with no constant, no ledger and no test. `MAX_HTML_CLONE_BYTES`
//! bounds the attribute bytes a clone of a formatting element copies, the one
//! place an HTML tree is bigger than its input — 116 kB of markup held 200 MB
//! of attribute values. Each `fixtures` is the cap, for
//! `MAX_ANNOTATION_BYTES`'s reason, and all three yardsticks are zeros,
//! because no container path parses HTML: an EPUB chapter is XHTML and is read
//! by the XML reader.
//!
//! *Amended, October 2026, the EPUB CSS row's gradients.* **One more row,
//! `MAX_CSS_GRADIENT_STOPS`, a cap on output.** A gradient is a stitching
//! function of one piece per pair of stops, written for every fragment of
//! its box on every page the box crosses; a stop is four bytes, `red,`. Its
//! `fixtures` is the cap — the gradient built at it parses — its comic and
//! fixed-document yardsticks are zeros, since neither has a stylesheet, and
//! its book yardstick is three, a rule fading in and out, since no committed
//! book declares a gradient.
//!
//! *Amended, October 2026, the EPUB CSS row's font features.* **One more row,
//! `MAX_CSS_FEATURE_SETTINGS`, a cap on copies.** `font-feature-settings` is
//! inherited, so a list is copied into the computed style of every element
//! under the one it is written on and into every run those elements set; a
//! setting is seven bytes, `"abcd",`. Its `fixtures` is the cap — the list
//! built at it parses — its comic and fixed-document yardsticks are zeros,
//! since neither has a stylesheet, and its book yardstick is four, figures
//! and small capitals on and two ligatures off, since no committed book
//! declares the property.
//!
//! *Amended, 3 October 2026, tier 5's table-reconstruction row.* **One more
//! row, `MAX_TABLE_RULES`, and the first that bounds work rather than a copy
//! or an allocation a format asks for.** Finding where a table's rules meet is
//! every horizontal rule against every vertical one, and a page of hatching is
//! a square's worth of junctions from a stream of a few bytes a rule. Past the
//! cap a page's rules are not read at all. Its `fixtures` is the cap, for
//! `MAX_ANNOTATION_BYTES`'s reason; its comic column is a zero, a comic page
//! being one image; its fixed-document and book columns are arithmetic about
//! two thousand stroked rectangles and a bordered forty-cell table, since the
//! corpus measurement the design asked it be sized from has not been taken.
//!
//! *Amended, 3 October 2026, the EPUB CSS row's shadows.* **One more row,
//! `MAX_CSS_SHADOWS`, output again.** A text shadow is its run drawn again, so
//! a shadow list is a multiplier on every glyph its element's subtree draws,
//! and `text-shadow` inherits: four bytes of `0 0,` per shadow asked for a copy
//! of a whole book's text each. Its `fixtures` is the cap — the list built at
//! it parses — its comic and fixed-document yardsticks are zeros, since
//! neither has a stylesheet, and its book yardstick is the two of an embossed
//! heading, since no committed book declares a shadow.
//!
//! *Amended, 3 October 2026, the review of the tagged-writing lane.* **Four
//! more rows, for the readers ISO 32000-2 added, and three of them caps on
//! copies.** `MAX_STRUCTURE_VALUES` is the structure walk's budget on the
//! array entries it reads from elements' `/A`, `/Headers` and `/AF` — one
//! array shared by every element was read once per element, and for `/A`
//! that was nine seconds for sixteen elements and two days for the element
//! cap. `MAX_STRUCTURE_BYTES` bounds what that walk copies out — one `/NS`
//! URI, `/ID` or `/Headers` string named from every element — and
//! `MAX_ASSOCIATED_FILE_BYTES` and `MAX_OUTPUT_INTENT_BYTES` the two
//! document-level listings, where 90 KB of `/AF` asked for 256 MiB of
//! descriptions. Each `fixtures` is the cap, for `MAX_ANNOTATION_BYTES`'s
//! reason. The comic and fixed-document columns are zeros because neither
//! path writes a structure tree, an `/AF` or an intent unasked; the book's
//! two structure columns are arithmetic about what the EPUB path writes, and
//! its two listing columns zeros.
//!
//! *Amended, 2 October 2026, the review of the redaction row.* **One more
//! row, `MAX_FORM_COPY_BYTES`, the third cap on copies.** A redaction
//! measures every placement of a form before it writes any, and kept every
//! distinct cut of every form — a whole copy of the form's content each, up
//! to `MAX_PLACEMENTS` of them — until the walk ended, then cloned each into
//! the editor. A deflate-bombed 128 MiB form placed at 64 offsets under one
//! rectangle asked for about 8 GiB twice over, from a file of a few hundred
//! kilobytes. Its `fixtures` is the cap, for `MAX_ANNOTATION_BYTES`'s
//! reason, and its three yardsticks are zeros, because none of the
//! container paths redacts.
//!
//! *Amended, 2 October 2026, tier 5's Markdown row.* **Two more rows, the
//! first for a reader whose input is text a caller names rather than a file
//! that names itself.** `MAX_MARKDOWN_NESTING` bounds how deep containers
//! open, because every line walks every open container; `MAX_MARKDOWN_REFERENCE_BYTES`
//! bounds what reference links copy out of their definitions, which is the
//! one place in CommonMark where a short input asks for a long output. All
//! three yardsticks are zeros, because no container path reads Markdown.
//!
//! *Amended, 2 October 2026, the review of the form data exchange row.* **One
//! more row, `MAX_FORM_DATA_BYTES`, the second cap on copies.** The FDF and
//! XFDF readers hand back qualified names, values and warnings, and each of
//! those repeated something the file says once: a field's name in every
//! warning met inside it, a shared indirect `/T` in every name beneath it, a
//! shared `/V` in every field. The review found 67 KiB of FDF asking for
//! 184 MB and 22 KiB asking for a gigabyte. Its `fixtures` is the cap, for
//! `MAX_ANNOTATION_BYTES`'s reason, and its three yardsticks are zeros,
//! because none of the container paths reads form data.
//!
//! *Amended, 26 September 2026, the annotation payloads row.* **One more row,
//! `MAX_ANNOTATION_BYTES`, and it is a cap on copies rather than on anything
//! parsed.** Everything a page's annotation listing hands back is a copy of an
//! object the parser already holds, and an indirect object is parsed once and
//! may be named by every one of the 4 096 entries `/Annots` is read to — so a
//! file of a few megabytes asks for tens of gigabytes. That was true of
//! `/Contents`, `/T` and `/M` from the day the listing landed, and the
//! per-family payloads would have made it true of every array in 12.5.6's
//! tables. The row's `fixtures` is the cap for `MAX_DECODED_STREAM`'s reason:
//! the test that fires it spends it.
//!
//! *Amended, 26 September 2026, the tier-4 archive row's BMP decoder.* **One
//! more row, the forty-eighth: `MAX_BMP_SAMPLES`.** It is `MAX_PNG_SAMPLES`'s
//! figure for `MAX_PNG_SAMPLES`'s reason — a decoded comic page lives under
//! one ceiling whichever container it came in — and it is a row of its own
//! rather than that cap under a second name because it bounds a different
//! header: `biWidth` and `biHeight` are signed 32-bit fields where IHDR's are
//! 31-bit, so the reachable product is its own arithmetic. Its `document` and
//! `book` columns are measured zeros, and the comment on each says why: XPS
//! admits no BMP part and an EPUB `<img>` does not place one.
//!
//! *Amended the same day, the archive row's GIF decoder.* **The forty-ninth,
//! `MAX_GIF_SAMPLES`**, for the same reason and with one difference worth the
//! sentence: GIF *is* an EPUB core media type, so its `book` column is a
//! picture rather than a zero.
//!
//! *Amended the same day, the archive row's WebP decoder.* **The
//! fiftieth, `MAX_WEBP_SAMPLES`**, GIF's row again — WebP is a core
//! media type too, so its `book` column is a picture — with its own
//! arithmetic: of the two headers that can ask, a `VP8X` canvas's two 24-bit
//! dimensions reach further than a lossless header's two 14-bit ones.
//!
//! *Amended the same day, the review of the SVG writer.* **The fifty-first,
//! `MAX_SVG_BYTES`**, and the first row whose quantity is output rather than
//! input: markup grows with what the page draws, one element per operator, so
//! a short content stream can ask for as much as it likes.
//!
//! *Amended the same day, the review of the retained page.* **The
//! fifty-second, `MAX_DISPLAY_LIST_BYTES`**, output again: a recording grows
//! with what the page draws, and a page that would pass it is drawn the direct
//! way rather than refused, so the cap costs a replay and never a picture.
//!
//! *Amended, 26 September 2026, the `jbig2` fuzz row.* **One more row, the
//! forty-fourth, and it is the first here whose cap is a *ratio* rather than a
//! quantity.**
//!
//! `MAX_JBIG2_SYMBOL_PAGE_MULTIPLE` bounds one symbol against the page it will
//! be composited onto. Every other row in this table compares a count, a byte
//! total or a pixel total against a constant; this one compares a symbol's
//! width with `/Width` and its height with `/Height`, so its currency is a
//! *multiple* and its ledger publishes `4` rather than a quantity.
//!
//! Two things about it are worth reading before the row.
//!
//! **It is the first JBIG2 row whose yardstick is a measurement.** The three
//! that landed at tier 1 publish `(estimate)` because the corpus could not
//! supply their figures: `SDNUMNEWSYMS`, `SDNUMEXSYMS` and `SBNUMINSTANCES` are
//! counts, and the corpus's counts were synthetic until tier 0's production
//! shard arrived. A symbol's *size* is different in kind — it is nowhere in any
//! segment header, because 6.5.5 accumulates both dimensions inside the
//! arithmetic coder — so the measurement needed a decode rather than a walk,
//! which is why `jbig2_census.rs` carried a `max_symbol_pixels` field that
//! nothing assigned from the day it was written. It assigns it now, and the figure this row
//! is calibrated on comes with it: **88 736 symbols over 243 dictionaries in
//! 502 images, and not one of them wider or taller than its page.** See
//! [`SCAN_SYMBOL_PAGE_MULTIPLE`].
//!
//! **And it is not `MAX_JBIG2_SYMBOL_PIXELS` wearing a second name**, which is
//! the objection this header raises twice already and which kept the `jbig2`
//! fuzz row open rather than closing it under a number nobody could argue for.
//! That cap bounds the pixels **one dictionary** decodes in total; this one
//! bounds **one symbol** against a quantity that cap never reads. The
//! distinction is the one `MAX_JBIG2_SYMBOL_PIXELS`'s own ledger draws in its
//! first sentence — *"a per-symbol bound is not a work bound once the count
//! branches"* — taken in the other direction: a total is not a per-item bound
//! either, and 105 bytes spending the whole 67 108 864 on a page of one pixel
//! is what that gap looked like from the outside (`docs/verification.md`).
//!
//! *Amended, 5 September 2026, tier 0's memory row.* **Two more rows, and the
//! first amendment to what a [`Bound`] is allowed to be.**
//!
//! The table goes from forty to **forty-two**, and the two are
//! `MAX_PAGE_PIXELS` and `MAX_DECODED_STREAM`: the largest allocation this
//! engine makes for one page, and the largest one it makes for one stream.
//! Neither is new, neither was ever quiet, and both had a clock-free firing
//! test before this milestone. What neither had is the arithmetic this file
//! exists for — *is the number in the code the number in the ledger, does the
//! cap sit under what its own inputs can ask for, and does it clear the thing
//! the format is for.*
//!
//! **Admitting them cost the contract an amendment, and that is the
//! interesting half.** `tinker-pdf-render` carried a recorded decision saying
//! the opposite of this milestone. Of `MAX_IMAGE_RUN_PIXELS` it read: *"it is
//! not a `bounds_ledger.rs` row for `MAX_PAGE_PIXELS`'s reason: both are
//! properties of the scale the caller asked for rather than counts read out of
//! a document, and that ledger measures documents."* That was an accurate
//! description of the table as it stood and a wrong rule, and the way to tell
//! is what it exempts: the largest allocation in the engine, from the one
//! check that would have caught `MAX_JPX_WORK`. `/MediaBox [0 0 1e9 1e9]` is
//! four tokens read out of a document whatever scale multiplies them. So
//! [`Bound`]'s contract now admits a **caller-parameterised** cap on one
//! condition — the parameter is fixed and written into the row, because a
//! yardstick that depends on an unstated number is not a yardstick.
//! `MAX_PAGE_PIXELS`'s three columns are at 150 dpi and its own ledger argues
//! the dpi rather than assuming it.
//!
//! `MAX_DECODED_STREAM` is the other kind of hole. It had no `reachable` and
//! could not have had one, because the sentence standing in front of it was
//! *"a 1 KB flate stream can legally expand without bound"* — and a cap with
//! no ceiling in front of it is a cap nobody can check, which is gap 18a
//! milestone 8's failure written as prose instead of as a constant. DEFLATE's
//! expansion is bounded: **1 032:1**, from RFC 1951's 258-byte longest match
//! costing two bits under a degenerate Huffman tree. The row's ceiling is that
//! ratio against an input of at most `u32::MAX` bytes — the narrowest target
//! this engine builds for, taken on purpose — and it clears the cap by
//! thirty-three thousand.
//!
//! And the direction that must be checked in both: `MAX_IMAGE_RUN_PIXELS` is
//! **still** not a row, and its comment now says so for a reason that
//! survives the amendment. A cap set under another cap, over a quantity that
//! other cap has already bounded, is the other cap wearing a second name —
//! which is the argument this header already makes for `MAX_EPUB_PAGES` at gap
//! 31's milestone 4 and for `MAX_LAYOUT_WORK` at its milestone 7.
//!
//! *Amended, 4 September 2026, tier 1's two ledger rows.* **Five more rows, and
//! the first three in this table that publish a number as an estimate.**
//!
//! The table goes from thirty-five to **forty**, and the five are the first
//! here that belong to no container format: `MAX_ICC_TAGS` and `MAX_ICC_BYTES`
//! bound a colour profile, and `MAX_JBIG2_SYMBOLS`,
//! `MAX_JBIG2_SYMBOL_PIXELS` and `MAX_JBIG2_TEXT_INSTANCES` bound a PDF image
//! filter. All five fired and were proved to fire before this milestone; what
//! they had no answer for is the question this file asks — *is the number in
//! the code the number in the ledger, does the cap sit under what its own
//! inputs can ask for, and does it clear the thing the format is for.*
//!
//! Two of the five arrive with the discipline unchanged. `MAX_ICC_BYTES` clears
//! the corpus's largest profile — 718 672 bytes, measured over every `acsp`
//! stream in all 4 594 files — by 2.9x, and `MAX_ICC_TAGS` clears the busiest
//! at eighteen tags by a factor of fifty-seven. Both were already exercised,
//! but inside **one** shared refusal test among ten assertions, and the rule
//! that each bound names a test that fires *it* is what makes a rename fail
//! here rather than quietly leave a cap unproven; so each has its own now.
//!
//! The other three are the interesting half, and they are why
//! [`every_bound_publishes_the_number_it_is`] learned a fourth suffix.
//! `docs/design/jbig2-symbol-text.md` took the measurement its milestone 7
//! asked for — every `SDNUMNEWSYMS`, `SDNUMEXSYMS` and `SBNUMINSTANCES` in all
//! 102 JBIG2-bearing corpus files — and found **8**, **11** and **9**. Nothing
//! in a hundred files exceeds twenty of anything, because every one of them is
//! a synthetic fixture built to exercise one placement variant: **the corpus
//! holds no real OCR JBIG2 at all**, and a cap calibrated against it would
//! admit anything. So those three rows' yardsticks are arithmetic, they say
//! `(estimate)` in the number they publish, and the measurement milestone 7
//! wanted is now a dependency of tier 0's production-corpus row rather than a
//! row of its own claiming to be blocked.
//!
//! Saying `estimate` out loud costs one line in the parser and buys the thing
//! this file exists for: a stated estimate that reads like a measurement is
//! how `MAX_JPX_WORK` survived. `SCAN_SYMBOLS` carries the arithmetic and the
//! one place where a column in this table holds a file its own format does not.
//!
//! *Amended, 6 September 2026.* **The estimate has a measurement beside it at
//! last, and it holds.** Tier 0's production-corpus row landed — a thousand
//! documents off the open web, fetched and pinned — and it carries the real
//! OCR JBIG2 the corpus had none of. Over the 117 JBIG2-bearing files in the
//! five corpora the largest dictionary exports **2 478** symbols, declares
//! 2 468 new ones and places **4 440** text instances, where a hundred
//! synthetic fixtures had never exceeded 11 and 9.
//!
//! The three rows keep `(estimate)` and that is not an oversight: the word
//! describes how the *cap* was derived, which is still arithmetic about a
//! plausible scan, and 100 000 was never read off a file. What the corpus now
//! says is that the arithmetic was not wrong — a real scanned document asks
//! for a fortieth of the symbol cap and a nine-hundredth of the instance cap.
//! `SCAN_SYMBOLS`'s 20 000 sits between the two, which is where a yardstick
//! belongs.
//!
//! *Amended, 22 August 2026, gap 31 milestone 13.* **No new row, and a third
//! yardstick on every one of the thirty-four — which found two caps set below a
//! real book.**
//!
//! Gap 29's yardstick is a 200-page comic and gap 30's is a dense fixed
//! document. Both are estimates: arithmetic about a plausible file, written down
//! so it can be argued with. Gap 31's is a 300-page reflowable book and it is
//! **not** an estimate, because this is the first format here whose reading path
//! publishes what it spent. [`tinker_pdf::cbz::ArchiveReport::book_cost`] gives
//! ten figures and the archive gives five more, so
//! [`the_book_yardstick_is_not_below_a_real_book`] opens every book in both
//! corpora on every run and measures sixteen of these rows against what a real
//! book actually costs.
//!
//! **Two rows failed the first time it ran, and neither could have been found
//! from the committed corpus.** `MAX_BOX_TREE_NODES` was 262 144 and
//! `sample-linear-algebra.epub` — 94 content documents of MathML — needs
//! **993 349**; `MAX_LAYOUT_WORK` was 4 000 000 and `sample-epub30-spec.epub`,
//! the EPUB 3.0 specification published as a book, spends **4 233 567**. The
//! six books this repository commissioned spend 326 and 39. A yardstick
//! calibrated on our own corpus would have agreed with both wrong numbers and
//! called the margin comfortable.
//!
//! Neither cap was quiet: both refuse by name. But the layout budget is spent
//! across a **whole book** and never refunded, so the chapter that crossed the
//! box cap refused and so did every chapter after it — a 94-chapter book that
//! opened, paginated to its spine, and lost two thirds of its text with a
//! warning per page nobody had to read. That is
//! [`no_bound_refuses_a_real_book`]'s whole reason for existing, reached from
//! the direction this file has always warned about: **a cap that refuses the
//! thing the format is for is not a bound, it is a missing feature.**
//!
//! [`Bound::book`] is not an `Option` and no row opts out. Gap 30's milestone 9
//! had to go back and fill in seven `None`s that had stood for seven
//! milestones; this one is filled in at the milestone that adds it, and where
//! the honest figure is zero it is a zero with a comment saying what makes it
//! one — a book holds no comic page and no XPS part, and that is a fact about
//! the format rather than an absence of measurement.
//!
//! *Amended, 20 August 2026, gap 31 milestone 7.* **Four more rows**, the whole
//! of `tinker-pdf-layout`'s `limits.rs`, and the table goes from twenty-nine to
//! thirty-three. Two of them are worth reading before the rest, and one of the
//! plan's own rows is **not** here.
//!
//! `MAX_BOX_DEPTH` exists where gap 31's bounds section says a depth cap would
//! not. That section's *"four deliberately absent"* list says there is nothing
//! on DOM depth because `MAX_XML_DEPTH` is 256 and stands in front of every
//! content document, so a second constant could never fire — and that is right
//! about the facade and wrong about the crate that lays a tree out. **This
//! crate's input is a caller-built tree rather than a parsed document.** The
//! twenty-fourth fuzz target builds one from a structured generator with no
//! parser anywhere in front of it, and layout recurses over it, so the ceiling
//! in this row is the only unbounded one in the table.
//!
//! `MAX_LAYOUT_PAGES` **is** gap 31's `MAX_EPUB_PAGES`, under the name of the
//! crate that fragments. Milestone 4 amended that row in place — *"it arrives
//! with milestone 7's fragmentation and not before"* — and this is that
//! milestone. It is declared in `tinker-pdf-layout` rather than in `epub.rs`
//! for `MAX_DOM_NODES`'s reason one milestone earlier: a cap belongs where the
//! thing it bounds is decided, and pages are decided by `layout::fragment`.
//!
//! **`MAX_LAYOUT_WORK` is in gap 31's bounds table and was not in this one
//! until milestone 10.** Milestone 7's argument for its absence was: in a build
//! with no float re-flow, no two-pass table layout and no shrink-to-fit, every
//! unit of layout work is one box or one line box; boxes are bounded by
//! `MAX_BOX_TREE_NODES` and line boxes by `MAX_LINE_BREAK_WORK`, because a line
//! box needs a character and every character is charged before the breaker is
//! entered. A cap there would sit above what its own inputs can ask for — gap
//! 18a milestone 8's failure — or below the box cap, where it would be the box
//! cap wearing another name. It was written, its firing test was attempted, and
//! it could not be made to fire without lowering itself. The argument ended:
//! **the bound arrives with the multi-pass layout or not at all**, which is
//! milestones 10 and 11.
//!
//! *Amended, 21 August 2026, gap 31 milestone 10.* **It arrived, and the
//! sentence above is why the row can be checked rather than argued.** Floats
//! are the multi-pass layout: §9.5.1 places each float against every float
//! already placed and §9.5's line boxes ask all of them for their measure, so
//! the work is the **product** of the two caps that were said to bound it —
//! 262 144 floats examined 262 144 times is 6.9e10 with every other cap
//! satisfied. It is the first row in this table whose ceiling is the *square*
//! of another row, and it fires on 2 000 floats in one chapter.
//!
//! Earning that absence cost three fixes rather than none, and they are the
//! interesting half: *depth is not work once the recursion branches* has a
//! loop-shaped twin, and three places in `layout::flow` were quadratic. The
//! line filler restarted its scan of the break opportunities at zero for every
//! line, which for a page one point wide is `O(characters^2)`; `piece_at`
//! scanned the span list once per boundary; and the list-item ordinal counted
//! from the first child for every item. A work cap would have **charged** for
//! all three instead of removing them.
//!
//! Every one of the four spends **zero** against gap 29's comic and gap 30's
//! fixed document, and that is a measured fact rather than an opt-out: neither
//! format has a box tree.
//!
//! *Amended, 20 August 2026, gap 31 milestone 6.* **Eight more rows**, the whole
//! of `tinker-pdf-css`'s `limits.rs`, and the table goes from twenty-one to
//! twenty-nine. Two of them are worth reading before the rest.
//!
//! `MAX_SELECTOR_MATCHES` is the first row here whose reachable ceiling is a
//! **product** rather than a field width: `MAX_CSS_RULES` bounds the stylesheet
//! and `MAX_DOM_NODES` bounds the document, a file chooses both independently,
//! and neither bounds the other. That is `5adf502`'s finding — *depth is not
//! work once the recursion branches* — in the one place in this engine where
//! the arithmetic is a multiplication, and gap 31's bounds table calls it the
//! single most important constant in that plan. It is the only row whose
//! `reachable` is checked at **compile time** as well as here, by a `const`
//! block in the crate that declares it.
//!
//! `MAX_DOM_NODES` is declared in `tinker-pdf-css` rather than with the element
//! tree that will admit the elements, and the reason is that `const` block: a
//! compile-time relation can only name constants its own crate can reach, and
//! `tinker-pdf-css`'s allow-list is empty by the fifth DAG amendment. So the
//! **other** half of the relation gap 31's bounds section asks for —
//! `MAX_DOM_NODES < MAX_XML_TOKENS` — cannot live there and is owed by the
//! facade at milestone 8, which is the crate that can see both. Until then it
//! is this row's `reachable` column, which is exactly the check it would be:
//! 65 536 against 1 048 576, so the element cap fires long before the XML
//! parser in front of it does.
//!
//! Every one of the eight spends **zero** against gap 29's comic and gap 30's
//! fixed document, and that is a fact rather than an opt-out: neither format
//! holds a stylesheet. Milestone 9's rule — *a row that opts out of a check is
//! a row that is not checked* — is satisfied by a measured zero and would not
//! be by an `Option`.
//!
//! *Amended, 19 August 2026, gap 31 milestone 4.* Three more rows —
//! `MAX_EPUB_MANIFEST_ITEMS`, `MAX_EPUB_SPINE_ITEMS` and
//! `MAX_EPUB_FALLBACK_DEPTH` — and one the plan's own bounds table names that
//! is **deliberately absent**, which is the more interesting half.
//!
//! Gap 31's table has a row for `MAX_EPUB_PAGES` and argues that it cannot be
//! bounded by the spine item count, *"because one spine item of 128 MiB of text
//! fragments into as many pages as its length divided by the page height"*.
//! That argument is right and it is about a build that **fragments**. This one
//! does not: milestone 4 puts exactly one page on each `<itemref>`, so a page
//! cap above `MAX_EPUB_SPINE_ITEMS` could never fire and one below it would be
//! the spine cap wearing another name. Adding it now would be gap 18a milestone
//! 8's failure reached from the direction that writes the constant first, and
//! it is the same argument `MAX_XPS_VISUAL_DEPTH`'s absence carries below:
//! **the bound arrives with the fragmentation or not at all**, which is
//! milestone 7.
//!
//! The pair among the three is worth stating for the reason `MAX_XPS_PAGES` and
//! `MAX_XPS_PARTS` were: **the manifest cap does not bound the spine cap.**
//! `epubcheck` reports two `<itemref>`s naming one manifest item as `OPF-034`,
//! which is an error and not a well-formedness failure, so a hostile package
//! document may name one item four thousand times. The `const` relation in
//! `epub.rs` orders the two as a matter of policy and says so; neither could
//! stand in for the other.
//!
//! *Amended, 19 August 2026, gap 31 milestone 3.* One more row —
//! `MAX_OCF_PATH_LEN` — and it is the first here whose number is a
//! **specification's own**: OCF 3.3 §4.2.3 says a content path must not exceed
//! 65 535 bytes, so this cap is taken rather than invented. That makes
//! [`every_bound_can_fire`]'s check the interesting one: the ceiling in front
//! of it is an XML attribute value in a ZIP entry, 128 MiB, so the spec's own
//! figure sits two thousand times below what an attacker may ask for and the
//! cap is a cap.
//!
//! Two constants that could have joined it did not, and both absences are
//! argued where they are declared rather than here: nothing on container-path
//! **depth**, because nothing in this engine touches a filesystem so depth
//! bounds no allocation and no recursion; and nothing on a **segment**'s
//! length, because §4.2.3's 255-byte file-name limit is an interoperability
//! rule about somebody else's file system and enforcing it would refuse a path
//! that names an entry the container actually holds.
//!
//! *Amended, 19 August 2026, gap 30 milestone 9.* **No new row, and that is the
//! point of this amendment: what it adds is the missing half of the rows that
//! were already here.** Gap 30's yardstick — a 200-page fixed document at
//! roughly 2 000 drawable elements and 40 000 path segments a page — arrived in
//! milestone 2 with a figure for gap 30's own rows and `None` for gap 29's
//! seven, and milestone 2 wrote down that milestone 9 would fill them in. It
//! has, so [`Bound::document`] is no longer an `Option` and
//! [`no_bound_refuses_a_dense_fixed_document`] sweeps **seventeen** rows rather
//! than ten. Row 9 asks for *"three recorded numbers each"* and a row with a
//! `None` in it had two.
//!
//! Filling them in is not bookkeeping. Four of the seven are gap 29's ZIP
//! caps, and **every XPS part in this repository is a ZIP entry** — so those
//! four stand in front of the whole of gap 30 and had never been measured
//! against anything gap 30 produces. `MAX_PNG_SAMPLES` is the row that shows
//! why it was worth doing: gap 29's yardstick spends 24 000 000 against it and
//! gap 30's spends 33 660 000, because a 300 dpi RGBA page scan in a report is
//! a larger image than any page of a comic, and the margin under the cap is
//! half what the comic suggested.
//!
//! `MAX_XPS_VISUAL_DEPTH` is in gap 30's bounds table and is **not** here, and
//! the argument is milestone 8's rather than an omission: `VisualBrush` is
//! refused by name, so a cap over a walk nothing performs is a constant that
//! could never fire — [`every_bound_can_fire`]'s own failure, reached from the
//! direction that writes the constant first. The bound arrives with the walk or
//! not at all.
//!
//! *Amended, 18 August 2026, gap 30 milestone 7.* One more row —
//! `MAX_XPS_GLYPHS` — and it is here rather than absent because a `Glyphs` is
//! **one** element and **no** segments, so neither work cap milestone 6 added
//! sees a single glyph. `1;` is two bytes and one more glyph mapping, and one
//! mapping is eighty bytes of value, so a single `Indices` attribute in a part
//! this build already admits is a hundred million of them. It is charged
//! *before* the mappings are materialised for that reason, which is
//! `tinker-pdf-zip`'s own posture: a permit is what has been promised.
//!
//! *Amended, 18 August 2026, gap 30 milestone 6.* Three more rows —
//! `MAX_XPS_ELEMENTS`, `MAX_XPS_SEGMENTS` and `MAX_XPS_RESOURCE_DEPTH`. The
//! first two are the plan's own **work caps**, the numbers a file chooses when
//! it decides how much markup a page holds, and milestone 5 recorded that they
//! are *"where a file-chosen count is refused"*. The third arrives with them
//! rather than later because row 6's `{StaticResource}` criterion asks for *"a
//! depth cap and a cycle refused rather than recursed"*, and those are two
//! rules with two names in the report — a chain of twenty distinct keys is not
//! a cycle and a cycle of two is not deep.
//!
//! *Amended, 18 August 2026, gap 30 milestone 3.* Two more rows —
//! `MAX_XPS_PARTS` and `MAX_XPS_PAGES` — and the relation
//! `MAX_XPS_PAGES < MAX_XPS_PARTS < MAX_ZIP_ENTRIES`, written in a `const`
//! block beside the constants so a build that breaks it **does not compile**.
//! The pair is worth having as a pair: two hundred `PageContent` elements may
//! name one part between them, so the page count is not bounded by the part
//! count and neither cap could stand in for the other.
//!
//! *Amended, 18 August 2026, gap 30 milestone 2.* Four more rows —
//! `tinker-pdf-xml`'s — and one more relation. Gap 30's bounds section says the
//! new constants join **this** table rather than getting a sweep of their own,
//! *"because the whole value of it is that it is one table"*, and they inherit
//! all five checks below unchanged. What they add is a second yardstick: gap
//! 29's is a 200-page comic and gap 30's is a 200-page fixed document at
//! roughly 2 000 drawable elements and 40 000 path segments a page, and a bound
//! that refuses either is a missing feature wearing a `MAX_` prefix. The
//! yardstick is `Option`al per row because gap 29's seven have no figure for it
//! yet; gap 30's milestone 9 fills those in when it adds the rest of its own
//! table.
//!
//! Each of the four modules this gap added carries its own ledger beside its
//! own constants — `tinker-pdf-zip`'s `limits.rs`, `png.rs`'s module note,
//! `cbz.rs`'s bounds section — and each proves its own caps fire in its own
//! tests. What none of them can do from where it stands is check the **set**:
//! that every bound the plan's table names has a ledger at all, that the number
//! in the ledger is the number in the code, and that the cap sits below what
//! its own inputs can ask for.
//!
//! That last one is the whole reason this file exists. Gap 18a's milestone 8
//! found `MAX_JPX_WORK` set *above* the most its own inputs could reach, so it
//! could never fire; nothing failed, because a cap that cannot fire behaves
//! exactly like a cap that is never approached. The check that would have
//! caught it is arithmetic — compare the constant against the ceiling of what
//! stands in front of it — and it is done here for all seven at once.
//!
//! # What is asserted, and what is only recorded
//!
//! Asserted: the constant equals the number its ledger publishes; the cap is
//! **reachable**, so it can fire; a 200-page 2000 x 3000 comic fits under it,
//! so it does not refuse the thing the format is for; and the test named as
//! proving each one fires **exists**, in the file this table says it is in.
//!
//! Recorded but not asserted here: what each of those tests does. They are
//! read by name, not by behaviour, because a test in another crate is not
//! something this one can run — the discipline is that the name is checked, so
//! a ledger citing a test that was renamed or deleted fails here rather than
//! quietly becoming prose.
//!
//! # Why `fixtures <= comic` is not one of the relations
//!
//! It holds for six of the seven and cannot hold for the seventh.
//! `MAX_CBZ_PAGES` is proved to fire by building the real 4 097-entry archive
//! rather than by lowering the constant, so the most any fixture in this
//! repository spends against *that* bound is the cap itself — far more than a
//! comic. A relation that six rows satisfy and one does not is not a relation.

use tinker_pdf::cbz::{
    zip_limits, MAX_CBZ_PAGES, MAX_COMIC_INFO_BYTES, MAX_SYNTHESISED_PDF, PAGE_OVERHEAD,
};
use tinker_pdf::epub::{
    MAX_EPUB_FALLBACK_DEPTH, MAX_EPUB_MANIFEST_ITEMS, MAX_EPUB_SPINE_ITEMS, MAX_OCF_PATH_LEN,
};
use tinker_pdf::form_data::MAX_FORM_DATA_BYTES;
use tinker_pdf::markdown::{MAX_MARKDOWN_NESTING, MAX_MARKDOWN_REFERENCE_BYTES};
use tinker_pdf::redact::MAX_FORM_COPY_BYTES;
use tinker_pdf::structure::{MAX_STRUCTURE_BYTES, MAX_STRUCTURE_VALUES};
use tinker_pdf::xps::{
    MAX_XPS_ELEMENTS, MAX_XPS_GLYPHS, MAX_XPS_PAGES, MAX_XPS_PARTS, MAX_XPS_RESOURCE_DEPTH,
    MAX_XPS_SEGMENTS,
};
use tinker_pdf::{MAX_ANNOTATION_BYTES, MAX_ASSOCIATED_FILE_BYTES, MAX_OUTPUT_INTENT_BYTES};
use tinker_pdf_color::icc::{MAX_ICC_BYTES, MAX_ICC_TAGS};
use tinker_pdf_css::limits as css_limits;
use tinker_pdf_filters::{
    MAX_BMP_SAMPLES, MAX_GIF_SAMPLES, MAX_JBIG2_SYMBOLS, MAX_JBIG2_SYMBOL_PAGE_MULTIPLE,
    MAX_JBIG2_SYMBOL_PIXELS, MAX_JBIG2_TEXT_INSTANCES, MAX_JBIG2_WORK_MULTIPLE, MAX_PNG_SAMPLES,
    MAX_WEBP_SAMPLES,
};
use tinker_pdf_layout::limits as layout_limits;
use tinker_pdf_xml::limits as xml_limits;

/// The sources the ledgers live in, so a number here can be checked against
/// the number written beside the constant rather than against a memory of it.
const ZIP_LIMITS: &str = include_str!("../../tinker-pdf-zip/src/limits.rs");
const ZIP_TESTS: &str = include_str!("../../tinker-pdf-zip/src/tests.rs");
const PNG: &str = include_str!("../../tinker-pdf-filters/src/png.rs");
const PNG_TESTS: &str = include_str!("../../tinker-pdf-filters/src/png/tests.rs");
const CBZ: &str = include_str!("../src/cbz.rs");
const CBZ_TESTS: &str = include_str!("cbz.rs");
const CBZ_UNIT_TESTS: &str = include_str!("../src/cbz/tests.rs");
const CBZ_COMIC_INFO: &str = include_str!("../src/cbz/comic_info.rs");
const XML_LIMITS: &str = include_str!("../../tinker-pdf-xml/src/limits.rs");
const XML_TESTS: &str = include_str!("../../tinker-pdf-xml/src/tests.rs");
const EPUB: &str = include_str!("../src/epub.rs");
const EPUB_TESTS: &str = include_str!("epub_ocf.rs");
const EPUB_UNIT_TESTS: &str = include_str!("../src/epub/tests.rs");
const CSS_LIMITS: &str = include_str!("../../tinker-pdf-css/src/limits.rs");
const CSS_BOUNDS_TESTS: &str = include_str!("../../tinker-pdf-css/src/tests/bounds.rs");
const LAYOUT_LIMITS: &str = include_str!("../../tinker-pdf-layout/src/limits.rs");
const LAYOUT_TESTS: &str = include_str!("../../tinker-pdf-layout/src/tests.rs");
const XPS: &str = include_str!("../src/xps.rs");
const XPS_TESTS: &str = include_str!("xps_opc.rs");
const XPS_MARKUP_TESTS: &str = include_str!("xps_markup.rs");
const XPS_GLYPH_TESTS: &str = include_str!("xps_glyphs.rs");
/// One `include_str!` where the others are two, because these two crates keep
/// their tests in the file that declares the constants rather than in a
/// separate module — so `declared_in` and the `fires_in` source are the same
/// text, and there is nowhere for a ledger and its firing test to drift apart.
const ICC: &str = include_str!("../../tinker-pdf-color/src/icc.rs");
const JBIG2: &str = include_str!("../../tinker-pdf-filters/src/jbig2.rs");
/// Tier 0's memory row: the two runtime bounds, and the two sources that prove
/// them. `RENDER` is the first `declared_in` here that is a whole crate root
/// rather than a `limits.rs` — [`tinker_pdf_render::MAX_PAGE_PIXELS`] is
/// declared beside the function that spends it, which is where a cap belongs
/// by this table's own rule.
const RENDER: &str = include_str!("../../tinker-pdf-render/src/lib.rs");
const PAGE_GEOMETRY_TESTS: &str = include_str!("page_geometry.rs");
const COS_LIMITS: &str = include_str!("../../tinker-pdf-cos/src/limits.rs");
/// The tier-4 archive row's container decoders, which keep their caps beside
/// the decoder that spends them — `png.rs`'s shape.
const BMP: &str = include_str!("../../tinker-pdf-filters/src/bmp.rs");
const BMP_TESTS: &str = include_str!("../../tinker-pdf-filters/src/bmp/tests.rs");
const GIF: &str = include_str!("../../tinker-pdf-filters/src/gif.rs");
const GIF_TESTS: &str = include_str!("../../tinker-pdf-filters/src/gif/tests.rs");
const WEBP: &str = include_str!("../../tinker-pdf-filters/src/webp.rs");
const WEBP_TESTS: &str = include_str!("../../tinker-pdf-filters/src/webp/tests.rs");
const INLINE_IMAGE_TESTS: &str = include_str!("inline_images.rs");
/// The annotation payloads' copy budget: declared beside the payload readers
/// that spend it, and fired by a test beside the listing that owns the budget.
const ANNOTATION_PAYLOADS: &str = include_str!("../src/annotations/payload.rs");
const REDACT: &str = include_str!("../src/redact.rs");
const ANNOTATION_TESTS: &str = include_str!("../src/annotations.rs");
/// The form data readers' copy budget, declared beside the two readers that
/// spend it, and fired by the exchange row's own suite.
const FORM_DATA: &str = include_str!("../src/form_data.rs");
const FORM_DATA_TESTS: &str = include_str!("form_data.rs");
/// Lane 4C's review: the SVG writer's markup, declared beside the writer, and
/// the retained page's recording, declared beside the recorder.
const SVG_OUT: &str = include_str!("../src/svg_out.rs");
const SVG_OUTPUT_TESTS: &str = include_str!("svg_output.rs");
const RENDER_DISPLAY: &str = include_str!("../../tinker-pdf-render/src/display.rs");
const DISPLAY_LIST_TESTS: &str = include_str!("display_list.rs");
const MARKDOWN: &str = include_str!("../src/markdown.rs");
const MARKDOWN_TESTS: &str = include_str!("markdown.rs");
/// The review of the tagged-writing lane: the structure walk's two budgets,
/// declared beside the walk, and the two PDF 2.0 listings' copy budgets,
/// declared beside each listing; fired by the suites that read them.
const STRUCTURE: &str = include_str!("../src/structure.rs");
const TAGGED_PDF_TESTS: &str = include_str!("tagged_pdf.rs");
const ASSOCIATED_FILES: &str = include_str!("../src/associated_files.rs");
const OUTPUT_INTENTS: &str = include_str!("../src/output_intents.rs");
const PDF20_TESTS: &str = include_str!("pdf20.rs");
/// Tier 5's table-reconstruction row: the rule cap, declared beside the
/// tables it bounds, fired by the suite that reads them.
const TABLES: &str = include_str!("../src/tables.rs");
const TABLES_TESTS: &str = include_str!("tables.rs");
/// The review of tier 5's formats lane: HTML's two caps live with the XML
/// reader's four, and its bounds suite fires them.
const HTML_TESTS: &str = include_str!("../../tinker-pdf-xml/tests/html.rs");

/// One bound, as its own ledger publishes it.
///
/// **What is allowed to be one — amended by tier 0's memory row.** Until then
/// every row here capped a count read out of a document, and
/// `tinker-pdf-render` had written that pattern down as a *rule* and used it
/// to keep the page ceiling out. The rule is now the thing the pattern was
/// evidence for: **a cap belongs in this table when a hostile input can reach
/// it and an honest one must not.** That admits a cap the *caller*
/// parameterises, on one condition — the parameter is fixed and written into
/// the row. [`Bound::comic`], [`Bound::document`] and [`Bound::book`] are a
/// yardstick each, and a yardstick that depends on an unstated number is not
/// one; `MAX_PAGE_PIXELS`'s three are at a dpi its own ledger names and
/// argues for.
///
/// It does **not** admit a cap set under another cap over a quantity that
/// other cap has already bounded — `MAX_IMAGE_RUN_PIXELS` is a quarter of
/// `MAX_PAGE_PIXELS` and stays out — for the reason this file's header gives
/// twice already: that is the other cap wearing a second name.
struct Bound {
    /// The constant's name, as written in the code.
    name: &'static str,
    /// Its value, read from the crate that declares it.
    cap: u128,
    /// The cap as its ledger's third row writes it, digit groups and all.
    published: &'static str,
    /// The most any fixture in this repository spends against it.
    fixtures: u128,
    /// The most gap 29's yardstick spends: a 200-page comic at 2000 x 3000.
    comic: u128,
    /// The most gap 30's yardstick spends: a 200-page fixed document at
    /// roughly 2 000 drawable elements and 40 000 path segments a page.
    ///
    /// Not an `Option` since milestone 9. It was one for seven milestones,
    /// because gap 29's rows arrived before gap 30 had a yardstick to measure
    /// them with — and a row that opts out of a check is a row that is not
    /// checked, which is the shape of every failure this file exists for.
    document: u128,
    /// The most gap 31's yardstick spends: **a 300-page reflowable book**.
    ///
    /// The third yardstick, and unlike the first two it is not an estimate.
    /// Sixteen of these forty-seven rows are figures a real book can be
    /// *measured* against, and
    /// [`the_book_yardstick_is_not_below_a_real_book`] measures every book in
    /// both corpora against them on every run — the committed six always, the
    /// fetched twenty when `TINKER_EPUB_CORPUS` names them. Each of those
    /// sixteen is the largest figure any of the twenty-six actually spends,
    /// rounded up; the other twenty-six carry a derivation in their own
    /// comment.
    ///
    /// **Not an `Option`, and no row opts out.** Gap 30's milestone 9 had to go
    /// back and fill in seven `None`s that had stood for seven milestones, and
    /// wrote down why: *a row that opts out of a check is a row that is not
    /// checked*. Where the honest figure is zero it is a zero and the comment
    /// says what makes it one — a book holds no comic page and no XPS part, and
    /// that is a fact about the format rather than an absence of measurement.
    book: u128,
    /// The most this bound's own inputs can ask for, which must exceed the cap
    /// or the cap can never fire.
    reachable: u128,
    /// Why that is the ceiling in front of it.
    reachable_because: &'static str,
    /// The source the constant and its ledger live in.
    declared_in: &'static str,
    /// The test that proves it fires by its own refusal or warning, and the
    /// source that test lives in.
    fires_in: (&'static str, &'static str),
}

/// 4 GiB: a ZIP's central-directory offsets are 32-bit without Zip64, so this
/// is how large an ordinary archive can be.
const ARCHIVE_CEILING: u128 = 1 << 32;

/// Gap 31's yardstick, where three rows share a number.
///
/// **A 300-page reflowable book of 128 spine items**, which is the shape of the
/// densest thing either corpus holds and then some: `sample-linear-algebra.epub`
/// is 94 content documents and 96 manifest items, and no other book comes near
/// it. The manifest and the spine take the same figure because a book that
/// names every item it reads has one of each, and the row for each says why the
/// two caps still cannot stand in for one another.
const BOOK_SPINE_ITEMS: u128 = 128;

/// The book's entries: its 128 documents, 24 pictures, four stylesheets, and
/// the eight files an OCF container and an EPUB 3 package need between them.
const BOOK_ENTRIES: u128 = BOOK_SPINE_ITEMS + 24 + 4 + 8;

/// The longest container path, which is the longest real one doubled: 45 bytes
/// is the most any book in either corpus spends and a yardstick is a plausible
/// book rather than the corpus.
const BOOK_PATH_LEN: u128 = 90;

/// **The three JBIG2 rows' yardstick, and the one place in this table where a
/// column carries a file its own format does not hold.**
///
/// The other thirty-seven rows bound something a comic archive, an XPS package
/// or an EPUB is made of. These three bound a *PDF image filter*, and none of
/// the three container formats reaches it: a CBZ page is a JPEG or a PNG, an
/// XPS image is PNG, JPEG, TIFF or JPEG XR, and a book's pictures are the same
/// again — nothing in any of those paths decodes JBIG2. So the honest figure
/// for [`Bound::comic`] and [`Bound::document`] on these three rows is zero,
/// and a zero would make [`no_bound_refuses_a_two_hundred_page_comic`] and
/// [`no_bound_refuses_a_dense_fixed_document`] say **nothing** about the only
/// three rows the roadmap added them for.
///
/// What those two columns carry instead is the 200-page document this bound is
/// actually for — **a bilevel scan sharing one global dictionary** — at gap
/// 29's and gap 30's own scale, and this comment is the notice that it is not
/// a comic and not an XPS package. [`Bound::book`] stays a zero, because a
/// book's format really does settle the question.
///
/// It is **arithmetic rather than a measurement**, and that is not a lowered
/// bar: gap 29's comic and gap 30's fixed document are estimates too, and this
/// file's header says why that is the honest kind of number to write down.
/// What it replaces is worse. `docs/design/jbig2-symbol-text.md` took the
/// measurement milestone 7 asked for — `SDNUMNEWSYMS`, `SDNUMEXSYMS` and
/// `SBNUMINSTANCES` off the segment headers of all 102 JBIG2-bearing corpus
/// files — and found **8**, **11** and **9**. Every one of those files is a
/// synthetic fixture built to exercise one placement variant, so a cap
/// calibrated on them would admit anything; the three `published` strings say
/// **estimate** out loud for exactly that reason.
///
/// The arithmetic, from that document: a 300 dpi A4 text page reduces to a few
/// hundred distinct glyph bitmaps and a few thousand placements, so 200 pages
/// against one shared dictionary reach the low tens of thousands of symbols
/// and the low thousands of instances per region.
///
/// **Corroborated 6 September 2026 and left where it is.** The largest real
/// dictionary in the five fetched corpora exports 2 478 symbols, so this
/// yardstick is eight times what a real scanned document has asked for and a
/// fifth of the cap it is checked against. A yardstick below the real
/// population would be the failure worth catching; this is the other side.
const SCAN_SYMBOLS: u128 = 20_000;

/// [`SCAN_SYMBOLS`]'s glyphs, at what one occupies: a 25 x 50 box, which is
/// roughly a 10-point glyph at 300 dpi.
const SCAN_SYMBOL_PIXELS: u128 = SCAN_SYMBOLS * 25 * 50;

/// One **page** of [`SCAN_SYMBOLS`]'s document, because `SBNUMINSTANCES` is a
/// text region's own count and a page carries one region or a few. A dense A4
/// text page sets a few thousand characters.
///
/// **Raised from 4 000 on 26 September 2026, and by this file's own rule rather
/// than by preference.** [`SCAN_SYMBOLS`]'s comment says a yardstick below the
/// real population is the failure worth catching, and
/// [`the_book_yardstick_is_not_below_a_real_book`] says what to do about one:
/// *the yardstick is the row that is wrong, not the book — raise it, and check
/// whether the cap above it still stands over the new figure*. The 6 September
/// measurement recorded 4 440 real placements in one text region of
/// `safedocs/0000425.pdf` and left this at 4 000, so the only yardstick in this
/// table that a real document exceeded stood unchanged until now.
/// `MAX_JBIG2_TEXT_INSTANCES` stands over the new figure by 839x.
const SCAN_TEXT_INSTANCES: u128 = 5_000;

/// **The fourth JBIG2 row's yardstick, and the only one of the four that is a
/// measurement rather than arithmetic: one.**
///
/// `MAX_JBIG2_SYMBOL_PAGE_MULTIPLE` bounds a single symbol against the page it
/// will be composited onto, so its currency is a *multiple of the page* and not
/// a count of anything — which is what let it be measured where the other three
/// could not. A symbol's width and height are nowhere in a segment header (6.5.5
/// accumulates both inside the arithmetic coder), so
/// `crates/tinker-pdf/tests/jbig2_census.rs` takes the figure by decoding: every
/// symbol of every JBIG2 image in the five fetched corpora, through
/// `tinker_pdf_filters::jbig2_decode_measured`.
///
/// **88 736 symbols, 243 dictionaries, 502 images, 118 files, and not one symbol
/// is wider or taller than its page.** The measurement is **1**, and the tightest
/// fit in the population is *exactly* 1 — `pdfjs/test/pdfs/bitmap-symbol-big-segmentid.pdf`
/// holds a symbol 399 pixels wide on a page 399 pixels wide. Neither the comic
/// nor the fixed-document column can hold anything else, for the reason
/// [`SCAN_SYMBOLS`] gives at length: neither format decodes JBIG2, so both carry
/// the 200-page bilevel scan instead, whose symbols are glyphs a fiftieth of the
/// page across.
///
/// That the population's ceiling *is* its tightest fit is why the cap is not 1.
/// A bound set at the worst real document is the failure
/// [`no_bound_refuses_a_real_book`] exists to catch, reached from the direction
/// where the measurement flatters it. There is no tail here to clear — the
/// distribution stops at one — so the margin is chosen the way this table's
/// other tail-free rows are: `MAX_JBIG2_SYMBOL_PIXELS` is 2.7x its yardstick and
/// `MAX_JBIG2_SYMBOLS` is 5x its own, and **4** sits between them. Four times
/// the page in each dimension is sixteen times its area, which is still nothing
/// a page can show.
const SCAN_SYMBOL_PAGE_MULTIPLE: u128 = 1;

/// **The fifth JBIG2 row's yardstick: seven, and arithmetic again.**
///
/// `MAX_JBIG2_WORK_MULTIPLE` bounds a whole decode's work against the pixels
/// its caller's ceiling holds, so the figure depends on the ceiling, and this
/// file's rule for a caller-parameterised cap is that the parameter is fixed
/// and written down. It is fixed at the tightest a caller can choose: **a
/// ceiling of exactly the image's own packed page**, below which the page
/// itself is refused. The engine names a work ceiling of the image's own
/// pixels plus 8 388 608 for a shared dictionary (`jbig2_work_ceiling` in
/// `src/resources.rs`), against which this scan spends 3.1; the census and
/// attribution suites pass 4 MiB and no work ceiling.
///
/// The page is one of [`SCAN_SYMBOLS`]'s 200: 300 dpi A4, 8 699 840 pixels.
/// Its global dictionary decodes whole for every page that names it —
/// [`SCAN_SYMBOL_PIXELS`] and the integers that size its symbols, 25.4 million
/// units; copying its symbols into the page's text region 4 million; the region
/// 8.7 million; [`SCAN_TEXT_INSTANCES`] placements of a 25 x 50 glyph 6.3
/// million; and a generic region beside it for the figures 8.7 million. That is
/// 53 million units, 6.1 pages, and seven rounded up — the cap's 16 clears it
/// by 2.3x. **The real figure is owed rather than taken**: `jbig2_census.rs`
/// now reports every image's work as a multiple of its own packed page, and
/// the fetched corpora were not where this row was written. The corpus's
/// largest real dictionary spends 1 568 118 pixels against the 25 000 000
/// counted here, so the arithmetic errs the safe way by the same margin
/// `MAX_JBIG2_SYMBOL_PIXELS`'s own row does.
const SCAN_WORK_MULTIPLE: u128 = 7;

/// The widest code table anybody has published: B.9 and B.10, at 22 lines.
///
/// Not a measurement of documents, and the row that uses it says so. A custom
/// table exists to be *narrower* than a standard one — it names the ranges one
/// encoder actually needs — so Annex B's own widest is the ceiling the
/// population offers, and the cap clears it by 186 times.
const TABLE_LINES: u128 = 22;

fn ledger() -> Vec<Bound> {
    vec![
        Bound {
            name: "MAX_ZIP_ENTRIES",
            cap: zip_limits::MAX_ZIP_ENTRIES as u128,
            published: "16 384",
            fixtures: 6,
            comic: 202,
            // An OPC package of the yardstick's shape: the package
            // relationships part and `[Content_Types].xml`, one
            // `FixedDocumentSequence`, one `FixedDocument`, two hundred fixed
            // pages with a `_rels` part each, and about a hundred fonts and
            // images between them. The same 505 `MAX_XPS_PARTS` counts, because
            // in this format a part *is* an entry.
            document: 505,
            // 128 content documents, 24 pictures, four stylesheets, the
            // package document, the navigation document, the NCX,
            // `container.xml`, `mimetype` and pandoc's seventh `META-INF`
            // entry. The densest real book in either corpus holds **99**:
            // `sample-linear-algebra.epub`, 94 of them content documents.
            book: BOOK_ENTRIES,
            // A central directory record is 46 bytes plus a name, so a name of
            // one byte is the densest an archive can be.
            reachable: ARCHIVE_CEILING / 47,
            reachable_because: "47-byte central directory records in a 4 GiB archive",
            declared_in: ZIP_LIMITS,
            fires_in: (
                "an_archive_with_more_entries_than_the_cap_is_refused_by_name",
                ZIP_TESTS,
            ),
        },
        Bound {
            name: "MAX_ZIP_ENTRY_BYTES",
            cap: zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            published: "128 MiB",
            fixtures: 1_024,
            comic: 48_000_000,
            // The largest single entry, which for this yardstick is one fixed
            // page's markup rather than an image: 40 000 segments at about
            // fourteen bytes of `L 1234,5678 ` apiece, plus 2 000 elements at
            // about sixty. A comic's largest entry is a scan and is seventy
            // times this, which is why the two yardsticks disagree most here.
            document: 40_000 * 14 + 2_000 * 60,
            // Two mebibytes: the largest single entry, which for a book is a
            // full-page plate or a very long chapter rather than markup. The
            // largest any real book here holds is **2 020 786** bytes, which is
            // `sample-linear-algebra.epub`'s MathML — markup after all, and the
            // one place the two guesses cross.
            book: 2 << 20,
            reachable: u32::MAX as u128,
            reachable_because: "the uncompressed-size field is 32 bits, and Zip64's is 64",
            declared_in: ZIP_LIMITS,
            fires_in: (
                "an_entry_declaring_more_than_the_per_entry_cap_is_refused_before_it_allocates",
                ZIP_TESTS,
            ),
        },
        Bound {
            name: "MAX_ZIP_INFLATED",
            cap: zip_limits::MAX_ZIP_INFLATED as u128,
            published: "1 GiB",
            fixtures: 1_024,
            comic: 300_000_000,
            // Two hundred of those pages, plus about twenty megabytes of fonts
            // and images. This is the row the whole of gap 30 stands behind:
            // an XPS part reaches this engine as a ZIP entry, so nothing gap 30
            // reads is admitted without being charged here first.
            document: 200 * (40_000 * 14 + 2_000 * 60) + 20_000_000,
            // Thirty-two mebibytes, and this is the row every byte of gap 31
            // is admitted through: an EPUB entry reaches this engine as a ZIP
            // entry exactly as an XPS part does. The densest real book inflates
            // to **25 473 290**.
            book: 32 << 20,
            // The work cap's whole argument: a per-entry ceiling times a
            // file-chosen entry count is not a bound, and this is the product
            // it would otherwise be.
            reachable: zip_limits::MAX_ZIP_ENTRIES as u128
                * zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            reachable_because: "every entry the entry cap allows, each at the per-entry cap",
            declared_in: ZIP_LIMITS,
            fires_in: (
                "a_zip_bomb_is_refused_by_name_rather_than_by_running_out_of_memory",
                ZIP_TESTS,
            ),
        },
        Bound {
            name: "MAX_ZIP_NAME_LEN",
            cap: zip_limits::MAX_ZIP_NAME_LEN as u128,
            published: "1 024",
            fixtures: 24,
            comic: 42,
            // The longest part name a real package in this repository holds,
            // measured off milestone 1's committed inventory rather than
            // imagined: `Resources/595c31af-dbe8-48a5-a032-c677a052f501.ODTTF`,
            // which is `Resources/` plus a GUID plus an extension. Doubled for
            // headroom, because the yardstick is a *plausible* document rather
            // than the corpus.
            document: 104,
            // The longest container path a book here holds is **45** bytes —
            // `sample-wasteland-otf-obf.epub`'s and `pg16328-beowulf.epub`'s
            // agree on the figure — and the yardstick doubles it, because a
            // yardstick is a plausible book rather than the corpus.
            book: BOOK_PATH_LEN,
            reachable: u16::MAX as u128,
            reachable_because: "the name-length field is 16 bits",
            declared_in: ZIP_LIMITS,
            fires_in: ("a_name_past_the_cap_is_truncated_and_says_so", ZIP_TESTS),
        },
        Bound {
            name: "MAX_PNG_SAMPLES",
            cap: MAX_PNG_SAMPLES as u128,
            published: "67 108 864",
            fixtures: 4_096,
            comic: 24_000_000,
            // **The row that made filling these in worth doing.** A full-page
            // 300 dpi RGBA scan — 2 550 x 3 300 x 4 — which is an ordinary
            // thing for a report to carry and is *larger* than any page of a
            // 2000 x 3000 comic. The margin under this cap is half what gap
            // 29's yardstick alone suggested, and RGBA is not academic here:
            // it is what WPF's serialiser writes, so it is the colour type
            // every real package in this repository uses.
            document: 2_550 * 3_300 * 4,
            // A full-page 300 dpi RGBA plate, which is gap 30's figure for gap
            // 30's reason: an illustrated book and a report carry the same
            // picture. Every picture in the committed corpus is far smaller,
            // because milestone 1's own PNGs are written byte by byte from the
            // specification.
            book: 2_550 * 3_300 * 4,
            // Thirteen bytes of IHDR: two 31-bit dimensions, charged at the
            // widest layout the colour type can produce.
            reachable: 0x7FFF_FFFFu128 * 0x7FFF_FFFF * 4,
            reachable_because: "IHDR's two 31-bit dimensions, times four components",
            declared_in: PNG,
            fires_in: (
                "an_image_past_the_sample_cap_is_refused_before_it_allocates",
                PNG_TESTS,
            ),
        },
        Bound {
            name: "MAX_CBZ_PAGES",
            cap: MAX_CBZ_PAGES as u128,
            published: "4 096",
            // The archive built past this cap holds 4 097 entries; 4 096 is
            // the most any fixture here spends and is *allowed*.
            fixtures: 4_096,
            comic: 200,
            // Zero, and it is an answer rather than a blank: a fixed document
            // has no comic pages at all. The symmetry is the check — a
            // yardstick that measured something here would mean the two paths
            // had been confused, which is the defect this whole gap exists to
            // fix.
            //
            // *Amended in tier 4.* The old wording read "exactly as a comic
            // archive has no XML", and that half stopped being true when
            // `ComicInfo.xml` got a reader: the four `MAX_XML_*` rows below
            // carry a measured comic figure now instead of a zero. The
            // symmetry this row rests on is the *page* one, which is
            // unchanged.
            document: 0,
            // **Zero, measured rather than assumed.** `epub::route` runs
            // before `cbz::pages_from_archive` in `open_container`, so a book
            // never reaches the comic path at all and no book can spend one
            // page against this cap.
            book: 0,
            reachable: zip_limits::MAX_ZIP_ENTRIES as u128,
            reachable_because: "every entry the archive reader will hand over could be an image",
            declared_in: CBZ,
            fires_in: ("a_page_count_past_the_cap_is_refused_by_name", CBZ_TESTS),
        },
        Bound {
            name: "MAX_SYNTHESISED_PDF",
            cap: MAX_SYNTHESISED_PDF as u128,
            published: "512 MiB",
            fixtures: 70_000,
            comic: 300_000_000,
            // The document gap 30 synthesises from that package: 40 000
            // segments a page at about twenty bytes of content-stream operator,
            // two hundred times, plus the fonts and the images. Shared with
            // gap 29 rather than duplicated — `cbz.rs` declares this cap and
            // `xps.rs` reuses it, which is the ledger entry the plan asked for
            // in as many words.
            document: 200 * 40_000 * 20 + 20_000_000,
            // Twenty megabytes. `epub::Limits` reuses this constant rather than
            // declaring its own, so a book is charged here exactly as a comic
            // is; the largest real book writes **19 781 810** bytes, which is
            // `sample-linear-algebra.epub` at the default box.
            book: 20_000_000,
            reachable: MAX_CBZ_PAGES as u128
                * (PAGE_OVERHEAD as u128 + zip_limits::MAX_ZIP_ENTRY_BYTES as u128),
            reachable_because: "every page the page cap allows, each carrying a whole entry",
            declared_in: CBZ,
            fires_in: (
                "a_synthesis_past_the_byte_cap_is_refused_by_name",
                CBZ_TESTS,
            ),
        },
        // ---- tier 4, W-ARCHIVE milestone 1 -----------------------------
        Bound {
            name: "MAX_COMIC_INFO_BYTES",
            cap: MAX_COMIC_INFO_BYTES as u128,
            published: "64 KiB",
            fixtures: 88,
            // A 200-page comic's own metadata file: a few hundred bytes of
            // credits, and a `<Pages>` list of one `<Page/>` element of about
            // sixty bytes per page.
            comic: 16_384,
            // An XPS package holds no `ComicInfo.xml`, and this is the one
            // format-specific direction that stayed a zero when the four
            // `MAX_XML_*` rows above stopped being zeros: those are the *XML
            // reader's* caps and every format here now spends against them,
            // where this is the comic path's own cap on one named entry.
            document: 0,
            // And a book does not reach the comic path at all, which is
            // `MAX_CBZ_PAGES`'s measured zero for the same reason.
            book: 0,
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            reachable_because: "the entry is a ZIP entry, capped at MAX_ZIP_ENTRY_BYTES",
            declared_in: CBZ_COMIC_INFO,
            fires_in: (
                "the_comic_info_cap_admits_exactly_its_own_size",
                CBZ_UNIT_TESTS,
            ),
        },
        // ---- gap 30, milestone 2 ---------------------------------------
        //
        // The ceiling in front of all four is the same and it is worth stating
        // once: an XML part reaches this engine as a ZIP entry, so
        // `MAX_ZIP_ENTRY_BYTES` — 128 MiB — is the most text any of them can be
        // handed. Every `reachable` below is that number divided by what one
        // unit of the thing being counted costs in bytes.
        Bound {
            name: "MAX_XML_DEPTH",
            cap: xml_limits::MAX_XML_DEPTH as u128,
            published: "256",
            // The fixture that proves it fires nests 257 and is 771 bytes, so
            // the most any fixture *spends* is the cap. Real markup reaches 6,
            // measured by `xml_real_packages.rs`.
            fixtures: xml_limits::MAX_XML_DEPTH as u128,
            // **A comic archive holds one XML entry since tier 4**, and this
            // is what it nests: `ComicInfo` > `Pages` > `Page`, which is three,
            // with room for the wrapper elements a tool might add around a
            // summary. The schema defines no deeper structure than that.
            comic: 8,
            // ECMA-388 18.2 recommends 16 canvases; a path geometry adds four
            // and a resource dictionary two.
            document: 24,
            // Element nesting in one content document. The deepest in either
            // corpus is **24**, `sample-linear-algebra.epub`'s MathML, and no
            // prose book passes ten.
            book: 32,
            reachable: (zip_limits::MAX_ZIP_ENTRY_BYTES as u128) / 3,
            reachable_because: "`<a>` is three bytes, in a part of at most MAX_ZIP_ENTRY_BYTES",
            declared_in: XML_LIMITS,
            fires_in: ("nesting_past_the_depth_cap_is_refused_by_name", XML_TESTS),
        },
        Bound {
            name: "MAX_XML_ATTRIBUTES",
            cap: xml_limits::MAX_XML_ATTRIBUTES as u128,
            published: "256",
            fixtures: xml_limits::MAX_XML_ATTRIBUTES as u128,
            // `ComicInfo.xsd`'s `<Page>` carries eight — `Image`, `ImageSize`,
            // `ImageWidth`, `ImageHeight`, `Type`, `DoublePage`, `Key` and
            // `Bookmark` — and the root carries the two `xmlns:xsi`/`xsd`
            // declarations every real file writes. Doubled, because a
            // yardstick is a plausible file rather than the schema.
            comic: 16,
            // A `Glyphs` with every optional attribute ECMA-388 12.1 gives it.
            document: 24,
            // Attributes on one element. The most any real book puts on one is
            // **seven**, which is a `<div>` with `epub:type`, `class`, `id`,
            // `title`, `lang`, `xml:lang` and `role`.
            book: 16,
            reachable: (zip_limits::MAX_ZIP_ENTRY_BYTES as u128) / 5,
            reachable_because: "` a=\"\"` is five bytes, and they may all sit on one element",
            declared_in: XML_LIMITS,
            fires_in: ("more_attributes_than_the_cap_is_refused_by_name", XML_TESTS),
        },
        Bound {
            name: "MAX_XML_NAME_LEN",
            cap: xml_limits::MAX_XML_NAME_LEN as u128,
            published: "1 024",
            fixtures: xml_limits::MAX_XML_NAME_LEN as u128,
            // The longest name in `ComicInfo.xsd` is `MainCharacterOrTeam` at
            // 19; the longest *qualified* name a real file writes is
            // `xsi:noNamespaceSchemaLocation` at 29. Rounded up, and neither is
            // one this build maps.
            comic: 32,
            // `LinearGradientBrush.GradientStops` is 33, plus room for a prefix.
            document: 48,
            // The longest element or attribute name. The longest in either
            // corpus is **19** — `preserveAspectRatio`, on an SVG cover — and
            // the vendor-prefixed CSS property names that are longer are not
            // XML names.
            book: 32,
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            reachable_because: "a name may be as long as the part that holds it",
            declared_in: XML_LIMITS,
            fires_in: (
                "a_name_past_the_cap_is_refused_rather_than_truncated",
                XML_TESTS,
            ),
        },
        Bound {
            name: "MAX_XML_TOKENS",
            cap: xml_limits::MAX_XML_TOKENS as u128,
            published: "1 048 576",
            fixtures: xml_limits::MAX_XML_TOKENS as u128,
            // A 200-page comic's own `ComicInfo.xml`: about fifty metadata
            // elements and a `<Pages>` list of 200 `<Page/>`s, at two events an
            // element and one text event apiece. `MAX_COMIC_INFO_BYTES` stands
            // in front of this on the comic path anyway — 64 KiB of `<a/>` is
            // 32 768 events — so the yardstick is far under a ceiling that is
            // itself far under the cap.
            comic: 1_024,
            // 2 000 drawable elements at three elements of markup each, plus
            // 40 000 path segments as `PolyLineSegment` children, at two events
            // an element.
            document: 2_000 * 3 * 2 + 40_000 * 2,
            // Tokens in **one** content document, which is where this cap is
            // spent. `sample-linear-algebra.epub` spends a million across all
            // ninety-four of its documents and its largest one is a fifth of
            // that.
            book: 262_144,
            // The work cap's argument, in this format's terms: `<a/>` is four
            // bytes and produces two events, so a per-element cap times a
            // file-chosen element count is not a bound and this is the product
            // it would otherwise be.
            reachable: (zip_limits::MAX_ZIP_ENTRY_BYTES as u128) / 2,
            reachable_because: "`<a/>` is four bytes and two events, across a whole part",
            declared_in: XML_LIMITS,
            fires_in: (
                "more_events_than_the_token_cap_is_refused_by_name",
                XML_TESTS,
            ),
        },
        // ---- gap 30, milestone 3 ---------------------------------------
        Bound {
            name: "MAX_XPS_PARTS",
            cap: MAX_XPS_PARTS as u128,
            published: "8 192",
            // The package built *past* this cap holds 8 193 parts; 8 192 is the
            // most any fixture here spends and is allowed. The largest real
            // package in the corpus holds 7.
            fixtures: MAX_XPS_PARTS as u128,
            // A comic archive is not a package at all.
            comic: 0,
            // One sequence, one document, two hundred pages, two hundred page
            // relationships parts, the package relationships part and about a
            // hundred fonts and images.
            document: 505,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            reachable: zip_limits::MAX_ZIP_ENTRIES as u128,
            reachable_because: "every entry the archive reader will hand over could be a part",
            declared_in: XPS,
            fires_in: ("a_package_past_the_part_cap_is_refused_by_name", XPS_TESTS),
        },
        Bound {
            name: "MAX_XPS_PAGES",
            cap: MAX_XPS_PAGES as u128,
            published: "4 096",
            fixtures: MAX_XPS_PAGES as u128,
            comic: 0,
            document: 200,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            // **Not** the part cap, and this is the row that says why: two
            // hundred `PageContent` elements may name one part between them, so
            // the page count is not bounded by the part count at all. What
            // stands in front of it is the markup reader's own total.
            reachable: xml_limits::MAX_XML_TOKENS as u128,
            reachable_because: "every event one fixed document part may produce could be a page",
            declared_in: XPS,
            fires_in: (
                "a_page_count_past_the_xps_cap_is_refused_by_name",
                XPS_TESTS,
            ),
        },
        Bound {
            name: "MAX_XPS_ELEMENTS",
            cap: MAX_XPS_ELEMENTS as u128,
            published: "1 048 576",
            // One short of the cap, which is what
            // `a_page_past_the_element_cap_is_refused_by_name`'s *opening*
            // package spends; the one built past it spends three more.
            fixtures: MAX_XPS_ELEMENTS as u128 - 1,
            comic: 0,
            document: 400_000,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            // No **single** part can reach this, which is the whole reason it
            // is a total: `MAX_XML_TOKENS` bounds one part at a million events,
            // of which at most half can be start tags. The ceiling is that,
            // once per part the package may hold.
            reachable: MAX_XPS_PARTS as u128 * (xml_limits::MAX_XML_TOKENS as u128 / 2),
            reachable_because: "half a million elements in each of the parts a package may hold",
            declared_in: XPS,
            fires_in: (
                "a_page_past_the_element_cap_is_refused_by_name",
                XPS_MARKUP_TESTS,
            ),
        },
        Bound {
            name: "MAX_XPS_SEGMENTS",
            cap: MAX_XPS_SEGMENTS as u128,
            published: "8 388 608",
            fixtures: MAX_XPS_SEGMENTS as u128,
            comic: 0,
            document: 8_000_000,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            // `H1` is two bytes and one segment, in a part this build already
            // admits at 128 MiB — and that is one path, before the file has
            // chosen how many paths or how many pages.
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128 / 2,
            reachable_because: "a two-byte `H` command per segment in one 128 MiB part",
            declared_in: XPS,
            fires_in: (
                "a_geometry_past_the_segment_cap_is_refused_by_name",
                XPS_MARKUP_TESTS,
            ),
        },
        Bound {
            name: "MAX_XPS_GLYPHS",
            cap: MAX_XPS_GLYPHS as u128,
            published: "2 097 152",
            fixtures: MAX_XPS_GLYPHS as u128,
            comic: 0,
            document: 1_000_000,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            // `1;` is two bytes and one more mapping, in one attribute of one
            // element, in a part this build already admits at 128 MiB — and a
            // `Glyphs` costs one element and no segments, so neither cap
            // milestone 6 added stands in front of this one.
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128 / 2,
            reachable_because: "a two-byte `1;` per glyph in one `Indices` attribute",
            declared_in: XPS,
            fires_in: (
                "a_run_past_the_glyph_cap_is_refused_by_name",
                XPS_GLYPH_TESTS,
            ),
        },
        Bound {
            name: "MAX_XPS_RESOURCE_DEPTH",
            cap: MAX_XPS_RESOURCE_DEPTH as u128,
            published: "16",
            fixtures: MAX_XPS_RESOURCE_DEPTH as u128,
            comic: 0,
            document: 2,
            // Zero, and it is a fact about the format rather than a gap in the
            // measurement: an EPUB container holds neither of OPC's two items,
            // which `no_fetched_book_carries_either_of_opcs_two_items` asserts
            // over all twenty fetched books.
            book: 0,
            // One dictionary may hold as many entries as its part has events,
            // and a chain through all of them is not a cycle.
            reachable: xml_limits::MAX_XML_TOKENS as u128,
            reachable_because: "every entry one resource dictionary part could declare, chained",
            declared_in: XPS,
            fires_in: (
                "a_static_resource_chain_past_the_depth_cap_is_named",
                XPS_MARKUP_TESTS,
            ),
        },
        // ---- gap 31, milestone 3 ---------------------------------------
        Bound {
            name: "MAX_OCF_PATH_LEN",
            cap: MAX_OCF_PATH_LEN as u128,
            published: "65 535",
            // The container built *past* this cap names a path of 65 536; the
            // longest path in any of the twenty-six real books milestone 1
            // measured is 39 bytes.
            fixtures: MAX_OCF_PATH_LEN as u128,
            // A comic archive has no container paths at all, and a fixed
            // document has OPC part names rather than OCF content paths — two
            // grammars that disagree about case folding and about `..`, which
            // is why `PartName` is not reused. Both are a zero that is an
            // answer rather than a blank, in the shape every gap 30 row above
            // writes `comic: 0`.
            comic: 0,
            document: 0,
            // The same 45 bytes `MAX_ZIP_NAME_LEN` measures, doubled, because
            // in this format a container path **is** an entry name — which is
            // why the two rows agree and why neither could stand in for the
            // other: one is 16 bits of ZIP field and one is §4.2.3's own
            // number.
            book: BOOK_PATH_LEN,
            // An XML attribute value may be as long as the part that holds it,
            // and a `META-INF/container.xml` reaches this engine as a ZIP entry
            // — so the ceiling is the per-entry cap, and the specification's own
            // number sits two thousand times below it.
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            reachable_because: "a `full-path` attribute may be as long as the entry that holds it",
            declared_in: EPUB,
            fires_in: (
                "a_content_path_past_the_length_cap_is_refused_by_name",
                EPUB_TESTS,
            ),
        },
        Bound {
            name: "MAX_EPUB_MANIFEST_ITEMS",
            cap: MAX_EPUB_MANIFEST_ITEMS as u128,
            published: "8 192",
            // The manifest built *past* this cap; the largest real book in
            // either corpus names ninety-six items.
            fixtures: MAX_EPUB_MANIFEST_ITEMS as u128,
            // A comic archive has no package document and a fixed document has
            // an OPC one, whose `[Content_Types].xml` is a media-type map
            // rather than a manifest of resources. Both are a zero that is an
            // answer rather than a blank.
            comic: 0,
            document: 0,
            // The manifest of a 128-document book. The largest real one is
            // **96**, and the pair below it is why the two are not one row:
            // §5.7.2 lets four thousand itemrefs name one item.
            book: BOOK_SPINE_ITEMS,
            // `MAX_XML_TOKENS` stands in front of it: an `<item/>` produces two
            // events, so one package document may name half a million of them.
            reachable: (xml_limits::MAX_XML_TOKENS / 2) as u128,
            reachable_because: "an `<item/>` is two XML events and the token cap is a million",
            declared_in: EPUB,
            fires_in: (
                "the_manifest_and_spine_caps_refuse_rather_than_truncate",
                EPUB_UNIT_TESTS,
            ),
        },
        Bound {
            name: "MAX_EPUB_SPINE_ITEMS",
            cap: MAX_EPUB_SPINE_ITEMS as u128,
            published: "4 096",
            fixtures: MAX_EPUB_SPINE_ITEMS as u128,
            comic: 0,
            document: 0,
            // 128 itemrefs. The longest real spine is **94**,
            // `sample-linear-algebra.epub`'s, and the committed corpus's
            // longest is five.
            book: BOOK_SPINE_ITEMS,
            // **Not** bounded by the manifest cap, which is why the two are
            // separate rows rather than one. `epubcheck` reports two itemrefs
            // naming one manifest item as `OPF-034` — an error, not a
            // well-formedness failure — so a package document may name one item
            // four thousand times, exactly as gap 30 found four thousand
            // `PageContent` elements naming one part.
            reachable: (xml_limits::MAX_XML_TOKENS / 2) as u128,
            reachable_because: "an `<itemref/>` is two XML events, and one manifest item may be \
                                named by every one of them",
            declared_in: EPUB,
            fires_in: (
                "the_manifest_and_spine_caps_refuse_rather_than_truncate",
                EPUB_UNIT_TESTS,
            ),
        },
        Bound {
            name: "MAX_EPUB_FALLBACK_DEPTH",
            cap: MAX_EPUB_FALLBACK_DEPTH as u128,
            published: "16",
            // The chain built past it is seventeen links. **No real book in
            // either corpus carries a `fallback` attribute at all**, so this
            // clause is proved entirely by fixtures — which is worth writing
            // down, because a rule with no real example is a rule whose
            // behaviour is a guess until somebody builds the input.
            fixtures: MAX_EPUB_FALLBACK_DEPTH as u128,
            comic: 0,
            document: 0,
            // **Zero, and measured.** Not one of the twenty-six books in either
            // corpus writes a `fallback` attribute at all: §3.5.1's chain is a
            // hostile-input surface rather than a thing producers use, which is
            // exactly what makes a cap on it worth having and a yardstick
            // figure for it a zero.
            book: 0,
            // The longest acyclic chain is one link per manifest item, so the
            // cap in front of it is the manifest's.
            reachable: MAX_EPUB_MANIFEST_ITEMS as u128,
            reachable_because: "a fallback chain may name every manifest item once",
            declared_in: EPUB,
            fires_in: (
                "a_fallback_chain_reaches_a_content_document_or_says_why_it_did_not",
                EPUB_UNIT_TESTS,
            ),
        },
        // ---- gap 31 milestone 6: `tinker-pdf-css` ----------------------
        //
        // Every one of the eight spends zero against both earlier yardsticks,
        // because neither a comic nor a fixed XPS document holds a stylesheet.
        // The book yardstick these were written against — a 400-page novel of
        // 120 000 words in 40 spine items, with four stylesheets totalling
        // 40 KB — is milestone 13's third column and is recorded in each
        // constant's own ledger in the meantime.
        Bound {
            name: "MAX_CSS_BYTES",
            cap: css_limits::MAX_CSS_BYTES as u128,
            published: "8 388 608",
            fixtures: css_limits::MAX_CSS_BYTES as u128,
            comic: 0,
            document: 0,
            // Sixty-four kibibytes of stylesheet across the book. The most any
            // real book carries is **39 413**, `sample-internallinks.epub`'s
            // three sheets.
            book: 64 << 10,
            // Every stylesheet in an EPUB is a ZIP entry, so gap 29's per-entry
            // cap is what stands in front of this one — sixteen times it.
            reachable: zip_limits::MAX_ZIP_ENTRY_BYTES as u128,
            reachable_because: "a stylesheet is a ZIP entry, and one may be 128 MiB",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_stylesheet_past_the_byte_cap_is_refused_by_name",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_CSS_TOKENS",
            cap: css_limits::MAX_CSS_TOKENS as u128,
            published: "4 000 000",
            fixtures: css_limits::MAX_CSS_TOKENS as u128,
            comic: 0,
            document: 0,
            // The densest real book charges **191 656**, which is
            // `sample-linear-algebra.epub`. This is the row where the two
            // corpora disagree most: the committed six charge at most 8 300.
            book: 200_000,
            // A token is at least one byte, so one sheet at the byte cap can
            // cross this total on its own — which is what makes a *work* cap
            // reachable from a single entry rather than only from a manifest
            // that names four thousand sheets.
            reachable: css_limits::MAX_CSS_BYTES as u128,
            reachable_because: "one byte is one token, and a sheet may be MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: ("the_token_total_refuses_by_name", CSS_BOUNDS_TESTS),
        },
        Bound {
            name: "MAX_CSS_RULES",
            cap: css_limits::MAX_CSS_RULES as u128,
            published: "20 000",
            fixtures: css_limits::MAX_CSS_RULES as u128,
            comic: 0,
            document: 0,
            // **9 167** in `sample-linear-algebra.epub`, against a cap of
            // 20 000 — the tightest margin in this table for any row a real
            // book reaches, and the reason this figure is measured rather than
            // guessed.
            book: 10_000,
            // `a{}` is three bytes.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 3,
            reachable_because: "a qualified rule is three bytes, in a sheet of MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: ("the_rule_total_refuses_by_name", CSS_BOUNDS_TESTS),
        },
        Bound {
            name: "MAX_CSS_DECLARATIONS",
            cap: css_limits::MAX_CSS_DECLARATIONS as u128,
            published: "100 000",
            fixtures: css_limits::MAX_CSS_DECLARATIONS as u128,
            comic: 0,
            document: 0,
            // **20 861**, the same book.
            book: 21_000,
            // `a:b;` is four.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 4,
            reachable_because: "a declaration is four bytes, in a sheet of MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: ("the_declaration_total_refuses_by_name", CSS_BOUNDS_TESTS),
        },
        Bound {
            name: "MAX_CSS_SELECTOR_PARTS",
            cap: css_limits::MAX_CSS_SELECTOR_PARTS as u128,
            published: "64",
            fixtures: css_limits::MAX_CSS_SELECTOR_PARTS as u128,
            comic: 0,
            document: 0,
            // Compounds in one complex selector. Real book stylesheets stay
            // under five — `body > section p.first` is four — and the
            // hand-written sheet that fires this cap is the fixture's.
            book: 8,
            // A compound plus its combinator is two bytes: `a `.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 2,
            reachable_because: "`a ` is one compound and one combinator in two bytes",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_selector_past_the_compound_cap_is_dropped_with_its_own_warning",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_CSS_IMPORT_DEPTH",
            cap: css_limits::MAX_CSS_IMPORT_DEPTH as u128,
            published: "8",
            fixtures: css_limits::MAX_CSS_IMPORT_DEPTH as u128,
            comic: 0,
            document: 0,
            // One. Not one book in either corpus writes an `@import` at all;
            // both producers link their sheets from the content document. The
            // yardstick allows one because a book that did would be ordinary,
            // and the chain that fires the cap is the fixture's.
            book: 1,
            // The ceiling is the container's entry count: every level of an
            // `@import` chain is a sheet the caller's resolver found, and gap
            // 29's cap is what bounds how many of those there can be. A
            // *cycle* has no ceiling at all, which is why the guard beside this
            // cap is a different fact and warns by a different name.
            reachable: zip_limits::MAX_ZIP_ENTRIES as u128,
            reachable_because: "an @import chain is as deep as the container has entries",
            declared_in: CSS_LIMITS,
            fires_in: (
                "an_import_chain_past_the_depth_cap_warns_by_its_own_name",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_DOM_NODES",
            cap: css_limits::MAX_DOM_NODES as u128,
            published: "65 536",
            fixtures: css_limits::MAX_DOM_NODES as u128,
            comic: 0,
            document: 0,
            // Elements in **one** content document, which is where this cap is
            // spent — the cascade runs per document. The largest real one is
            // **20 160**, `sample-linear-algebra.epub`'s longest chapter; the
            // book's total across ninety-four documents is 272 628 and is not
            // what this bounds.
            book: 24_576,
            // The half of gap 31's `const` relation that cannot live in the
            // crate: `tinker-pdf-css` has an empty allow-list by the fifth DAG
            // amendment, so it cannot name `MAX_XML_TOKENS`. Here it can.
            reachable: xml_limits::MAX_XML_TOKENS as u128,
            reachable_because: "MAX_XML_TOKENS stands in front of every content document",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_tree_past_the_element_cap_is_refused_by_name",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_SELECTOR_MATCHES",
            cap: css_limits::MAX_SELECTOR_MATCHES as u128,
            published: "4 000 000",
            fixtures: css_limits::MAX_SELECTOR_MATCHES as u128,
            comic: 0,
            document: 0,
            // **521 101** compound-against-element tests, and the book that
            // spends them is not the one with the most elements: it is
            // `sample-epub30-spec.epub`, whose stylesheet defeats the
            // rightmost-compound index more often. The product of the two caps
            // is 1.3e9, so a real book spends four ten-thousandths of what this
            // row's own ceiling allows.
            book: 525_000,
            // **The product**, and the only row here whose ceiling is one. The
            // matcher buckets rules by their rightmost compound, so an ordinary
            // book tests each element against a handful — but a stylesheet
            // whose every rule names one class defeats the index completely and
            // gets the whole multiplication, which is the fixture that fires it.
            // The same relation is asserted at compile time in the crate, in
            // the opposite direction from an ordinary ordering: the product
            // must *exceed* the cap or the cap could never fire.
            reachable: css_limits::MAX_CSS_RULES as u128 * css_limits::MAX_DOM_NODES as u128,
            reachable_because: "MAX_CSS_RULES x MAX_DOM_NODES, and neither factor bounds the other",
            declared_in: CSS_LIMITS,
            fires_in: (
                "the_match_budget_refuses_a_stylesheet_that_defeats_the_index",
                CSS_BOUNDS_TESTS,
            ),
        },
        // ---- gap 31, milestone 7 ---------------------------------------
        //
        // The tenth leaf's four. The first is the only row in this table whose
        // ceiling is not a field width, a file size or a product but an
        // **unbounded** input: a box tree is handed to this crate by a caller,
        // and there is no parser in front of it to refuse one first.
        Bound {
            name: "MAX_BOX_DEPTH",
            cap: layout_limits::MAX_BOX_DEPTH as u128,
            published: "256",
            fixtures: layout_limits::MAX_BOX_DEPTH as u128,
            comic: 0,
            document: 0,
            // Box tree depth, which is element depth plus whatever anonymous
            // boxes and table fixup add. The deepest real document nests **24**
            // elements.
            book: 48,
            // Nothing. `tinker-pdf-layout` takes a tree of plain structs from a
            // caller, so the ceiling is whatever that caller builds — which for
            // the twenty-fourth fuzz target is a structured generator with no
            // file in front of it at all. A stack overflow is a crash rather
            // than a refusal, so the number here is the recursion's, not a
            // budget's.
            reachable: u128::MAX,
            reachable_because: "a caller-built tree has no parser in front of it",
            declared_in: LAYOUT_LIMITS,
            // **Two** tests fire this one and the ledger can name only one, so
            // the pair is recorded here: a chain of blocks with no text reaches
            // the block walk's check, and a chain of inlines reaches the
            // gather's. They were one test until the injection matrix found
            // that deleting the block walk's check changed no answer — the
            // fixture ended in text, so the gather caught it and the block
            // walk's check had never been the reason. A rule enforced twice
            // hides the reachable half.
            fires_in: (
                "a_tree_of_blocks_past_the_depth_cap_is_refused_by_name",
                LAYOUT_TESTS,
            ),
        },
        Bound {
            name: "MAX_BOX_TREE_NODES",
            cap: layout_limits::MAX_BOX_TREE_NODES as u128,
            published: "2 097 152",
            fixtures: layout_limits::MAX_BOX_TREE_NODES as u128,
            comic: 0,
            document: 0,
            // **993 349 boxes**, `sample-linear-algebra.epub`, and this row is
            // the reason milestone 13's yardstick exists. The cap was 262 144
            // until this milestone and that book crossed it partway through:
            // the budget is spent across a whole book and never refunded, so
            // the chapter that crossed it refused by name and **so did every
            // chapter after it** — a 94-chapter W3C sample book that opened,
            // paginated to its spine, and came back with two thirds of its text
            // replaced by grey pages and a warning each. Three boxes per element
            // is right for prose and wrong for MathML, where `<mi>` and `<mo>`
            // put an inline box on every symbol.
            book: 1_000_000,
            // Boxes are not elements, which is the whole reason this is not
            // `MAX_DOM_NODES` under another name: anonymous block generation,
            // `::before`/`::after` and table-structure fixup each make boxes
            // the document did not write. The ceiling is every element of every
            // spine item, at one box apiece before any of that.
            reachable: css_limits::MAX_DOM_NODES as u128
                * tinker_pdf::epub::MAX_EPUB_SPINE_ITEMS as u128,
            reachable_because: "MAX_DOM_NODES elements in each of MAX_EPUB_SPINE_ITEMS documents",
            declared_in: LAYOUT_LIMITS,
            fires_in: ("a_tree_past_the_box_cap_is_refused_by_name", LAYOUT_TESTS),
        },
        Bound {
            name: "MAX_LINE_BREAK_WORK",
            cap: layout_limits::MAX_LINE_BREAK_WORK as u128,
            published: "4 000 000",
            fixtures: layout_limits::MAX_LINE_BREAK_WORK as u128,
            comic: 0,
            document: 0,
            // **1 234 335 charged characters**, which is `pg2701-images.epub` —
            // Moby-Dick, the longest book in either corpus, at 701 pages.
            book: 1_250_000,
            // A character is a byte at least, and a book's characters are
            // bounded only by what the archive will inflate.
            reachable: zip_limits::MAX_ZIP_INFLATED as u128,
            reachable_because: "one character per inflated byte of the whole container",
            declared_in: LAYOUT_LIMITS,
            fires_in: (
                "a_paragraph_past_the_line_break_budget_is_refused_by_name",
                LAYOUT_TESTS,
            ),
        },
        Bound {
            name: "MAX_LAYOUT_WORK",
            cap: layout_limits::MAX_LAYOUT_WORK as u128,
            published: "16 000 000",
            fixtures: layout_limits::MAX_LAYOUT_WORK as u128,
            comic: 0,
            document: 0,
            // **4 233 567 float examinations**, `sample-epub30-spec.epub`, and
            // the second row this milestone had to raise a cap for: at
            // 4 000 000 the EPUB 3.0 specification refused to lay out from page
            // 601 of 777, by name, as `NotFragmented`.
            book: 4_500_000,
            // The **square** of the box cap, which is what makes this row
            // exist: a book may float every box it is allowed, and placing the
            // last of them examines all the others. Neither work cap below
            // bounds a product of itself.
            reachable: layout_limits::MAX_BOX_TREE_NODES as u128
                * layout_limits::MAX_BOX_TREE_NODES as u128,
            reachable_because:
                "every one of MAX_BOX_TREE_NODES floats examined against all the others",
            declared_in: LAYOUT_LIMITS,
            fires_in: (
                "a_book_past_the_float_work_total_is_refused_by_name",
                LAYOUT_TESTS,
            ),
        },
        Bound {
            name: "MAX_LAYOUT_PAGES",
            cap: layout_limits::MAX_LAYOUT_PAGES as u128,
            published: "65 536",
            fixtures: layout_limits::MAX_LAYOUT_PAGES as u128,
            comic: 0,
            document: 0,
            // **856 pages**, `sample-linear-algebra.epub` at the default box
            // once the box cap above stopped truncating it. The figure is a
            // function of the caller's page box rather than of any file, which
            // is this format's own determinism question and
            // `a_book_is_stable_at_each_page_box_and_the_two_boxes_differ`'s
            // subject.
            book: 1_000,
            // **Not** bounded by the spine item count, which is the trap gap
            // 31's bounds table names: one spine item of 128 MiB fragments into
            // as many pages as its length allows. A page needs one line box and
            // a line box needs one character, so the ceiling is the break total
            // — which is also the `const` relation the crate asserts at compile
            // time.
            reachable: layout_limits::MAX_LINE_BREAK_WORK as u128,
            reachable_because: "one page per line box, and one line box per charged character",
            declared_in: LAYOUT_LIMITS,
            fires_in: ("a_book_past_the_page_cap_is_refused_by_name", LAYOUT_TESTS),
        },
        Bound {
            name: "MAX_ICC_TAGS",
            cap: MAX_ICC_TAGS as u128,
            published: "1 024",
            // The busiest of the six `.icc` seeds `fuzz/corpus/icc_profile/`
            // commits, which the `icc_profile` target hands straight to
            // `Profile::parse`. No `.pdf` or `.xps` fixture in this repository
            // embeds a profile at all — measured, not assumed.
            fixtures: 7,
            // **Zero, and it is a fact about the format rather than an
            // absence.** Nothing in this engine reads a PNG `iCCP` chunk or a
            // JPEG `APP2` profile — there is no such code in
            // `tinker-pdf-filters` — so a comic page carries its profile past
            // this parser without it ever being opened.
            comic: 0,
            // **Eighteen**, the busiest profile in the corpus, measured by
            // reading the count at offset 128 off every `acsp` stream in all
            // 4 594 files. A fixed document reaches this cap for real: 15.2.5's
            // `ContextColor` names a profile part, `xps::profiles` embeds it
            // verbatim as an `/ICCBased` space, and rendering the synthesised
            // document hands it to `Profile::parse` like any other.
            document: 18,
            // A book's pictures are PNG, JPEG, GIF or SVG and its stylesheets
            // name sRGB by keyword; there is no `/ICCBased` anywhere in the
            // reflowable path. The comic's zero, for the comic's reason.
            book: 0,
            // The count is a 32-bit field at offset 128, and it is read
            // *before* the `12 * count` bytes it describes — so a 132-byte
            // profile asks for a 51 GiB tag table and is refused for it.
            reachable: 1 << 32,
            reachable_because: "a 32-bit tag count, checked before the table it describes",
            declared_in: ICC,
            fires_in: (
                "a_tag_count_past_the_cap_is_refused_before_the_table_is_walked",
                ICC,
            ),
        },
        Bound {
            name: "MAX_ICC_BYTES",
            cap: MAX_ICC_BYTES as u128,
            published: "2 MiB",
            // `srgb-para-curve.icc`, the largest of the six committed seeds.
            fixtures: 392,
            comic: 0,
            // **718 672 bytes**, the largest profile in the corpus — a printer
            // profile carrying a full set of lookup tables — measured over the
            // same sweep as the row above. It is the figure the roadmap row
            // that asked for these two rows names, and the margin over it is
            // 2.9x.
            document: 718_672,
            book: 0,
            // A profile arrives as a decoded stream, so what stands in front of
            // this cap is the ceiling on one of those. Sixty-four times the
            // cap, which is what makes the cap a cap.
            reachable: tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128,
            reachable_because: "`MAX_DECODED_STREAM`: 128 MiB of decoded stream may arrive",
            declared_in: ICC,
            fires_in: (
                "a_profile_past_the_byte_cap_is_refused_before_its_signature_is_read",
                ICC,
            ),
        },
        Bound {
            name: "MAX_JBIG2_SYMBOLS",
            cap: MAX_JBIG2_SYMBOLS as u128,
            // **`estimate` is in the published string on purpose**, and it is
            // the one thing these three rows say that the other thirty-seven
            // do not. See `SCAN_SYMBOLS`.
            published: "100 000 (estimate)",
            // Annex H's own dictionary, which is every committed JBIG2 fixture
            // worth counting: `SDNUMEXSYMS` 3 at most, `SDNUMNEWSYMS` 2.
            // Measured by walking the segment headers of all 22 seeds in
            // `fuzz/corpus/jbig2/`.
            fixtures: 3,
            comic: SCAN_SYMBOLS,
            document: SCAN_SYMBOLS,
            // An EPUB carries no JBIG2: its pictures are PNG, JPEG, GIF or SVG
            // and there is no PDF image filter anywhere in the reflowable path.
            book: 0,
            // `SDNUMNEWSYMS` is a 32-bit field at 7.4.3.1.5, read straight off
            // the segment header, so twelve bytes may ask for four billion.
            reachable: 1 << 32,
            reachable_because: "`SDNUMNEWSYMS`, a 32-bit field read off the segment header",
            declared_in: JBIG2,
            fires_in: (
                "a_dictionary_declaring_more_symbols_than_the_cap_is_refused_by_name",
                JBIG2,
            ),
        },
        Bound {
            name: "MAX_JBIG2_SYMBOL_PIXELS",
            cap: MAX_JBIG2_SYMBOL_PIXELS as u128,
            published: "67 108 864 (estimate)",
            // Annex H's two six-by-six symbols, decoded and measured rather
            // than read off a header — this cap is the one of the three that
            // accumulates rather than reading a field.
            fixtures: 72,
            comic: SCAN_SYMBOL_PIXELS,
            document: SCAN_SYMBOL_PIXELS,
            book: 0,
            // **One symbol.** Width and height each accumulate from Annex B
            // deltas whose tables carry 32-bit ranges and are refused only
            // above `u32::MAX`, so a single symbol may be charged
            // `u32::MAX` squared before a second is read. The only row in this
            // table whose ceiling is the square of a *field width* rather than
            // of another cap.
            reachable: (u32::MAX as u128) * (u32::MAX as u128),
            reachable_because: "one symbol's width times its height, each clamped at `u32::MAX`",
            declared_in: JBIG2,
            fires_in: (
                "a_dictionary_past_the_symbol_pixel_cap_is_refused_before_it_allocates",
                JBIG2,
            ),
        },
        Bound {
            name: "MAX_JBIG2_SYMBOL_PAGE_MULTIPLE",
            cap: MAX_JBIG2_SYMBOL_PAGE_MULTIPLE as u128,
            // **No `(estimate)`, and it is the only JBIG2 row without one.**
            // The three above publish arithmetic about a plausible scan; this
            // one publishes a corpus measurement. See `SCAN_SYMBOL_PAGE_MULTIPLE`.
            published: "4",
            // Every committed fuzz seed that decodes a symbol at all, measured
            // through `jbig2_decode_measured` at the page its own control byte
            // chooses: Annex H's 6 x 8 symbols against a 64 x 56 page, the
            // sub-rectangle seed's 14 x 6 against 37 x 8. The one seed that
            // exceeds this is `symbol-dictionary-spends-the-pixel-budget`,
            // which is the finding this cap closes rather than a fixture it
            // has to clear: 246 988 x 1 against a page of 1 x 1, refused at
            // its first symbol at 69 x 1.
            fixtures: SCAN_SYMBOL_PAGE_MULTIPLE,
            comic: SCAN_SYMBOL_PAGE_MULTIPLE,
            document: SCAN_SYMBOL_PAGE_MULTIPLE,
            book: 0,
            // **One symbol against a one-pixel page.** A symbol's width
            // accumulates from Annex B deltas and is refused only above
            // `u32::MAX`, and `Jbig2Params::width` may be 1, so the multiple
            // one symbol may span its page is `u32::MAX` — the only row here
            // whose ceiling is a field width divided by a caller's parameter.
            reachable: u32::MAX as u128,
            reachable_because:
                "one symbol's width, clamped at `u32::MAX`, against a page one pixel wide",
            declared_in: JBIG2,
            fires_in: (
                "a_symbol_larger_than_its_page_is_refused_at_the_first_symbol",
                JBIG2,
            ),
        },
        Bound {
            name: "MAX_JBIG2_TEXT_INSTANCES",
            cap: MAX_JBIG2_TEXT_INSTANCES as u128,
            published: "4 194 304 (estimate)",
            // The largest `SBNUMINSTANCES` in the 22 committed seeds, from the
            // same header walk as the symbol row.
            fixtures: 5,
            comic: SCAN_TEXT_INSTANCES,
            document: SCAN_TEXT_INSTANCES,
            book: 0,
            // `SBNUMINSTANCES` is a 32-bit field at 7.4.4.5, checked before a
            // symbol is placed and before the region bitmap is made, so
            // twenty-three bytes may ask for four billion composites.
            reachable: 1 << 32,
            reachable_because:
                "`SBNUMINSTANCES`, a 32-bit field checked before the first placement",
            declared_in: JBIG2,
            fires_in: (
                "a_text_region_declaring_more_instances_than_the_cap_is_refused_by_name",
                JBIG2,
            ),
        },
        Bound {
            name: "MAX_JBIG2_TABLE_LINES",
            cap: tinker_pdf_filters::MAX_JBIG2_TABLE_LINES as u128,
            published: "4 096",
            // Annex B's own widest tables, B.9 and B.10, carry 22 lines each,
            // and no custom table in the corpus exceeds them. A code table's
            // size is a property of the format rather than of the document,
            // which is why all four yardsticks are the same number: the
            // population being cleared is the set of published tables, not the
            // set of files.
            fixtures: TABLE_LINES,
            comic: 0,
            document: TABLE_LINES,
            book: 0,
            // 7.4.13's `HTLOW` and `HTHIGH` are 32-bit, and a range length of
            // zero advances the running low by one, so nine bytes of header
            // name every value a table could.
            reachable: 1 << 32,
            reachable_because:
                "`HTLOW` and `HTHIGH`, two 32-bit fields, walked by a range length of zero",
            declared_in: JBIG2,
            fires_in: (
                "a_custom_table_declaring_more_lines_than_the_cap_is_refused",
                JBIG2,
            ),
        },
        Bound {
            name: "MAX_JBIG2_WORK_MULTIPLE",
            cap: u128::from(MAX_JBIG2_WORK_MULTIPLE),
            // **`(estimate)`, for `SCAN_WORK_MULTIPLE`'s reason**: the
            // yardstick is arithmetic about a scan and the corpus figure is
            // owed.
            published: "16 (estimate)",
            // Every committed seed but the one this cap closes, through
            // `jbig2_decode_measured` under the target's own 64 KiB, both
            // ways round: Annex H's whole file is the most, 5 962 units of
            // 524 288, which rounds up to one. The seed this row was written
            // for, `symbol-dictionary-spun-past-its-marker`, asks for 98.
            fixtures: 1,
            comic: SCAN_WORK_MULTIPLE,
            document: SCAN_WORK_MULTIPLE,
            book: 0,
            // **One dictionary under the fuzz target's ceiling.** A dictionary
            // may spend `MAX_JBIG2_SYMBOL_PIXELS` and a stream may hold as
            // many as its bytes have room for; one is already 128 times the
            // 524 288 pixels 64 KiB holds — the row's parameter, as this
            // file's rule asks, and the ceiling the finding was made under.
            reachable: u128::from(MAX_JBIG2_SYMBOL_PIXELS) / (8 << 16),
            reachable_because:
                "one dictionary spending `MAX_JBIG2_SYMBOL_PIXELS`, under the `jbig2` fuzz target's 64 KiB ceiling",
            declared_in: JBIG2,
            fires_in: (
                "the_decode_stops_at_the_work_budget_however_the_work_is_split",
                JBIG2,
            ),
        },
        // ---- tier 0, the memory row ------------------------------------
        //
        // The two largest runtime bounds, and the first two rows here that a
        // *process* spends rather than a document. See the header amendment
        // for what admitting them cost the `Bound` contract.
        Bound {
            name: "MAX_PAGE_PIXELS",
            cap: tinker_pdf_render::MAX_PAGE_PIXELS as u128,
            published: "67 108 864",
            // The cap itself, and allowed for `MAX_CBZ_PAGES`'s reason: this
            // bound **degrades rather than refuses**, so the fixture that
            // proves it fires asks `page_pixels` for `1e9 x 1e9` — 10^18
            // pixels — and gets a canvas of at most the cap. Nothing here can
            // allocate past it, so the most any fixture spends *is* it.
            fixtures: tinker_pdf_render::MAX_PAGE_PIXELS as u128,
            // Every figure below is at **150 dpi**, and the dpi is not a
            // detail: a page's pixel count is its box in points times the
            // square of the caller's scale, so this is the only row in the
            // table whose columns are a property of the ask as well as of the
            // file. `tinker-pdf-render`'s own ledger argues the number —
            // briefly, 72 dpi is the floor and measures nothing, 300 dpi asks
            // to upsample a comic scan four-fold and crosses this cap at 241,
            // and 150 is `tpdf render`'s own default.
            //
            // A 200-page comic's largest page is a 2000 x 3000 scan, and
            // `cbz::synthesise` makes one image pixel one PDF point, so the
            // box is 2000 x 3000 pt: 4 167 x 6 250 device pixels.
            comic: 4_167 * 6_250,
            // A fixed page is US Letter — ECMA-388's units are 1/96 inch and
            // 816 x 1056 of them is 612 x 792 pt — which is 1 275 x 1 650
            // device pixels. The same sheet `MAX_PNG_SAMPLES` measures its own
            // yardstick against, at the same dpi, reached by two paths.
            document: 1_275 * 1_650,
            // `epub::DEFAULT_PAGE` is 432 x 648 pt, a 6 x 9 inch trade
            // paperback, and it is the box every book in both corpora is
            // actually laid out at: 900 x 1 350 device pixels. Not a zero and
            // not an estimate — a book has a page, and this engine chooses it.
            book: 900 * 1_350,
            // `page_pixels` rounds each side outward and clamps each at
            // `u32::MAX`, and the area is their product before the clamp to
            // the cap. The second row in this table whose ceiling is the
            // square of a field width rather than of another cap.
            reachable: (u32::MAX as u128) * (u32::MAX as u128),
            reachable_because: "a page box times any finite scale, each side clamped at `u32::MAX`",
            declared_in: RENDER,
            // The warning rather than the clamp, and both exist: `RENDER`'s own
            // `an_absurd_page_box_is_clamped_rather_than_allocated` proves the
            // canvas is bounded, and this one proves the *transform* was
            // bounded with it and that the caller is told. A cap that silently
            // cropped three quarters of the sheet would satisfy the first and
            // is the defect this row is a record of.
            fires_in: (
                "an_enormous_page_is_scaled_rather_than_cropped",
                PAGE_GEOMETRY_TESTS,
            ),
        },
        Bound {
            name: "MAX_DECODED_STREAM",
            cap: tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128,
            published: "128 MiB",
            // The cap, for `MAX_PAGE_PIXELS`'s reason one row up: the fixture
            // that proves it fires builds a zlib bomb of `cap + 1024` and the
            // decode stops at `cap`, so `cap` bytes is the most any fixture
            // produces.
            fixtures: tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128,
            // One stream each rather than a document's worth, because one
            // `stream_decoded` call is what this cap bounds. All three formats
            // are synthesised into a PDF and read back through
            // `tinker-pdf-cos`, and the largest single stream each holds is an
            // image.
            //
            // A 2000 x 3000 16-bit RGBA page, which is
            // `MAX_ZIP_ENTRY_BYTES`'s own comic figure arriving here as
            // decoded samples instead of as a ZIP entry.
            comic: 48_000_000,
            // A full-page 300 dpi RGBA scan, 2 550 x 3 300 x 4 — the figure
            // `MAX_PNG_SAMPLES` publishes for the same document, because the
            // samples that cap counts are the bytes this one counts.
            document: 2_550 * 3_300 * 4,
            // And the same plate, for `MAX_PNG_SAMPLES`'s stated reason: an
            // illustrated book and a report carry the same picture.
            book: 2_550 * 3_300 * 4,
            // **The field width this row had none of.** `limits.rs` used to
            // say a 1 KB flate stream expands *without bound*, which is a cap
            // with no ceiling to be compared against. DEFLATE's expansion is
            // bounded at 1 032:1 — RFC 1951's 258-byte longest match, costing
            // two bits under a degenerate dynamic Huffman tree, is 258 * 8 / 2
            // bytes out per byte in — and the input is a subslice of the
            // document buffer, at most `u32::MAX` bytes on the 32-bit targets
            // this engine builds for. The narrowest target is taken on
            // purpose: a cap that fires under the tightest ceiling fires under
            // every looser one.
            reachable: (u32::MAX as u128) * 1_032,
            reachable_because:
                "`u32::MAX` bytes of input on a 32-bit target, at DEFLATE's maximum 1 032:1",
            declared_in: COS_LIMITS,
            // Clock-free and both directions in one test, which is why it is
            // this one rather than a refusal test: a stream at three quarters
            // of the ceiling must come back **whole**, or the ceiling is lower
            // than it claims, and one past it must be capped and say so.
            fires_in: (
                "an_inline_image_decodes_under_the_shared_ceiling",
                INLINE_IMAGE_TESTS,
            ),
        },
        Bound {
            name: "MAX_ANNOTATION_BYTES",
            cap: MAX_ANNOTATION_BYTES as u128,
            published: "64 MiB",
            // The cap, for `MAX_DECODED_STREAM`'s reason one row up: the test
            // that proves it fires names one 4 096-number array from four
            // thousand annotations and spends the budget to the byte it runs
            // out at. Every other fixture that lists a page's annotations —
            // measured over all of them on 26 September 2026 — spends at most
            // 923 bytes.
            fixtures: MAX_ANNOTATION_BYTES as u128,
            // A comic page carries no annotation at all.
            comic: 0,
            // The XPS path writes `/Link`s with a `/Rect`, a `/Dest` and a
            // three-zero `/Border`, and the listing copies none of those at a
            // cost: the budget is spent on strings, names and variable-length
            // arrays, and a `/Border` of three numbers is none of them.
            document: 0,
            // The EPUB path writes the same `/Link`s through the same builder.
            book: 0,
            // One page may be read to 4 096 `/Annots` entries, and every one
            // of them may name the same indirect string or array — parsed
            // once, copied per annotation — as long as the file, which on the
            // narrowest target is at most `u32::MAX` bytes.
            reachable: 4_096 * (1u128 << 32),
            reachable_because: "4 096 annotations naming one shared object as long as a 4 GiB file",
            declared_in: ANNOTATION_PAYLOADS,
            fires_in: (
                "a_listing_past_its_copy_budget_says_what_it_cut",
                ANNOTATION_TESTS,
            ),
        },
        Bound {
            name: "MAX_FORM_DATA_BYTES",
            cap: MAX_FORM_DATA_BYTES as u128,
            published: "64 MiB",
            // The cap, for `MAX_ANNOTATION_BYTES`'s reason one row up: the
            // test that proves it fires builds files that ask for more and
            // spends the budget to the byte it runs out at. Beside it, an
            // honest form of ten thousand fields spends 4 140 000 bytes, and
            // every other file `tests/form_data.rs` reads — measured over all
            // of them on 2 October 2026 — at most 20 125, a name ten thousand
            // partial names deep.
            fixtures: MAX_FORM_DATA_BYTES as u128,
            // None of the three container paths reads FDF or XFDF.
            comic: 0,
            document: 0,
            book: 0,
            // An FDF's field tree nests 256 deep, and every level may name
            // one indirect `/T` as long as the file: the deepest name alone
            // is 256 copies of it, on the narrowest target at most
            // `u32::MAX` bytes each.
            reachable: 256 * (1u128 << 32),
            reachable_because: "256 nested fields naming one shared /T as long as a 4 GiB file",
            declared_in: FORM_DATA,
            fires_in: (
                "a_file_that_asks_for_more_than_the_budget_is_refused",
                FORM_DATA_TESTS,
            ),
        },
        Bound {
            name: "MAX_FORM_COPY_BYTES",
            cap: MAX_FORM_COPY_BYTES as u128,
            published: "32 MiB",
            // The cap, for `MAX_ANNOTATION_BYTES`'s reason: the test that
            // fires it holds forty cuts of a mebibyte each and lets them go
            // at the one that would pass it. Every other redaction fixture,
            // measured over all of them on 2 October 2026, holds at most
            // 92 920 bytes of cuts — the firing test's own exact half.
            fixtures: MAX_FORM_COPY_BYTES as u128,
            // None of the three container paths redacts.
            comic: 0,
            document: 0,
            book: 0,
            // One form may be placed `MAX_PLACEMENTS` times, each cut
            // differently, and each cut is as long as the form's content,
            // which one decode may make `MAX_DECODED_STREAM` long.
            reachable: 64 * (128u128 << 20),
            reachable_because: "64 placements of one form cut differently, each cut 128 MiB",
            declared_in: REDACT,
            fires_in: ("a_walk_past_its_copy_budget_cuts_the_form_in_place", REDACT),
        },
        Bound {
            name: "MAX_BMP_SAMPLES",
            cap: MAX_BMP_SAMPLES as u128,
            published: "67 108 864",
            // bmpsuite's alpha files: 127 x 64 at four components. The unit
            // test that proves the cap fires builds a header *at* it, but is
            // answered by the caller's ceiling and allocates nothing.
            fixtures: 127 * 64 * 4,
            // A 2000 x 3000 page with an alpha mask, `MAX_PNG_SAMPLES`'s own
            // comic figure: a BMP has no pass-through, so every BMP page
            // spends this.
            comic: 24_000_000,
            // Zero, measured rather than absent: ECMA-388 admits JPEG, PNG,
            // TIFF and JPEG XR image parts and nothing else, so a fixed
            // document holds no BMP for this cap to count.
            document: 0,
            // Zero again: BMP is not one of EPUB 3.3 §3.2's core image media
            // types, and `epub::read`'s `<img>` path places only those, so a
            // book's BMP is refused by name before it is decoded.
            book: 0,
            // `biWidth` and `biHeight` are signed 32-bit fields, so the widest
            // positive product is (2^31 - 1)^2, charged at four components.
            reachable: 0x7FFF_FFFFu128 * 0x8000_0000 * 4,
            reachable_because: "two signed 32-bit dimensions, times four components",
            declared_in: BMP,
            fires_in: (
                "an_image_past_the_sample_cap_is_refused_before_it_allocates",
                BMP_TESTS,
            ),
        },
        Bound {
            name: "MAX_GIF_SAMPLES",
            cap: MAX_GIF_SAMPLES as u128,
            published: "67 108 864",
            // Pillow's interlaced 40 x 24, indexed at one sample a pixel; the
            // expanded omggif fixture is 13 x 7 x 4, smaller.
            fixtures: 40 * 24,
            // A 2000 x 3000 page expanded to RGBA — the widest a GIF page can
            // be charged, since a local table on part of the screen expands it.
            comic: 24_000_000,
            // Zero: ECMA-388 admits no GIF image part.
            document: 0,
            // Not a zero, unlike BMP's: GIF is an EPUB 3.3 §3.2 core media
            // type and an `<img>` draws one. A full-page 300 dpi plate charged
            // at four components, `MAX_PNG_SAMPLES`'s book figure.
            book: 2_550 * 3_300 * 4,
            // The cap is charged twice, on two buffers, and both clear it. The
            // canvas reaches furthest: a logical screen left at zero is the
            // first image's extent, `left + width` by `top + height`, so each
            // side is a sum of two 16-bit fields, and a local table on part of
            // it expands it to four components. The image's own indices are
            // the other charge — one byte each, `width x height` from its
            // descriptor, at most 65 535 squared whatever the screen is.
            reachable: (2u128 * 0xFFFF) * (2 * 0xFFFF) * 4,
            reachable_because: "a zero logical screen is the image's extent, \
                                two sums of 16-bit fields, times four components",
            declared_in: GIF,
            fires_in: (
                "an_image_past_the_sample_cap_is_refused_before_it_allocates",
                GIF_TESTS,
            ),
        },
        Bound {
            name: "MAX_WEBP_SAMPLES",
            cap: MAX_WEBP_SAMPLES as u128,
            published: "67 108 864",
            // Pillow's mixed 160 x 96, charged at four samples a pixel like
            // every WebP.
            fixtures: 160 * 96 * 4,
            // A 2000 x 3000 page at four samples: a WebP is charged as the
            // RGBA it decodes to, whether or not it is narrowed to RGB after.
            comic: 24_000_000,
            // Zero: ECMA-388 admits no WebP image part.
            document: 0,
            // GIF's figure for GIF's reason: WebP is an EPUB 3.3 §3.2 core
            // media type and an `<img>` draws one. A full-page 300 dpi plate
            // at four components, `MAX_PNG_SAMPLES`'s book figure.
            book: 2_550 * 3_300 * 4,
            // Two 24-bit `VP8X` canvas dimensions, each stored less one,
            // charged at four; a VP8L or VP8 header's 14-bit pair reaches 2^30.
            reachable: (1u128 << 24) * (1 << 24) * 4,
            reachable_because: "two 24-bit VP8X canvas dimensions, times four samples",
            declared_in: WEBP,
            fires_in: (
                "an_image_past_the_sample_cap_is_refused_before_it_allocates",
                WEBP_TESTS,
            ),
        },
        // ---- lane 4C's review: what a page's drawing allocates ----------
        //
        // A process's bound again, like the two above, and the first whose
        // quantity is *output*: markup grows with what the page does, every
        // operator an element, so a short stream asks for as much as it likes.
        Bound {
            name: "MAX_SVG_BYTES",
            cap: tinker_pdf::MAX_SVG_BYTES as u128,
            published: "256 MiB",
            // Measured: `svg_output.rs`'s 4 100 draws of one picture, the
            // largest page any suite writes at this cap. The firing test
            // lowers `SvgOptions::max_bytes`, which is the one parameter this
            // cap has; it can lower the cap and not raise it, and every column
            // here is at the default, which is the cap.
            fixtures: 266_127,
            // A 2000 x 3000 scan as an incompressible RGBA PNG — 3 000 rows of
            // a filter byte and 8 000 samples — in base64, rounded up for the
            // chunks. A picture is the largest thing one element can be.
            comic: 32_100_000,
            // A full-page 300 dpi scan, 2 550 x 3 300, the plate
            // `MAX_DECODED_STREAM` measures with: 44 884 400 bytes of base64,
            // and a megabyte for the page's own two thousand elements.
            document: 46_000_000,
            // The same plate on a page of text written as glyph outlines.
            book: 46_000_000,
            // Fourteen bytes of `0 0 m 1 1 l S` write a stroked `<path>` of at
            // least seventy, and a content stream may be as long as the
            // ceiling every stream decodes under — before any form fans it out.
            reachable: (tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128 / 14) * 70,
            reachable_because: "a `MAX_DECODED_STREAM` content stream of `0 0 m 1 1 l S`, \
                                at least seventy bytes of `<path>` per fourteen-byte operator",
            declared_in: SVG_OUT,
            fires_in: (
                "markup_past_its_budget_is_cut_short_and_says_so",
                SVG_OUTPUT_TESTS,
            ),
        },
        Bound {
            name: "MAX_DISPLAY_LIST_BYTES",
            cap: tinker_pdf_render::MAX_DISPLAY_LIST_BYTES as u128,
            published: "64 MiB",
            // The cap, for `MAX_PAGE_PIXELS`'s reason: this bound **degrades
            // rather than refuses** — a page past it is drawn the direct way —
            // and the firing test records past it, with the recorder's count
            // never passing it.
            fixtures: tinker_pdf_render::MAX_DISPLAY_LIST_BYTES as u128,
            // A synthesised comic page is `q`, the image's `cm` and `Do`, `Q`:
            // three events and one state, rounded up.
            comic: 1_000,
            // Gap 30's own yardstick, two thousand drawable elements each with
            // its state and forty thousand path segments, at this target's
            // sizes rather than a remembered number.
            document: 2_000 * (event_size() + state_size()) + 40_000 * segment_size(),
            // A 6 x 9 page of text: 2 500 glyphs, each an event, a state and
            // the character it shows.
            book: 2_500 * (event_size() + state_size() + 4),
            // `0 0 1 1 re f`, thirteen bytes of content, records one fill of
            // five segments, and a content stream may be as long as the
            // ceiling every stream decodes under — before any form fans it out.
            reachable: (tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128 / 13)
                * (event_size() + state_size() + 5 * segment_size()),
            reachable_because: "a `MAX_DECODED_STREAM` content stream of `0 0 1 1 re f`, one \
                                recorded five-segment fill per thirteen bytes",
            declared_in: RENDER_DISPLAY,
            fires_in: (
                "a_page_too_large_to_retain_is_drawn_the_direct_way",
                DISPLAY_LIST_TESTS,
            ),
        },
        Bound {
            name: "MAX_MARKDOWN_NESTING",
            cap: MAX_MARKDOWN_NESTING as u128,
            published: "100",
            // The test that fires it nests five past the cap, so it spends the
            // cap; every other fixture nests at most four (`markdown.rs`'s
            // release notes and the fuzz seeds).
            fixtures: MAX_MARKDOWN_NESTING as u128,
            // None of the three container paths reads Markdown.
            comic: 0,
            document: 0,
            book: 0,
            // A `>` is a block quote, so a file nests as deep as it is long —
            // on the narrowest target at most `u32::MAX` bytes.
            reachable: 1u128 << 32,
            reachable_because: "one block quote per byte of a 4 GiB file",
            declared_in: MARKDOWN,
            fires_in: (
                "a_container_past_the_nesting_cap_is_read_as_text_and_counted",
                MARKDOWN_TESTS,
            ),
        },
        Bound {
            name: "MAX_MARKDOWN_REFERENCE_BYTES",
            cap: MAX_MARKDOWN_REFERENCE_BYTES as u128,
            published: "100 KiB",
            // The firing test spends the budget to the reference it runs out
            // at, which is the cap less less than one destination.
            fixtures: MAX_MARKDOWN_REFERENCE_BYTES as u128,
            comic: 0,
            document: 0,
            book: 0,
            // Half a file of destination copied by a quarter-file of
            // three-byte `[a]`s: on the narrowest target, a 4 GiB file asks
            // for 2^31 × 2^32 / 6 bytes.
            reachable: (1u128 << 31) * (1u128 << 32) / 6,
            reachable_because: "a destination half a 4 GiB file long, used by a sixth of it",
            declared_in: MARKDOWN,
            fires_in: (
                "reference_links_past_the_copy_budget_read_as_text_and_are_counted",
                MARKDOWN_TESTS,
            ),
        },
        Bound {
            name: "MAX_CSS_SHADOWS",
            cap: css_limits::MAX_CSS_SHADOWS as u128,
            published: "32",
            // The list built exactly at the cap parses; the one past it is
            // refused by value.
            fixtures: css_limits::MAX_CSS_SHADOWS as u128,
            comic: 0,
            document: 0,
            // No committed book declares `box-shadow` or `text-shadow`
            // (`CENSUS.tsv`, and a search of their sheets); a heading's
            // embossed pair is the ordinary use, at two.
            book: 2,
            // `0 0,` is four bytes.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 4,
            reachable_because: "a shadow is four bytes, in a sheet of MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_shadow_list_past_the_cap_is_refused_by_value",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_STRUCTURE_VALUES",
            cap: MAX_STRUCTURE_VALUES as u128,
            published: "1 048 576",
            // The firing test spends the budget to the entry: every element's
            // `/AF` and `/Headers` together are exactly the cap. Every other
            // structure fixture is a table whose cells name a few headers
            // each — an estimate, not a sum anybody took.
            fixtures: MAX_STRUCTURE_VALUES as u128,
            // Neither path writes a structure tree.
            comic: 0,
            document: 0,
            // The EPUB path writes `/A` as one dictionary and no `/AF`, so
            // only `/Headers` spends this: a forty-cell table on each of three
            // hundred pages, every cell naming three header cells.
            book: 300 * 40 * 3,
            // One array of `MAX_ARRAY_LEN` entries, named by each of the walk's
            // 2^18 elements.
            reachable: (1u128 << 18) * (tinker_pdf_cos::limits::MAX_ARRAY_LEN as u128),
            reachable_because: "2^18 elements naming one shared array of 2^20 entries",
            declared_in: STRUCTURE,
            fires_in: (
                "shared_header_and_file_arrays_are_retained_within_one_budget",
                TAGGED_PDF_TESTS,
            ),
        },
        Bound {
            name: "MAX_STRUCTURE_BYTES",
            cap: MAX_STRUCTURE_BYTES as u128,
            published: "64 MiB",
            // The firing test copies to the URI the budget runs out at.
            fixtures: MAX_STRUCTURE_BYTES as u128,
            comic: 0,
            document: 0,
            // Two 200-byte `/Alt`s, a forty-cell table of 30-byte `/ID`s each
            // naming three 30-byte headers, and fifty 5-byte `/Lang`s a page,
            // over three hundred pages, rounded up to 2 MiB.
            book: 2 << 20,
            // Each of the walk's 2^18 elements may name one indirect string as
            // long as the file, on the narrowest target at most `u32::MAX`
            // bytes.
            reachable: (1u128 << 18) * (1u128 << 32),
            reachable_because: "2^18 elements naming one shared string as long as a 4 GiB file",
            declared_in: STRUCTURE,
            fires_in: (
                "a_shared_namespace_is_copied_within_the_walks_copy_budget",
                TAGGED_PDF_TESTS,
            ),
        },
        Bound {
            name: "MAX_ASSOCIATED_FILE_BYTES",
            cap: MAX_ASSOCIATED_FILE_BYTES as u128,
            published: "64 MiB",
            // The firing test copies to the description the budget runs out
            // at; `pdf20.rs`'s other files are a few short names each.
            fixtures: MAX_ASSOCIATED_FILE_BYTES as u128,
            // None of the three paths associates a file with the catalog or a
            // page.
            comic: 0,
            document: 0,
            book: 0,
            // `/AF` is read to `MAX_ARRAY_LEN` entries, each of which may name
            // one specification whose `/Desc` is as long as the file.
            reachable: (tinker_pdf_cos::limits::MAX_ARRAY_LEN as u128) * (1u128 << 32),
            reachable_because: "2^20 /AF entries naming one /Desc as long as a 4 GiB file",
            declared_in: ASSOCIATED_FILES,
            fires_in: (
                "an_associated_file_listing_spends_one_budget_and_says_what_it_cut",
                PDF20_TESTS,
            ),
        },
        Bound {
            name: "MAX_OUTPUT_INTENT_BYTES",
            cap: MAX_OUTPUT_INTENT_BYTES as u128,
            published: "64 MiB",
            // The firing test copies to the `/Info` the budget runs out at.
            fixtures: MAX_OUTPUT_INTENT_BYTES as u128,
            // None of the three paths writes an intent unless asked for an
            // archival profile, and then one.
            comic: 0,
            document: 0,
            book: 0,
            reachable: (tinker_pdf_cos::limits::MAX_ARRAY_LEN as u128) * (1u128 << 32),
            reachable_because:
                "2^20 /OutputIntents entries naming one /Info as long as a 4 GiB file",
            declared_in: OUTPUT_INTENTS,
            fires_in: (
                "an_output_intent_listing_spends_one_budget_and_says_what_it_cut",
                PDF20_TESTS,
            ),
        },
        Bound {
            name: "MAX_TABLE_RULES",
            cap: tinker_pdf::tables::MAX_TABLE_RULES as u128,
            published: "16 384",
            // The firing test draws the cap and one more; every other fixture
            // is a grid of a dozen cells, forty-eight rules at the most.
            fixtures: tinker_pdf::tables::MAX_TABLE_RULES as u128,
            // A comic page is one image and draws no rule.
            comic: 0,
            // Gap 30's two thousand drawable elements, each a stroked
            // rectangle of four rules.
            document: 2_000 * 4,
            // A forty-cell table bordered cell by cell, four filled
            // rectangles a border, its frame and a rule under its header:
            // about 170, rounded up.
            book: 240,
            // `0 0 m 9 0 l` is twelve bytes and one rule, in a stream as long
            // as the ceiling every stream decodes under.
            reachable: tinker_pdf_cos::limits::MAX_DECODED_STREAM as u128 / 12,
            reachable_because: "a `MAX_DECODED_STREAM` content stream of `0 0 m 9 0 l`, one \
                                rule per twelve bytes",
            declared_in: TABLES,
            fires_in: ("a_page_past_the_rule_cap_has_no_rules_read", TABLES_TESTS),
        },
        Bound {
            name: "MAX_HTML_ACTIVE_FORMATTING",
            cap: xml_limits::MAX_HTML_ACTIVE_FORMATTING as u128,
            published: "1 024",
            // The firing test builds 1 206 entries and the one beside it
            // 1 005; html5lib's trees are a few hundred bytes each.
            fixtures: xml_limits::MAX_HTML_ACTIVE_FORMATTING as u128,
            // No container path parses HTML: a comic has no markup, a fixed
            // document is XML, and an EPUB chapter is XHTML.
            comic: 0,
            document: 0,
            book: 0,
            // Constructive rather than a field width: thirty-two table cells
            // nested one inside another, each leaving a hundred `<b>`s that a
            // `</p>` closed behind its marker, with the stack never past 231.
            reachable: 32 * (100 + 1),
            reachable_because: "thirty-two nested cells of a hundred closed `<b>`s and a \
                                marker each, under MAX_XML_DEPTH",
            declared_in: XML_LIMITS,
            fires_in: (
                "the_list_of_active_formatting_elements_stops_at_its_cap",
                HTML_TESTS,
            ),
        },
        Bound {
            name: "MAX_HTML_CLONE_BYTES",
            cap: xml_limits::MAX_HTML_CLONE_BYTES as u128,
            published: "64 MiB",
            // The firing test copies to the clone the budget runs out at, and
            // the one beside it to the last clone that fits.
            fixtures: xml_limits::MAX_HTML_CLONE_BYTES as u128,
            comic: 0,
            document: 0,
            book: 0,
            // A value half a one-megabyte input long, reopened by the eight-byte
            // `<p>x</p>`s in its other half.
            reachable: (1u128 << 19) * ((1u128 << 19) / 8),
            reachable_because: "a 512 KiB attribute value reopened by 65 536 `<p>x</p>`s",
            declared_in: XML_LIMITS,
            fires_in: (
                "attribute_bytes_copied_onto_clones_stop_at_their_cap",
                HTML_TESTS,
            ),
        },
        Bound {
            name: "MAX_CSS_FEATURE_SETTINGS",
            cap: css_limits::MAX_CSS_FEATURE_SETTINGS as u128,
            published: "32",
            // The list built exactly at the cap parses; the one past it is
            // refused by value.
            fixtures: css_limits::MAX_CSS_FEATURE_SETTINGS as u128,
            comic: 0,
            document: 0,
            // No committed book declares `font-feature-settings`
            // (`CENSUS.tsv`, and a search of their sheets); old-style figures
            // and small capitals on and two ligatures off is a typesetter's
            // ordinary list.
            book: 4,
            // `"abcd",` is seven bytes, a tag with no value being on.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 7,
            reachable_because: "a setting is seven bytes, in a sheet of MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_feature_list_past_the_cap_is_refused_by_value",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_CSS_GRADIENT_STOPS",
            cap: css_limits::MAX_CSS_GRADIENT_STOPS as u128,
            published: "32",
            // The gradient built exactly at the cap parses; the one past it is
            // refused by value.
            fixtures: css_limits::MAX_CSS_GRADIENT_STOPS as u128,
            comic: 0,
            document: 0,
            // No committed book declares a gradient (a search of their
            // sheets); a chapter head's rule fading in and out is three.
            book: 3,
            // `red,` is four bytes.
            reachable: css_limits::MAX_CSS_BYTES as u128 / 4,
            reachable_because: "a stop is four bytes, in a sheet of MAX_CSS_BYTES",
            declared_in: CSS_LIMITS,
            fires_in: (
                "a_gradient_past_the_stop_cap_is_refused_by_value",
                CSS_BOUNDS_TESTS,
            ),
        },
        Bound {
            name: "MAX_EMBEDDING_DEPTH",
            cap: layout_limits::MAX_EMBEDDING_DEPTH as u128,
            published: "125",
            // Two hundred nested isolating spans, the run inside them cut at
            // the cap.
            fixtures: layout_limits::MAX_EMBEDDING_DEPTH as u128,
            // Neither a comic nor a fixed document lays out an inline box.
            comic: 0,
            document: 0,
            // No committed book has a `dir`, a `<bdi>` or a `unicode-bidi`
            // (a search of their content documents and sheets); a `<bdi>`
            // inside a `dir="rtl"` span is two.
            book: 2,
            // A level is opened by an inline box, and the box tree is
            // `MAX_BOX_DEPTH` deep.
            reachable: layout_limits::MAX_BOX_DEPTH as u128,
            reachable_because: "an inline box at each of MAX_BOX_DEPTH levels opens one",
            declared_in: LAYOUT_LIMITS,
            fires_in: (
                "a_run_carries_no_deeper_a_stack_than_uax9_reads",
                LAYOUT_TESTS,
            ),
        },
    ]
}

/// What one recorded call is before its heap parts, for
/// `MAX_DISPLAY_LIST_BYTES`'s row: read off this target, as the recorder's own
/// count reads it.
fn event_size() -> u128 {
    std::mem::size_of::<tinker_pdf_content::Event>() as u128
}

/// What one recorded call's graphics state is.
fn state_size() -> u128 {
    std::mem::size_of::<tinker_pdf_content::GraphicsState>() as u128
}

/// What one recorded path segment is.
fn segment_size() -> u128 {
    std::mem::size_of::<tinker_pdf_content::PathSegment>() as u128
}

/// Gap 29's bounds table has five rows and its code has seven, because two of
/// the plan's "per-item caps sit beside them" were built as named constants.
/// Gap 30's milestone 2 adds four, its milestone 3 adds two and its milestone
/// 6 adds three; gap 31's milestone 3 adds one, its milestone 4 adds three, its
/// milestone 6 adds eight, its milestone 7 adds four and its milestone 10 adds
/// the one milestone 7 argued would arrive with the multi-pass layout; tier 4's
/// W-ARCHIVE milestone 1 adds the one `ComicInfo.xml` needs; tier 1's two
/// ledger rows add the five that were fired but unrecorded — ICC's two and
/// JBIG2's three; and tier 0's memory row adds the two largest **runtime**
/// bounds, `MAX_PAGE_PIXELS` and `MAX_DECODED_STREAM`; and Tier 2's custom
/// code tables add `MAX_JBIG2_TABLE_LINES`; and the `jbig2` fuzz row adds
/// `MAX_JBIG2_SYMBOL_PAGE_MULTIPLE`; and the annotation payloads row adds
/// `MAX_ANNOTATION_BYTES`; and the review of the form data exchange row adds
/// `MAX_FORM_DATA_BYTES`; and the review of the redaction row adds
/// `MAX_FORM_COPY_BYTES`; and the tier-4 archive row's BMP decoder adds
/// `MAX_BMP_SAMPLES`; and the archive row's GIF decoder adds
/// `MAX_GIF_SAMPLES`; and the archive row's WebP decoder adds
/// `MAX_WEBP_SAMPLES`; and the review of the SVG writer adds
/// `MAX_SVG_BYTES`; and the review of the retained page adds
/// `MAX_DISPLAY_LIST_BYTES`; and tier 5's Markdown row adds
/// `MAX_MARKDOWN_NESTING` and `MAX_MARKDOWN_REFERENCE_BYTES`; and the EPUB
/// CSS row's shadows add `MAX_CSS_SHADOWS`; and the review of the
/// tagged-writing lane adds `MAX_STRUCTURE_VALUES`, `MAX_STRUCTURE_BYTES`,
/// `MAX_ASSOCIATED_FILE_BYTES` and `MAX_OUTPUT_INTENT_BYTES`; and tier 5's
/// table-reconstruction row adds `MAX_TABLE_RULES`; and the review of tier
/// 5's formats lane adds HTML's `MAX_HTML_ACTIVE_FORMATTING` and
/// `MAX_HTML_CLONE_BYTES`; and the EPUB CSS row's font features add
/// `MAX_CSS_FEATURE_SETTINGS`, and its gradients `MAX_CSS_GRADIENT_STOPS`;
/// and the review of lane 8C adds `MAX_EMBEDDING_DEPTH`; and the `jbig2` fuzz
/// sweep adds `MAX_JBIG2_WORK_MULTIPLE`. All **sixty-six** are here, and a
/// bound added without a row fails this.
#[test]
fn the_sweep_covers_every_bound_these_three_gaps_added() {
    let names: Vec<&str> = ledger().iter().map(|b| b.name).collect();
    assert_eq!(
        names,
        [
            "MAX_ZIP_ENTRIES",
            "MAX_ZIP_ENTRY_BYTES",
            "MAX_ZIP_INFLATED",
            "MAX_ZIP_NAME_LEN",
            "MAX_PNG_SAMPLES",
            "MAX_CBZ_PAGES",
            "MAX_SYNTHESISED_PDF",
            "MAX_COMIC_INFO_BYTES",
            "MAX_XML_DEPTH",
            "MAX_XML_ATTRIBUTES",
            "MAX_XML_NAME_LEN",
            "MAX_XML_TOKENS",
            "MAX_XPS_PARTS",
            "MAX_XPS_PAGES",
            "MAX_XPS_ELEMENTS",
            "MAX_XPS_SEGMENTS",
            "MAX_XPS_GLYPHS",
            "MAX_XPS_RESOURCE_DEPTH",
            "MAX_OCF_PATH_LEN",
            "MAX_EPUB_MANIFEST_ITEMS",
            "MAX_EPUB_SPINE_ITEMS",
            "MAX_EPUB_FALLBACK_DEPTH",
            "MAX_CSS_BYTES",
            "MAX_CSS_TOKENS",
            "MAX_CSS_RULES",
            "MAX_CSS_DECLARATIONS",
            "MAX_CSS_SELECTOR_PARTS",
            "MAX_CSS_IMPORT_DEPTH",
            "MAX_DOM_NODES",
            "MAX_SELECTOR_MATCHES",
            "MAX_BOX_DEPTH",
            "MAX_BOX_TREE_NODES",
            "MAX_LINE_BREAK_WORK",
            "MAX_LAYOUT_WORK",
            "MAX_LAYOUT_PAGES",
            "MAX_ICC_TAGS",
            "MAX_ICC_BYTES",
            "MAX_JBIG2_SYMBOLS",
            "MAX_JBIG2_SYMBOL_PIXELS",
            "MAX_JBIG2_SYMBOL_PAGE_MULTIPLE",
            "MAX_JBIG2_TEXT_INSTANCES",
            "MAX_JBIG2_TABLE_LINES",
            "MAX_JBIG2_WORK_MULTIPLE",
            "MAX_PAGE_PIXELS",
            "MAX_DECODED_STREAM",
            "MAX_ANNOTATION_BYTES",
            "MAX_FORM_DATA_BYTES",
            "MAX_FORM_COPY_BYTES",
            "MAX_BMP_SAMPLES",
            "MAX_GIF_SAMPLES",
            "MAX_WEBP_SAMPLES",
            "MAX_SVG_BYTES",
            "MAX_DISPLAY_LIST_BYTES",
            "MAX_MARKDOWN_NESTING",
            "MAX_MARKDOWN_REFERENCE_BYTES",
            "MAX_CSS_SHADOWS",
            "MAX_STRUCTURE_VALUES",
            "MAX_STRUCTURE_BYTES",
            "MAX_ASSOCIATED_FILE_BYTES",
            "MAX_OUTPUT_INTENT_BYTES",
            "MAX_TABLE_RULES",
            "MAX_HTML_ACTIVE_FORMATTING",
            "MAX_HTML_CLONE_BYTES",
            "MAX_CSS_FEATURE_SETTINGS",
            "MAX_CSS_GRADIENT_STOPS",
            "MAX_EMBEDDING_DEPTH",
        ],
        "a bound was added or renamed without a row in this sweep"
    );

    // Every one of them is a `pub const` where its ledger says it is, which is
    // what makes the numbers above readable from outside their own crate.
    for bound in ledger() {
        assert!(
            bound
                .declared_in
                .contains(&format!("pub const {}", bound.name)),
            "{} is not declared where this sweep says it is",
            bound.name
        );
    }
}

/// **The check gap 18a milestone 8 was missing.**
///
/// A cap is only a cap if its own inputs can ask for more than it allows. Each
/// row computes the ceiling of what stands in front of it — the field widths
/// the format gives, or the product of the caps below it — and the assertion
/// is that the constant sits underneath. A row that fails this has a constant
/// that no input can ever reach, which is decoration with a `MAX_` prefix.
#[test]
fn every_bound_can_fire() {
    for bound in ledger() {
        assert!(
            bound.reachable > bound.cap,
            "{} is {} and the most its own inputs can ask for is {} ({}): it \
             can never fire, which is gap 18a milestone 8's failure exactly",
            bound.name,
            bound.cap,
            bound.reachable,
            bound.reachable_because,
        );
    }
}

/// And the other direction: a cap that refuses the thing the format is for is
/// not a bound, it is a missing feature.
///
/// The yardstick is gap 29's own — a 200-page comic at 2000 x 3000 — and the
/// margin between it and the cap is the safety margin the plan asks to be
/// written down. Writing it down is what would have caught `MAX_JPX_WORK`.
#[test]
fn no_bound_refuses_a_two_hundred_page_comic() {
    for bound in ledger() {
        assert!(
            bound.comic < bound.cap,
            "{} is {} and a 200-page comic spends {}: this cap refuses a real \
             archive",
            bound.name,
            bound.cap,
            bound.comic,
        );
        assert!(
            bound.fixtures <= bound.cap,
            "{}: a fixture spends {} against a cap of {}",
            bound.name,
            bound.fixtures,
            bound.cap,
        );
    }
}

/// Gap 30's yardstick, for the rows that have one: a 200-page fixed document at
/// roughly 2 000 drawable elements and 40 000 path segments a page.
///
/// A separate test from the comic rather than a second assertion inside it,
/// because the two yardsticks measure different documents and a row's two
/// figures are genuinely different numbers — a comic holds no XML and a fixed
/// document holds no comic page, and both of those are recorded as a zero
/// rather than as an absence. What must not happen is a row acquiring a bound
/// that refuses the format it was written for, which is the failure this pair
/// of tests exists to make impossible in both directions.
///
/// *Amended by milestone 9.* It swept ten rows of seventeen until then, because
/// gap 29's seven arrived before gap 30 had a yardstick and opted out with a
/// `None`. **A row that opts out of a check is a row that is not checked**, and
/// four of those seven are the ZIP caps every XPS part in this repository is
/// admitted through — so the seven rows standing in front of gap 30's whole
/// input path were the seven this test could not see.
#[test]
fn no_bound_refuses_a_dense_fixed_document() {
    let mut measured = 0usize;
    for bound in ledger() {
        measured += 1;
        assert!(
            bound.document < bound.cap,
            "{} is {} and a dense 200-page fixed document spends {}: this cap \
             refuses a real document",
            bound.name,
            bound.cap,
            bound.document,
        );
    }
    // A sweep that found nothing to sweep is a sweep that does not run, and a
    // sweep that found *some* of it is what this test was until milestone 9.
    assert_eq!(
        measured,
        ledger().len(),
        "gap 30's yardstick covers {measured} rows and the ledger has {}",
        ledger().len(),
    );
    assert_eq!(measured, 66, "the ledger is sixty-six rows");
}

/// Gap 31's yardstick: **a 300-page reflowable book**, on every row.
///
/// A third test rather than a third assertion inside either of the other two,
/// for `no_bound_refuses_a_dense_fixed_document`'s reason: the three yardsticks
/// measure three different documents and a row's three figures are genuinely
/// three numbers. A comic holds no stylesheet, a fixed document holds no box
/// tree, and a book holds neither a comic page nor an XPS part — and all three
/// of those are recorded as a measured zero rather than as an absence.
///
/// **Two rows failed this the first time it ran**, which is the whole reason
/// the yardstick is worth the milestone. `MAX_BOX_TREE_NODES` was 262 144 and
/// `sample-linear-algebra.epub` needs 993 349; `MAX_LAYOUT_WORK` was 4 000 000
/// and `sample-epub30-spec.epub` spends 4 233 567. Neither was quiet about it
/// — both refuse by name — but a refusal aimed at a book W3C publishes is a
/// missing feature wearing a `MAX_` prefix, which is exactly what this pair of
/// directions exists to make impossible.
#[test]
fn no_bound_refuses_a_real_book() {
    for bound in ledger() {
        assert!(
            bound.book < bound.cap,
            "{} is {} and a 300-page reflowable book spends {}: this cap \
             refuses a real book",
            bound.name,
            bound.cap,
            bound.book,
        );
    }
    // A sweep that found nothing to sweep is a sweep that does not run.
    assert_eq!(ledger().len(), 66, "the ledger is sixty-six rows");
}

/// **And the yardstick is not a number somebody made up.**
///
/// The comic and the fixed document are estimates — arithmetic about a
/// plausible file, written down so it can be argued with. This one does not
/// have to be, because gap 31 is the first format in this repository whose own
/// reading path publishes what it spent:
/// [`tinker_pdf::cbz::ArchiveReport::book_cost`] carries ten of the figures
/// above, and the archive carries five more.
///
/// So every book in both corpora is opened here and measured against the row
/// that bounds it. The committed nine always; the fetched twenty when
/// `TINKER_EPUB_CORPUS` names the directory `fetch-corpus.sh` filled — and the
/// difference between the two is the finding rather than a detail. **The
/// committed books are a hundred times smaller than the fetched twenty on every
/// row that matters**: they spend 326 boxes against 993 349 and 39 float
/// examinations against 4 233 567. A yardstick calibrated on the corpus this
/// repository commissioned would have agreed with the caps that were wrong.
///
/// *Amended by tier 4:* the committed corpus is nine books rather than six, and
/// the three that joined it do not move that conclusion — a pre-paginated comic
/// is six one-element documents and the two font books are prose. What they do
/// add is the first committed entry large enough to be interesting to
/// `MAX_ZIP_ENTRY_BYTES`: a 393 576-byte font program, against a previous
/// largest of a few kilobytes.
///
/// Printed as well as asserted, because the figure a partial build is judged on
/// is the margin rather than the boolean.
#[test]
fn the_book_yardstick_is_not_below_a_real_book() {
    let mut books = corpus_books(
        &std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests")
            .join("epub"),
    );
    let committed = books.len();
    assert_eq!(
        committed, 9,
        "milestone 1 committed six books and tier 4 added three"
    );
    match std::env::var("TINKER_EPUB_CORPUS") {
        Ok(dir) => books.extend(corpus_books(std::path::Path::new(&dir))),
        Err(_) => println!(
            "  epub-corpus: SKIPPED — the fetched twenty are not here, so this \
             sweep measured the committed six only"
        ),
    }
    println!("  measuring {} books", books.len());

    let rows = ledger();
    let row = |name: &str| {
        rows.iter()
            .find(|bound| bound.name == name)
            .unwrap_or_else(|| panic!("{name} has no row"))
    };
    let mut worst: Vec<(&str, u128, String)> = Vec::new();
    let mut note = |name: &'static str, spent: u128, book: &str| match worst
        .iter_mut()
        .find(|(row, _, _)| *row == name)
    {
        Some(slot) if slot.1 >= spent => {}
        Some(slot) => *slot = (name, spent, book.to_owned()),
        None => worst.push((name, spent, book.to_owned())),
    };

    for (name, bytes) in &books {
        // The five the container itself decides, read through `tinker-pdf-zip`
        // rather than through the book: these bound what is admitted, and what
        // is admitted is measured before anything is read.
        let archive = tinker_pdf::cbz::open_archive(bytes, &tinker_pdf_zip::Limits::DEFAULT)
            .unwrap_or_else(|e| panic!("{name} is not a readable ZIP: {e:?}"));
        note("MAX_ZIP_ENTRIES", archive.entries().len() as u128, name);
        note(
            "MAX_ZIP_ENTRY_BYTES",
            archive
                .entries()
                .iter()
                .map(|entry| entry.uncompressed_size as u128)
                .max()
                .unwrap_or(0),
            name,
        );
        note(
            "MAX_ZIP_INFLATED",
            archive
                .entries()
                .iter()
                .map(|entry| entry.uncompressed_size as u128)
                .sum(),
            name,
        );
        let longest = archive
            .entries()
            .iter()
            .map(|entry| entry.name.len() as u128)
            .max()
            .unwrap_or(0);
        note("MAX_ZIP_NAME_LEN", longest, name);
        note("MAX_OCF_PATH_LEN", longest, name);

        // And the ten the reading path spends, published by the report for
        // exactly this reason.
        let layout = tinker_pdf::epub::BookLayout::default();
        let (_, report) =
            match tinker_pdf::epub::route(archive, &tinker_pdf::epub::Limits::DEFAULT, &layout) {
                tinker_pdf::epub::Routing::Document(pdf, report) => (pdf, report),
                tinker_pdf::epub::Routing::Refused(why) => {
                    panic!("{name} was refused: {why:?}")
                }
                _ => panic!("{name} is not an EPUB"),
            };
        let cost = report.book_cost().expect("a book publishes its cost");
        note(
            "MAX_SYNTHESISED_PDF",
            report.synthesised_bytes() as u128,
            name,
        );
        note("MAX_EPUB_MANIFEST_ITEMS", cost.manifest_items as u128, name);
        note("MAX_EPUB_SPINE_ITEMS", cost.spine_items as u128, name);
        note("MAX_CSS_TOKENS", cost.css_tokens as u128, name);
        note("MAX_CSS_RULES", cost.css_rules as u128, name);
        note("MAX_CSS_DECLARATIONS", cost.css_declarations as u128, name);
        note("MAX_SELECTOR_MATCHES", cost.selector_matches as u128, name);
        note("MAX_BOX_TREE_NODES", cost.boxes as u128, name);
        note("MAX_LINE_BREAK_WORK", cost.break_work as u128, name);
        note("MAX_LAYOUT_WORK", cost.layout_work as u128, name);
        note("MAX_LAYOUT_PAGES", cost.pages as u128, name);
    }

    assert_eq!(
        worst.len(),
        16,
        "sixteen rows are measured against a real book rather than argued"
    );
    for (name, spent, book) in &worst {
        let bound = row(name);
        println!(
            "  {name:26} book yardstick {:>12}  worst real {:>12}  ({book})",
            bound.book, spent
        );
        assert!(
            *spent <= bound.book,
            "{name}: {book} spends {spent} and the book yardstick says {}. The \
             yardstick is the row that is wrong, not the book — raise it, and \
             check whether the cap above it still stands over the new figure",
            bound.book,
        );
        // And the cap, from the other side, which is the assertion that would
        // have caught `MAX_BOX_TREE_NODES` at milestone 10 rather than here.
        assert!(
            *spent < bound.cap,
            "{name}: {book} spends {spent} against a cap of {}, so a real book \
             is refused",
            bound.cap,
        );
    }
}

/// Every `.epub` in a directory, by name, or nothing if there is no such
/// directory.
fn corpus_books(dir: &std::path::Path) -> Vec<(String, Vec<u8>)> {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return Vec::new();
    };
    let mut out: Vec<(String, Vec<u8>)> = entries
        .flatten()
        .map(|entry| entry.path())
        .filter(|path| path.extension().and_then(|e| e.to_str()) == Some("epub"))
        .map(|path| {
            let name = path
                .file_name()
                .map(|name| name.to_string_lossy().into_owned())
                .unwrap_or_default();
            let bytes = std::fs::read(&path).unwrap_or_else(|e| panic!("reading {name}: {e}"));
            (name, bytes)
        })
        .collect();
    out.sort_by(|left, right| left.0.cmp(&right.0));
    out
}

/// Each constant's ledger publishes its value in prose, and prose does not
/// compile.
///
/// So the published rendering is asserted to be in the file that declares the
/// constant, beside a `**This cap**` row. A constant changed without its table
/// fails here — which is the drift `tinker-pdf-math` demonstrated for the leaf
/// count, where a number written in three documents moved in none of them.
#[test]
fn every_bound_publishes_the_number_it_is() {
    for bound in ledger() {
        assert!(
            bound
                .declared_in
                .contains(&format!("**This cap** | **{}**", bound.published)),
            "{}'s ledger does not publish {} as its cap",
            bound.name,
            bound.published,
        );
    }

    // The published renderings are the values, not decoration: every one of
    // them parses back to the constant it names.
    for bound in ledger() {
        // `(estimate)` joined the suffixes with tier 1's JBIG2 row, and it is
        // the only one that is not a unit. Three caps bound a format no file in
        // the corpus carries a real example of — the census found `SDNUMEXSYMS`
        // 11 across 102 files that are all synthetic — so their yardsticks are
        // arithmetic, and the roadmap's exit criterion is that the ledger
        // **say so** rather than let a stated estimate read as a measurement.
        // Stripped before the digits are parsed and not after, because
        // `100000(estimate)` is not a number.
        let published = bound
            .published
            .strip_suffix(" (estimate)")
            .unwrap_or(bound.published);
        let published = published.replace(' ', "");
        // `KiB` joined `MiB` and `GiB` in tier 4: `MAX_COMIC_INFO_BYTES` is the
        // first cap here small enough to be published in kibibytes, and a
        // ledger that had to write `65 536` to satisfy this check would be
        // less readable for the check's benefit.
        let value = match published.strip_suffix("KiB") {
            Some(n) => n.parse::<u128>().expect("a number") * (1 << 10),
            None => match published.strip_suffix("MiB") {
                Some(n) => n.parse::<u128>().expect("a number") * (1 << 20),
                None => match published.strip_suffix("GiB") {
                    Some(n) => n.parse::<u128>().expect("a number") * (1 << 30),
                    None => published.parse::<u128>().expect("a number"),
                },
            },
        };
        assert_eq!(
            value, bound.cap,
            "{}'s ledger publishes {} and the constant is {}",
            bound.name, bound.published, bound.cap,
        );
    }
}

/// Every bound names a test that fires it, and that test exists.
///
/// The plan's exit criterion is that each fires "by its own warning or
/// refusal, not by a clock" — `5adf502`'s method, taken for its stated reason:
/// a timing assertion fails on a slow machine and passes on a fast one with
/// the budget removed. What this can check from here is that the named test is
/// still in the file it is claimed to be in; what it cannot check is that the
/// test still asserts a refusal, which is why each of those tests carries a
/// doc comment saying which refusal it is waiting for.
#[test]
fn every_bound_names_a_test_that_exists() {
    for bound in ledger() {
        let (test, source) = bound.fires_in;
        assert!(
            source.contains(&format!("fn {test}(")),
            "{} is proved to fire by {test}, and there is no such test",
            bound.name,
        );
        // And it is a test rather than a helper that happens to be named like
        // one, and not an `#[ignore]`d one either: the attribute immediately
        // before it is `#[test]` and nothing else. Whitespace is trimmed rather
        // than matched, because a checkout with `core.autocrlf` on ends these
        // lines with `\r\n` — which the injection matrix found by rewriting
        // these files through a tool that translates them.
        let at = source.find(&format!("fn {test}(")).expect("just found");
        assert!(
            source[..at].trim_end().ends_with("#[test]"),
            "{test} is not a `#[test]`, or is ignored",
        );
    }

    // Not one of them may be a timing assertion. `5adf502` is the scar: a
    // budget proved by a clock passes on a fast machine with the budget
    // removed.
    // `XPS_GLYPH_TESTS` joined this list in milestone 9 and was missing from it
    // from the moment milestone 7 added the row it holds: a source named by a
    // `fires_in` and left out here is a file where a clock could be introduced
    // without this sweep noticing, which is half of the fifth check absent for
    // exactly one bound.
    // `ICC` and `JBIG2` joined it with tier 1's two ledger rows, and they are
    // the first entries here that are also a `declared_in`: those two crates
    // keep their tests beside their constants, so one `include_str!` is both
    // the ledger and the proof.
    // `PAGE_GEOMETRY_TESTS` and `INLINE_IMAGE_TESTS` joined it with tier 0's
    // memory row, and they are the entries this rule was most needed for: the
    // roadmap row that added them says in as many words that the only
    // peak-memory tests in this repository are `#[ignore]`d and wanted a
    // clock. Neither of these does, and this is what keeps it that way.
    for source in [
        ZIP_TESTS,
        PNG_TESTS,
        CBZ_TESTS,
        XML_TESTS,
        XPS_TESTS,
        XPS_MARKUP_TESTS,
        XPS_GLYPH_TESTS,
        EPUB_TESTS,
        CSS_BOUNDS_TESTS,
        LAYOUT_TESTS,
        ICC,
        JBIG2,
        PAGE_GEOMETRY_TESTS,
        INLINE_IMAGE_TESTS,
        ANNOTATION_TESTS,
        FORM_DATA,
        FORM_DATA_TESTS,
        TAGGED_PDF_TESTS,
        PDF20_TESTS,
        TABLES_TESTS,
    ] {
        assert!(
            !source.contains("Instant::now"),
            "a bound in this gap is being proved by a clock"
        );
    }
}
