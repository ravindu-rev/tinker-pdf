//! A comic archive becomes a document (gap 29, milestone 5).
//!
//! A CBZ is a ZIP of page images, one file per page. This module is where the
//! archive stops being a bag of names and becomes a `Document`: which entries
//! are pages, in what order, at what size, and what a page that cannot be
//! built looks like.
//!
//! # Why this is in the facade and not below it
//!
//! Ruling 8 keeps the leaves PDF-free — `tinker-pdf-zip` turns bytes into
//! names and byte ranges and has no opinion about what an entry is *for* — and
//! deciding what a page *is* needs document types. It cannot live in
//! `tinker-pdf-cos` either without teaching the object model about a container
//! no PDF stream will ever hold. So it lives here, beside `resources.rs`,
//! which already makes the other boundary decisions for the same reason.
//!
//! # Synthesis, not an enum
//!
//! [`crate::Document::cos`] returns `&CosDocument` — a **borrow, and not an
//! `Option`** — and that one signature decides the whole shape of this. A CBZ
//! has no `CosDocument` to lend, so one is *made*: the pages are built through
//! [`DocumentBuilder`], serialised by `finish`, and parsed straight back by
//! `CosDocument::open`. The synthesised document goes out through the writer
//! and in through the reader, so it is parsed by the same parser as every real
//! PDF and cannot take a shortcut around it — and every capability the engine
//! already has (cancellation, warnings, `at_dpi`, bounded painting) arrives for
//! nothing rather than being wired a second time.
//!
//! # The image bytes are not touched
//!
//! Synthesis happens whole at open, so whatever a page holds is held for the
//! document's life. A JPEG is placed verbatim ([`ImageData::Jpeg`]) and a PNG
//! goes through [`png_image`], whose default route copies the IDAT into a
//! `/FlateDecode` stream with `/Predictor 15` and never builds a raster. A
//! TIFF goes through [`tiff_image_directory`], which does the same thing for
//! five more codings: a G3 or G4 strip is a `/CCITTFaxDecode` stream, an LZW
//! strip is a `/LZWDecode` one, a DEFLATE strip is `/FlateDecode`, a JPEG
//! strip is `/DCTDecode` and a JPEG 2000 strip is `/JPXDecode` — so a scanned
//! comic costs its own bytes rather than its own pixels, the same as every
//! other entry here. A TIFF of several directories — a scanned chapter in one
//! file — is several pages, one per directory that is a page. A JPEG 2000
//! file, JP2 or bare codestream, is the simplest of them: it *is* a
//! `/JPXDecode` stream (7.4.9 takes both shapes), so its bytes are placed
//! whole and only its header is read, for the page's size.
//! Decoding every page instead would cost *w x h x 3* each — about 3.6 GB for
//! a 200-page archive at 2000 x 3000 — and the failure would arrive only at
//! the size that matters.
//!
//! **A BMP and a GIF are the exceptions, and they are by the format rather
//! than by choice**: no `/Filter` reads a bottom-up pixel array padded to four
//! bytes a row, nor either of BMP's RLE codings, nor GIF's LZW — whose root
//! set, bit order and width rule all differ from `/LZWDecode`'s — so those
//! pages are decoded and cost their pixels. Each is kept `/Indexed` where the
//! file was, which is a third of the raster an expanded one would hold
//! ([`RasterImageData`]).
//!
//! # Two levels of refusal, and the difference is the feature
//!
//! **Archive level** ([`ArchiveRefusal`], via [`crate::OpenError`]): not a ZIP,
//! damaged past recovery, every entry encrypted, multi-disk, a Zip64 value the
//! archive cannot contain, a bound spent, and a valid archive with no image
//! entries at all. That last one matters most: opening it as a zero-page
//! document is `NotAPdf`'s failure wearing a success costume — a host asks for
//! the page count, gets 0, and shows an empty reader with no error to display.
//!
//! **Page level** ([`PageDefect`]): an entry that is recognisably an image and
//! cannot be turned into a real page **still becomes a page**, of the right
//! size, carrying the neutral placeholder and a named warning. Dropping it
//! would produce a document that looks complete — 99 pages where the archive
//! holds 100, every page correct, and the story jumping in the middle with
//! nothing anywhere saying so.
//!
//! Entries that are not images at all — `Thumbs.db`, `__MACOSX/`, directory
//! records — are neither pages nor warnings. Skipping them is correct rather
//! than lenient, and warning about them would bury the warnings that matter.
//!
//! **`ComicInfo.xml` is the one exception, and it is a third thing rather than
//! a page.** Tier 4 gave it a reader ([`comic_info`]): it produces no page, no
//! [`PageOrigin`] and no page number, and it writes the archive's title,
//! series, credits and summary into the synthesised document's `/Info`. The
//! distinction the change must not blur is that *not a page* and *not read* are
//! different sentences — `extension_claims_image("ComicInfo.xml")` is still
//! false and is still asserted to be.

use std::borrow::Cow;
use std::cmp::Ordering;

use tinker_pdf_archive::{rar, sevenz, tar};
use tinker_pdf_cos::{
    bmp_image, gif_image, png_image, tiff_image_directory, webp_image, CompressedImage,
    DocumentBuilder, ImageColorSpace, ImageData, ImageFilter, PngImageData, RasterImageData,
    TiffImageData,
};
use tinker_pdf_filters::{tiff_scan_directory, JpxHeader, Limits as FilterLimits, TiffError};
use tinker_pdf_zip::{Archive, ArchiveError};

pub use tinker_pdf_archive::tar::{
    limits as tar_limits, EntryError as TarEntryError, Error as TarError, Limits as TarLimits,
    Warning as TarWarning,
};

pub use tinker_pdf_archive::sevenz::{
    limits as sevenz_limits, EntryError as SevenZipEntryError, Error as SevenZipError,
    Limits as SevenZipLimits, Warning as SevenZipWarning,
};

pub use tinker_pdf_archive::rar::{
    limits as rar_limits, EntryError as RarEntryError, Error as RarError, Limits as RarLimits,
    Warning as RarWarning,
};

pub use tinker_pdf_zip::{
    limits as zip_limits, EntryError as ZipEntryError, InflateWarning, Limits as ZipLimits,
    MethodFeature as ZipMethodFeature, Warning as ZipWarning,
};

pub mod comic_info;

pub use comic_info::{ComicInfo, ComicInfoDefect, MAX_COMIC_INFO_BYTES};

// ---- Bounds -----------------------------------------------------------------

/// The most pages one archive may synthesise.
///
/// Gap 18a milestone 8 found `MAX_JPX_WORK` set *above* the most its own inputs
/// could ask for, so it could never fire. That failure decides this number in
/// one direction: [`zip_limits::MAX_ZIP_ENTRIES`] is 16 384, so a cap at or
/// above that could never be the thing that stopped anything, and this one has
/// to sit below it to be a cap at all.
///
/// | | Pages |
/// | --- | --- |
/// | The most any fixture in this repository spends | 4 096 (the archive built *past* this cap holds 4 097 entries; nothing else here holds more than 13) |
/// | A 200-page comic | 200 |
/// | **This cap** | **4 096** |
///
/// A page costs an object graph as well as an archive entry, which is why the
/// archive's entry cap is not this cap and why `cos::limits::MAX_PAGES` — 2^21
/// — is not either: that is a bound on a page tree a real document may have,
/// and it is four hundred times more pages than any comic is.
///
/// Reachable: `a_page_count_past_the_cap_is_refused_by_name` builds the real
/// 4 097-entry archive rather than lowering the constant, because a cap proved
/// only against a lowered copy of itself has not been proved to fire.
pub const MAX_CBZ_PAGES: usize = 4_096;

/// The most bytes the synthesiser may hand [`tinker_pdf_cos::CosDocument`].
///
/// Charged **before each page is built**, on what that page has undertaken to
/// contribute: its image bytes, its soft mask, and [`PAGE_OVERHEAD`] for the
/// objects it costs. That is `tinker-pdf-zip`'s `Budget` posture — a permit is
/// what has been promised, not what happened to arrive — and it is what keeps
/// the *work* bounded rather than only the answer.
///
/// The archive's own caps do not bound this on their own, which is the reason
/// it exists: [`ZipLimits::max_inflated_total`] bounds the image data and
/// nothing bounds the object graph, so thousands of one-byte entries are a page
/// tree far larger than their input.
///
/// | | Bytes |
/// | --- | --- |
/// | The most any fixture in this repository spends | ~70 KB |
/// | A 200-page comic at 2000 x 3000, 1.5 MB a page | ~300 MB |
/// | **This cap** | **512 MiB** |
///
/// A margin of 1.8x, and deliberately not more. The synthesiser holds two
/// copies of this in flight — the object set and the serialised output — and
/// `usize` is 32 bits on `wasm32-unknown-unknown` and `wasm32-wasip1`, both of
/// which this engine builds for, where a gigabyte held twice is more than half
/// the address space and the allocator would fire before the cap did.
pub const MAX_SYNTHESISED_PDF: usize = 512 << 20;

/// What one page costs in objects, charged against [`MAX_SYNTHESISED_PDF`]
/// on top of its image data.
///
/// A page dictionary, a content stream, an image dictionary, their three
/// cross-reference entries and this page's slot in `/Kids`. Measured rather
/// than guessed: `the_synthesised_document_fits_inside_what_was_charged_for_it`
/// builds documents from 1 to 200 pages and asserts the finished length is
/// inside the charge, so a change to the writer that made a page cost more
/// would fail rather than quietly overrun the cap.
pub const PAGE_OVERHEAD: usize = 1_024;

/// What the catalog, the page tree, the header and the trailer cost, charged
/// once against [`MAX_SYNTHESISED_PDF`] before the first page.
pub const DOCUMENT_OVERHEAD: usize = 4_096;

/// The neutral grey a placeholder page is filled with.
///
/// The same 0xBF the renderer paints over an image it could not decode, so a
/// page that is missing looks the same whichever level lost it. Grey rather
/// than a diagonal-cross convention because it never reads as content.
///
/// Shared with [`crate::xps`] rather than copied, so a fixed page whose markup
/// is not painted yet and a comic page whose image would not decode look the
/// same — which they should, because they are the same statement.
pub(crate) const PLACEHOLDER_GREY: f64 = 191.0 / 255.0;

/// The page size a placeholder falls back to when the book never says.
///
/// US Letter, and it is only ever reached by an archive in which **no** entry
/// produced a real image — one of nothing but GIFs, say. A placeholder in an
/// ordinary archive takes the size of the first real page instead, because a
/// comic's pages are one size and a placeholder that matches its neighbours is
/// the one a reader can page through.
const FALLBACK_PAGE: (f64, f64) = (612.0, 792.0);

/// Resource ceilings for synthesising a document from an archive.
///
/// Separate from [`ZipLimits`] and carrying one, because they bound different
/// things: the archive's caps bound what comes *out* of the container and these
/// bound what is built *from* it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Limits {
    /// Pages synthesised. See [`MAX_CBZ_PAGES`].
    pub max_pages: usize,
    /// Bytes of the document handed to the parser. See [`MAX_SYNTHESISED_PDF`].
    pub max_synthesised: usize,
    /// What the archive reader is allowed to spend.
    pub zip: ZipLimits,
    /// What the RAR reader is allowed to spend (tier 4, W-ARCHIVE milestone
    /// 4).
    ///
    /// Three numbers. Like a tar and unlike a 7z, a **stored** RAR entry is a
    /// byte range of the input; what RAR has that tar does not is a header
    /// whose length the file chooses.
    pub rar: RarLimits,
    /// What the 7z reader is allowed to spend (tier 4, W-ARCHIVE milestone
    /// 3).
    ///
    /// Five numbers, where the tar reader needs two, and the difference is
    /// compression: nothing in a tar expands, so the input's own length bounds
    /// it, and a `.7z` declares its unpacked sizes in a field a file chooses.
    /// `tinker_pdf_archive::sevenz::limits` argues each one.
    pub sevenz: SevenZipLimits,
    /// What the tar reader is allowed to spend (tier 4, W-ARCHIVE milestone
    /// 2).
    ///
    /// Two numbers rather than the ZIP reader's four, and the difference is a
    /// fact about the format rather than an oversight: nothing in a tar
    /// decompresses, so the input's own length already bounds every entry and
    /// all of them together. `tinker_pdf_archive::tar::limits` argues it.
    pub tar: TarLimits,
    /// What reading one `ComicInfo.xml` is allowed to spend (tier 4,
    /// W-ARCHIVE milestone 1).
    ///
    /// The comic path's only markup, and it carries the *same* four caps the
    /// XPS and EPUB paths pass rather than a fifth set of numbers: a metadata
    /// file two orders of magnitude smaller than either does not need its own
    /// ceilings, and a second copy of four constants is how two readers of one
    /// format start disagreeing. What is comic-specific is
    /// [`MAX_COMIC_INFO_BYTES`], which is a cap on the entry rather than on
    /// the parse.
    pub xml: tinker_pdf_xml::Limits,
}

impl Limits {
    /// The constants above, which is what [`Default`] hands back.
    pub const DEFAULT: Self = Self {
        max_pages: MAX_CBZ_PAGES,
        max_synthesised: MAX_SYNTHESISED_PDF,
        zip: ZipLimits::DEFAULT,
        tar: TarLimits::DEFAULT,
        sevenz: SevenZipLimits::DEFAULT,
        rar: RarLimits::DEFAULT,
        xml: tinker_pdf_xml::Limits::DEFAULT,
    };
}

impl Default for Limits {
    fn default() -> Self {
        Self::DEFAULT
    }
}

// ---- The sniff --------------------------------------------------------------

/// A container format recognised at the head of a file.
///
/// Recognising a container rather than falling through to "not a PDF" is the
/// point rather than an afterthought: "this is a CBR and I do not read CBR" is
/// a different sentence from "this is not a PDF", and a host shows different
/// things for them. Since tier 4 most of these are read, and the distinction
/// still earns its keep: what is left is refused by name.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum Container {
    /// `PK\x03\x04` — a ZIP local file header, which is what a CBZ is.
    Zip,
    /// `Rar!\x1A\x07` — RAR, which a CBR is. Not read here.
    Rar,
    /// `7z\xBC\xAF\x27\x1C` — 7z, which a CB7 is. Read since tier 4,
    /// through `tinker_pdf_archive::sevenz`.
    SevenZip,
    /// POSIX `ustar` — tar, which a CBT is. Read since tier 4,
    /// through `tinker_pdf_archive::tar`.
    Tar,
}

/// Which container the bytes **begin** with, if any.
///
/// Every signature here is tested at a fixed position and nowhere else, which
/// is what keeps a PDF that happens to contain `PK\x03\x04` inside a stream —
/// an attachment, a compressed object, a font program — an ordinary PDF.
/// Searching for these would turn a legal document into a refused archive.
///
/// tar's `ustar` is at offset 257 because that is where POSIX 1003.1 puts the
/// magic field of the first header block. It is still a fixed position rather
/// than a search.
#[must_use]
pub fn container(bytes: &[u8]) -> Option<Container> {
    if bytes.starts_with(b"PK\x03\x04") {
        return Some(Container::Zip);
    }
    if bytes.starts_with(b"Rar!\x1A\x07") {
        return Some(Container::Rar);
    }
    if bytes.starts_with(b"7z\xBC\xAF\x27\x1C") {
        return Some(Container::SevenZip);
    }
    if bytes.get(257..262) == Some(b"ustar".as_slice()) {
        return Some(Container::Tar);
    }
    None
}

// ---- Refusals and reports ---------------------------------------------------

/// Why a container this build recognises could not be opened as a document.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum ArchiveRefusal {
    /// A container this build does not read: RAR, 7z, tar.
    NotAZip,
    /// The central directory could not be located and no local header was
    /// found either.
    Damaged,
    /// Every entry that could have been a page is encrypted, so there is
    /// nothing to page. Neither ZipCrypto nor the AES extensions are in scope.
    Encrypted,
    /// Spanned or multi-disk. The fragment that happens to be here is not the
    /// archive.
    MultiDisk,
    /// A Zip64 field declares a size or offset the archive cannot contain.
    Zip64OutOfBounds,
    /// A valid archive holding not one image entry.
    ///
    /// Refused rather than opened as zero pages: a host that asks for the page
    /// count, gets 0 and has no error to show has been handed a failure
    /// dressed as a success.
    ///
    /// **This is a sentence about a comic archive and never about an XPS.**
    /// Before gap 30's milestone 3 it was what five of milestone 1's eight real
    /// packages came back as, including a three-page document, because the
    /// comic path counted raster parts and a fixed document has none.
    NoImages,
    /// A bound was spent: [`MAX_CBZ_PAGES`], [`MAX_SYNTHESISED_PDF`],
    /// [`crate::xps::MAX_XPS_PARTS`], [`crate::xps::MAX_XPS_PAGES`], or one of
    /// the archive reader's own.
    TooLarge,
    /// An OPC package that claims to be an XPS and whose own structure will not
    /// read (gap 30, milestone 3).
    ///
    /// ECMA-388 E.3's second step held — the archive carries both
    /// `[Content_Types].xml` and `_rels/.rels` — and its third did not: a
    /// content-types item or a package relationships part that is not
    /// well-formed XML, a fixed-representation target naming a part the package
    /// does not hold, or one whose media type is not the fixed document
    /// sequence's.
    ///
    /// Refused rather than fallen through to the comic path, which is a
    /// deliberate refinement of E.3 and is argued in [`crate::xps`]'s header: a
    /// package that carries OPC's own two parts is not a comic, and paging its
    /// images would be gap 30's headline defect wearing a smaller hat. A ZIP
    /// carrying a `[Content_Types].xml` and **no** relationships part is still
    /// a comic archive, and so is an OPC package that names no fixed
    /// representation at all.
    UnreadablePackage,
    /// An interleaved package whose pieces (OPC 7.2.4's `…/[0].piece` items)
    /// do not assemble into a part: a piece number missing or repeated, no
    /// `.last` piece or one that is not the highest, a number with a leading
    /// zero, or a part stored both whole and in pieces.
    ///
    /// Refused by name rather than half-assembled, because the package does
    /// not determine the part's bytes. **An interleaved package whose pieces
    /// do assemble is read** since tier 4's XPS row: `xps::opc` joins them.
    Interleaved,
    /// A package holding an item that is not a part name (OPC 6.2.2.2) and is
    /// not the content-types item.
    InvalidPartName,
    /// A package holding two part names equal under OPC 6.2.2.3's ASCII case
    /// folding, or one name derivable from another — `/a` beside `/A`, or
    /// `/segment1` beside `/segment1/segment2`.
    ///
    /// Refused rather than resolved to whichever came first, because "whichever
    /// came first" is directory order and directory order is whatever the
    /// producing tool walked.
    AmbiguousPartNames,
    /// An XPS whose fixed payload names no page: a `FixedDocumentSequence` that
    /// will not read or names no document, or a document set that names no
    /// `PageContent` between them.
    ///
    /// There is no page to degrade *to*, which is the one thing that separates
    /// this from every page-level defect in [`crate::xps::XpsPageDefect`].
    NoFixedPages,
    /// An OCF container whose own `META-INF` will not read (gap 31, milestone
    /// 3).
    ///
    /// `META-INF/container.xml` is present — that is what routed the archive
    /// here — and is not the file OCF 3.3 §4.2.6.3.1 defines: markup that is
    /// not well formed, a root element that is not `container`, no `rootfile`
    /// naming a package document, or a `full-path` that is not a container path
    /// under §4.2.3. An `encryption.xml` that will not read lands here too,
    /// because it is the other reserved file this build acts on.
    ///
    /// **This is a sentence about a book**, which is the whole point of gap
    /// 31's milestone 3: before it, such a file opened as however many images
    /// it happened to hold.
    UnreadableContainer,
    /// A container naming a package document the book does not hold (gap 31,
    /// milestone 3).
    ///
    /// Distinct from [`ArchiveRefusal::UnreadableContainer`] because the two
    /// blame different halves of the file, and because the difference is the
    /// **only** observable consequence of resolving §4.2.6.3.1's `full-path`
    /// against the container root rather than against `META-INF/`. A build that
    /// resolved it against the referring document returns this for every real
    /// book ever written.
    RootfileMissing,
    /// A book whose resources are encrypted rather than obfuscated (gap 31,
    /// milestone 3).
    ///
    /// `META-INF/encryption.xml` names an algorithm that is not one of OCF's
    /// two font obfuscations — or names none at all, which XML Encryption
    /// permits and this build cannot agree to. Refused rather than paginated
    /// into placeholders: a complete-looking book of nothing is the failure gap
    /// 17 spent itself on.
    ///
    /// **Not** [`ArchiveRefusal::Encrypted`], which is a sentence about a comic
    /// archive whose every page entry the ZIP reader refused.
    EncryptedResources,
    /// An EPUB: recognised, read as far as its container goes, and not laid out
    /// (gap 31, milestone 3).
    ///
    /// A reflowable book has no pages until something paginates it, and gap
    /// 31's milestones 4 to 12 are that engine. Milestone 3 returned this for
    /// **every** valid book; milestone 4 gave the spine its pages, so nothing
    /// in this build returns it any more.
    ///
    /// It is kept rather than removed for the reason
    /// [`ArchiveRefusal`]'s `#[non_exhaustive]` exists: a caller that matched on
    /// it should not fail to compile because a milestone landed, and the doc
    /// comment is where the history goes. A future build that meets a book it
    /// recognises and cannot paginate at all may return it again.
    UnpaginatedBook,
    /// A book whose package document will not read (gap 31, milestone 4).
    ///
    /// `container.xml` named it and the container holds it, and it is not the
    /// file EPUB 3.3 §5.4 defines: markup that is not well formed, a root
    /// element that is not `package` in the OPF namespace, or a document
    /// carrying no `<manifest>` or no `<spine>`.
    ///
    /// **Not** [`ArchiveRefusal::UnreadablePackage`], which is gap 30's and is a
    /// sentence about an *OPC* package — a different format's word for a
    /// different file. Milestone 1 measured 0 of 26 books carrying OPC's two
    /// items, so the two can never both be true of one archive, and collapsing
    /// them would tell a caller a book is an XPS.
    UnreadablePackageDocument,
    /// A package document declaring a version this build does not read (gap 31,
    /// milestone 4).
    ///
    /// §5.4.1's `version` is required and this build reads `2.0` and `3.x`.
    /// **An absent attribute lands here too**, and the two are one refusal
    /// because the consequence is identical: nothing can know which vocabulary
    /// the markup is written in, and guessing 3.0 for an EPUB 4 is how a reader
    /// silently mis-reads a format it has never seen.
    UnsupportedPackageVersion,
    /// A package document whose spine holds no `itemref` (gap 31, milestone 4).
    ///
    /// §5.7.2 requires at least one, and a book with an empty spine has no
    /// reading order at all. Refused rather than opened as zero pages, for
    /// [`ArchiveRefusal::NoImages`]'s reason: a host that asks for the page
    /// count, gets 0 and has no error to show has been handed a failure dressed
    /// as a success.
    EmptySpine,
}

impl core::fmt::Display for ArchiveRefusal {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str(match self {
            ArchiveRefusal::NotAZip => "a container this build does not read",
            ArchiveRefusal::Damaged => "the archive is damaged past recovery",
            ArchiveRefusal::Encrypted => "every entry that could be a page is encrypted",
            ArchiveRefusal::MultiDisk => "a spanned or multi-disk archive",
            ArchiveRefusal::Zip64OutOfBounds => "a Zip64 value the archive cannot contain",
            ArchiveRefusal::NoImages => "a valid archive with no image entries",
            ArchiveRefusal::TooLarge => "the archive is past a bound this build enforces",
            ArchiveRefusal::UnreadablePackage => {
                "an XPS package whose own structure could not be read"
            }
            ArchiveRefusal::Interleaved => "an interleaved part whose pieces do not assemble",
            ArchiveRefusal::InvalidPartName => "an item that is not a part name",
            ArchiveRefusal::AmbiguousPartNames => "two part names one package may not both hold",
            ArchiveRefusal::NoFixedPages => "a fixed payload that names no page",
            ArchiveRefusal::UnreadableContainer => {
                "an OCF container whose META-INF could not be read"
            }
            ArchiveRefusal::RootfileMissing => {
                "a container naming a package document the book does not hold"
            }
            ArchiveRefusal::EncryptedResources => {
                "a book whose resources are encrypted rather than obfuscated"
            }
            ArchiveRefusal::UnpaginatedBook => {
                "an EPUB, which this build recognises and does not lay out yet"
            }
            ArchiveRefusal::UnreadablePackageDocument => {
                "a book whose package document could not be read"
            }
            ArchiveRefusal::UnsupportedPackageVersion => {
                "a package version this build does not read"
            }
            ArchiveRefusal::EmptySpine => "a book whose spine names no content at all",
        })
    }
}

/// An image format recognised by its magic bytes.
///
/// Classification is **never** by extension: a `.jpg` that is a PNG is routine,
/// and an extension is a claim where the first bytes of a file are a fact.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum ImageFormat {
    /// JFIF/EXIF JPEG. Read.
    Jpeg,
    /// PNG. Read.
    Png,
    /// GIF, 87a or 89a. Read — see `tinker_pdf_cos::gif_image`: the first
    /// image, decoded, because a GIF's LZW is not `/LZWDecode`'s, and kept
    /// `/Indexed` with its transparent index as a colour-key mask.
    Gif,
    /// WebP. Read — see `tinker_pdf_cos::webp_image`: RFC 9649's lossless
    /// bitstream or RFC 6386's lossy one with its `ALPH`, decoded, and the
    /// first frame of an animation.
    WebP,
    /// Windows bitmap. Read — see [`bmp_image`]: decoded, because no
    /// `/Filter` reads a bottom-up, four-byte-padded pixel array or either of
    /// its RLE codings, and kept `/Indexed` when the file was.
    Bmp,
    /// TIFF, either byte order, classic or BigTIFF. Read — see
    /// `tinker_pdf_cos::tiff_image`, which places a single-strip G3, G4, LZW,
    /// DEFLATE, JPEG or JPEG 2000 file's own bytes and decodes the rest — and
    /// paged: every directory that is a page is a page of its own.
    Tiff,
    /// AVIF. Not read here.
    Avif,
    /// JPEG 2000, in the JP2 wrapper or as a bare codestream. Read on the
    /// comic path since tier 4's archive row: placed as a `/JPXDecode` stream
    /// with its own bytes, its header read for the page's size. An EPUB
    /// `<img>` still does not take it — it is not one of EPUB 3.3 §3.2's core
    /// image media types.
    Jpeg2000,
}

/// Why an XHTML `<img>` did not become a replaced box on the page.
///
/// **Four arms and not a string**, because each of them is a different party's
/// fault and a host acts on them differently: the book is wrong in the first,
/// the book is beyond this build in the second and third, and this build is
/// wrong -- or the bytes are -- in the fourth.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum ImageDefect {
    /// `src` is absent or empty, or it resolves to a path the container holds
    /// no entry for, or the entry would not inflate.
    Unresolved,
    /// A format recognised by its magic bytes and not placed here, named rather
    /// than collapsed.
    ///
    /// An EPUB `<img>` reaches the page through **JPEG, PNG, GIF and WebP**,
    /// EPUB 3.3 §3.2's four core raster media types, so no core raster type
    /// lands here any more. What does — BMP, TIFF, JPEG 2000, AVIF — are
    /// foreign resources a §3.2-conforming book may only use behind a
    /// manifest fallback this build does not follow, so they are named
    /// rather than decoded even where the comic path would read them.
    UnsupportedFormat(ImageFormat),
    /// Bytes whose leading magic matches no format [`image_format`] knows.
    ///
    /// **This is where an SVG lands**, and it is where it belongs: an SVG is
    /// XML and has no magic number, so the classifier that refuses to read an
    /// extension as a fact cannot recognise one. `<img src="cover.svg">` is a
    /// core media type this build places only as a **spine item** -- see
    /// [`ArchiveWarning::Svg`] -- and never as a replaced box.
    Unknown,
    /// A JPEG or a PNG whose bytes would not make an image: an unreadable
    /// header, a colour type outside Table 11.1, a zero dimension, a raster
    /// past the ceiling. [`PageDefect::Undecodable`]'s sentence, one container
    /// along.
    Undecodable,
}

/// Why a page is a placeholder rather than the picture the archive holds.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[non_exhaustive]
pub enum PageDefect {
    /// An image format this build does not read, named rather than collapsed.
    UnsupportedFormat(ImageFormat),
    /// The archive would not hand the entry's bytes over: encrypted, a
    /// checksum failure, a truncation, a compression method not read here.
    EntryRefused(ZipEntryError),
    /// The **tar** would not hand the entry's bytes over: a sparse file, a
    /// multi-volume continuation, an entry that holds no file data, or an
    /// archive that ends before the entry does (tier 4, W-ARCHIVE milestone
    /// 2).
    ///
    /// A second variant rather than a widened first one, and the shape is
    /// [`ArchiveWarning::Zip`]'s: each container's own reader keeps its own
    /// vocabulary and the facade carries it verbatim. Flattening four
    /// containers' answers into one namespace is what made
    /// [`ArchiveRefusal`] a twenty-variant union of which only seven are
    /// comic-reachable, and this is that not repeated one level down.
    TarEntryRefused(TarEntryError),
    /// The **7z** would not hand the entry's bytes over: a block that would
    /// not decompress, a coder this build does not read, an entry whose
    /// recorded CRC-32 does not match (tier 4, W-ARCHIVE milestone 3).
    ///
    /// The CRC arm is the one worth naming. Every other container here refuses
    /// an entry because it could not *find* the bytes; 7z refuses one because
    /// it found them and the archive's own checksum says they are wrong —
    /// which is the format adjudicating this engine's LZMA decoder, and the
    /// whole reason a hand-rolled decompressor could be written without an
    /// oracle to check it against.
    SevenZipEntryRefused(SevenZipEntryError),
    /// The **RAR** would not hand the entry's bytes over (tier 4, W-ARCHIVE
    /// milestone 4).
    ///
    /// [`RarEntryError::Compressed`] is the variant that matters and it is the
    /// reason this is a page defect rather than an archive refusal: this build
    /// reads RAR 5's method 0 and not its methods 1 to 5, so an archive that
    /// mixes them pages the stored entries and puts a placeholder where the
    /// others are (ruling 2). `docs/design/comic-archives.md` argues why the
    /// algorithm is not written: the fixture this repository can produce
    /// stores every entry, so a decoder for it would have nothing first-party
    /// to be held to.
    RarEntryRefused(RarEntryError),
    /// The bytes are a JPEG, a PNG, a TIFF or a JPEG 2000 file and could not
    /// be made into an image — an unreadable header, a colour type outside
    /// Table 11.1, a JPEG 2000 header this build's decoder refuses, a raster
    /// past the ceiling.
    Undecodable,
}

/// What synthesising a document from an archive tolerated (ruling 10).
///
/// Recorded at open, because open is where the knowledge is: by the time a page
/// is rendered the entry it came from is gone.
#[derive(Clone, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum ArchiveWarning {
    /// What the archive reader tolerated, carried verbatim.
    Zip(ZipWarning),
    /// What the **tar** reader tolerated, carried verbatim (tier 4, W-ARCHIVE
    /// milestone 2): a header that did not checksum and ended the walk, a name
    /// that is not UTF-8, an archive with no end-of-archive blocks.
    Tar(TarWarning),
    /// What the **7z** reader tolerated, carried verbatim (tier 4, W-ARCHIVE
    /// milestone 3): a name that is not valid UTF-16, a header property this
    /// build does not act on, an entry the archive recorded no CRC-32 for.
    SevenZip(SevenZipWarning),
    /// What the **RAR** reader tolerated, carried verbatim (tier 4, W-ARCHIVE
    /// milestone 4): a header that did not checksum and ended the walk, a name
    /// that is not UTF-8, an entry with no recorded CRC-32.
    Rar(RarWarning),
    /// An entry that is an image became a placeholder page. **The page count
    /// and every page number after it are unchanged**, which is the whole
    /// reason the entry was not dropped.
    PlaceholderPage {
        /// Zero-based page index.
        page: u32,
        /// Why.
        defect: PageDefect,
    },
    /// The image reached the page and something about it was degraded: a
    /// raster short by whole rows, a dropped ancillary chunk, a file that
    /// stopped before its end marker.
    DegradedImage {
        /// Zero-based page index.
        page: u32,
    },
    /// A `ComicInfo.xml` is present and did not become the document's `/Info`
    /// (tier 4, W-ARCHIVE milestone 1).
    ///
    /// **No page is affected**, which is what separates this from every other
    /// variant here: the document is every page the archive holds either way,
    /// and this says only that it opened without the title it was carrying.
    /// Warned rather than silent for ruling 10's reason — an archive with no
    /// `ComicInfo.xml` at all produces no warning, so "no title" and "a title
    /// this build could not read" stay distinguishable.
    ComicInfo(ComicInfoDefect),
    /// A synthesised **fixed page** is a placeholder rather than the picture
    /// the package holds (gap 30, milestone 3).
    ///
    /// The page keeps its number and its neighbours' size, for
    /// [`ArchiveWarning::PlaceholderPage`]'s reason: dropping it renumbers
    /// every page after it and a reader sees a document that jumps.
    XpsPage {
        /// Zero-based page index.
        page: u32,
        /// Why.
        defect: crate::xps::XpsPageDefect,
    },
    /// One **element** of a fixed page is not the picture its markup describes
    /// (gap 30, milestone 6).
    ///
    /// Distinct from [`ArchiveWarning::XpsPage`] because the two are different
    /// claims: the page one says *this page is a placeholder*, and this one
    /// says *this page drew, and this much of it did not*. A page whose
    /// `Glyphs` are not painted yet and whose paths are is exactly that, and
    /// collapsing the two would make a page that mostly worked
    /// indistinguishable from one that did not open.
    ///
    /// **Deduplicated per page**: a page of ten thousand `Glyphs` runs has one
    /// thing wrong with it and not ten thousand.
    XpsElement {
        /// Zero-based page index.
        page: u32,
        /// Why.
        defect: crate::xps::XpsElementDefect,
    },
    /// What OCF 3.3 §4.3.2 tolerated about a book's container (gap 31,
    /// milestone 4).
    ///
    /// Milestone 3 could compute every one of these and had **nowhere to put
    /// them**: a refused book carries no [`ArchiveReport`], so
    /// [`crate::epub::ocf::OcfWarning`] was reachable only by opening the
    /// container by hand. This is the commit that gives a book a report to carry
    /// them in, and closing that is why the variant is a carrier rather than a
    /// second spelling of the same five clauses.
    Ocf(crate::epub::ocf::OcfWarning),
    /// What EPUB 3.3 §5.5.3.1 and §5.6.1 tolerated about a book's package
    /// document (gap 31, milestone 4).
    Package(crate::epub::package::PackageDefect),
    /// A shaped text run could not be written into a page's content stream,
    /// so the words it carried are on no page (milestone 6 of
    /// `docs/design/shaping.md`).
    ///
    /// `DocumentBuilder::glyph_run` refuses a run whose font is not a
    /// registered composite one, whose size is not a number a content stream
    /// can carry, or whose placements are not finite — and a writer that
    /// refused in silence would leave a page short of a word with nothing
    /// anywhere saying so, which is ruling 10's whole subject. Counted rather
    /// than reported once per run, for
    /// [`ArchiveWarning::UnimplementedFeature`]'s reason.
    ///
    /// **Distinct from [`ArchiveWarning::UnrepresentedCharacters`]**: that one
    /// says a character had no code in any font, and this one says the code
    /// existed and the operators did not reach the page.
    UnwritableTextRun {
        /// How many shaped runs were refused.
        runs: usize,
    },
    /// A synthesised **spine page** is a placeholder rather than the chapter it
    /// stands for (gap 31, milestone 4).
    ///
    /// The page keeps its number and the book's page box, for
    /// [`ArchiveWarning::PlaceholderPage`]'s reason with more force: dropping a
    /// spine item does not renumber a page, it **removes a chapter**, and a book
    /// that jumps from chapter 4 to chapter 6 reads as a bad conversion rather
    /// than as a bug.
    ///
    /// **Every page of every book carries one at milestone 4**, because there
    /// is no layout engine yet and a page that draws nothing while saying
    /// nothing is a book of blank paper reported as a success.
    SpinePage {
        /// Zero-based page index.
        page: u32,
        /// Why.
        defect: crate::epub::SpineDefect,
    },
    /// A §5.6.2 manifest property naming behaviour this build does not have,
    /// with the number of manifest items carrying it (gap 31, milestone 4).
    ///
    /// **Deduplicated per book and counted**, which is gap 31's third honesty
    /// device rather than a convenience: the fetched corpus holds a book with
    /// seventy-one `mathml` items, and seventy-one identical warnings would
    /// destroy the distinction between "it opened" and "it opened cleanly"
    /// before anybody had looked at one.
    UnimplementedFeature {
        /// Which property.
        property: crate::epub::package::Property,
        /// How many manifest items carry it.
        items: u32,
    },
    /// A number the **caller** passed in [`crate::OpenOptions`] could not be
    /// used, and the default was laid out instead (gap 31, milestone 4).
    ///
    /// Not a claim about the file, which is why it is not an
    /// [`ArchiveRefusal`]: a host that passes a page width of `NaN` should still
    /// get its book, and should be told which of its numbers was thrown away.
    UnusableOption(crate::epub::BookOptionDefect),
    /// A font provider was attached **after** the book was paginated (gap 31,
    /// milestone 4).
    ///
    /// [`crate::Document::with_fonts`] arrives after `open`, and a reflowable
    /// book's line breaks — and therefore its page count — were decided at
    /// `open` from the metrics available then. The provider still supplies
    /// glyphs, so the text draws; what it cannot do is re-paginate.
    ///
    /// **Silently accepting it is the failure this warning exists for.**
    /// `crate::OpenOptions::fonts` is where a provider goes if it is to decide
    /// anything, and this is the sentence that says the late one did not.
    FontsAttachedAfterPagination,
    /// A content document's markup could not be read to the end, or had no
    /// element in it at all (gap 31, milestone 8).
    ///
    /// The chapter is **kept** with whatever tree the reader got to, which is
    /// ruling 2 rather than laziness: a book whose last chapter has one
    /// unescaped `&` in its last paragraph should lose that paragraph and not
    /// the chapter. The item is named because a book has many of them and
    /// "some markup was truncated" is not something a host can act on.
    Markup {
        /// The container path of the content document.
        item: String,
        /// Which failure.
        defect: crate::epub::xhtml::MarkupDefect,
    },
    /// What an SVG content document asked for that this build did not draw
    /// (Tier 4's SVG lane, milestone 7).
    ///
    /// Carried verbatim from `tinker_pdf_svg::Warning`, deduplicated **per
    /// document** by the crate that produced it — so a cover with four hundred
    /// `<animate>` elements is one sentence and not four hundred. The item is
    /// named because a book has many of them and *"a filter was not drawn"* is
    /// not something a host can act on.
    Svg {
        /// The container path of the SVG content document.
        item: String,
        /// What it asked for.
        warning: tinker_pdf_svg::Warning,
    },
    /// An `<image>` inside an SVG content document whose reference this build
    /// did not resolve into a picture, with the number of them on that page.
    ///
    /// Distinct from [`ArchiveWarning::Svg`] because the two blame different
    /// halves: that one is a capability this build does not have, and this one
    /// is a reference that named nothing the container holds, or bytes in a
    /// format this build does not decode. A page short of a photograph is a
    /// page a host should be told about either way.
    SvgImageUnresolved {
        /// The container path of the SVG content document.
        item: String,
        /// How many references on that page did not resolve.
        images: usize,
    },
    /// An `<img>` in an XHTML content document that **did not become a box on
    /// the page**, with the number of them in that document that failed the
    /// same way.
    ///
    /// The ruling 10 companion to [`ArchiveWarning::SvgImageUnresolved`], which
    /// is an SVG `<image>` and only that. The two are separate variants because
    /// the two elements are read by different halves of this reader — one is a
    /// display list drawn onto a page and the other is a replaced box in a flow
    /// — and a host told only that *"an image did not resolve"* could not say
    /// which of the two to look at.
    ///
    /// **A refusal here is a page with nothing where a picture was**, and the
    /// hole is invisible: HTML §4.8.4.4 makes an `<img>` a replaced element
    /// *"only when the image is available"*, so an unavailable one generates no
    /// box at all and the text around it closes over the gap. Nothing about the
    /// page says a picture was meant to be there, which is precisely why this
    /// says it.
    ImageNotDrawn {
        /// The container path of the content document the `<img>` is in.
        item: String,
        /// Why it did not reach the page.
        defect: ImageDefect,
        /// How many `<img>` elements in that document failed that way.
        images: usize,
    },
    /// A `background-image` (`css-backgrounds-3` §2.2) that did not reach the
    /// page: its `url()` named nothing the container holds, or bytes that are
    /// no picture this build reads.
    ///
    /// [`ArchiveWarning::ImageNotDrawn`]'s companion for the picture a
    /// stylesheet names, and invisible the same way: the box keeps its colour
    /// and border and loses only the image, so the page looks finished.
    BackgroundImageNotDrawn {
        /// The content document whose boxes asked for the image.
        item: String,
        /// Why it did not reach the page.
        defect: ImageDefect,
        /// How many elements in that document asked for an image that failed
        /// that way.
        elements: usize,
    },
    /// A `<link rel="stylesheet">` whose `href` produced no sheet, so the
    /// document was set **without rules its author wrote** (tier 5's formats
    /// row).
    ///
    /// The companion to [`ArchiveWarning::ImageNotDrawn`] for the other
    /// reference a content document makes, and invisible in the same way: the
    /// page is set by the user-agent sheet and looks finished. A book names an
    /// entry its container does not hold; a loose XHTML file opened from its
    /// bytes alone has nothing beside it at all, so every sheet it links lands
    /// here.
    StylesheetUnresolved {
        /// The content document that links the sheets.
        item: String,
        /// How many of its `<link>` elements did not resolve.
        sheets: usize,
    },
    /// What translating a Markdown or FB2 document into the reader's tree had
    /// to do (tier 5's formats rows), with how many times.
    ///
    /// Distinct from [`ArchiveWarning::Markup`], which is the XML reader
    /// stopping: this is the step before it, deciding what of a language that
    /// is not XHTML arrives as XHTML — and the cases where it arrives as
    /// something else are what a host is told.
    Translation {
        /// The document translated (empty for one opened from bytes alone).
        item: String,
        /// What was done.
        defect: crate::standalone::TranslationDefect,
        /// How many times.
        count: usize,
    },
    /// A CSS property this build does not implement, and **how many elements
    /// it reached** (gap 31, milestone 8).
    ///
    /// **This is the census, and it is the number this reader is judged on.**
    /// Decision 5 makes a property a parser variant only when a consumer
    /// exists; everything else is `Unsupported` by name, and this is where that
    /// name reaches a caller. Counted by element rather than by declaration
    /// because `float`, unimplemented, affecting 412 elements is a sentence a
    /// host can show and four hundred identical warnings is not — and because a
    /// rule that matched nothing is not a gap the book noticed.
    UnimplementedProperty {
        /// The property's name, as a specification spells it.
        property: &'static str,
        /// How many elements it reached.
        elements: usize,
    },
    /// What `tinker-pdf-layout` could not honour, deduplicated with a count
    /// (gap 31, milestone 8).
    ///
    /// Distinct from [`ArchiveWarning::UnimplementedProperty`] because the two
    /// answer different questions: that one says a property was never
    /// implemented, and this one says a property that *is* implemented met a
    /// case this build does not lay out — a float, a line with nowhere to
    /// break, content wider than the page.
    Layout {
        /// Which one.
        warning: tinker_pdf_layout::Warning,
        /// How many times it fired.
        count: usize,
    },
    /// Characters that could not be given a code in any font this document
    /// carries, and are therefore on no page (gap 31, milestone 8).
    ///
    /// A simple font has 256 codes, so a book with more than 224 distinct
    /// characters outside `WinAnsiEncoding` for one standard face loses the
    /// excess — of the characters no embedded face covers and, in a
    /// `bundled-fonts` build, that the face's Liberation stand-in does not
    /// cover either: what the stand-in covers is drawn in it as a composite
    /// font, which has a code for every glyph. **Reported rather than
    /// dropped silently**, because text that is missing from a page and
    /// missing from `Page::text()` is exactly what text conservation exists to
    /// find, and a build that lost it without saying so would be a build whose
    /// own harness had to catch it.
    UnrepresentedCharacters {
        /// How many characters.
        characters: usize,
    },
    /// Characters drawn in a face that has no glyph for them, so the page shows
    /// a notdef where the text is (gap 31, milestone 9).
    ///
    /// **A different fact from [`ArchiveWarning::UnrepresentedCharacters`]**,
    /// and the two are kept apart because a host can act on one and not the
    /// other: an unrepresented character is missing from the picture *and* from
    /// `Page::text()`, and an uncovered one is missing from the picture and
    /// present in the text — so the book is still searchable and still wrong to
    /// look at. Milestone 8 reported only the first, and a notdef went
    /// unwarned; row 9 asks for *"a character no available face covers
    /// producing a named warning rather than a blank"*, and this is it.
    ///
    /// Counted per occurrence rather than per distinct character, because the
    /// number a host wants is how much of the book is blank.
    UncoveredCharacters {
        /// How many characters.
        characters: usize,
    },
    /// An `@font-face` did not become a usable face, with the family it named
    /// and why (gap 31, milestone 9).
    ///
    /// **Deduplicated per family and defect**, for
    /// [`ArchiveWarning::UnimplementedFeature`]'s reason: a book that declares
    /// one family across thirteen chapters' stylesheets would otherwise produce
    /// thirteen identical warnings, and a book whose fonts are all WOFF2 would
    /// bury the one sentence a producer needs under a list.
    FontFace {
        /// The `font-family` the rule declared, as the sheet wrote it.
        family: String,
        /// Why no face came of it.
        defect: crate::epub::typeface::FaceDefect,
        /// How many rules met this.
        rules: usize,
    },
    /// A spine item is EPUB 3.3 §8.2's `pre-paginated` and states no
    /// §8.2.2.6 viewport, so its page is the caller's box (gap 31, milestone
    /// 12).
    ///
    /// **The spine rule still holds** — the item is one page, which is EPUB RS
    /// 3.3 §8.1's *"exactly one page per spine itemref"* — and what is missing
    /// is the *size* of that page. A fixed-layout document laid into a page it
    /// was not designed for is a picture of the right content at the wrong
    /// scale, which looks like a rendering bug rather than like a book with no
    /// viewport in it.
    FixedLayoutWithoutViewport {
        /// The container path of the content document.
        item: String,
    },
    /// A pre-paginated content document's content did not fit its initial
    /// containing block and was **clipped** (gap 31, milestone 12).
    ///
    /// EPUB RS 3.3 §8.1.2 makes the viewport the initial containing block and
    /// clips what falls outside it, and §8.1 forbids the second page a
    /// reflowable document would get. So the characters are gone from the page
    /// *and* from `Page::text()`, which is exactly the shape
    /// [`ArchiveWarning::UnrepresentedCharacters`] has and the reason this is
    /// counted in characters rather than reported as a flag: text conservation
    /// is an equality, and a book that lost text without saying so would be a
    /// build whose own harness had to catch it.
    FixedLayoutContentClipped {
        /// The container path of the content document.
        item: String,
        /// How many characters did not fit.
        characters: usize,
    },
    /// The book has a table of contents and this build could not write it as
    /// an outline (gap 31, milestone 8).
    ///
    /// `DocumentBuilder::set_outline` refuses a tree **this repository's own
    /// reader** could not read back — deeper than `MAX_NEST_DEPTH`, or a level
    /// with more than `MAX_TREE_ENTRIES` siblings. A document written with an
    /// outline it cannot read is worse than one written with none, and this is
    /// the sentence that says which happened.
    OutlineUnwritable,
    /// Language declarations this build did not carry into the structure
    /// tree as `/Lang` (ISO 32000-1 14.9.2), because they are not shaped like
    /// a language tag — `en_US`, a stray space, a script name with no
    /// language before it.
    ///
    /// Counted per document: an `xml:lang` or `lang` attribute of a content
    /// document, or the package document's `dc:language`, which would have
    /// been the catalog's `/Lang`. The text is still drawn and still tagged;
    /// what it lacks is a statement of its language, which a reader then
    /// takes from the nearest ancestor that made one.
    LanguageTagIgnored {
        /// The container path of the content document, or of the package
        /// document for its `dc:language`.
        item: String,
        /// How many declarations were not written.
        tags: usize,
    },
    /// Element names this build wrote as their standard structure type
    /// rather than as themselves, because the document's `/RoleMap` (ISO
    /// 32000-1 14.7.3) already held `MAX_DICT_ENTRIES` names — the most
    /// entries of one dictionary this engine's reader keeps, so a mapping
    /// past it would be written and then dropped on read, and its elements
    /// would read as types no standard defines.
    ///
    /// Counted per content document. The elements are still tagged and still
    /// say what they are; what they lose is the book's own name for it.
    ElementNamesUnmapped {
        /// The container path of the content document.
        item: String,
        /// How many distinct element names were written as their standard
        /// type.
        names: usize,
    },
}

/// Where one page came from.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PageOrigin {
    /// The archive entry's stored path, as the archive spelled it.
    pub name: String,
    /// `None` when the page is the entry's own picture.
    pub defect: Option<PageDefect>,
}

/// What a document synthesised from a container cost, and where its pages came
/// from.
///
/// Reachable through [`crate::Document::archive`], and `None` for an ordinary
/// PDF — which is how a caller tells the two apart without guessing from the
/// bytes it handed in.
#[derive(Clone, Debug)]
pub struct ArchiveReport {
    warnings: Vec<ArchiveWarning>,
    pages: Vec<PageOrigin>,
    synthesised_bytes: usize,
    dialect: Option<crate::xps::Dialect>,
    parsed_parts: usize,
    layout: Option<crate::epub::BookLayout>,
    cost: Option<crate::epub::BookCost>,
    /// Boxed, and the reason is measured rather than stylistic: six
    /// `Option<String>`s inline push this struct past the point where
    /// `clippy::large_enum_variant` fires on `xps::Routing` and
    /// `epub::Routing`, which carry it by value and are returned from every
    /// route decision. One allocation on the rare path is the cheaper half of
    /// that trade — an XPS package and a book never build one at all.
    info: Option<Box<ComicInfo>>,
}

impl ArchiveReport {
    /// Builds a report. `pub(crate)` because the three synthesisers are the only
    /// things that can honestly fill one in.
    pub(crate) fn synthesised(
        warnings: Vec<ArchiveWarning>,
        pages: Vec<PageOrigin>,
        synthesised_bytes: usize,
        dialect: Option<crate::xps::Dialect>,
        parsed_parts: usize,
    ) -> ArchiveReport {
        ArchiveReport {
            warnings,
            pages,
            synthesised_bytes,
            dialect,
            parsed_parts,
            layout: None,
            cost: None,
            info: None,
        }
    }

    /// Records what a comic archive's `ComicInfo.xml` said (tier 4, W-ARCHIVE
    /// milestone 1).
    ///
    /// A setter rather than a sixth parameter on [`ArchiveReport::synthesised`],
    /// because that constructor is the *fixed document* path's too and an XPS
    /// package holds no such file: a parameter every XPS call site had to pass
    /// `None` for would be a field pretending to be a question both formats
    /// answer.
    pub(crate) fn with_comic_info(mut self, info: Option<ComicInfo>) -> ArchiveReport {
        self.info = info.map(Box::new);
        self
    }

    /// Builds a report for a **reflowable book** (gap 31, milestone 4).
    ///
    /// A separate constructor rather than a sixth parameter on the one above,
    /// because the two describe different things: a comic and a fixed document
    /// have a page geometry the file states, and a book has one the caller
    /// chose. [`ArchiveReport::layout`] is `Some` exactly for the second, which
    /// is what [`crate::Document::with_fonts`] keys on.
    pub(crate) fn book(
        warnings: Vec<ArchiveWarning>,
        pages: Vec<PageOrigin>,
        synthesised_bytes: usize,
        layout: crate::epub::BookLayout,
        cost: crate::epub::BookCost,
    ) -> ArchiveReport {
        ArchiveReport {
            warnings,
            pages,
            synthesised_bytes,
            cost: Some(cost),
            dialect: None,
            // No markup part is *cached* by the book path the way gap 30's is —
            // the OCF layer reads each entry once and the package document is
            // one file — so this stays the comic path's honest zero rather than
            // acquiring a second meaning.
            parsed_parts: 0,
            layout: Some(layout),
            info: None,
        }
    }

    /// Adds a warning after the fact.
    ///
    /// The one thing that legitimately happens after synthesis is a caller
    /// attaching a font provider too late to change the pagination, and saying
    /// so is [`ArchiveWarning::FontsAttachedAfterPagination`]'s whole job.
    pub(crate) fn warn(&mut self, warning: ArchiveWarning) {
        self.warnings.push(warning);
    }

    /// Everything tolerated, in the order it happened.
    #[must_use]
    pub fn warnings(&self) -> &[ArchiveWarning] {
        &self.warnings
    }

    /// Which spelling of XPS this document was, or `None` for a comic archive.
    ///
    /// Public because gap 30's decision 3 is a claim a caller should be able to
    /// check rather than take on trust: the two dialects carry **byte-identical
    /// content types**, which milestone 1 measured, so the namespace is the
    /// only discriminator there is and this is where the answer it reached
    /// comes out.
    #[must_use]
    pub fn xps_dialect(&self) -> Option<crate::xps::Dialect> {
        self.dialect
    }

    /// One entry per page, in page order.
    #[must_use]
    pub fn pages(&self) -> &[PageOrigin] {
        &self.pages
    }

    /// How many bytes the synthesised document is.
    ///
    /// Public because a bound nobody can measure is a bound nobody can check:
    /// this is what the [`MAX_SYNTHESISED_PDF`] ledger's first column is read
    /// from, rather than asserted about in prose.
    #[must_use]
    pub fn synthesised_bytes(&self) -> usize {
        self.synthesised_bytes
    }

    /// How many parts' markup was parsed while the document was synthesised
    /// (gap 30, milestone 4).
    ///
    /// **Zero for a comic archive**, and that is a real answer rather than a
    /// placeholder: this counts the parts a *fixed document*'s payload cache
    /// was asked for, and the comic path has no such cache. A comic archive
    /// does now parse markup — one entry of it, through
    /// [`comic_info::parse`] — and it is deliberately not counted here, because
    /// a second meaning on a counter is how a number stops answering the
    /// question it was published for. [`ArchiveReport::comic_info`] is where
    /// that read comes out.
    ///
    /// For an XPS this is the count of **distinct parts**, not of references to
    /// them, and it is published for the same reason
    /// [`ArchiveReport::synthesised_bytes`] is. `crate::xps::Payload` caches a
    /// parse per part because `Source::new` walks the whole part before it
    /// yields an event, so a fixed document naming one page four thousand times
    /// would otherwise scan it four thousand times — and nothing else about the
    /// document would change, so a test with no counter to read could not tell
    /// the cache from its own absence.
    #[must_use]
    pub fn parsed_parts(&self) -> usize {
        self.parsed_parts
    }

    /// What a comic archive's `ComicInfo.xml` said, or `None` when it held
    /// none, held one this build could not read, or is not a comic archive
    /// (tier 4, W-ARCHIVE milestone 1).
    ///
    /// Published for [`ArchiveReport::synthesised_bytes`]'s reason: the fields
    /// reach the document's `/Info` and a caller that wanted to know *which*
    /// of them did would otherwise have to re-derive the mapping from the
    /// dictionary it produced. The three ways to get `None` are told apart by
    /// [`ArchiveWarning::ComicInfo`], which names the last two and is absent
    /// for the first.
    #[must_use]
    pub fn comic_info(&self) -> Option<&ComicInfo> {
        self.info.as_deref()
    }

    /// The page box and base font size a **reflowable** book was laid out at,
    /// or `None` for a document whose geometry its own file states (gap 31,
    /// milestone 4).
    ///
    /// Public because it is the provenance of the page count. A comic's page
    /// count is a property of the archive and an XPS's is a property of the
    /// package; a book's is a function of the numbers in here, and a caller
    /// looking at `page_count()` has no other way to know which kind of number
    /// it is holding.
    #[must_use]
    pub fn layout(&self) -> Option<crate::epub::BookLayout> {
        self.layout
    }

    /// What a **reflowable** book spent against the ten caps its reading path
    /// charges, or `None` for a document whose pages this engine did not lay
    /// out (gap 31, milestone 13).
    ///
    /// Public for [`ArchiveReport::synthesised_bytes`]'s reason, one gap later
    /// and nine caps wider: **a bound nobody can measure is a bound nobody can
    /// check.** `bounds_ledger.rs`'s third yardstick is a 300-page book, and
    /// what stops that column from being a number somebody made up is
    /// `the_book_yardstick_is_not_below_a_real_book`, which opens every book in
    /// both corpora and reads these figures out.
    ///
    /// `None` for a comic archive and for a fixed document, and that is an
    /// answer rather than a gap: neither format has a stylesheet, a box tree or
    /// a caller-chosen page box, so a zero here would claim a measurement that
    /// was never taken.
    #[must_use]
    pub fn book_cost(&self) -> Option<crate::epub::BookCost> {
        self.cost
    }
}

// ---- Ordering ---------------------------------------------------------------

/// Natural order over stored paths, so `page2` precedes `page10`.
///
/// Lexicographic is the obvious wrong answer and it fails invisibly: an archive
/// of `1.jpg` through `12.jpg` reads as 1, 10, 11, 12, 2, 3 … — every page
/// present, every page rendered correctly, and the comic unreadable. A
/// zero-padded archive (`page001.jpg`) sorts identically under both orders, so
/// a fixture with padded names proves **nothing** about this and must say so.
/// The ZIP format is no help: APPNOTE puts no ordering requirement on the
/// central directory.
///
/// Defined in byte arithmetic so ruling 4 holds — a locale-aware or
/// Unicode-collating comparison is a per-platform answer and this engine may
/// not have one.
///
/// - The **full stored path**, not the basename, so directories group.
/// - Split into maximal runs of ASCII digits and maximal runs of everything
///   else, compared run by run.
/// - Two digit runs compare by **length after leading zeros are trimmed, then
///   by those bytes** — never by parsing an integer, because a forty-digit run
///   is a legal filename and `u64::from_str` is not a total function over one.
/// - Any other pairing compares as text: byte by byte with ASCII letters
///   case-folded, then by the unfolded bytes to break the tie.
/// - Runs exhausted first sorts first, and two names that are still equal
///   (`p01` against `p1`) fall back to their raw bytes, so the order is a total
///   one before the caller's own tie-break is reached.
fn natural_cmp(a: &str, b: &str) -> Ordering {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    let (mut i, mut j) = (0usize, 0usize);

    while i < a.len() && j < b.len() {
        // `i < a.len()` and `j < b.len()`, so both index in bounds.
        let a_digit = a[i].is_ascii_digit();
        let b_digit = b[j].is_ascii_digit();
        let next_a = run_end(a, i, a_digit);
        let next_b = run_end(b, j, b_digit);
        let (ra, rb) = (&a[i..next_a], &b[j..next_b]);

        let ord = if a_digit && b_digit {
            digit_cmp(ra, rb)
        } else {
            text_cmp(ra, rb)
        };
        if ord != Ordering::Equal {
            return ord;
        }
        i = next_a;
        j = next_b;
    }

    // One of them ran out of runs: the shorter remainder sorts first.
    (a.len() - i)
        .cmp(&(b.len() - j))
        // Equal run by run and still not the same string — `p01` against `p1`,
        // which the digit rule calls equal on purpose. Raw bytes settle it so
        // the comparison is total rather than leaving two names unordered.
        .then_with(|| a.cmp(b))
}

/// Where the run starting at `at` ends: maximal digits, or maximal non-digits.
fn run_end(s: &[u8], at: usize, digits: bool) -> usize {
    let mut end = at;
    while end < s.len() && s[end].is_ascii_digit() == digits {
        end += 1;
    }
    end
}

/// A digit run: magnitude first, then the digits themselves.
fn digit_cmp(a: &[u8], b: &[u8]) -> Ordering {
    let ta = trim_zeros(a);
    let tb = trim_zeros(b);
    ta.len().cmp(&tb.len()).then_with(|| ta.cmp(tb))
}

/// Leading zeros removed. All-zero trims to nothing, which is the right
/// magnitude for it.
fn trim_zeros(s: &[u8]) -> &[u8] {
    let mut at = 0usize;
    while at < s.len() && s[at] == b'0' {
        at += 1;
    }
    &s[at..]
}

/// A text run: ASCII case folded, then the unfolded bytes.
fn text_cmp(a: &[u8], b: &[u8]) -> Ordering {
    a.iter()
        .map(u8::to_ascii_lowercase)
        .cmp(b.iter().map(u8::to_ascii_lowercase))
        .then_with(|| a.cmp(b))
}

/// One entry, reduced to the three things paging a comic needs to know about
/// it (tier 4, W-ARCHIVE milestone 2).
///
/// The container-independent half of `tinker_pdf_zip::Entry` and
/// `tinker_pdf_archive::tar::Entry`, and it is a struct in the *facade* rather
/// than a trait in either leaf. That is the crate rule read from this side:
/// the two readers hand back different things and cannot usefully share a
/// signature, so the conversion happens once, here, where the formats already
/// converge — a `Vec` of these per archive, which is the same cost the sort
/// below already pays.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Listing {
    /// The stored path.
    pub(crate) name: String,
    /// Position in the container's own entry list, which is the tie-break.
    pub(crate) index: usize,
    /// Whether the entry holds no file data at all.
    pub(crate) directory: bool,
}

/// The archive's entries in reading order.
///
/// Ties break on the entry's position in the container's own list, which makes
/// the order total: two entries in a ZIP may legally have the same name, and
/// so may two headers in a tar.
fn reading_order(entries: &[Listing]) -> Vec<usize> {
    let mut order: Vec<usize> = (0..entries.len()).collect();
    order.sort_by(|&x, &y| {
        // Both indices come from the range above, so neither `get` can miss;
        // the fallbacks keep the comparison total rather than panicking.
        let (a, b) = (entries.get(x), entries.get(y));
        match (a, b) {
            (Some(a), Some(b)) => natural_cmp(&a.name, &b.name).then_with(|| a.index.cmp(&b.index)),
            _ => x.cmp(&y),
        }
    });
    order
}

/// The container an archive turned out to be, held open (tier 4, W-ARCHIVE
/// milestone 2).
///
/// **An enum and not a trait**, which is `tinker-pdf-archive`'s own rule
/// arriving where it has to be honoured: `tinker_pdf_zip::Archive::read`
/// returns a `Cow` and hands a stored entry back **borrowed**, and
/// `tar::Archive::read` returns a plain borrow. A trait over them would have
/// to return the weakest signature either could satisfy, and the borrow is the
/// property `tinker-pdf-zip`'s own test suite exists to hold — *the moment
/// this copies, a 3.6 GB peak comes back*. So they are matched on, and the
/// `Cow` here is the ZIP reader's own rather than a widening of tar's.
///
/// **`sevenz` is what makes the argument concrete rather than theoretical.** A
/// 7z solid block decodes many files from one LZMA stream, so there is no
/// range of the input that is any one file and its `read` returns owned bytes
/// and takes `&mut self`. A trait over all three would have to be that
/// signature — which would delete the borrow in the two that have it, in order
/// to give three unrelated readers one name.
enum Reader<'a> {
    Zip(Archive<'a>),
    Tar(tar::Archive<'a>),
    SevenZip(sevenz::Archive<'a>),
    Rar(rar::Archive<'a>),
    /// One picture with no archive around it (tier 5's formats row): a bare
    /// image opened by [`crate::standalone`] is the comic of its one entry,
    /// paged by this module's own body rather than by a copy of it.
    Picture(&'a [u8]),
}

impl<'a> Reader<'a> {
    /// Every entry, as the three things paging needs.
    fn listing(&self) -> Vec<Listing> {
        match self {
            Reader::Zip(archive) => archive
                .entries()
                .iter()
                .map(|entry| Listing {
                    name: entry.name.clone(),
                    index: entry.index,
                    // 4.4.17.1: a stored path ending in `/` is a directory
                    // record, which holds no bytes and is not a page.
                    directory: entry.is_directory(),
                })
                .collect(),
            Reader::Tar(archive) => archive
                .entries()
                .iter()
                .map(|entry| Listing {
                    name: entry.name.clone(),
                    index: entry.index,
                    directory: entry.is_directory(),
                })
                .collect(),
            Reader::SevenZip(archive) => archive
                .entries()
                .iter()
                .map(|entry| Listing {
                    name: entry.name.clone(),
                    index: entry.index,
                    directory: entry.is_directory(),
                })
                .collect(),
            Reader::Rar(archive) => archive
                .entries()
                .iter()
                .map(|entry| Listing {
                    name: entry.name.clone(),
                    index: entry.index,
                    directory: entry.is_directory(),
                })
                .collect(),
            // No stored path: a file opened from its bytes has no name, which
            // is also what the page's `PageOrigin` reports.
            Reader::Picture(_) => vec![Listing {
                name: String::new(),
                index: 0,
                directory: false,
            }],
        }
    }

    /// One entry's bytes, or the page-level defect that says why there are
    /// none.
    ///
    /// The mapping into [`PageDefect`] is here rather than at the call site so
    /// that adding a container is one arm rather than a second `match` a
    /// hundred lines away.
    fn read(&mut self, index: usize) -> Result<Cow<'a, [u8]>, PageDefect> {
        match self {
            Reader::Zip(archive) => read_entry(archive, index).map_err(PageDefect::EntryRefused),
            Reader::Tar(archive) => archive
                .read(index)
                .map(Cow::Borrowed)
                .map_err(PageDefect::TarEntryRefused),
            // `Cow::Owned`, and it is the only arm that is: a solid block is
            // many files in one stream. The reader caches the block it last
            // decompressed, so a whole comic out of one block decompresses
            // once rather than once per page.
            Reader::SevenZip(archive) => archive
                .read(index)
                .map(Cow::Owned)
                .map_err(PageDefect::SevenZipEntryRefused),
            // The RAR reader's own `Cow`, carried rather than widened: a
            // stored entry comes back borrowed, which is every entry this
            // build reads.
            Reader::Rar(archive) => archive.read(index).map_err(PageDefect::RarEntryRefused),
            // `listing` names one entry, at index 0, and `pages_from_reader`
            // asks only for indices `listing` handed it.
            Reader::Picture(bytes) => Ok(Cow::Borrowed(*bytes)),
        }
    }

    /// What the container's own reader tolerated, carried verbatim (ruling
    /// 10).
    fn warnings(&self) -> Vec<ArchiveWarning> {
        match self {
            Reader::Zip(archive) => archive
                .warnings()
                .iter()
                .map(|w| ArchiveWarning::Zip(*w))
                .collect(),
            Reader::Tar(archive) => archive
                .warnings()
                .iter()
                .map(|w| ArchiveWarning::Tar(*w))
                .collect(),
            Reader::SevenZip(archive) => archive
                .warnings()
                .iter()
                .map(|w| ArchiveWarning::SevenZip(*w))
                .collect(),
            Reader::Rar(archive) => archive
                .warnings()
                .iter()
                .map(|w| ArchiveWarning::Rar(*w))
                .collect(),
            Reader::Picture(_) => Vec::new(),
        }
    }
}

// ---- Classification ---------------------------------------------------------

/// What the first bytes of an entry say it is.
///
/// Magic bytes and nothing else. An entry matching none of these is not an
/// image and is not a page — `Thumbs.db`, `.DS_Store` and the `__MACOSX/`
/// AppleDouble files all land here, and warning about each of them would bury
/// the warnings that matter.
///
/// `ComicInfo.xml` lands here too and is **not** decided by this function: the
/// synthesiser takes it by name before classification is reached
/// ([`comic_info::is_comic_info`]), because it is the one entry whose meaning
/// is its stored path rather than its first bytes. That is the narrow exception
/// [`extension_claims_image`] already argues for, read the other way round —
/// and it is still not a page.
#[must_use]
pub fn image_format(bytes: &[u8]) -> Option<ImageFormat> {
    if bytes.starts_with(&[0xFF, 0xD8, 0xFF]) {
        return Some(ImageFormat::Jpeg);
    }
    if bytes.starts_with(&[0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A]) {
        return Some(ImageFormat::Png);
    }
    if bytes.starts_with(b"GIF87a") || bytes.starts_with(b"GIF89a") {
        return Some(ImageFormat::Gif);
    }
    // RIFF container with a WEBP form type; the four bytes between are the
    // chunk length and carry no signature.
    if bytes.starts_with(b"RIFF") && bytes.get(8..12) == Some(b"WEBP".as_slice()) {
        return Some(ImageFormat::WebP);
    }
    // ISO base media: a `ftyp` box whose major brand is one of AVIF's two.
    if matches!(bytes.get(4..12), Some(b"ftypavif" | b"ftypavis")) {
        return Some(ImageFormat::Avif);
    }
    // TIFF 6.0's magic 42, and BigTIFF's 43 in front of the same two order
    // bytes.
    if bytes.starts_with(b"II\x2A\x00")
        || bytes.starts_with(b"MM\x00\x2A")
        || bytes.starts_with(b"II\x2B\x00")
        || bytes.starts_with(b"MM\x00\x2B")
    {
        return Some(ImageFormat::Tiff);
    }
    // 15444-1 I.5.1's twelve-byte JP2 signature box, and the bare SOC/SIZ pair
    // a `.j2k` codestream starts with.
    if bytes.starts_with(&[
        0, 0, 0, 0x0C, b'j', b'P', b' ', b' ', 0x0D, 0x0A, 0x87, 0x0A,
    ]) || bytes.starts_with(&[0xFF, 0x4F, 0xFF, 0x51])
    {
        return Some(ImageFormat::Jpeg2000);
    }
    // Two bytes is a thin signature, so it is checked last and only for a file
    // long enough to carry a BITMAPFILEHEADER and the smallest DIB header.
    if bytes.starts_with(b"BM") && bytes.len() >= 26 {
        return Some(ImageFormat::Bmp);
    }
    None
}

/// Whether a name claims to be an image, for an entry whose bytes cannot be
/// read at all.
///
/// This is the **one** place an extension is consulted, and only because there
/// is nothing else: an encrypted entry, or one whose checksum failed, has no
/// first bytes to classify. The question here is narrower than "what is this" —
/// it is "was this meant to be a page", and getting it wrong in the direction
/// of making a page is the safe direction, because a spurious placeholder is
/// visible where a missing page renumbers every page after it.
fn extension_claims_image(name: &str) -> bool {
    // 4.4.17.1: separators are `/`, so the last segment is the file name.
    let file = name.rsplit('/').next().unwrap_or(name);
    let Some((stem, extension)) = file.rsplit_once('.') else {
        return false;
    };
    // A name that is nothing but a dot and a suffix is a hidden file rather
    // than a page — `.DS_Store` is the one every archiver leaves behind.
    if stem.is_empty() {
        return false;
    }
    let lower = extension.to_ascii_lowercase();
    matches!(
        lower.as_str(),
        "jpg"
            | "jpeg"
            | "jpe"
            | "jfif"
            | "png"
            | "gif"
            | "webp"
            | "bmp"
            | "dib"
            | "tif"
            | "tiff"
            | "avif"
            | "jp2"
            | "j2k"
            | "jpf"
            | "jpx"
    )
}

// ---- Synthesis --------------------------------------------------------------

/// One page, decided but not yet written.
enum Content<'a> {
    /// JPEG bytes, placed exactly as the archive holds them.
    Jpeg(Cow<'a, [u8]>),
    /// A PNG, through gap 29 milestone 4's chooser.
    Png(Box<PngImageData>),
    /// A TIFF, through the chooser that is that one's sibling.
    Tiff(Box<TiffImageData>),
    /// A JPEG 2000 file, placed as the archive holds it, with what its header
    /// said about the decode.
    Jpx(Cow<'a, [u8]>, JpxHeader),
    /// A format with no pass-through route — BMP and GIF — decoded and
    /// arranged by `tinker_pdf_cos::raster_embed`.
    Raster(Box<RasterImageData>),
    /// Nothing usable; the page is the neutral placeholder.
    Placeholder,
}

/// A page's plan: where it came from, how big it is, and what goes on it.
struct Plan<'a> {
    name: String,
    /// `None` when the size is not known and has to be borrowed from the book.
    size: Option<(f64, f64)>,
    content: Content<'a>,
    defect: Option<PageDefect>,
    degraded: bool,
    /// Bytes this page has undertaken to contribute to the finished document.
    charge: usize,
}

/// Turns an archive into the bytes of a PDF, and a report of what that cost.
///
/// This is what [`crate::Document::open`] does with a container, and it is
/// public for two reasons. Converting a comic archive into a PDF is a thing a
/// host wants for its own sake — the bytes here are a complete document, and
/// [`tinker_pdf_cos::CosDocument::open`] is what the facade does with them
/// next. And a bound that can only ever be exercised at its shipped value is a
/// bound no test can prove fires: `limits` is how
/// `a_synthesis_past_the_byte_cap_is_refused_by_name` reaches
/// [`MAX_SYNTHESISED_PDF`]'s branch without building half a gigabyte.
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal, each of them by name.
///
/// # This door is the comic path and nothing else
///
/// It opens its own archive and pages whatever it finds, so handing it an XPS
/// gets a comic made of that package's resources — which is precisely gap 30's
/// headline defect, and is why [`crate::Document::open`] does **not** come
/// through here. That route opens the archive once and asks
/// [`crate::xps::route`] what it is first.
pub fn synthesise(
    what: Container,
    bytes: &[u8],
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    match what {
        Container::Zip => {
            let archive = open_archive(bytes, &limits.zip)?;
            pages_from_archive(archive, limits)
        }
        Container::Tar => {
            let archive = open_tar(bytes, &limits.tar)?;
            pages_from_tar(archive, limits)
        }
        Container::SevenZip => {
            let archive = open_sevenz(bytes, &limits.sevenz)?;
            pages_from_sevenz(archive, limits)
        }
        Container::Rar => {
            let archive = open_rar(bytes, &limits.rar)?;
            pages_from_rar(archive, limits)
        } // **No `_` arm, and its absence is load-bearing.** `Container` is
          // `#[non_exhaustive]` for callers and exhaustive here, so every
          // signature the sniff can return now has a reader behind it and a
          // fifth one added later fails *this* build rather than silently
          // falling through to a refusal nobody meant.
    }
}

/// Opens a RAR, mapping the reader's refusals onto this one's (tier 4,
/// W-ARCHIVE milestone 4).
///
/// # Errors
/// [`ArchiveRefusal::NotAZip`] for a file with no RAR signature **and for a
/// RAR 4**, [`ArchiveRefusal::Encrypted`], [`ArchiveRefusal::MultiDisk`] for a
/// volume of a set, [`ArchiveRefusal::TooLarge`] past a bound, and
/// [`ArchiveRefusal::Damaged`] for a first header that does not checksum.
///
/// **RAR 4 lands on `NotAZip` rather than `Damaged`**, and the leaf keeps the
/// distinction the facade cannot: `rar::Error::Rar4` is its own variant with
/// its own sentence, because "this is a RAR of a version I do not read" is not
/// "this file is broken". `docs/design/comic-archives.md` argues why there is
/// no RAR 4 decoder — WinRAR 7.20 on this machine cannot produce a RAR 4, so
/// one would have no first-party fixture to be held to (ruling 13).
pub fn open_rar<'a>(
    bytes: &'a [u8],
    limits: &RarLimits,
) -> Result<rar::Archive<'a>, ArchiveRefusal> {
    rar::Archive::open(bytes, limits).map_err(|e| match e {
        RarError::NotARar | RarError::Rar4 => ArchiveRefusal::NotAZip,
        RarError::Encrypted => ArchiveRefusal::Encrypted,
        RarError::MultiVolume => ArchiveRefusal::MultiDisk,
        RarError::TooManyEntries => ArchiveRefusal::TooLarge,
        _ => ArchiveRefusal::Damaged,
    })
}

/// Pages an already-open RAR as a comic (tier 4, W-ARCHIVE milestone 4).
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal, each of them by name.
pub fn pages_from_rar(
    archive: rar::Archive<'_>,
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    pages_from_reader(Reader::Rar(archive), limits)
}

/// Opens a 7z, mapping the reader's refusals onto this one's (tier 4,
/// W-ARCHIVE milestone 3).
///
/// # Errors
/// [`ArchiveRefusal::NotAZip`] for a file with no 7z signature,
/// [`ArchiveRefusal::Encrypted`] for AES-256, [`ArchiveRefusal::TooLarge`]
/// past a bound, and [`ArchiveRefusal::Damaged`] for a header that does not
/// checksum or does not parse.
///
/// **`UnsupportedCoder` lands on `NotAZip` and that is deliberate.** It is the
/// refusal whose sentence is *"this build does not read that"*, which is what
/// a `.cb7` compressed with a coder this build does not implement is; calling
/// it `Damaged` would tell a host the file is broken when it is fine and only
/// this engine is short.
pub fn open_sevenz<'a>(
    bytes: &'a [u8],
    limits: &SevenZipLimits,
) -> Result<sevenz::Archive<'a>, ArchiveRefusal> {
    sevenz::Archive::open(bytes, limits).map_err(|e| match e {
        SevenZipError::NotA7z => ArchiveRefusal::NotAZip,
        SevenZipError::Encrypted => ArchiveRefusal::Encrypted,
        SevenZipError::TooManyEntries => ArchiveRefusal::TooLarge,
        SevenZipError::UnsupportedCoder { .. } | SevenZipError::NotAChain => {
            ArchiveRefusal::NotAZip
        }
        // `sevenz::Error` is `#[non_exhaustive]`, so a variant added later
        // compiles here rather than failing the build — and lands on the
        // refusal that means "structure present, nothing recoverable".
        _ => ArchiveRefusal::Damaged,
    })
}

/// Pages an already-open 7z as a comic (tier 4, W-ARCHIVE milestone 3).
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal, each of them by name.
pub fn pages_from_sevenz(
    archive: sevenz::Archive<'_>,
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    pages_from_reader(Reader::SevenZip(archive), limits)
}

/// Opens a tar, mapping the reader's two refusals onto this one's (tier 4,
/// W-ARCHIVE milestone 2).
///
/// # Errors
/// [`ArchiveRefusal::NotAZip`] for a file with no `ustar` magic -- the name is
/// the one it has always had and is a sentence about *this build's* container
/// support rather than about ZIP -- and [`ArchiveRefusal::TooLarge`] past
/// [`TarLimits::max_entries`].
pub fn open_tar<'a>(
    bytes: &'a [u8],
    limits: &TarLimits,
) -> Result<tar::Archive<'a>, ArchiveRefusal> {
    tar::Archive::open(bytes, limits).map_err(|e| match e {
        TarError::NotATar => ArchiveRefusal::NotAZip,
        TarError::TooManyEntries => ArchiveRefusal::TooLarge,
        // `tar::Error` is `#[non_exhaustive]`, so a variant added later
        // compiles here rather than failing the build — and lands on the
        // refusal that means "structure present, nothing recoverable" rather
        // than on one that would claim something specific about it.
        _ => ArchiveRefusal::Damaged,
    })
}

/// Pages an already-open tar as a comic (tier 4, W-ARCHIVE milestone 2).
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal, each of them by name.
pub fn pages_from_tar(
    archive: tar::Archive<'_>,
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    pages_from_reader(Reader::Tar(archive), limits)
}

/// Opens the archive, once, mapping the reader's refusals onto this one's.
///
/// Split out of [`synthesise`] so `Document::open` can open a ZIP **once** and
/// then decide what it is: milestone 3's exit criterion is that the sniff and
/// the read share one [`Archive`], because opening it twice doubles the work
/// and creates a window in which the two reads could disagree.
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal the archive reader made.
pub fn open_archive<'a>(
    bytes: &'a [u8],
    limits: &ZipLimits,
) -> Result<Archive<'a>, ArchiveRefusal> {
    Archive::open(bytes, limits).map_err(|e| match e {
        ArchiveError::NotAZip => ArchiveRefusal::NotAZip,
        ArchiveError::Damaged => ArchiveRefusal::Damaged,
        ArchiveError::MultiDisk => ArchiveRefusal::MultiDisk,
        ArchiveError::Zip64OutOfBounds => ArchiveRefusal::Zip64OutOfBounds,
        ArchiveError::TooManyEntries => ArchiveRefusal::TooLarge,
    })
}

/// Reads one entry of a comic's ZIP, checked, with ZIP methods 14, 12 and 93
/// decoded.
///
/// [`Archive::read`] with the three things `tinker-pdf-zip` cannot carry: an
/// LZMA decoder, a bzip2 decoder and a Zstandard decoder. That crate may
/// depend on `tinker-pdf-filters` and nothing else, and all three decoders
/// live in `tinker-pdf-archive` — LZMA's written for 7z, bzip2's for 7z and
/// ZIP alike, Zstandard's for ZIP — so the facade, which already depends on
/// both, hands them in through
/// [`Archive::read_coded`]. Everything that is ZIP's stays ZIP's: APPNOTE
/// 5.8.8's header on a method-14 entry is read and checked there (a damaged
/// one is [`ZipEntryError::LzmaHeader`]), the declared size is bounded and
/// charged against the archive's total there, and what comes back is held to
/// the declared length and the recorded CRC-32 there. So a decoder wrong by
/// one byte is refused by the archive's own checksum, exactly as a `.cb7`'s
/// is.
///
/// **Only the comic path takes this door.** OPC forbids every compression
/// method but DEFLATE and OCF 3.3 §4.3.2 allows Stored and Deflated
/// (`epub::ocf`'s header records both), so an XPS or an EPUB item compressed
/// with LZMA, bzip2 or Zstandard is a package outside its own format, and those readers
/// keep [`Archive::read`]'s refusal by number.
///
/// # Errors
/// [`ZipEntryError`], one variant per refusal. The decoders' own failures are
/// mapped onto the reader's vocabulary: an LZMA property byte whose `lc + lp`
/// is past 4 is [`ZipEntryError::LzmaHeader`] — it is one of the five header
/// bytes — a stream that runs out or ends before its declared length is
/// [`ZipEntryError::Truncated`], a bzip2 or Zstandard stream that would decode
/// past it is [`ZipEntryError::OversizedStream`], a feature the decoder
/// refuses by name — a Zstandard frame naming a dictionary, a randomised
/// bzip2 block — is [`ZipEntryError::UnsupportedFeature`] naming it, and
/// anything else is [`ZipEntryError::Corrupt`].
pub fn read_entry<'a>(
    archive: &mut Archive<'a>,
    index: usize,
) -> Result<Cow<'a, [u8]>, ZipEntryError> {
    archive.read_coded(index, |coded| match coded {
        tinker_pdf_zip::Coded::Lzma(stream) => decode_lzma(stream),
        tinker_pdf_zip::Coded::Bzip2 { stream, unpacked } => decode_bzip2(stream, *unpacked),
        tinker_pdf_zip::Coded::Zstandard { stream, unpacked } => decode_zstd(stream, *unpacked),
        // `Coded` is `#[non_exhaustive]`: a method the zip crate learns the
        // framing of later is one this facade has not wired a decoder for.
        other => Err(ZipEntryError::UnsupportedMethod(other.method())),
    })
}

/// ZIP method 12's stream through the bzip2 decoder 7z's `040202` uses.
fn decode_bzip2(stream: &[u8], unpacked: usize) -> Result<Vec<u8>, ZipEntryError> {
    use tinker_pdf_archive::bzip2;
    // The ceiling is the declared size, bounded and charged by the zip crate,
    // exactly as for method 14.
    let limits = bzip2::Limits {
        max_unpacked: unpacked,
    };
    bzip2::decode(stream, &limits).map_err(|e| match e {
        bzip2::Error::Truncated => ZipEntryError::Truncated,
        bzip2::Error::TooLarge => ZipEntryError::OversizedStream {
            declared: unpacked as u64,
        },
        // Refused by name, and not damage: a well-formed block of a kind
        // nothing has written since 1999.
        bzip2::Error::Randomised => {
            ZipEntryError::UnsupportedFeature(ZipMethodFeature::Bzip2Randomised)
        }
        // `bzip2::Error` is `#[non_exhaustive]`: a bad table, a failed block
        // or stream CRC and whatever is added later are all a stream that is
        // not the one the entry claims.
        _ => ZipEntryError::Corrupt,
    })
}

/// ZIP method 93's frames through the Zstandard decoder.
fn decode_zstd(stream: &[u8], unpacked: usize) -> Result<Vec<u8>, ZipEntryError> {
    use tinker_pdf_archive::zstd;
    // The ceiling is the declared size, bounded and charged by the zip crate,
    // exactly as for methods 14 and 12.
    let limits = zstd::Limits {
        max_unpacked: unpacked,
    };
    zstd::decode(stream, &limits).map_err(|e| match e {
        zstd::Error::Truncated => ZipEntryError::Truncated,
        zstd::Error::TooLarge => ZipEntryError::OversizedStream {
            declared: unpacked as u64,
        },
        // Refused by name, and not damage: a ZIP has nowhere to carry a
        // dictionary, so no reader of the archive alone can decode the frame,
        // however well formed it is.
        zstd::Error::NeedsDictionary => {
            ZipEntryError::UnsupportedFeature(ZipMethodFeature::ZstandardDictionary)
        }
        // `zstd::Error` is `#[non_exhaustive]`: a damaged section, a failed
        // content checksum or size, and whatever is added later are all a
        // stream that is not the one the entry claims.
        _ => ZipEntryError::Corrupt,
    })
}

/// ZIP method 14's stream through the decoder 7z already uses.
fn decode_lzma(stream: &tinker_pdf_zip::LzmaStream<'_>) -> Result<Vec<u8>, ZipEntryError> {
    use tinker_pdf_archive::lzma;
    // The ceiling is the declared size, which `tinker-pdf-zip` has already
    // bounded by the per-entry cap and charged against the archive's total, so
    // the decoder may produce exactly what the archive was permitted to spend.
    let limits = lzma::Limits {
        max_unpacked: stream.unpacked,
    };
    lzma::decode(stream.stream, stream.properties, stream.unpacked, &limits).map_err(|e| match e {
        lzma::Error::BadProperties => ZipEntryError::LzmaHeader,
        lzma::Error::Truncated | lzma::Error::ShortOutput => ZipEntryError::Truncated,
        lzma::Error::TooLarge => ZipEntryError::EntryTooLarge,
        // `lzma::Error` is `#[non_exhaustive]`: a bad range-coder start, a
        // match reaching past the output, and whatever is added later are all
        // a stream that is not the one the entry claims to hold.
        _ => ZipEntryError::Corrupt,
    })
}

/// Pages an already-open archive as a comic.
///
/// # Errors
/// [`ArchiveRefusal`], one variant per refusal, each of them by name.
pub fn pages_from_archive(
    archive: Archive<'_>,
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    pages_from_reader(Reader::Zip(archive), limits)
}

/// Pages one picture with no archive around it, as the comic of that one
/// entry (tier 5's formats row): what [`crate::Document::open`] does with a
/// bare image.
///
/// The same body as every container's, so a bare GIF, WebP or multi-page TIFF
/// is exactly the document a one-entry CBZ holding it is — the same pages,
/// sizes, pixels and warnings — and the two cannot drift apart.
///
/// # Errors
/// [`ArchiveRefusal::NoImages`] for bytes [`image_format`] does not
/// recognise, and [`ArchiveRefusal::TooLarge`] past a bound.
pub(crate) fn pages_from_picture(
    bytes: &[u8],
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    pages_from_reader(Reader::Picture(bytes), limits)
}

/// Pages whichever container was opened.
///
/// One body for every container rather than one per format, which is the half
/// of the crate rule that *is* shared: what a page is, what order the pages
/// come in, which entries are metadata and what a page that cannot be built
/// looks like are decisions about a comic and not about a container. Only
/// [`Reader`] knows which format it is holding, and only for two questions --
/// how to list an entry and how to read one.
fn pages_from_reader(
    mut archive: Reader<'_>,
    limits: &Limits,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    let listing = archive.listing();
    let order = reading_order(&listing);
    let mut plans: Vec<Plan<'_>> = Vec::new();
    let mut spent = DOCUMENT_OVERHEAD;
    // Read before the pages, and its outcome kept until after them, because a
    // refusal below (`NoImages`, a bound) means there is no document for a
    // title to be on. Nothing here can refuse the archive.
    let (info, info_defect) = read_comic_info(&mut archive, &listing, limits);

    for position in order {
        let Some(entry) = listing.get(position).cloned() else {
            continue;
        };
        // A record that holds no file data is not a page: APPNOTE 4.4.17.1's
        // trailing slash in a ZIP, and a type flag that is not a file in a tar.
        if entry.directory {
            continue;
        }
        // Not a page, and — since tier 4 — not ignored either. It was read
        // above; `plan_entry` would classify it by magic bytes, find no image
        // and skip it anyway, and this makes that an intention rather than a
        // coincidence two readers of the same entry happen to share.
        if comic_info::is_comic_info(&entry.name) {
            continue;
        }
        // Usually one plan, none for an entry that is not an image, and one
        // per directory for a multi-page TIFF — each of which is a page, and
        // each of which the page cap and the byte cap count as one **the
        // moment it is planned**, before the next is decoded. A TIFF's
        // directories are handed over one at a time for that reason: planned
        // all at once and charged after, sixty-four directories over one
        // 16 MiB strip held a gigabyte before the 512 MiB cap was asked.
        plan_entry(&mut archive, position, &entry.name, limits, &mut |plan| {
            if plans.len() >= limits.max_pages {
                return Err(ArchiveRefusal::TooLarge);
            }
            spent = spent
                .checked_add(plan.charge)
                .filter(|&total| total <= limits.max_synthesised)
                .ok_or(ArchiveRefusal::TooLarge)?;
            plans.push(plan);
            Ok(())
        })?;
    }

    if plans.is_empty() {
        return Err(ArchiveRefusal::NoImages);
    }
    // Archive level, and only when there is nothing else: an archive of a
    // hundred JPEGs and one encrypted entry keeps its hundred readable pages.
    if plans
        .iter()
        .all(|p| p.defect == Some(PageDefect::EntryRefused(ZipEntryError::Encrypted)))
    {
        return Err(ArchiveRefusal::Encrypted);
    }

    // A placeholder has no size of its own. It takes the first real page's,
    // because a comic's pages are one size and a placeholder that matches its
    // neighbours is one a reader can page through; paper is the answer only
    // for a book that never states one.
    let fallback = plans.iter().find_map(|p| p.size).unwrap_or(FALLBACK_PAGE);

    let mut builder = DocumentBuilder::new();
    let mut warnings: Vec<ArchiveWarning> = Vec::new();
    let mut pages: Vec<PageOrigin> = Vec::with_capacity(plans.len());

    // §14.3.3's document information dictionary, filled from the archive's own
    // `ComicInfo.xml`. The mapping lives in `comic_info::ComicInfo::info_entries`
    // and not here, so a test reading the finished `/Info` and a caller reading
    // the report are looking at one decision. `set_info` answers false only
    // under an archival profile, which a synthesised comic never has.
    if let Some(info) = &info {
        for (key, value) in info.info_entries() {
            builder.set_info(key, &value);
        }
    }
    if let Some(defect) = info_defect {
        warnings.push(ArchiveWarning::ComicInfo(defect));
    }

    for (number, plan) in plans.iter().enumerate() {
        // Each page names its own image and no other. Without this every page
        // would inherit every image registered before it, and a 200-page
        // archive would carry 20 100 resource entries for the 200 it uses.
        builder.clear_image_resources();

        let drawn = match &plan.content {
            Content::Jpeg(data) => builder.add_image(IMAGE_RESOURCE, &ImageData::Jpeg(data)),
            Content::Png(png) => builder.add_image(IMAGE_RESOURCE, &png.image()),
            Content::Tiff(tiff) => builder.add_image(IMAGE_RESOURCE, &tiff.image()),
            Content::Jpx(data, header) => builder.add_image(
                IMAGE_RESOURCE,
                &ImageData::Compressed(jpx_image(data, header)),
            ),
            Content::Raster(raster) => builder.add_image(IMAGE_RESOURCE, &raster.image()),
            Content::Placeholder => false,
        };

        let (width, height) = plan.size.unwrap_or(fallback);
        builder.add_page(width, height, |page| {
            if drawn {
                // 8.9.5.2: an image occupies the unit square, so one image
                // pixel is one PDF point exactly when the transform is the
                // page's own size.
                page.image(IMAGE_RESOURCE, 0.0, 0.0, width, height);
            } else {
                page.fill_rect(0.0, 0.0, width, height, PLACEHOLDER_GREY);
            }
        });

        // A plan that said "real image" and whose image the writer refused is
        // a placeholder too, and the report has to say so rather than claiming
        // a picture that is not there.
        let defect = plan.defect.or(match plan.content {
            Content::Placeholder => Some(PageDefect::Undecodable),
            _ if drawn => None,
            _ => Some(PageDefect::Undecodable),
        });
        let page = number as u32;
        if let Some(defect) = defect {
            warnings.push(ArchiveWarning::PlaceholderPage { page, defect });
        } else if plan.degraded {
            warnings.push(ArchiveWarning::DegradedImage { page });
        }
        pages.push(PageOrigin {
            name: plan.name.clone(),
            defect,
        });
    }

    // Taken after every read, because reading is what most of them come from.
    warnings.extend(archive.warnings());

    let pdf = builder.finish();
    let synthesised_bytes = pdf.len();
    // `parsed_parts` stays zero: it counts a *fixed document*'s payload cache,
    // which the comic path does not have. The one entry of markup this path
    // does read comes out through `ArchiveReport::comic_info`.
    Ok((
        pdf,
        ArchiveReport::synthesised(warnings, pages, synthesised_bytes, None, 0)
            .with_comic_info(info),
    ))
}

/// Reads the archive's `ComicInfo.xml`, if it holds one.
///
/// Returns what it said and what went wrong, and **never both**: a defect means
/// there is nothing to write, and a value means there was nothing to warn
/// about. An archive with no such entry returns neither, which is what makes
/// "no metadata" and "metadata this build could not read" different states a
/// host can show differently (ruling 10).
///
/// The entry is charged against the archive reader's own inflation budget like
/// any other, so a `ComicInfo.xml` that inflates to gigabytes is refused by
/// `tinker-pdf-zip` before this sees a byte — and by
/// [`MAX_COMIC_INFO_BYTES`] if it fits inside that and is still not a
/// plausible metadata file.
fn read_comic_info(
    archive: &mut Reader<'_>,
    listing: &[Listing],
    limits: &Limits,
) -> (Option<ComicInfo>, Option<ComicInfoDefect>) {
    let Some(index) = listing
        .iter()
        .position(|entry| comic_info::is_comic_info(&entry.name))
    else {
        return (None, None);
    };
    let data = match archive.read(index) {
        Ok(data) => data,
        Err(_) => return (None, Some(ComicInfoDefect::EntryRefused)),
    };
    match comic_info::parse(&data, &limits.xml) {
        Ok(info) => (Some(info), None),
        Err(defect) => (None, Some(defect)),
    }
}

/// The resource name every synthesised page gives its own image.
///
/// The same name on every page is not a collision: each page's `/Resources`
/// holds exactly one `/XObject`, and they are different objects.
const IMAGE_RESOURCE: &[u8] = b"Im";

/// What a planned page is handed to: the page cap and the byte cap, charged
/// on it before anything else is planned, and a refusal when either is spent.
type Admit<'p, 'a> = dyn FnMut(Plan<'a>) -> Result<(), ArchiveRefusal> + 'p;

/// Decides what one entry becomes — no page (it is not an image), one page, or
/// for a TIFF of several directories one page per directory that is one — and
/// hands each to `admit` as it is made.
///
/// # Errors
/// Whatever `admit` refuses, at the first page it refuses.
fn plan_entry<'a>(
    archive: &mut Reader<'a>,
    index: usize,
    name: &str,
    limits: &Limits,
    admit: &mut Admit<'_, 'a>,
) -> Result<(), ArchiveRefusal> {
    let data = match archive.read(index) {
        Ok(data) => data,
        Err(defect) => {
            // No bytes, so no magic. See `extension_claims_image` for why the
            // name is allowed to decide this one case and nothing else.
            return if extension_claims_image(name) {
                admit(placeholder_plan(name, defect))
            } else {
                Ok(())
            };
        }
    };
    match image_format(&data) {
        None => Ok(()),
        Some(ImageFormat::Tiff) => tiff_plans(
            &data,
            |directory| tiff_page(name, &data, directory, limits),
            admit,
        ),
        Some(format) => match plan_image(format, data, name, limits) {
            Some(plan) => admit(plan),
            None => Ok(()),
        },
    }
}

/// A page of the book's size carrying the neutral grey, and why.
fn placeholder_plan<'a>(name: &str, defect: PageDefect) -> Plan<'a> {
    Plan {
        name: name.to_owned(),
        size: None,
        content: Content::Placeholder,
        defect: Some(defect),
        degraded: false,
        charge: PAGE_OVERHEAD,
    }
}

/// One entry of a format that is one page, whatever it holds.
fn plan_image<'a>(
    format: ImageFormat,
    data: Cow<'a, [u8]>,
    name: &str,
    limits: &Limits,
) -> Option<Plan<'a>> {
    let placeholder = |defect: PageDefect| placeholder_plan(name, defect);

    match format {
        ImageFormat::Jpeg => {
            // The same reader `add_image` uses, so the `/MediaBox` and the
            // `/Width` cannot disagree.
            let Some((width, height, _)) = tinker_pdf_cos::jpeg_shape(&data) else {
                return Some(placeholder(PageDefect::Undecodable));
            };
            if width == 0 || height == 0 {
                return Some(placeholder(PageDefect::Undecodable));
            }
            Some(Plan {
                name: name.to_owned(),
                size: Some((f64::from(width), f64::from(height))),
                charge: PAGE_OVERHEAD.saturating_add(data.len()),
                content: Content::Jpeg(data),
                defect: None,
                degraded: false,
            })
        }
        ImageFormat::Png => {
            // The decoded route's ceiling is the largest entry this build will
            // read out of an archive: a page whose raster is bigger than the
            // biggest file the archive may hold is not a comic page. It is the
            // *caller's* number, which is what `ExceedsOutputLimit` carries,
            // so a host that lowered it can tell its decision from the
            // decoder's own `MAX_PNG_SAMPLES`.
            let Ok(png) = png_image(&data, &FilterLimits::new(limits.zip.max_entry_bytes)) else {
                return Some(placeholder(PageDefect::Undecodable));
            };
            if png.width() == 0 || png.height() == 0 {
                return Some(placeholder(PageDefect::Undecodable));
            }
            let size = (f64::from(png.width()), f64::from(png.height()));
            let degraded = !png.complete();
            let charge = PAGE_OVERHEAD.saturating_add(embedded_len(&png.image()));
            Some(Plan {
                name: name.to_owned(),
                size: Some(size),
                content: Content::Png(Box::new(png)),
                defect: None,
                degraded,
                charge,
            })
        }
        // `plan_entry` sends a TIFF to `tiff_plans`, for its directories; this
        // arm is the first directory alone, for a caller that asked for one.
        ImageFormat::Tiff => Some(tiff_page(name, &data, 0, limits)),
        ImageFormat::Jpeg2000 => {
            // The header and nothing past it: the box walk, the main and
            // tile-part headers, the budgets and Annex I's channel plan. That
            // is everything the file *declares*, so a codestream the decoder
            // would refuse by name is a placeholder here, before it becomes a
            // page. Damage inside the packets is found where every PDF's JPX
            // stream has it found, when the page is drawn.
            //
            // The ceiling is the PNG and TIFF routes' — the largest entry this
            // build will read — because the raster a decode would produce is
            // what it bounds, and a decode happens later at render time.
            let Ok(header) = tinker_pdf_filters::jpx_header(
                &data,
                &FilterLimits::new(limits.zip.max_entry_bytes),
            ) else {
                return Some(placeholder(PageDefect::Undecodable));
            };
            // What the renderer draws a JPX image from: one, three or four
            // colour channels (`resources.rs`'s `jpx_image`). A two-channel
            // file would open and then draw as the renderer's own grey, with
            // the report calling it a picture.
            if header.width == 0 || header.height == 0 || jpx_space(&header).is_none() {
                return Some(placeholder(PageDefect::Undecodable));
            }
            Some(Plan {
                name: name.to_owned(),
                size: Some((f64::from(header.width), f64::from(header.height))),
                charge: PAGE_OVERHEAD.saturating_add(data.len()),
                // A channel `cdef` typed as opacity is dropped: a comic page
                // is painted over nothing, and `CompressedImage` carries no
                // `/SMaskInData`. The picture reaches the page and the report
                // says it is not the whole of what the file held.
                degraded: header.opacity,
                content: Content::Jpx(data, header),
                defect: None,
            })
        }
        // No pass-through route exists for a BMP, a GIF or a WebP, so the
        // decode is the route: `raster_plan` bounds it by the same caller's
        // ceiling the PNG and TIFF decoded routes take, and says why.
        ImageFormat::Bmp => Some(raster_plan(
            name,
            bmp_image(&data, &FilterLimits::new(limits.zip.max_entry_bytes)).ok(),
        )),
        ImageFormat::Gif => Some(raster_plan(
            name,
            gif_image(&data, &FilterLimits::new(limits.zip.max_entry_bytes)).ok(),
        )),
        ImageFormat::WebP => Some(raster_plan(
            name,
            webp_image(&data, &FilterLimits::new(limits.zip.max_entry_bytes)).ok(),
        )),
        // Recognised, named, and refused at the page level rather than the
        // archive's: an archive of a hundred JPEGs and one AVIF keeps its
        // hundred readable pages, and the AVIF keeps its page number.
        other => Some(placeholder(PageDefect::UnsupportedFormat(other))),
    }
}

/// Every directory of a TIFF that is a page, in the order the `NextIFD` chain
/// gives them.
///
/// TIFF 6.0's `NewSubfileType` says which directories are not pages: bit 0 is
/// a reduced-resolution copy of another image — the thumbnail a scanner
/// writes after the page — and bit 2 a transparency mask for one. Neither is
/// drawn as a page of its own, and a directory refused as
/// `PhotometricInterpretation` 4 is a mask whatever its subfile type said. The
/// first directory is always a page: it is the picture a single-image reader
/// shows, and an entry that became no page would renumber the book.
///
/// The chain is walked under `tiff.rs`'s cycle guard and its 64-directory
/// bound, and each directory is built by `page` and handed to `admit` —
/// which charges it against [`MAX_CBZ_PAGES`] and [`MAX_SYNTHESISED_PDF`] —
/// **before the next is decoded**. That is what makes a directory cost what
/// an entry of its own costs: an entry is charged before the next entry is
/// read, and a directory before the next directory is built. Collecting them
/// first and charging after kept every decoded raster and every copied
/// strip alive at once, so sixty-four directories over one 16 MiB strip
/// peaked at a gigabyte before the 512 MiB cap was asked.
///
/// `page` is a parameter rather than a call so that the order is what a test
/// holds, not only the outcome.
///
/// # Errors
/// Whatever `admit` refuses, at the first directory it refuses; nothing after
/// that directory is built.
fn tiff_plans<'a>(
    data: &[u8],
    mut page: impl FnMut(usize) -> Plan<'a>,
    admit: &mut Admit<'_, 'a>,
) -> Result<(), ArchiveRefusal> {
    let directories = tiff_scan_directory(data, 0).map_or(1, |scan| scan.pages as usize);
    admit(page(0))?;
    for index in 1..directories {
        match tiff_scan_directory(data, index) {
            Ok(scan) if scan.subfile & 0b101 != 0 => continue,
            Err(TiffError::UnsupportedPhotometric(4)) => continue,
            _ => admit(page(index))?,
        }
    }
    Ok(())
}

/// One directory of a TIFF as a page, or its placeholder.
///
/// The same ceiling the PNG route takes, for the same reason: the largest
/// entry this build will read out of an archive is the most a page's raster
/// may be, and it is the *caller's* number, which is what `ExceedsOutputLimit`
/// carries back. It binds only the decoded route. A single-strip G4 page — the
/// shape a scanned comic actually has — builds no raster at all, so a page far
/// past this ceiling still opens.
fn tiff_page<'a>(name: &str, data: &[u8], directory: usize, limits: &Limits) -> Plan<'a> {
    let ceiling = FilterLimits::new(limits.zip.max_entry_bytes);
    let tiff = match tiff_image_directory(data, directory, &ceiling) {
        Ok(tiff) if tiff.width() > 0 && tiff.height() > 0 => tiff,
        _ => return placeholder_plan(name, PageDefect::Undecodable),
    };
    let size = (f64::from(tiff.width()), f64::from(tiff.height()));
    let degraded = !tiff.complete();
    let charge = PAGE_OVERHEAD.saturating_add(embedded_len(&tiff.image()));
    Plan {
        name: name.to_owned(),
        size: Some(size),
        content: Content::Tiff(Box::new(tiff)),
        defect: None,
        degraded,
        charge,
    }
}

/// A page from a decoder with no pass-through route, or its placeholder.
///
/// The decode ran under the largest entry this build will read out of an
/// archive, the PNG and TIFF decoded routes' ceiling for their reason: a page
/// whose raster is bigger than the biggest file the archive may hold is not a
/// comic page. **This is the one route here whose cost is `w x h x c`** rather
/// than the entry's own bytes, and the module note's peak argument is why an
/// indexed file is kept indexed on the way through.
fn raster_plan<'a>(name: &str, raster: Option<RasterImageData>) -> Plan<'a> {
    let Some(raster) = raster.filter(|r| r.width() > 0 && r.height() > 0) else {
        return Plan {
            name: name.to_owned(),
            size: None,
            content: Content::Placeholder,
            defect: Some(PageDefect::Undecodable),
            degraded: false,
            charge: PAGE_OVERHEAD,
        };
    };
    let size = (f64::from(raster.width()), f64::from(raster.height()));
    let degraded = !raster.complete();
    let charge = PAGE_OVERHEAD.saturating_add(embedded_len(&raster.image()));
    Plan {
        name: name.to_owned(),
        size: Some(size),
        content: Content::Raster(Box::new(raster)),
        defect: None,
        degraded,
        charge,
    }
}

/// The device space a JPEG 2000 file's decode lands in, by its channel count
/// — the three counts the renderer draws — or `None` for any other.
fn jpx_space(header: &JpxHeader) -> Option<ImageColorSpace<'static>> {
    match header.components {
        1 => Some(ImageColorSpace::DeviceGray),
        3 => Some(ImageColorSpace::DeviceRgb),
        4 => Some(ImageColorSpace::DeviceCmyk),
        _ => None,
    }
}

/// A JPEG 2000 page's image: the file's own bytes under `/JPXDecode`.
///
/// `bits_per_component` and `color_space` are the decode's description, from
/// the header, and [`ImageFilter::Jpx`] is why neither reaches the dictionary:
/// the codestream states both, and a `/ColorSpace` would override a JP2's own
/// `colr` box.
fn jpx_image<'b>(data: &'b [u8], header: &JpxHeader) -> CompressedImage<'b> {
    CompressedImage {
        width: header.width,
        height: header.height,
        bits_per_component: header.precision,
        // `plan_entry` refused every count `jpx_space` does not map, so this
        // default is never taken; it keeps the function total.
        color_space: jpx_space(header).unwrap_or(ImageColorSpace::DeviceGray),
        filter: Some(ImageFilter::Jpx),
        data,
        color_key_mask: None,
        soft_mask: None,
    }
}

/// How many bytes a prepared image will put in the file.
///
/// Takes the [`ImageData`] rather than the preparer's own type, because both
/// preparers produce the same shape and the charge is a fact about the bytes.
fn embedded_len(image: &ImageData<'_>) -> usize {
    match image {
        ImageData::Compressed(image) => image
            .data
            .len()
            .saturating_add(image.soft_mask.as_ref().map_or(0, |m| m.data.len())),
        // Neither preparer builds anything else, and a shape that costs nothing
        // to charge for is one that has not been written yet.
        _ => 0,
    }
}

#[cfg(test)]
mod tests;
