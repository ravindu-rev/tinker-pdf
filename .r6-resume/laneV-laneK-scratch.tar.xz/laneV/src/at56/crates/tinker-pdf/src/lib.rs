//! A from-scratch, pure-Rust PDF engine.
//!
//! This facade is the only crate users depend on; everything below it is an
//! implementation detail that may be reshaped without notice until the API
//! freezes at 0.1.0.
//!
//! ```no_run
//! # fn main() -> Result<(), Box<dyn std::error::Error>> {
//! let bytes = std::fs::read("document.pdf")?;
//! let doc = tinker_pdf::Document::open(bytes)?;
//! println!("{} pages", doc.page_count());
//! for page in doc.pages() {
//!     println!("{}", page.text().plain_text());
//! }
//! # Ok(())
//! # }
//! ```
//!
//! Feature documentation: `docs/architecture.md`, and one doc per feature
//! under `docs/features/`.

#![forbid(unsafe_code)]
#![warn(missing_docs)]

mod annotations;
mod annots;
mod associated_files;
pub mod cbz;
mod copies;
mod display;
pub mod epub;
pub mod fb2;
pub mod fontlist;
pub mod fonts;
pub mod form_data;
pub mod html;
mod images;
pub mod layers;
pub mod markdown;
pub mod mdp;
mod observe;
mod optional;
mod output_intents;
pub mod pdfa;
pub mod pdfua;
pub mod pdfx;
mod png_read;
pub mod reading_order;
mod recode;
pub mod redact;
mod render_part;
mod resources;
pub mod shaping;
pub mod signature;
pub mod standalone;
pub mod structure;
pub mod subset;
mod svg_out;
pub mod tables;
mod text_order;
pub mod verdict;
pub mod write;
pub mod xps;

use std::sync::Arc;

use tinker_pdf_content::{interpret, Matrix, TextDevice};
use tinker_pdf_cos::{outline as cos_outline, pages as cos_pages};

/// The read surface's own projections (ruling 11), and the argument for them.
///
/// Three questions a *document* answers about itself — what fonts it carries,
/// what layers it declares, what is annotated on a page — in types this crate
/// owns rather than the internal ones. `fontlist`'s module comment argues the
/// boundary once for all three.
pub use annotations::{Annotation, AnnotationFlags, AnnotationKind};
/// Associated files (ISO 32000-2 14.13), as `Document::associated_files`,
/// `associated_files_of` and `structure_associated_files`,
/// `Page::associated_files`, `annotation_associated_files` and
/// `marked_content_associated_files`, and `StructElement::associated_files`
/// read them.
pub use associated_files::{
    AssociatedFile, MarkedContentFileList, MarkedContentFiles, MAX_ASSOCIATED_FILE_BYTES,
};
/// Comic archives: what [`Document::open`] does with a `PK\x03\x04` at offset
/// zero, and what it refuses by name.
pub use cbz::{
    ArchiveRefusal, ArchiveReport, ArchiveWarning, ComicInfo, ComicInfoDefect, Container,
    PageDefect, PageOrigin,
};
pub use fontlist::{DocumentFont, FontProgram};
pub use fonts::{FontProvider, FontRequest, SimpleFontProvider};
/// HTML and CSS to PDF as a creation API (tier 5): with [`FromHtml`] in scope,
/// `DocumentBuilder::from_html(markup, stylesheet, page)` lays markup out
/// through the EPUB reader's cascade, layout and painter.
pub use html::{FromHtml, HtmlError, HtmlReport, PageBox};
pub use layers::OptionalGroup;
/// Digital signatures, read (12.8), behind [`Document::signatures`].
pub use mdp::{Change, Modification, Modifications, Touched};
/// Output intents, the catalog's and (PDF 2.0) a page's: what
/// `Document::output_intents` and `Page::output_intents` hand back.
pub use output_intents::{OutputIntent, MAX_OUTPUT_INTENT_BYTES};
/// PDF/A conformance (ISO 19005), behind [`Document::validate_pdfa`].
pub use pdfa::{
    Clause, ConformanceFinding, Coverage as PdfACoverage, FindingKind, Flavour, Level, Part,
    RuleGroup as PdfARuleGroup, StagedRule, Verdict as PdfAVerdict, STAGED as PDFA_STAGED,
};
/// PDF/UA conformance (ISO 14289), behind [`Document::validate_pdfua`]: the
/// same findings, and the clauses this build abstains on, by name.
pub use pdfua::{
    Abstention as PdfUaAbstention, AbstentionClass as PdfUaAbstentionClass,
    Coverage as PdfUaCoverage, UaGap as PdfUaGap, UaPart as PdfUaPart, Verdict as PdfUaVerdict,
    STAGED as PDFUA_STAGED, UNDECIDABLE as PDFUA_UNDECIDABLE,
};
/// PDF/X conformance (ISO 15930), behind [`Document::validate_pdfx`]: the
/// 2003 levels' rules as the CGATS application notes restate them, and every
/// clause of the claimed level this build did not read, by name.
pub use pdfx::{
    Abstention as PdfXAbstention, AbstentionClass as PdfXAbstentionClass, Coverage as PdfXCoverage,
    Verdict as PdfXVerdict, XClaim as PdfXClaim, XFlavour as PdfXFlavour, XGap as PdfXGap,
    STAGED as PDFX_STAGED, UNREAD as PDFX_UNREAD,
};
/// Reading order, named — the stream's, the tree's, and one inferred from
/// geometry and labelled as such: [`Page::text_in`], [`Page::inferred_order`]
/// (`docs/design/reading-order.md`).
pub use reading_order::{
    DeclineReason, InferenceOptions, InferenceWarning, InferredBlock, InferredOrder, OrderedText,
    ReadingOrder, Role,
};
pub use signature::{
    Anchor, Coverage, CoverageDefect, SecurityStore, SecurityStoreWarning, Signature,
    SignatureWarning, SubFilter, ValidationEntry,
};
/// One-file documents that are not PDFs: what [`Document::open`] does with a
/// standalone SVG, a bare image and a loose XHTML file (tier 5).
pub use standalone::Standalone;
/// Tagged PDF: the logical structure tree, and the reading-order view over it
/// (14.7, 14.8).
pub use structure::{
    StructElement, StructKid, StructureTree, StructureWarning, StructuredNode, StructuredText,
    TextSource,
};
/// Font subsetting on rewrite (9.6.4, 9.9).
pub use subset::{SubsetReport, Subsetted, Type3Subsetted, Untouched, UntouchedReason};
/// Tables, stated in the structure tree and inferred from what a page draws:
/// [`Page::tables`], [`Page::stated_tables`], [`Page::inferred_tables`] and the
/// rules [`Page::table_rules`] reads (`docs/design/table-reconstruction.md`).
pub use tables::{
    HeaderEvidence, InferredCell, InferredTable, InferredTables, PageTables, StatedCell,
    StatedTable, TableEvidence, TableOptions, TableRule, TableRules, TableSource, TableWarning,
};
/// How [`Page::text_with`] orders a line: logical by default, or the content
/// stream's own order (ruling 14).
pub use text_order::TextOptions;
pub use tinker_pdf_content::{
    HyphenCounts, MarkedProps, PlainText, PlainTextOptions, Quad, SearchOptions, TextBlock,
    TextChar, TextLine, TextPage, TextWarning, TextWord, WritingMode,
};
/// Structured text serialisation — JSON, XML and HTML with fonts, sizes and
/// boxes — behind [`Page::text_frame`] and [`TextPage::serialize`].
pub use tinker_pdf_content::{PageFrame, TextFormat, TextWriter, TEXT_FORMAT_VERSION};
/// The strict validator's verdict (ruling 13), behind [`Document::validate`].
///
/// `kind_counts` and `tier_counts` are how a report says *which* rules a file
/// broke without carrying every instance of them.
pub use tinker_pdf_cos::{kind_counts, tier_counts, Defect, DefectKind, Tier};
pub use tinker_pdf_cos::{
    Action, Attachment, AuthError, AuthLevel, Date, DestKind, Destination, DocumentScript, Field,
    FieldKind, FieldScripts, FieldValue, LadderLevel, Link, Metadata, OutlineItem, Script,
    ScriptSummary, Trapped, Warning, WarningKind,
};
pub use tinker_pdf_cos::{
    BlendMode, CieSpace, DeviceSpace, ExtGState, FormXObject, Function, Glyph, MaskKind, PieceText,
    PlacedGlyph, Shading, ShadingPattern, StateMask, TextPiece, TilingPattern, TilingType,
    TransparencyGroup,
};
/// Streaming open: where a document's bytes come from when they are not all
/// in hand (`docs/design/streaming-open.md`).
///
/// [`ByteSource`] is the seam a host implements to supply ranges — a mapping,
/// a file handle, an HTTP server answering range requests. It is on this
/// facade rather than left in the crate underneath because ruling 11 makes
/// this the only public surface: a host that cannot name the trait cannot
/// implement it. [`SliceSource`] is the degenerate case every existing caller
/// already uses without knowing it, which is why [`Document::open`] keeps its
/// exact signature.
pub use tinker_pdf_cos::{
    ByteSource, CountingSource, ShreddedSource, SliceSource, SourceMiss, CHUNK_SIZE,
};
/// 9.6/9.7's font families and 9.9's `/FontFile*` keys, as [`Document::fonts`]
/// reports them.
///
/// Re-exported rather than twinned: both are `Copy` enums over a closed table
/// in the specification, so a facade copy would be a second enum to keep in
/// step and a `match` that stops being exhaustive without saying so. Ruling 11
/// asks that a caller be able to *name* what it is handed, and a re-export is
/// that.
pub use tinker_pdf_cos::{FontKind, ProgramKey};

/// How many bytes are read to decide whether a source holds a container.
///
/// `cbz::container` tests fixed positions and reads no further than byte 262;
/// one kilobyte is that with room, and it is one head read either way. It is
/// also the window a PDF header is looked for in, which is what lets a streamed
/// PDF skip [`standalone::sniff`]'s larger one.
const CONTAINER_SNIFF: u64 = 1024;
/// The per-family annotation payloads (12.5.6) behind [`Annotation::payload`],
/// the types they are built from, and [`Page::annotation_list`]'s answer —
/// every one of them a field type or a return type of the read surface, so a
/// caller can name what it is handed (ruling 11).
pub use annotations::{
    AnnotationList, AnnotationPayload, Border, BorderEffect, FileSpec, Linked, RichText,
    MAX_ANNOTATION_BYTES,
};
/// A page interpreted once and drawn at any scale: [`Page::display_list`].
pub use display::DisplayList;
/// Images a page draws, with their samples before any colour conversion and
/// the space they are in, behind [`Page::images`].
pub use images::{ImageMask, ImageSpace, PageImage, SampleCodec};
/// Why [`Bitmap::from_png`] would not read a file: the decoder's own reason,
/// named rather than collapsed, because "not a PNG" and "a colour type Table
/// 11.1 does not permit" are different answers to show a person.
pub use png_read::PngReadError;
/// Why [`Page::render_form`] or [`Page::render_annotation`] drew nothing.
pub use render_part::{NotDrawn, RenderPartError};
/// A page written as SVG 1.1: [`Page::to_svg`], and what it could not say.
pub use svg_out::{Rasterised, Svg, SvgOptions, SvgWarning, MAX_SVG_BYTES};
/// Writing: creation, editing and saving.
///
/// Without these on the facade a caller depending only on this crate could
/// read a document and never produce one, which is half a library.
///
/// The second block is gap 30 milestone 5's — the graphics state, transparency
/// groups, gradients, tiling patterns and glyphs addressed by index. Every one
/// of them is an *argument* to a [`DocumentBuilder`] method rather than
/// something a method hands back, and an argument type that cannot be named is
/// a method that cannot be called: without `ExtGState` on the facade,
/// `add_ext_gstate` is unreachable from outside this workspace. `DeviceSpace`
/// comes with them because `TransparencyGroup` and `Shading` are built from
/// one; it was already needed by `ImageColorSpace::Indexed` and already
/// missing, which is a gap 29 omission this closes as a side effect rather
/// than a policy this milestone changed.
///
/// `Target` is gap 31 milestone 5's, and it arrives for the same reason: it is
/// the argument to `PageBuilder::link` and the field an `OutlineEntry` carries,
/// so without it neither is callable from outside. Its view type is
/// [`DestKind`] — the **reader's** own, already on this facade — rather than a
/// second vocabulary for one concept, which is what makes a write followed by
/// a read an equality rather than a translation.
///
/// `EmbeddedWhole` and `SubsetRefusal` arrive with CFF subsetting and are the
/// return type of `DocumentBuilder::finish_reporting`, so without them on this
/// facade the method is callable and its answer is unnameable. They exist
/// because ruling 10 makes "the face went in whole" a reported fact rather
/// than an absence: a producer-made subset that this subsetter cannot beat is
/// a different event from a format it declines, and the caller is told which.
/// `EditCheckpoint` is gap 32 milestone 1's, and it is here for the reason
/// the paragraph above gives for `ExtGState` and `Target`: it is the return
/// type of [`DocumentEditor::checkpoint`] and the argument to
/// [`DocumentEditor::restore`], so without it on this facade neither method
/// can be named from outside this workspace. It is the closure-free spelling
/// of [`DocumentEditor::transaction`] — the same two functions, reachable from
/// a language that has no closures to hand across a boundary (ruling 11,
/// `docs/design/bindings-write.md`).
/// `ArchivalProfile` and the three types it is built from are milestone 6 of
/// `docs/design/pdfa.md`, and they are on this facade for the reason
/// `ExtGState` is: `DocumentBuilder::archival` cannot be called without naming
/// its argument. `ArchivalRefusal` comes with them because it is what
/// `finish_archival` returns and what `refusals` hands back — a refusal a
/// caller cannot name is a refusal they cannot match on, which is the thing
/// this whole surface exists to avoid.
///
/// `Tag` is the argument to `PageBuilder::tagged_with` and `open_tag`, the
/// tagging API that writes 14.9's properties; `is_language_tag` is the check
/// its `lang` documentation sends a caller to. `NamespaceId` is what
/// `DocumentBuilder::add_namespace` hands back and `Tag::namespace` takes, and
/// the three namespace URIs are ISO 32000-2's, which both the writer's
/// `add_namespace` and the reader's `StructElement::standard_namespace` speak.
/// `NewOutputIntent` is `PageBuilder::output_intent`'s argument, and
/// `NewAssociatedFile` the argument of every `associate_file`; the
/// `FileRelationship` it carries is the one `AssociatedFile` reads back.
pub use tinker_pdf_cos::{
    is_language_tag, is_standard_namespace, ArchivalLevel, ArchivalPart, ArchivalProfile,
    ArchivalRefusal, DocumentBuilder, DocumentEditor, EditCheckpoint, EmbeddedWhole, Encryption,
    FileRelationship, FillError, FillRejection, ImageData, NamespaceId, NewAssociatedFile,
    NewOutputIntent, OutlineEntry, PageBuilder, SkippedWidget, SubsetRefusal, TableAttributes,
    TableScope, Tag, Target, WidgetDefect, WriteMode, WriteOptions, MATHML_NAMESPACE,
    PDF_1_7_NAMESPACE, PDF_2_0_NAMESPACE,
};
/// Creating form fields (12.7.3), behind [`DocumentEditor::add_field`].
///
/// Here for the reason `ExtGState` is: [`NewField`] is the method's argument
/// and [`AddFieldError`] its refusal, and a method whose argument cannot be
/// named is callable by nobody outside this workspace (ruling 11). [`Rect`]
/// comes with them because every widget a field places is one; it is the
/// object model's own rectangle rather than a second spelling of four
/// numbers.
///
/// [`SignatureAppearance`] and [`SignatureImage`] are the payload of
/// [`SigningTarget::NewVisibleField`], the signature that draws a seal, and
/// are here for the same reason: a variant whose payload cannot be named is a
/// variant nobody outside this workspace can build.
pub use tinker_pdf_cos::{
    AddFieldError, NewField, NewFieldKind, RadioButton, Rect, SignatureAppearance, SignatureImage,
};
/// Document operations on [`DocumentEditor`]: page labels, embedded files,
/// `/Info` and XMP, viewer preferences, the production page boundaries, and
/// sanitising.
///
/// Each is the argument or the answer of an editor method, so each is here for
/// the reason `ExtGState` is above (ruling 11): a method whose argument cannot
/// be named from outside this workspace is a method nobody outside it can
/// call. `LabelStyle` was the reader's already and was never re-exported, so
/// [`Document::page_labels`]' vocabulary arrives with the writer's.
/// [`ViewerPreferences`] and [`PageBoundary`] are the reading side's types too
/// — [`Document::viewer_preferences`] and [`Page::trim_box`] hand back the
/// same values the editor takes, so a write followed by a read is an equality.
/// [`SanitiseReport`] is what [`DocumentEditor::sanitise`] answers with, and
/// every type its entries are built from comes with it, because a report whose
/// fields cannot be named cannot be read. [`SaveRefusal`] is what
/// [`DocumentEditor::check_save`] and [`DocumentEditor::check_decrypt`]
/// answer with: whether a save would undo an encryption.
pub use tinker_pdf_cos::{
    AttachError, DeletedObject, Duplex, EmbeddedFile, EnforcedPreference, EntryHolder, LabelStyle,
    MetadataSync, NonFullScreenPageMode, PageBoundary, PageLabelError, PageLabelRange, PathStep,
    PrintScaling, ReadingDirection, Removal, RemovedEntry, Sanitise, SanitiseReport, SaveRefusal,
    TreeWriteError, ViewerPreferences,
};
/// Form calculations: running the `/AA` calculate actions a form carries.
///
/// The interpreter itself is [`tinker_pdf_cos::script`]; these are the types a
/// caller of [`DocumentEditor::recalculate`] handles.
///
/// [`ScriptPolicy`] and [`Trigger`] are here for the reason `ExtGState` is:
/// they are the argument to [`DocumentEditor::recalculate_under`], so without
/// them on this facade the method is callable by nobody outside this
/// workspace (ruling 11). The same argument brings [`Keystroke`], which is
/// what [`DocumentEditor::keystroke`] takes, and [`EventVerdict`],
/// [`DisplayString`], [`ScriptScope`] and [`ScriptBudget`], which are what
/// the methods hand back or what a host builds to ask a question with.
///
/// [`DisplayString`] is worth one more sentence, because its whole job is to
/// be a type: it is what a format action produces, it has no `Deref` and no
/// `Into<String>`, and none of the write doors will take one — which is how
/// 12.7.3.3 stopped being a convention and became a guarantee.
pub use tinker_pdf_cos::{
    CalcError, DisplayString, EventVerdict, Keystroke, Recalculation, ScriptBudget, ScriptError,
    ScriptPolicy, ScriptScope, Trigger,
};
/// Graphics on write and on existing pages: the tint spaces and the
/// calculator a `/DeviceN` tint transform is written as, layers, and stamps.
///
/// [`CalculatorOp`] is the payload of [`Function::Calculator`] and
/// [`DeviceNAttributes`] the argument to
/// [`DocumentBuilder::add_device_n_color_space`], so without them here the
/// variant cannot be built and the method cannot be called from outside this
/// workspace — the omission the `ExtGState` paragraph above records (ruling
/// 11).
///
/// [`LayerId`] is what [`DocumentBuilder::add_layer`] hands back and what
/// [`PageBuilder::optional`] takes, so without it the two could not be joined
/// from outside this workspace.
///
/// [`StampPlacement`] is the argument to [`DocumentEditor::stamp`], for the
/// same reason.
pub use tinker_pdf_cos::{CalculatorOp, DeviceNAttributes, LayerId, StampPlacement};
/// Signing on an incremental save (12.8.1), behind
/// [`DocumentEditor::save_signed`].
///
/// The key never crosses this boundary: a [`Signer`] receives a digest and
/// returns finished CMS bytes. [`DigestAlgorithm`] is shared with the reading
/// side on purpose — one definition of what a `/ByteRange` covers, so what is
/// signed and what is checked cannot drift apart.
pub use tinker_pdf_cos::{
    Certification, DigestAlgorithm, FieldLock, SignError, SignRefused, Signer, SigningRequest,
    SigningTarget, TimestampRequest, Timestamper, ValidationData,
};
/// The bytes-already-encoded image road: everything [`ImageData::Compressed`]
/// is built out of.
///
/// [`ImageData`] was re-exported above and its `Compressed` variant was not
/// constructible, which is the same defect the paragraphs above record for
/// `ExtGState` and `Target` one level in: the *enum* could be named and the
/// payload could not, so the variant was visible in the documentation and
/// unreachable from any caller outside this workspace. That is worse than an
/// absent variant, because it reads as a capability.
///
/// The roadmap row that named this counted four. It is **five**:
/// [`CcittParams`] is the payload of [`ImageFilter::CcittFax`] and lives in the
/// filters crate rather than in the writer's, so a grep over the writer's own
/// names does not find it — and without it that variant can be neither built
/// nor matched on. [`DeviceSpace`] was the same omission caught earlier and is
/// already here, which is why it is not a sixth.
///
/// The doctest below is the check, and it is a compile rather than an
/// assertion: it names all five through this facade and nothing else, so
/// deleting any one of them fails `cargo test --doc` rather than quietly
/// reopening the row.
///
/// ```
/// use tinker_pdf::{
///     CcittParams, CompressedImage, DeviceSpace, DocumentBuilder, ImageColorSpace, ImageData,
///     ImageFilter, SoftMask,
/// };
///
/// // Four palette entries, so the samples below are indices rather than
/// // colours: `/Indexed` is what needs `DeviceSpace` for its base.
/// let palette = [0u8, 0, 0, 255, 0, 0, 0, 255, 0, 255, 255, 255];
/// // Two by two, one index a byte, deflated — `/FlateDecode` over the samples
/// // directly, which is what `ImageFilter::Flate` names.
/// let samples = [
///     0x78, 0xda, 0x63, 0x60, 0x64, 0x62, 0x06, 0x00, 0x00, 0x0e, 0x00, 0x07,
/// ];
/// // 11.6.5.3's `/SMask`: its own geometry, its own filter, always
/// // `/DeviceGray`.
/// let alpha = [255u8, 128, 128, 0];
///
/// let mut builder = DocumentBuilder::new();
/// assert!(builder.add_image(
///     b"Im0",
///     &ImageData::Compressed(CompressedImage {
///         width: 2,
///         height: 2,
///         bits_per_component: 8,
///         color_space: ImageColorSpace::Indexed {
///             base: DeviceSpace::Rgb,
///             lookup: &palette,
///         },
///         filter: Some(ImageFilter::Flate),
///         data: &samples,
///         color_key_mask: None,
///         soft_mask: Some(SoftMask {
///             width: 2,
///             height: 2,
///             bits_per_component: 8,
///             filter: None,
///             data: &alpha,
///         }),
///     }),
/// ));
///
/// // The fifth name. 7.4.6's parameters are the filters crate's own struct
/// // rather than a second spelling of `/K`, so this is the type that has to
/// // cross the facade for `CcittFax` to be nameable at all.
/// let fax = ImageFilter::CcittFax(CcittParams {
///     k: -1,
///     columns: 8,
///     rows: 1,
///     black_is_1: false,
///     byte_align: false,
///     end_of_line: false,
///     end_of_block: true,
/// });
/// assert!(matches!(fax, ImageFilter::CcittFax(p) if p.columns == 8));
///
/// builder.add_page(20.0, 20.0, |page| page.image(b"Im0", 0.0, 0.0, 20.0, 20.0));
/// assert!(!builder.finish().is_empty());
/// ```
pub use tinker_pdf_cos::{CompressedImage, ImageColorSpace, ImageFilter, SoftMask};
/// The object model behind [`Document::cos`].
///
/// The escape hatch is only an escape hatch if the types it hands back can be
/// named without depending on the crate underneath, so they are re-exported
/// here rather than left for a caller to find.
pub use tinker_pdf_cos::{
    CosDocument, CosError, Dict, Name, ObjRef, Object, PdfString, Revision, StreamObj, XrefEntry,
    XrefTable,
};
pub use tinker_pdf_cos::{EntropySource, PubSecError, PublicKeyEncryption, Recipient, SealError};
pub use tinker_pdf_crypto::Permissions;
/// 7.4.6 Table 11's `/CCITTFaxDecode` parameters, which
/// [`ImageFilter::CcittFax`] carries and this facade would otherwise leave
/// unnameable. It comes from the filters crate because there is one definition
/// of `/K` in this workspace and the decoder owns it — re-spelling it for the
/// writer is how a `/Rows` that is a strip's rather than an image's gets to
/// disagree with itself.
pub use tinker_pdf_filters::CcittParams;
pub use tinker_pdf_filters::PngError;
pub use tinker_pdf_raster::canvas::PixelFormat;
pub use tinker_pdf_render::{CancelToken, PixelRegion, RenderWarning};
/// Signature verdicts (12.8), behind [`Document::verify_signatures`].
pub use verdict::{
    AuthorityCertificate, Chain, CmsState, DocumentDigest, SignatureCheck, SignerDescription,
    Stamped, TimestampVerdict, TrustAnchors, Unchecked, Verdict, Weakness,
};
/// Saving, with the font policy attached to the save rather than left to the
/// caller's memory.
///
/// The function stays behind [`write::save`], as [`subset::apply`] does: a
/// bare `save` at the crate root next to [`tinker_pdf_cos::DocumentEditor`]'s
/// own `save` would be two doors with one name, and which door you used is
/// the thing this module exists to make visible.
pub use write::{
    BilevelCodec, ContinuousCodec, FontPolicy, ImageCoding, ImageOutcome, ImagePolicy,
    ImageRecoding, ImageReport, JpegTables, Recoded, SaveOptions, Saved, SubsetOutcome,
    UntouchedImage, UntouchedImageReason,
};
/// Fixed documents: the other thing a `PK\x03\x04` can be (gap 30).
pub use xps::{Dialect, XpsElementDefect, XpsPageDefect};

/// The engine's version.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// What this build is and what it can do.
///
/// Reachable on purpose: the engine this replaces blocklisted its own version
/// constant from its bindings, so nothing could report which build a bug
/// report came from.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct BuildInfo {
    /// The crate version.
    pub version: &'static str,
    /// The PDF specification this engine targets.
    pub spec: &'static str,
}

/// Describes this build.
#[must_use]
pub fn build_info() -> BuildInfo {
    BuildInfo {
        version: VERSION,
        spec: "ISO 32000-1 (PDF 1.7)",
    }
}

/// How a page should be rendered.
#[derive(Clone, Debug)]
pub struct RenderOptions {
    /// Pixels per PDF point. 1.0 renders at 72 dpi.
    pub scale: f64,
    /// How the bitmap stores its pixels.
    pub format: PixelFormat,
    /// Lets a caller stop a long render.
    pub cancel: Option<CancelToken>,
    /// Whether to draw annotation appearance streams over the page.
    ///
    /// On by default, because that is what a reader sees: a page rendered
    /// without its annotations is missing its highlights, its stamps and its
    /// filled-in form fields, and looks convincingly complete without them.
    pub annotations: bool,
    /// Which part of the page to render, or `None` for all of it.
    ///
    /// A rectangle of the **rendered bitmap's own pixels**, counting down from
    /// its top-left corner — [`PixelRegion`] argues why that unit and not
    /// points, and why that origin. The rest of the options mean exactly what
    /// they mean without it: a region changes the size of the buffer and where
    /// the page sits in it, and nothing else.
    ///
    /// # What it is for, and the promise that makes it worth having
    ///
    /// Ruling 5: **a tile is byte-equal to the corresponding sub-rectangle of
    /// the full-page render**, so a caller who cannot hold a whole page at
    /// 600 dpi can assemble one out of tiles and get the identical picture,
    /// seams included. That is a guarantee rather than an aspiration —
    /// `crates/tinker-pdf/tests/render_regions.rs` holds every fixture in that
    /// file to it at tile sizes that deliberately do not divide the page — and
    /// it is the reason a region is a rectangle of pixels rather than of
    /// points.
    ///
    /// It holds for a region trimmed by the page edge too: what comes back is
    /// the part of the ask that is on the page, which is still a sub-rectangle
    /// of the full render at the coordinates the caller named.
    ///
    /// ```no_run
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let bytes = std::fs::read("document.pdf")?;
    /// let doc = tinker_pdf::Document::open(bytes)?;
    /// let page = doc.page(0).ok_or("no first page")?;
    /// let mut options = tinker_pdf::RenderOptions::at_dpi(600.0);
    /// let (width, height) = page.pixel_size(&options);
    ///
    /// for top in (0..height).step_by(512) {
    ///     for left in (0..width).step_by(512) {
    ///         options.region = Some(tinker_pdf::PixelRegion::new(left, top, 512, 512));
    ///         let tile = page.render(&options);
    ///         // `tile` is exactly the 512x512 of the full render at (left, top),
    ///         // trimmed at the right and bottom edges of the page.
    ///         let _ = tile;
    ///     }
    /// }
    /// # Ok(())
    /// # }
    /// ```
    pub region: Option<PixelRegion>,
    /// Whether a page asked for in [`PixelFormat::CmykA8`] comes back in it.
    ///
    /// Off by default, and with it off `format: CmykA8` still returns
    /// `Rgba8`, as it always has. A `Bitmap` says how many components it has
    /// and nothing about what they mean, so a consumer handed five bytes of
    /// ink and reading the first three as red, green and blue produces a
    /// picture that looks almost right — which is why ink is not a page
    /// format by accident. This is the caller saying they know it is ink. It
    /// changes nothing for any other `format`.
    ///
    /// # What the ink is
    ///
    /// The page is composited **over ink** — a `/Multiply` darkens by adding
    /// ink, 11.3.5's separable formulas applied to complemented components —
    /// on a canvas that starts with none (`0, 0, 0, 0`, opaque), and the
    /// buffer is handed back as it stands instead of being converted to light
    /// at the end.
    ///
    /// **A DeviceCMYK colour is the document's own ink.** A fill, a stroke,
    /// a glyph or a stencil mask (8.9.6.2's image painted in the fill colour)
    /// whose colour was set in DeviceCMYK — `k`, `K`, or `sc`/`scn`
    /// in a space that is DeviceCMYK, named directly or through
    /// `/ColorSpace` — composites its own components, each
    /// `round(255 × component)`: `1 0 0 0 k` arrives as `(255, 0, 0, 0)` and
    /// a rich black `1 1 1 1 k` as all four inks. Every other colour is light
    /// where its resource is read, and a CMYK buffer turns light into ink by
    /// 8.6.4.4's relation inverted with maximum undercolour removal — `K`
    /// takes all the grey it can — so `1 0 0 rg` arrives as `(0, 255, 255, 0)`.
    /// That includes what is not a flat colour — an image, a shading — and
    /// the spaces whose components are not DeviceCMYK's although they may be
    /// ink: an ICC CMYK profile, and a `/Separation` or `/DeviceN` through its
    /// alternate.
    ///
    /// **What is drawn on ink keeps its ink, wherever it is drawn.** A form
    /// is drawn on the page. A coloured tiling pattern's cell (`/PaintType 1`)
    /// is drawn into a buffer of the page's own format and composited
    /// component for component, so a `k` inside it arrives as its components
    /// and an `rg` as light turned to ink, exactly as on the page. A
    /// transparency group does the same when it composites in ink — no `/CS`,
    /// or `/CS /DeviceCMYK` — and composites in the space it names otherwise
    /// (11.6.6), so a rich black inside a `/CS /DeviceRGB` group arrives as
    /// pure `K`. An uncoloured pattern (`/PaintType 2`) paints in the colour
    /// its `scn` operands gave, and that colour is light even over a
    /// DeviceCMYK base: `[/Pattern /DeviceCMYK]` with `1 1 1 1 /P0 scn` is
    /// pure `K` too.
    ///
    /// [`Bitmap::to_png`] writes an ink page as the light it stands for,
    /// under colour type 6 — PNG has no CMYK. Where every partly covered or
    /// blended pixel is one ink and black, those are exactly the bytes the
    /// same render without this switch returns; where two inks and black
    /// share a partial pixel they are not, because compositing is linear in
    /// whichever components the canvas holds and 8.6.4.4 is a product — half
    /// a pixel of rich black is a quarter of white over ink and half of it
    /// over light.
    pub allow_cmyk: bool,
    /// Whether edges are anti-aliased. On by default.
    ///
    /// Off, **every pixel of every shape is either wholly covered or not
    /// covered at all**: a text glyph, a filled or stroked path, a clip, an
    /// image's edge, a mesh shading's silhouette and a tiling pattern's cell
    /// all take one threshold — half a pixel's coverage — on the coverage the
    /// rasterizer already measures, so a hard edge lands where the soft one is
    /// half-way and a shape keeps its area. Two shapes sharing an edge split
    /// its pixels between them rather than leaving a gap.
    ///
    /// Only coverage is hardened. A constant alpha, a soft mask, an image's own
    /// alpha channel and the colours inside an image are the document's, and a
    /// page that uses them still has intermediate values where it asked for
    /// them. A stroke is at least one whole pixel wide with this off (8.4.3.2's
    /// thinnest line, on a device that cannot draw part of one), because a
    /// narrower line straddling two pixels would leave each less than half
    /// covered and disappear. A feature of a glyph narrower than half a pixel
    /// can still disappear where it straddles a pixel edge, which is the price
    /// every threshold pays.
    ///
    /// A tile is still byte-equal to the page under it (ruling 5): the
    /// threshold is a function of one pixel's coverage, and the coverage
    /// already agreed.
    pub antialias: bool,
    /// Whether the page starts with nothing painted on it rather than white.
    /// Off by default.
    ///
    /// Only a format with an alpha channel can hold *nothing* — `GrayA8`,
    /// `Rgba8`, and `CmykA8` with [`RenderOptions::allow_cmyk`] — so with
    /// `Gray8` or `Rgb8` this changes nothing, and a page comes back on white
    /// as it always has. With one of those, a pixel nothing painted is
    /// `(0, 0, 0, 0)`, a pixel a half-opaque fill covers has an alpha of half,
    /// and an anti-aliased edge has the alpha its coverage gave it: the page as
    /// a layer, for a caller who composites it over something else.
    ///
    /// The page is composited exactly as it is over white, against a backdrop
    /// of nothing instead — 11.3.6's formulas with a backdrop alpha of zero,
    /// which the canvas already computes for every transparency group, where a
    /// group's buffer starts the same way.
    pub transparent: bool,
    /// Whether colour comes back **premultiplied** by alpha. Off by default.
    ///
    /// The canvas composites in straight alpha throughout — `tinker-pdf-raster`'s
    /// compositing documents why, and it is the convention every blend formula
    /// in 11.3 is written in — so this is a conversion at the very end: each
    /// colour component `c` of a pixel with alpha `a` becomes `c·a/255`,
    /// rounded to nearest (there is never a tie: `c·a` is an integer and 255 is
    /// odd). [`Bitmap::premultiplied`] says which the bytes are.
    ///
    /// On a page composited over white every pixel is opaque, and a pixel with
    /// an alpha of 255 is the same in both conventions — so this changes
    /// nothing unless [`RenderOptions::transparent`] is on too, and it is only
    /// meaningful for a format with alpha. It is kept independent of
    /// `transparent` all the same, because a caller whose compositor takes
    /// premultiplied input wants to say so once rather than know which pages
    /// happen to be opaque.
    ///
    /// [`Bitmap::to_png`] writes straight alpha, which is the only kind PNG
    /// has; a premultiplied bitmap is divided back out on the way. That is
    /// exact for a pixel whose alpha is 255 and loses precision below it, the
    /// same precision premultiplying lost: multiplying the PNG's samples by
    /// their alpha again gives back the premultiplied bytes exactly.
    pub premultiplied: bool,
}

impl Default for RenderOptions {
    fn default() -> Self {
        RenderOptions {
            scale: 1.0,
            format: PixelFormat::Rgb8,
            cancel: None,
            annotations: true,
            region: None,
            allow_cmyk: false,
            antialias: true,
            transparent: false,
            premultiplied: false,
        }
    }
}

impl RenderOptions {
    /// Options rendering at a resolution in dots per inch.
    #[must_use]
    pub fn at_dpi(dpi: f64) -> RenderOptions {
        RenderOptions {
            scale: dpi / 72.0,
            ..RenderOptions::default()
        }
    }
}

/// A rendered page.
#[derive(Clone, Debug)]
pub struct Bitmap {
    /// Width in pixels.
    pub width: u32,
    /// Height in pixels.
    pub height: u32,
    /// How pixels are stored.
    pub format: PixelFormat,
    /// Bytes per row.
    pub stride: usize,
    /// The pixels.
    pub data: Vec<u8>,
    /// What the renderer could not do exactly (ruling 2).
    pub warnings: Vec<RenderWarning>,
    /// Whether each colour component has been multiplied by its pixel's
    /// alpha ([`RenderOptions::premultiplied`]).
    ///
    /// `false` for every format without alpha, where the question does not
    /// arise, and for every bitmap [`Bitmap::from_png`] reads, because PNG's
    /// alpha is straight.
    pub premultiplied: bool,
}

impl Bitmap {
    /// How many bytes each pixel occupies.
    #[must_use]
    pub fn components(&self) -> usize {
        self.format.components()
    }

    /// This bitmap as a complete PNG file (ISO/IEC 15948), 8 bits a component.
    ///
    /// `None` exactly when the bitmap is not a picture: a zero `width` or
    /// `height`, a `stride` narrower than one row, or a `data` shorter than
    /// the rows the other three fields promise. There is nothing to degrade
    /// to — a PNG with no pixels is not a smaller PNG.
    ///
    /// [`Page::render`] produces a picture for every page, at every scale, and
    /// for every [`RenderOptions::region`] that meets the page: a page is at
    /// least one pixel and its buffer is sized from its own dimensions. The one
    /// way to render a bitmap that is not a picture is to ask for a region
    /// wholly off the page, which trims to nothing and says so with
    /// [`RenderWarning::RegionClamped`]. `Bitmap`'s fields are public besides,
    /// so a caller may always build one by hand.
    ///
    /// # Every format, and the two that cannot be written as they are
    ///
    /// PNG has five colour types — 0 grey, 2 truecolour, 3 indexed, 4 grey
    /// with alpha, 6 truecolour with alpha — and **no CMYK and no Lab**. Four
    /// of the six [`PixelFormat`]s are one of those layouts already and are
    /// written byte for byte. The other two are converted here, and the
    /// conversion is the point rather than a detail:
    ///
    /// | `PixelFormat` | Colour type | What happens |
    /// | --- | --- | --- |
    /// | `Gray8` | 0 | the bytes, unchanged |
    /// | `Rgb8` | 2 | the bytes, unchanged |
    /// | `GrayA8` | 4 | the bytes, unchanged |
    /// | `Rgba8` | 6 | the bytes, unchanged |
    /// | `CmykA8` | 6 | 8.6.4.4's device relation, ink to light; alpha kept |
    /// | `LabA8` | 6 | `L*a*b*` decoded back to sRGB; alpha kept |
    ///
    /// `tinker_pdf_render::page_format`'s own doc already argues why this must
    /// happen rather than being refused or passed through: a `Bitmap` says how
    /// many components it has and **nothing about what they mean**, so a
    /// consumer reading three bytes and calling them red, green and blue is
    /// handed ink and produces a picture that looks almost right. That is why
    /// `CmykA8` is a page format only for a caller who asks for it by name
    /// *and* sets [`RenderOptions::allow_cmyk`]. It is constructible besides —
    /// the fields are public, and a transparency group compositing over ink
    /// (11.6.6) is a real buffer of this shape — so this method has to be
    /// total over all six, and writing four components under colour type 6
    /// would put cyan, magenta and yellow into a file labelled RGB. An ink page
    /// written here is the light it stands for, byte for byte what the same
    /// render without `allow_cmyk` would have returned.
    ///
    /// # Eight bits, and what the round trip is therefore at
    ///
    /// Table 11.1 permits 16-bit components for four of the five colour types
    /// and this writes none: every `PixelFormat` is a byte a channel, so a
    /// 16-bit file would carry eight bits of information in each pair of
    /// bytes. **A 16-bit PNG read into a `Bitmap` and written back out comes
    /// back at 8-bit precision**, which is the precision the `Bitmap` had.
    ///
    /// [`Bitmap::from_png`] is the other direction, and for the four formats
    /// written byte for byte it is an exact inverse: dimensions, stride and
    /// bytes all come back as they went out.
    ///
    /// ```no_run
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let bytes = std::fs::read("document.pdf")?;
    /// let doc = tinker_pdf::Document::open(bytes)?;
    /// let page = doc.page(0).ok_or("no first page")?;
    /// let bitmap = page.render(&tinker_pdf::RenderOptions::at_dpi(150.0));
    /// std::fs::write("page-1.png", bitmap.to_png().ok_or("not a picture")?)?;
    /// # Ok(())
    /// # }
    /// ```
    #[must_use]
    pub fn to_png(&self) -> Option<Vec<u8>> {
        use tinker_pdf_filters::{png_encode, PngColour, PngSource};

        // PNG's alpha is straight, so premultiplied colour is divided back
        // out first; see `RenderOptions::premultiplied` for what that keeps.
        if self.premultiplied {
            return self.straightened()?.to_png();
        }

        // The four formats PNG already has a colour type for: no copy, and the
        // stride is handed through rather than flattened, because a padded
        // buffer's padding is not pixels.
        let direct = |colour: PngColour| PngSource {
            width: self.width,
            height: self.height,
            colour,
            stride: self.stride,
            data: &self.data,
        };
        let converted: Vec<u8>;
        let source = match self.format {
            PixelFormat::Gray8 => direct(PngColour::Grey),
            PixelFormat::GrayA8 => direct(PngColour::GreyAlpha),
            PixelFormat::Rgb8 => direct(PngColour::Rgb),
            PixelFormat::Rgba8 => direct(PngColour::Rgba),
            PixelFormat::CmykA8 | PixelFormat::LabA8 => {
                converted = self.to_rgba()?;
                PngSource {
                    width: self.width,
                    height: self.height,
                    colour: PngColour::Rgba,
                    stride: self.width as usize * 4,
                    data: &converted,
                }
            }
        };
        png_encode(&source).ok()
    }

    /// Multiplies every colour component by its pixel's alpha, in place, and
    /// records that it has. A format without alpha, or a bitmap that already
    /// is, is left alone.
    ///
    /// Row by row over `stride`, so a padded buffer's padding is not touched,
    /// and a row the buffer is too short to hold is skipped rather than read
    /// past (ruling 1: the fields are public).
    fn premultiply(&mut self) {
        if self.premultiplied || !self.format.has_alpha() {
            return;
        }
        let components = self.format.components();
        let colours = components - 1;
        let row_bytes = (self.width as usize).saturating_mul(components);
        for y in 0..self.height as usize {
            let Some(row) = y
                .checked_mul(self.stride)
                .and_then(|at| self.data.get_mut(at..at.checked_add(row_bytes)?))
            else {
                break;
            };
            for pixel in row.chunks_exact_mut(components) {
                // `chunks_exact_mut` hands out exactly `components` bytes, so
                // the alpha is the one byte after the colours.
                let (colour, alpha) = pixel.split_at_mut(colours);
                let a = u32::from(alpha.first().copied().unwrap_or(255));
                for c in colour {
                    // round(c·a/255): `c·a` is an integer and 255 is odd, so
                    // the fraction is never exactly a half.
                    *c = ((u32::from(*c) * a + 127) / 255) as u8;
                }
            }
        }
        self.premultiplied = true;
    }

    /// A straight-alpha copy of a premultiplied bitmap, or `None` when a row
    /// the fields promise is not in the buffer.
    ///
    /// `round(c·255/a)`, clamped to 255 for a component the premultiplied
    /// convention does not allow (`c > a`), and zero where the alpha is:
    /// nothing is painted there and there is no colour to recover.
    fn straightened(&self) -> Option<Bitmap> {
        let components = self.format.components();
        let colours = components.checked_sub(1)?;
        let row_bytes = (self.width as usize).checked_mul(components)?;
        let mut data = Vec::with_capacity(row_bytes.checked_mul(self.height as usize)?);
        for y in 0..self.height as usize {
            let at = y.checked_mul(self.stride)?;
            let row = self.data.get(at..at.checked_add(row_bytes)?)?;
            for pixel in row.chunks_exact(components) {
                let (colour, alpha) = pixel.split_at(colours);
                let a = u32::from(*alpha.first()?);
                for c in colour {
                    let straight = (u32::from(*c) * 255 + a / 2)
                        .checked_div(a)
                        .map_or(0, |v| v.min(255));
                    data.push(straight as u8);
                }
                data.push(a as u8);
            }
        }
        Some(Bitmap {
            width: self.width,
            height: self.height,
            format: self.format,
            stride: row_bytes,
            data,
            warnings: Vec::new(),
            premultiplied: false,
        })
    }

    /// The two formats PNG cannot carry, as straight RGBA.
    ///
    /// Both keep their alpha, which is what makes truecolour-with-alpha the
    /// right target for each: a `CmykA8` pixel is five bytes and a `LabA8` one
    /// is four, and both carry an alpha that a three-component target would
    /// have to drop or composite against a background nobody asked for.
    ///
    /// `None` when the buffer is shorter than the rows it promises — the same
    /// condition [`Bitmap::to_png`] answers `None` for, found here first
    /// because this is where the bytes are read.
    fn to_rgba(&self) -> Option<Vec<u8>> {
        let components = self.format.components();
        let width = self.width as usize;
        let mut out = Vec::with_capacity(width.checked_mul(self.height as usize)?.checked_mul(4)?);
        for y in 0..self.height as usize {
            let row = self.data.get(y.checked_mul(self.stride)?..)?;
            for x in 0..width {
                // Both ends checked: `width x components` is arithmetic on a
                // caller's own numbers, and an end that wrapped would be a
                // slice inside the buffer rather than a `None` (ruling 1).
                let at = x.checked_mul(components)?;
                let px = row.get(at..at.checked_add(components)?)?;
                let (r, g, b, a) = match self.format {
                    // 8.6.4.4, through the rasterizer's own byte-level copy of
                    // the relation — held to `tinker_pdf_color`'s by a test in
                    // `tinker-pdf-render` over every combination that matters,
                    // so the two cannot drift apart behind this call.
                    PixelFormat::CmykA8 => {
                        let (r, g, b) =
                            tinker_pdf_raster::canvas::cmyk_to_rgb(px[0], px[1], px[2], px[3]);
                        (r, g, b, px[4])
                    }
                    // The inverse of the `L/100`, `(a + 128)/255`,
                    // `(b + 128)/255` encoding `PixelFormat::LabA8` documents,
                    // taken from the crate that owns it rather than rewritten.
                    _ => {
                        let (r, g, b) = tinker_pdf_raster::canvas::lab_to_rgb(px[0], px[1], px[2]);
                        (r, g, b, px[3])
                    }
                };
                out.extend_from_slice(&[r, g, b, a]);
            }
        }
        Some(out)
    }
}

/// Why a document could not be opened.
///
/// **`#[non_exhaustive]`**, from gap 29 milestone 4, which is what let
/// milestone 5 add [`OpenError::UnsupportedArchive`] without a second break.
/// Gaps 30 and 31 expect their own. `Copy`, `PartialEq` and `Eq` are kept,
/// because `tests/tinker_parity.rs` compares values of this type by ruling 12.
/// `Clone` but not `Copy`: [`OpenError::SourceUnavailable`] carries the range
/// that was wanted, and a range is not `Copy`. Naming the bytes is worth more
/// than the convenience — a host told only "a range was missing" has to guess
/// which one to fetch, which is the whole question it needed answered.
#[derive(Clone, Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum OpenError {
    /// Nothing in the bytes resembles a PDF: not one indirect object could be
    /// found, even after a full rescan.
    ///
    /// Failing to be a PDF is not the same as failing to be a *document*: a
    /// container this build recognises and cannot page gets its own answer
    /// rather than being collapsed into this one.
    NotAPdf,
    /// The bytes are empty.
    ///
    /// Distinguished from [`OpenError::NotAPdf`] because it is almost always a
    /// caller's bug — a path that did not exist, a stream not read to the end —
    /// rather than a bad document, and telling the two apart is the difference
    /// between checking the file and checking the code.
    Empty,
    /// The bytes are a container this build recognises and cannot open as a
    /// document.
    ///
    /// The reason is named rather than collapsed into [`OpenError::NotAPdf`],
    /// because "I do not read CBR" and "this is not a document" are different
    /// answers and a host shows different things for them. See
    /// [`ArchiveRefusal`].
    UnsupportedArchive(ArchiveRefusal),
    /// A [`ByteSource`] could not supply the bytes an open must have.
    ///
    /// Only [`Document::open_streaming`] produces it, and the right response
    /// is the opposite of [`OpenError::NotAPdf`]'s: fetch the range the
    /// [`SourceMiss`] names and call again. Collapsing the two — which this
    /// enum did until the C ABI needed to tell a host which one had happened —
    /// makes the seam unusable for the thing it exists for, because "not a
    /// PDF" is a reason to stop.
    ///
    /// Only the head window produces it. A miss further in has the rescan
    /// ladder underneath it and degrades (ruling 2) rather than failing.
    SourceUnavailable(SourceMiss),
}

/// Why a document could not be *used* after it opened.
///
/// Separate from [`OpenError`]: a document that needs a password has opened
/// perfectly well, and a caller has to be able to tell that from bytes that
/// were never a PDF. Collapsing both into one variant meant every failure
/// looked like a corrupt file.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DocumentError {
    /// The document is encrypted and no password has been accepted yet.
    ///
    /// Call [`Document::authenticate`]; the empty string is the right first
    /// try, since a document encrypted only to restrict permissions has no
    /// user password.
    PasswordRequired,
    /// The document is encrypted with a handler this build does not implement.
    UnsupportedEncryption,
}

impl core::fmt::Display for DocumentError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            DocumentError::PasswordRequired => f.write_str("a password is required"),
            DocumentError::UnsupportedEncryption => {
                f.write_str("the encryption handler is not supported")
            }
        }
    }
}

impl std::error::Error for DocumentError {}

impl core::fmt::Display for OpenError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            OpenError::NotAPdf => f.write_str("not a PDF: no indirect objects found"),
            OpenError::Empty => f.write_str("no bytes to read"),
            OpenError::UnsupportedArchive(why) => write!(f, "not opened as a document: {why}"),
            OpenError::SourceUnavailable(miss) => write!(f, "the source could not supply {miss}"),
        }
    }
}

impl std::error::Error for OpenError {}

/// What a **reflowable** document needs decided before it has any pages.
///
/// Every field is ignored by a PDF, a CBZ and an XPS, which have their own page
/// geometry and always did — except [`OpenOptions::fonts`], which is where a
/// font provider goes for *any* document and is on this type because for a book
/// it decides more than glyphs.
///
/// # Why this exists at `open` and not later
///
/// A PDF page is fixed and a reflowable book is not, so somebody has to choose
/// the box a book is laid out into — and that choice decides how many pages
/// there are. Three facts made every later seam wrong:
///
/// 1. [`RenderOptions`] is a parameter of [`Page::render`], so it arrives
///    **after** pagination; its `scale` is a resolution and not a page box.
/// 2. [`Document::with_fonts`] is a builder that arrives **after** `open`.
/// 3. Line breaking needs advance widths, so a book laid out at `open` with no
///    provider is laid out with metrics the render then does not use.
///
/// A `with_fonts` that silently does not change the pagination is exactly the
/// invisible partial implementation gap 31 exists to prevent, so the late path
/// warns by name — [`ArchiveWarning::FontsAttachedAfterPagination`] — and this
/// is where a provider goes if it is to decide anything.
///
/// **For a reflowable EPUB the page count is a function of these numbers and is
/// not a property of the file.** Two hosts that pass different boxes get
/// different books, on purpose, and [`ArchiveReport::layout`] is where a caller
/// reads back which numbers produced the page count it is holding.
///
/// `mutool draw` takes `-W`, `-H` and `-S` for exactly these three fields,
/// separately from its render resolution. Agreeing with the implementation gap
/// 28 is removing is evidence the seam is in the right place.
///
/// ```no_run
/// # fn main() -> Result<(), Box<dyn std::error::Error>> {
/// let bytes = std::fs::read("book.epub")?;
/// let mut options = tinker_pdf::OpenOptions::default();
/// options.page = (600.0, 800.0);
/// let doc = tinker_pdf::Document::open_with(bytes, &options)?;
/// # Ok(())
/// # }
/// ```
#[derive(Clone)]
#[non_exhaustive]
pub struct OpenOptions {
    /// The page box a reflowable document is laid out into, in points.
    ///
    /// [`epub::DEFAULT_PAGE`] — 432 × 648, six inches by nine — and that number
    /// is argued where it is declared rather than here.
    pub page: (f64, f64),
    /// The base font size, in points, that `1rem` and an unstyled paragraph
    /// resolve to. [`epub::DEFAULT_FONT_SIZE`].
    pub font_size: f64,
    /// Faces for text the document does not embed.
    ///
    /// Here rather than only on [`Document::with_fonts`], because a substituted
    /// face's advance widths decide where every line breaks and therefore how
    /// many pages a reflowable document has. For a PDF, a comic and a fixed
    /// document it does exactly what `with_fonts` does and arrives earlier.
    pub fonts: Option<Arc<dyn FontProvider>>,
}

impl Default for OpenOptions {
    fn default() -> Self {
        OpenOptions {
            page: epub::DEFAULT_PAGE,
            font_size: epub::DEFAULT_FONT_SIZE,
            fonts: None,
        }
    }
}

impl OpenOptions {
    /// Options laying a reflowable document into a page box, in points.
    #[must_use]
    pub fn at_page(width: f64, height: f64) -> OpenOptions {
        OpenOptions {
            page: (width, height),
            ..OpenOptions::default()
        }
    }

    /// The same options with a font provider attached.
    #[must_use]
    pub fn with_fonts(mut self, provider: Arc<dyn FontProvider>) -> OpenOptions {
        self.fonts = Some(provider);
        self
    }
}

impl core::fmt::Debug for OpenOptions {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("OpenOptions")
            .field("page", &self.page)
            .field("font_size", &self.font_size)
            .field("fonts", &self.fonts.is_some())
            .finish()
    }
}

/// An open document.
///
/// Cheap to clone: the bytes and the object store are shared.
#[derive(Clone)]
pub struct Document {
    inner: Arc<CosDocument>,
    /// Where glyphs come from for fonts the document does not embed.
    ///
    /// None by default: the engine bundles no faces and reads no font
    /// directories, so a host that wants text drawn for such documents says
    /// where to find it. See [`fonts`].
    fonts: Option<Arc<dyn FontProvider>>,
    /// Present only when this document was **synthesised** from a container
    /// rather than parsed from a PDF. See [`Document::archive`].
    archive: Option<Arc<ArchiveReport>>,
}

/// Opens a recognised container **once** and routes it by what it holds.
///
/// One `Archive::open` for all three formats, which is gap 30 milestone 3's own
/// exit criterion rather than a nicety: opening it to sniff and again to read
/// doubles the central-directory walk and creates a window in which the two
/// reads could disagree about the same bytes. [`xps::route`] and [`epub::route`]
/// each hand the archive back **unread** when it is not theirs, and the cheap
/// half of both decisions costs no read at all.
///
/// # The order, and why each step is where it is
///
/// **XPS first, unchanged.** ECMA-388 E.3's three steps, all of them, exactly
/// as gap 30 wrote them. Its step 2 asks for `[Content_Types].xml` and
/// `_rels/.rels`, and gap 31's milestone 1 measured that **no** EPUB carries
/// either — 0 of 26 books — so an EPUB fails E.3 at step 2's first check having
/// read nothing, and this step is a comparison per entry for a book as it
/// already was for a comic.
///
/// **EPUB second**, by the presence of `META-INF/container.xml` (OCF 3.3
/// §4.2.6.3). It goes after XPS rather than before because E.3 is a
/// specification's own recipe and this is not: nothing in OCF says a container
/// may not also carry OPC's two items, and a file that satisfies both tests is
/// better read by the standard that describes how to recognise itself.
///
/// **The comic path is the fallthrough**, which is what E.3's own text asks
/// for. A ZIP that is neither is a bag of images, and that is the reading gap
/// 29 shipped.
///
/// `options` reaches only the EPUB step, because it is the only format here
/// whose page geometry its own file does not state. The two before it read
/// their sizes out of the package and ignore every field.
fn open_container(
    what: Container,
    bytes: &[u8],
    options: &OpenOptions,
) -> Result<(Vec<u8>, ArchiveReport), ArchiveRefusal> {
    let comic = cbz::Limits::DEFAULT;
    if what != Container::Zip {
        // **One routing table, and this is the delegation that keeps it one.**
        // Before tier 4 this line was `Err(NotAZip)` and `cbz::synthesise`
        // carried the same sentence a second time, so the two would have
        // disagreed about which containers are readable the moment either
        // gained a format — and the disagreement compiles.
        //
        // Only a ZIP can be an XPS or an EPUB: OPC and OCF are both ZIP by
        // definition, so the three-step route below is a question about ZIPs.
        // Every other container this build recognises is a comic archive and
        // nothing else, which is why the delegation is safe as well as short.
        return cbz::synthesise(what, bytes, &comic);
    }
    let archive = cbz::open_archive(bytes, &comic.zip)?;
    let archive = match xps::route(archive, &xps::Limits::DEFAULT) {
        xps::Routing::Document(pdf, report) => return Ok((pdf, report)),
        xps::Routing::Refused(why) => return Err(why),
        xps::Routing::NotXps(archive) => archive,
    };
    // A caller's number is checked once, here, before any book is read: the
    // defects belong in the report of the document that was laid out at the
    // replacement, and a book that turns out not to be one never sees them.
    let (layout, unusable) = epub::BookLayout::sanitised(options.page, options.font_size);
    let archive = match epub::route(archive, &epub::Limits::DEFAULT, &layout) {
        epub::Routing::Document(pdf, mut report) => {
            for defect in unusable {
                report.warn(ArchiveWarning::UnusableOption(defect));
            }
            return Ok((pdf, report));
        }
        epub::Routing::Refused(why) => return Err(why),
        epub::Routing::NotEpub(archive) => archive,
    };
    // **FB2's own packaging, before the comic fallthrough.** An `.fb2.zip` is
    // a ZIP of exactly one file, and that file is a FictionBook document —
    // decided by the sniff of its bytes and never by its name, for
    // `cbz::image_format`'s reason. Anything else, a one-image comic
    // included, is a comic as it always was; that comic's one entry is then
    // inflated twice, which `MAX_ZIP_ENTRY_BYTES` (128 MiB) twice over keeps
    // well inside the archive's 1 GiB `MAX_ZIP_INFLATED`.
    let mut archive = archive;
    let files: Vec<usize> = archive
        .entries()
        .iter()
        .enumerate()
        .filter(|(_, entry)| !entry.name.ends_with('/'))
        .map(|(at, _)| at)
        .collect();
    if let [only] = files[..] {
        if let Ok(inner) = cbz::read_entry(&mut archive, only) {
            if standalone::sniff(&inner) == Some(Standalone::Fb2) {
                let (layout, unusable) =
                    epub::BookLayout::sanitised(options.page, options.font_size);
                let (pdf, mut report) = standalone::synthesise(Standalone::Fb2, &inner, &layout)?;
                for warning in archive.warnings() {
                    report.warn(ArchiveWarning::Zip(*warning));
                }
                for defect in unusable {
                    report.warn(ArchiveWarning::UnusableOption(defect));
                }
                return Ok((pdf, report));
            }
        }
    }
    cbz::pages_from_archive(archive, &comic)
}

/// The first `end` bytes of a source, or as many as it holds.
///
/// **A loop, because a source may answer a range in pieces** — `ByteSource`
/// permits a short read and [`ShreddedSource`] serves exactly one byte. The
/// container sniff used to be one `read`, and over a source that splits its
/// answers it saw one byte of `PK\x03\x04`, so a comic archive streamed from
/// one was "not a PDF". A source that ends early ends the loop rather than
/// spinning on it: end of file is an answer, not a miss.
fn filled(source: &dyn ByteSource, end: u64) -> Result<Vec<u8>, OpenError> {
    let end = end.min(source.len());
    let mut bytes = Vec::with_capacity(usize::try_from(end).unwrap_or(0));
    let mut at = 0u64;
    while at < end {
        let got = source.read(at..end).map_err(OpenError::SourceUnavailable)?;
        if got.is_empty() {
            break;
        }
        at += got.len() as u64;
        bytes.extend_from_slice(&got);
    }
    Ok(bytes)
}

impl Document {
    /// Opens a document from bytes.
    ///
    /// Bytes rather than a path because `wasm32-unknown-unknown` has no
    /// filesystem and is a first-class target; native callers read the file
    /// themselves, or memory-map it and pass the mapping.
    ///
    /// A damaged file opens anyway wherever anything can be recovered — see
    /// [`Document::ladder_level`] and [`Document::warnings`] for what that
    /// cost.
    ///
    /// # Containers
    ///
    /// Bytes that **begin** with a container signature are not read as a PDF.
    /// A tar and a 7z become comic documents through `tinker-pdf-archive`
    /// (tier 4); RAR is refused by name. A ZIP is **one signature over five
    /// formats**, so it is opened once and then asked what it is: an XPS
    /// package becomes a document whose pages are its fixed pages (gap 30), an
    /// EPUB becomes a document whose pages are its spine (gap 31), and anything
    /// else is synthesised into a document whose pages are its images (gap 29).
    ///
    /// **A book paginates at a page box this call does not state**, so it gets
    /// the default: 432 × 648 points, from [`epub::DEFAULT_PAGE`]. See
    /// [`Document::open_with`] and [`OpenOptions`], where the page count stops
    /// being a property of the file.
    ///
    /// The order is not arbitrary and it is argued in [`open_container`]: the
    /// XPS test is ECMA-388 E.3's, all three steps of it, the EPUB test is
    /// OCF's `META-INF/container.xml`, and the comic path is the fallthrough —
    /// because an XPS or an EPUB mis-routed to the comic path is gap 30's and
    /// gap 31's headline defect, where a comic mis-routed either way would be a
    /// refusal where a document used to open.
    ///
    /// The signatures are tested at a fixed position and nowhere else, so a PDF
    /// that happens to carry `PK\x03\x04` inside a stream is unaffected — see
    /// [`cbz::container`].
    ///
    /// # Errors
    /// [`OpenError::Empty`] for no bytes, [`OpenError::UnsupportedArchive`] for
    /// a container this build recognises and cannot open as a document, and
    /// [`OpenError::NotAPdf`] when not one indirect object could be found.
    pub fn open(bytes: impl Into<Arc<[u8]>>) -> Result<Document, OpenError> {
        Document::open_with(bytes, &OpenOptions::default())
    }

    /// Opens a document, stating what a **reflowable** one needs decided before
    /// it has any pages.
    ///
    /// Identical to [`Document::open`] for a PDF, a comic archive and a fixed
    /// document, whose page geometry their own files state — except that
    /// [`OpenOptions::fonts`] is honoured for all of them, which is
    /// [`Document::with_fonts`] arriving early enough to matter.
    ///
    /// For an EPUB it is the difference between one book and another: **the
    /// page count is a function of [`OpenOptions::page`] and is not a property
    /// of the file.** See that type for why the seam is here rather than at
    /// `render` or at `with_fonts`.
    ///
    /// [`Document::open`]'s own signature is unchanged by this, deliberately:
    /// ruling 12's `tinker_parity.rs` compares it, and every existing caller
    /// keeps the defaults. `open(bytes)` *is* `open_with(bytes,
    /// &OpenOptions::default())`, which is written that way rather than
    /// duplicated so the two can never drift.
    ///
    /// # Errors
    /// The same three as [`Document::open`].
    pub fn open_with(
        bytes: impl Into<Arc<[u8]>>,
        options: &OpenOptions,
    ) -> Result<Document, OpenError> {
        let bytes: Arc<[u8]> = bytes.into();
        if bytes.is_empty() {
            return Err(OpenError::Empty);
        }

        if let Some(container) = cbz::container(&bytes) {
            let synthesised = open_container(container, &bytes, options)
                .map_err(OpenError::UnsupportedArchive)?;
            return Document::synthesised(synthesised, options);
        }
        // After the containers, because every signature there is a fixed
        // position a one-file document cannot also hold, and before the PDF
        // parser, because that parser's rescan would read an SVG as a damaged
        // PDF with no objects. `sniff` answers `None` for anything with a PDF
        // header where the COS parser looks for one, so a PDF never reaches
        // this.
        if let Some(kind) = standalone::sniff(&bytes) {
            let (layout, unusable) = epub::BookLayout::sanitised(options.page, options.font_size);
            let (pdf, mut report) = standalone::synthesise(kind, &bytes, &layout)
                .map_err(OpenError::UnsupportedArchive)?;
            // A bare image's page is its own pixels and never the caller's
            // box, so a bad box is only news for a document laid out into one.
            if report.layout().is_some() {
                for defect in unusable {
                    report.warn(ArchiveWarning::UnusableOption(defect));
                }
            }
            return Document::synthesised((pdf, report), options);
        }

        let inner = CosDocument::open(bytes).map_err(|_| OpenError::NotAPdf)?;
        Ok(Document {
            inner: Arc::new(inner),
            fonts: fonts::effective(options.fonts.clone()),
            archive: None,
        })
    }

    /// A document over a PDF this crate synthesised, and the report saying
    /// where its pages came from.
    fn synthesised(
        (pdf, report): (Vec<u8>, ArchiveReport),
        options: &OpenOptions,
    ) -> Result<Document, OpenError> {
        // These bytes came out of this repository's own writer moments ago, so
        // a parse failure is a defect here rather than a claim about the
        // input — but ruling 1 forbids asserting it, and `Damaged` is the
        // honest thing to say to a caller who cannot act on the difference
        // either way.
        let inner = CosDocument::open(pdf)
            .map_err(|_| OpenError::UnsupportedArchive(ArchiveRefusal::Damaged))?;
        Ok(Document {
            inner: Arc::new(inner),
            fonts: fonts::effective(options.fonts.clone()),
            archive: Some(Arc::new(report)),
        })
    }

    /// Opens bytes as a **Markdown** document (CommonMark 0.31.2, tier 5's
    /// formats row), laid out as a loose XHTML file is.
    ///
    /// A separate entry point rather than a branch of [`Document::open`],
    /// because Markdown has no signature: it is text, and a sniff that called
    /// text Markdown would turn every file that is not a PDF into a document of
    /// its own bytes — where `open` answers [`OpenError::NotAPdf`] for them,
    /// and `tinker_parity.rs` holds it to that. The caller who knows the bytes
    /// are Markdown says so here. See [`markdown`] for what is and is not
    /// CommonMark, and [`standalone::TranslationDefect`] for what the report
    /// names.
    ///
    /// # Errors
    /// [`OpenError::Empty`] for no bytes, and
    /// [`OpenError::UnsupportedArchive`]`(`[`ArchiveRefusal::TooLarge`]`)` for a
    /// document past the synthesised-document ceiling. Nothing else refuses.
    pub fn open_markdown(
        bytes: impl Into<Arc<[u8]>>,
        options: &OpenOptions,
    ) -> Result<Document, OpenError> {
        let bytes: Arc<[u8]> = bytes.into();
        if bytes.is_empty() {
            return Err(OpenError::Empty);
        }
        let (layout, unusable) = epub::BookLayout::sanitised(options.page, options.font_size);
        let (pdf, mut report) =
            standalone::markdown(&bytes, &layout).map_err(OpenError::UnsupportedArchive)?;
        for defect in unusable {
            report.warn(ArchiveWarning::UnusableOption(defect));
        }
        Document::synthesised((pdf, report), options)
    }

    /// Opens a document whose bytes are fetched from `source` as they are
    /// needed (`docs/design/streaming-open.md`).
    ///
    /// The same document as [`Document::open`] over the same bytes: the same
    /// pages, the same warnings, the same ladder level and the same pixels.
    /// A source is where bytes come from, never what they mean, and ruling 4
    /// makes that a contract rather than an intention -- the determinism
    /// fingerprints are run over a source that answers one byte at a time and
    /// must come out bit-identical.
    ///
    /// # Containers are whole-file, and say so
    ///
    /// A ZIP's central directory is at its end and synthesising a document
    /// from one rewrites the whole thing, so a recognised container fetches
    /// every byte before it is opened. That is declared rather than hidden:
    /// [`Document::whole_file_fetched`] answers true afterwards.
    ///
    /// # Errors
    /// The same three as [`Document::open`]. A source that cannot supply the
    /// bytes the open path needs is [`OpenError::NotAPdf`], because a document
    /// nobody could read is not one this call can return.
    pub fn open_streaming(source: Arc<dyn ByteSource>) -> Result<Document, OpenError> {
        Document::open_streaming_with(source, &OpenOptions::default())
    }

    /// [`Document::open_streaming`], stating what a reflowable document needs
    /// decided before it has any pages.
    ///
    /// # Errors
    /// The same three as [`Document::open`].
    pub fn open_streaming_with(
        source: Arc<dyn ByteSource>,
        options: &OpenOptions,
    ) -> Result<Document, OpenError> {
        if source.is_empty() {
            return Err(OpenError::Empty);
        }
        // The signatures are tested at a fixed position and nowhere else, so
        // one head window answers the question for every container this build
        // recognises -- `cbz::container` reads no further than byte 262.
        let head = filled(&*source, CONTAINER_SNIFF)?;
        // A one-file document is whole-file for a container's reason: an SVG's
        // and an XHTML file's last element can be its first page's, and a bare
        // image is one picture. Its sniff looks further in than the container
        // one, so it is asked only when the first window holds no PDF header —
        // which keeps a PDF whose header is in its first kilobyte to the reads
        // it always made. One with more junk in front than that costs the read
        // of the head window the parser searches for its header anyway, and
        // `sniff` answers `None` for it there, as it does buffered.
        let standalone = !head.windows(5).any(|w| w == b"%PDF-") && {
            let wider = filled(&*source, standalone::SNIFF_WINDOW as u64)?;
            standalone::sniff(&wider).is_some()
        };
        if cbz::container(&head).is_some() || standalone {
            // Whole-file by contract, and the only honest way to read one.
            let bytes = filled(&*source, source.len())?;
            if bytes.len() as u64 != source.len() {
                return Err(OpenError::NotAPdf);
            }
            return Document::open_with(bytes, options);
        }

        let inner = CosDocument::open_source(source).map_err(|error| match error {
            tinker_pdf_cos::OpenError::SourceUnavailable(miss) => {
                OpenError::SourceUnavailable(miss)
            }
            tinker_pdf_cos::OpenError::NoObjects => OpenError::NotAPdf,
        })?;
        Ok(Document {
            inner: Arc::new(inner),
            fonts: fonts::effective(options.fonts.clone()),
            archive: None,
        })
    }

    /// Whether this document's bytes are fetched from a [`ByteSource`].
    #[must_use]
    pub fn is_streamed(&self) -> bool {
        self.inner.is_streamed()
    }

    /// Where the first page's objects end (Annex F `/E`), when this document
    /// was opened on the linearized fast path.
    ///
    /// `None` for every other document. A caller measuring what a page-one
    /// render cost asks this for where the tail starts, rather than assuming
    /// a fraction of the file.
    #[must_use]
    pub fn first_page_end(&self) -> Option<u64> {
        self.inner.first_page_end()
    }

    /// Whether the main cross-reference table has been fetched.
    ///
    /// Always true for a document that did not open on Annex F's head-only
    /// path, which has one table and read it at open. For one that did, this
    /// is how a caller sees whether a page was reached through the hint
    /// tables, which cost that page's own bytes, or through the page tree,
    /// which costs the table at `/T` and therefore the tail.
    #[must_use]
    pub fn main_table_fetched(&self) -> bool {
        self.inner.main_table_fetched()
    }

    /// Whether every byte of the document has been fetched.
    ///
    /// Always true for one opened from a buffer. For a streamed one it is how
    /// a caller sees that a whole-file operation has happened.
    #[must_use]
    pub fn whole_file_fetched(&self) -> bool {
        self.inner.whole_file_fetched()
    }

    /// Where this document's pages came from, when it was synthesised from a
    /// container rather than parsed from a PDF.
    ///
    /// `None` for an ordinary PDF, which is how a caller tells the two apart.
    /// [`Document::cos`] answers the same for both, on purpose: the synthesised
    /// document is a real one, with a real catalog, a real page tree and real
    /// image XObjects, and it is what the renderer was given.
    #[must_use]
    pub fn archive(&self) -> Option<&ArchiveReport> {
        self.archive.as_deref()
    }

    /// Supplies fonts for documents that do not embed their own.
    ///
    /// Without one, such a document extracts its text perfectly — the
    /// standard-14 metrics are built in — and draws none of it, reporting
    /// [`RenderWarning::UnreadableFont`]. The engine bundles no faces and
    /// reads no font directories: bundling is a licensing decision and
    /// reading a directory is an operating-system dependency, and
    /// `wasm32-unknown-unknown` has neither.
    ///
    /// # On a reflowable document this is **too late**, and it says so
    ///
    /// A book's line breaks were decided when it was paginated, at `open`, from
    /// the metrics available then. A provider attached here still supplies
    /// glyphs; what it cannot do is change how many pages there are or which
    /// page a sentence is on. Silently accepting a provider that changes
    /// nothing is precisely the invisible partial implementation gap 31 exists
    /// to prevent, so this records
    /// [`ArchiveWarning::FontsAttachedAfterPagination`] on the document's own
    /// report — and [`OpenOptions::fonts`] is the route that works.
    ///
    /// Nothing is warned about for a PDF, a comic or a fixed document, whose
    /// pages this cannot move.
    #[must_use]
    pub fn with_fonts(mut self, provider: Arc<dyn FontProvider>) -> Document {
        // Through the same seam `open_with` uses, so the two cannot disagree
        // about whether a `bundled-fonts` build's own faces apply.
        self.fonts = fonts::effective(Some(provider));
        if let Some(report) = self.archive.as_mut() {
            if report.layout().is_some() {
                Arc::make_mut(report).warn(ArchiveWarning::FontsAttachedAfterPagination);
            }
        }
        self
    }

    /// Whether the bytes look like a PDF, without opening them.
    ///
    /// A PDF, specifically. [`Document::open`] also opens a comic archive, and
    /// this answers `false` for one — [`cbz::container`] is the question to ask
    /// about those.
    #[must_use]
    pub fn sniff(bytes: &[u8]) -> bool {
        let window = bytes.get(..1024.min(bytes.len())).unwrap_or_default();
        window.windows(5).any(|w| w == b"%PDF-")
    }

    /// How much repair opening the document needed.
    #[must_use]
    pub fn ladder_level(&self) -> LadderLevel {
        self.inner.ladder_level()
    }

    /// Everything the engine tolerated, in the order it happened.
    #[must_use]
    pub fn warnings(&self) -> Vec<Warning> {
        self.inner.warnings()
    }

    /// Reads the file again strictly, and reports what a tolerant read let
    /// through (ruling 13).
    ///
    /// [`Document::warnings`] says what the *reader* repaired. This says what
    /// is wrong with the file, which is a larger set: the reader's repairs
    /// plus every structure it never consults — the cross-reference sections
    /// as the bytes spell them, stream extents against `endstream`, the
    /// trailer against Table 15. An empty verdict is the strongest statement
    /// this repository makes about a file it wrote.
    ///
    /// Authenticate an encrypted document first: a stream that cannot be
    /// decrypted reads as one that does not decode.
    #[must_use]
    pub fn validate(&self) -> Vec<Defect> {
        tinker_pdf_cos::validate(&self.inner)
    }

    /// Whether the document is encrypted.
    #[must_use]
    pub fn is_encrypted(&self) -> bool {
        self.inner.is_encrypted()
    }

    /// How far the accepted password got.
    #[must_use]
    pub fn auth_level(&self) -> AuthLevel {
        self.inner.auth_level()
    }

    /// The document's permission flags, respecting the authentication level.
    ///
    /// An unencrypted document and one opened with the owner password both
    /// permit everything. Note that PDF permissions are advisory: a document
    /// that says printing is denied is asking, not enforcing.
    #[must_use]
    pub fn permissions(&self) -> Permissions {
        self.inner.permissions()
    }

    /// Tries a password.
    ///
    /// Reports **which** password matched, which the engine this replaces
    /// could not: its binding collapsed the C API's bitmask to a boolean, so
    /// "the owner password lifts every restriction" was unimplementable.
    ///
    /// Takes `&self`, so it works on a document that has already been shared —
    /// cloned, or had a page taken from it, which every caller does. Requiring
    /// unique ownership made the most ordinary sequence in the API
    /// (look at a page, then supply the password) report an encrypted document
    /// as unencrypted.
    pub fn authenticate(&self, password: &str) -> Result<AuthLevel, AuthError> {
        self.inner.authenticate(password)
    }

    /// Whether the document can be read, or what it wants first.
    ///
    /// A caller that opens a file and immediately asks for its text needs to
    /// know the difference between "this is not a PDF" and "this is a PDF and
    /// it wants a password". `open` answers the first; this answers the
    /// second, which it cannot, because a document that needs a password has
    /// opened perfectly well.
    ///
    /// # Errors
    /// [`DocumentError::PasswordRequired`] when the document is encrypted and
    /// nothing has been authenticated, and
    /// [`DocumentError::UnsupportedEncryption`] when the handler is one this
    /// build does not implement.
    pub fn readable(&self) -> Result<(), DocumentError> {
        if !self.is_encrypted() {
            return Ok(());
        }
        if self.auth_level() == AuthLevel::None {
            // An empty user password is the common case for a document
            // encrypted only to restrict permissions, and `open` does not try
            // it — trying it here would hide the distinction this exists for.
            return Err(DocumentError::PasswordRequired);
        }
        Ok(())
    }

    /// The number of pages.
    #[must_use]
    pub fn page_count(&self) -> u32 {
        cos_pages::count(&self.inner)
    }

    /// Every page, in document order.
    #[must_use]
    pub fn pages(&self) -> Vec<Page> {
        cos_pages::collect(&self.inner)
            .into_iter()
            .map(|inner| Page {
                doc: self.inner.clone(),
                inner,
                fonts: self.fonts.clone(),
            })
            .collect()
    }

    /// One page by zero-based index.
    #[must_use]
    pub fn page(&self, index: u32) -> Option<Page> {
        // Through the bounded walk rather than `pages()`, which collects every
        // page: on a streamed document opened through Annex F's head-only
        // path, the rest of the page tree is the rest of the file, and asking
        // for page one would spend all of it.
        let inner = cos_pages::at(&self.inner, index)?;
        Some(Page {
            doc: Arc::clone(&self.inner),
            inner,
            fonts: self.fonts.clone(),
        })
    }

    /// The document's logical structure tree (14.7.2).
    ///
    /// `None` when the catalog has no `/StructTreeRoot`, which is what most
    /// documents are. **Nothing is inferred for them**: 14.7 describes
    /// structure a producer writes down, and a tree guessed from geometry
    /// would be this engine's opinion about reading order presented as the
    /// file's own statement of it.
    ///
    /// Bound on every call rather than cached. A structure tree is read by
    /// callers that want one, which is a small fraction of them, and a cache
    /// on a `Clone` handle over a shared object store is a lifetime question
    /// this does not need to answer to be correct.
    #[must_use]
    pub fn structure(&self) -> Option<StructureTree> {
        structure::bind(&self.inner)
    }

    /// The document's information dictionary.
    #[must_use]
    pub fn metadata(&self) -> Metadata {
        cos_outline::metadata(&self.inner)
    }

    /// The version, as "PDF 1.7".
    ///
    /// The later of the header's (7.5.2) and the catalog's (7.7.2), never
    /// absent: a document stating neither reports the 1.7 baseline and says
    /// so with a `HeaderMissing` warning.
    #[must_use]
    pub fn pdf_version(&self) -> String {
        cos_outline::version_string(&self.inner)
    }

    /// The outline tree; empty when the document has none.
    #[must_use]
    pub fn outline(&self) -> Vec<OutlineItem> {
        cos_outline::outline(&self.inner)
    }

    /// Page labels, when the document defines them.
    #[must_use]
    pub fn page_labels(&self) -> Vec<String> {
        cos_outline::page_labels(&self.inner, self.page_count())
    }

    /// Every file attached to the document (7.11.4).
    ///
    /// Attachments are how a PDF carries a spreadsheet next to the report made
    /// from it, and how some invoicing standards carry their machine-readable
    /// half. The bytes are not read here — listing what a document carries
    /// should not cost what extracting it costs — so each entry hands back the
    /// stream reference to read through [`Document::cos`].
    #[must_use]
    pub fn attachments(&self) -> Vec<Attachment> {
        tinker_pdf_cos::attachments(&self.inner)
    }

    /// The document's XMP metadata, unparsed (14.3.2).
    ///
    /// RDF/XML, handed over as bytes: parsing it needs an XML reader this
    /// engine does not have and should not grow, and a caller that wants it
    /// already has one.
    #[must_use]
    pub fn xmp_metadata(&self) -> Option<Vec<u8>> {
        tinker_pdf_cos::xmp_metadata(&self.inner)
    }

    /// How the document asks to be shown and printed (12.2, Table 147).
    ///
    /// Every entry typed and every one an `Option`: `None` is the document
    /// saying nothing, which a viewer answers with the table's default, and is
    /// not the same file as one stating that default. Most documents state
    /// none of them.
    #[must_use]
    pub fn viewer_preferences(&self) -> ViewerPreferences {
        tinker_pdf_cos::viewer_preferences(self.inner.as_ref())
    }

    /// Every font the document's pages can reach (9.5 to 9.9).
    ///
    /// Name, family, whether the program is embedded, the subset tag, and
    /// where the program is — the bytes themselves only when
    /// [`DocumentFont::program_bytes`] is called, because a font program is
    /// routinely a megabyte and a caller who wanted a list did not ask for
    /// one. See [`crate::fontlist`] for the whole projection argument.
    ///
    /// Each font once, however many pages and resource names reach it, with
    /// the names it answered to on [`DocumentFont::resource_names`]. A
    /// composite font is one entry: 9.7.4 makes the descendant CIDFont part
    /// of it rather than a font of its own.
    ///
    /// Reachable means what an interpreter could bind — the pages'
    /// `/Resources`, the form XObject, tiling pattern, Type 3 and
    /// annotation-appearance scopes those open, and the form's `/DR`
    /// (12.7.3.3), where a field's `/DA` resolves its font and where a face
    /// no page mentions can be the only one a document carries.
    ///
    /// **This adds nothing to [`Document::warnings`].** Listing is a read,
    /// and a read that changed what the document reports about itself would
    /// make the answer depend on the order the caller asked in.
    #[must_use]
    pub fn fonts(&self) -> Vec<DocumentFont> {
        fontlist::of_document(&self.inner)
    }

    /// The document's optional content groups, in `/OCProperties /OCGs` order
    /// (8.11).
    ///
    /// Each with its `/Name` and whether the **default** configuration `/D`
    /// shows it (8.11.4.3) — the same answer, from the same bound
    /// configuration, that decides what [`Page::render`] paints. Empty for
    /// the great majority of documents, which declare no optional content.
    ///
    /// Read only. Writing groups and toggling a configuration are the other
    /// half of the roadmap's optional content row and are not in this build.
    #[must_use]
    pub fn layers(&self) -> Vec<OptionalGroup> {
        layers::of_document(&self.inner)
    }

    /// The document's interactive form fields (12.7).
    ///
    /// Empty when the document has no `/AcroForm`, which is most documents.
    #[must_use]
    pub fn form_fields(&self) -> Vec<Field> {
        tinker_pdf_cos::fields(&self.inner)
    }

    /// Opens a public-key-encrypted document with the caller's key (7.6.5).
    ///
    /// `/Adobe.PubSec` seals the file key to certificates rather than to a
    /// password, so there is nothing to type: the caller implements
    /// [`Recipient`], is handed the sealed key and the identifier saying whose
    /// it is, and does the one private-key operation this engine refuses to be
    /// able to do. Returning `None` from it means "not addressed to me".
    ///
    /// # Errors
    /// [`PubSecError`], which tells "this document is somebody else's" apart
    /// from every other way it can fail.
    pub fn authenticate_with_recipient(
        &self,
        recipient: &dyn Recipient,
    ) -> Result<AuthLevel, PubSecError> {
        self.inner.authenticate_with_recipient(recipient)
    }

    /// The document's digital signatures (12.8), in field order.
    ///
    /// One entry per signature field that carries a `/V`; a signature field
    /// with no value is a place for a signature rather than a signature, and
    /// [`Document::form_fields`] already lists it.
    ///
    /// Nothing here is verified. Each entry says what the file claims and what
    /// checking that claim against the file established — in particular
    /// [`Signature::coverage`], which is the difference between a signature
    /// over this document and a signature over some of it.
    #[must_use]
    pub fn signatures(&self) -> Vec<Signature> {
        signature::signatures(self)
    }

    /// What every signature in this document turns out to prove (12.8).
    ///
    /// One [`Verdict`] per signature, in the order [`Document::signatures`]
    /// returns them. `anchors` are the certificates the *caller* trusts —
    /// with none, the chain result is [`Chain::NoAnchors`], which is honest:
    /// without something trusted to reach, a chain proves that a key signed
    /// something and not whose key it was.
    ///
    /// `at` is the instant to judge certificate validity at, in seconds since
    /// the Unix epoch. `None` reports the windows and judges nothing, which is
    /// the default because ruling 4 bans a clock from this engine and because
    /// "expired" is a claim about now.
    #[must_use]
    pub fn verify_signatures(&self, anchors: &TrustAnchors, at: Option<i64>) -> Vec<Verdict> {
        self.signatures()
            .iter()
            .map(|signature| verdict::verdict(self, signature, anchors, at))
            .collect()
    }

    /// The document security store (ISO 32000-2 12.8.4.3): the long-term
    /// validation material the catalog's `/DSS` carries, as references to its
    /// streams, and the `/VRI` entries filing some of it under particular
    /// signatures ([`SecurityStore::entry_for`]). `None` when there is none:
    /// no `/DSS`, a null one, or a reference to no object (7.3.10). A `/DSS`
    /// that is something other than a dictionary is an empty store whose
    /// warnings say so, and every member skipped for its type is named the
    /// same way ([`SecurityStoreWarning`]).
    ///
    /// Surfaced and never evaluated: nothing here reads a CRL or an OCSP
    /// response, and the verdict does not consult the store.
    #[must_use]
    pub fn security_store(&self) -> Option<SecurityStore> {
        signature::security_store(self)
    }

    /// What this build makes of the document's PDF/A claim (ISO 19005).
    ///
    /// A list of findings rather than a verdict: conformance is the list being
    /// empty **and** [`PdfACoverage::is_complete`] being true, and until the
    /// remaining rule groups land it is not. A caller reaching for a boolean
    /// should read both.
    #[must_use]
    pub fn validate_pdfa(&self) -> PdfAVerdict {
        pdfa::validate(self, PdfACoverage::IMPLEMENTED)
    }

    /// [`Document::validate_pdfa`], running only the rule groups in `groups`.
    ///
    /// The design doc requires that a syntax-only sweep over the whole veraPDF
    /// corpus never builds the machinery the other groups need, and a
    /// requirement nothing can ask for is a requirement nothing can check. This
    /// is how it is asked for: [`PdfACoverage::SYNTAX`] parses no XMP packet at
    /// all, and the verdict's own `coverage` reports back exactly which groups
    /// ran, so a caller cannot read a short sweep as a clean bill of health.
    ///
    /// Asking for a group this build has no rules for is not an error and does
    /// not make the verdict claim it ran — `coverage` is what actually
    /// happened, never what was requested.
    #[must_use]
    pub fn validate_pdfa_with(&self, groups: PdfACoverage) -> PdfAVerdict {
        pdfa::validate(self, groups)
    }

    /// What this build makes of the document's PDF/UA claim (ISO 14289).
    ///
    /// Findings for the clauses a reader decides, numbered by the part the
    /// file claims, and — in the same struct — every clause this build did
    /// not decide, as [`PdfUaVerdict::abstained`], each staged or
    /// undecidable with its reason. An empty finding list is "nothing this
    /// build decides was broken", never "it conforms": most of ISO 14289 is
    /// a judgement about meaning no reader makes (`docs/design/pdfua.md`).
    #[must_use]
    pub fn validate_pdfua(&self) -> PdfUaVerdict {
        pdfua::validate(self, PdfUaCoverage::IMPLEMENTED)
    }

    /// [`Document::validate_pdfua`], running only the rule groups in
    /// `groups`; the verdict's own `coverage` says which ran.
    #[must_use]
    pub fn validate_pdfua_with(&self, groups: PdfUaCoverage) -> PdfUaVerdict {
        pdfua::validate(self, groups)
    }

    /// What this build makes of the document's PDF/X claim (ISO 15930).
    ///
    /// The claim is `/Info`'s `GTS_PDFXVersion`, read with no XML parse.
    /// Rules run under PDF/X-1a:2003 and PDF/X-3:2003 only — transcribed from
    /// the CGATS application notes, the one free restatement of those levels —
    /// and [`PdfXVerdict::abstained`] names every clause of the claimed level
    /// this build did not decide. No annotated PDF/X corpus exists, so these
    /// rules have a false-positive bar and no false-negative one
    /// (`docs/design/pdfx.md`): an empty finding list is "nothing this build
    /// looked for was broken", never "it conforms". A file claiming nothing is
    /// not judged.
    #[must_use]
    pub fn validate_pdfx(&self) -> PdfXVerdict {
        pdfx::validate(self, PdfXCoverage::IMPLEMENTED)
    }

    /// [`Document::validate_pdfx`], running only the rule groups in
    /// `groups`; the verdict's own `coverage` says which ran.
    #[must_use]
    pub fn validate_pdfx_with(&self, groups: PdfXCoverage) -> PdfXVerdict {
        pdfx::validate(self, groups)
    }

    /// The strictest certification any signature in this document declares
    /// (12.8.2.2), or `None` when none of them certifies it.
    ///
    /// A shortcut past `signatures()` for the common question "is this
    /// document certified, and how tightly".
    #[must_use]
    pub fn certification(&self) -> Option<Certification> {
        mdp::strictest(self)
    }

    /// What the form's calculations depend on, in the order they run
    /// (12.7.2, table 218).
    ///
    /// The references are field objects; match them against
    /// [`Field::reference`]. Empty for a form that declares no order, which
    /// includes forms whose fields calculate anyway.
    #[must_use]
    pub fn calculation_order(&self) -> Vec<ObjRef> {
        tinker_pdf_cos::calculation_order(&self.inner)
    }

    /// The document-level scripts, from `/Names /JavaScript` (7.7.4).
    #[must_use]
    pub fn document_scripts(&self) -> Vec<DocumentScript> {
        tinker_pdf_cos::document_scripts(&self.inner)
    }

    /// The catalog's `/AA` additional actions (12.6.3, table 200).
    #[must_use]
    pub fn catalog_scripts(&self) -> Vec<DocumentScript> {
        tinker_pdf_cos::catalog_scripts(&self.inner)
    }

    /// How much script this document's form carries — the fields' `/AA`,
    /// `/CO`, `/Names /JavaScript` and the catalog's `/AA` — for a caller that
    /// has to say so before it fills anything.
    ///
    /// Not every script the document carries: `/OpenAction`, page and
    /// annotation actions, outline actions and `/Next` chains are not counted
    /// ([`tinker_pdf_cos::script_summary`]). Reading a script runs nothing.
    #[must_use]
    pub fn script_summary(&self) -> ScriptSummary {
        tinker_pdf_cos::script_summary(&self.inner)
    }

    /// The underlying object model, for callers that need raw access.
    #[must_use]
    pub fn cos(&self) -> &CosDocument {
        &self.inner
    }

    /// An editor over this document, for callers that want to write it back.
    ///
    /// [`Document::cos`] *lends* the object model and [`DocumentEditor`] needs
    /// to *share* it, so without this a caller who opened a document through
    /// this facade could read it and never save it — including a document
    /// synthesised from a comic archive, which is the one thing gap 29 wanted a
    /// third party to be able to check.
    #[must_use]
    pub fn editor(&self) -> DocumentEditor {
        DocumentEditor::new(self.inner.clone())
    }
}

impl core::fmt::Debug for Document {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("Document")
            .field("pages", &self.page_count())
            .field("encrypted", &self.is_encrypted())
            .field("ladder", &self.ladder_level())
            .finish()
    }
}

/// One page.
#[derive(Clone)]
pub struct Page {
    doc: Arc<CosDocument>,
    inner: cos_pages::Page,
    fonts: Option<Arc<dyn FontProvider>>,
}

impl Page {
    /// Zero-based position in the document.
    #[must_use]
    pub fn index(&self) -> u32 {
        self.inner.index
    }

    /// `/MediaBox`, as `(x0, y0, x1, y1)` in points.
    #[must_use]
    pub fn media_box(&self) -> (f64, f64, f64, f64) {
        let r = self.inner.media_box;
        (r.x0, r.y0, r.x1, r.y1)
    }

    /// `/CropBox`, clipped to the media box.
    #[must_use]
    pub fn crop_box(&self) -> (f64, f64, f64, f64) {
        let r = self.inner.crop_box;
        (r.x0, r.y0, r.x1, r.y1)
    }

    /// `/BleedBox` (14.11.2): the page's own, clipped to the media box, and
    /// the crop box when the page states none.
    ///
    /// Never inherited from the page tree: 7.7.3.3 Table 30 does not make the
    /// three production boxes inheritable, so a value on a `/Pages` node
    /// describes no page.
    #[must_use]
    pub fn bleed_box(&self) -> (f64, f64, f64, f64) {
        self.boundary(PageBoundary::BleedBox)
    }

    /// `/TrimBox` (14.11.2): the finished page after trimming, under
    /// [`Page::bleed_box`]'s rules.
    #[must_use]
    pub fn trim_box(&self) -> (f64, f64, f64, f64) {
        self.boundary(PageBoundary::TrimBox)
    }

    /// `/ArtBox` (14.11.2): the extent of the page's meaningful content, under
    /// [`Page::bleed_box`]'s rules.
    #[must_use]
    pub fn art_box(&self) -> (f64, f64, f64, f64) {
        self.boundary(PageBoundary::ArtBox)
    }

    /// Any of the five boundaries, as `(x0, y0, x1, y1)` in points.
    #[must_use]
    pub fn boundary(&self, boundary: PageBoundary) -> (f64, f64, f64, f64) {
        let r = self.inner.boundary(boundary);
        (r.x0, r.y0, r.x1, r.y1)
    }

    /// `/Rotate`, normalized to 0, 90, 180 or 270.
    #[must_use]
    pub fn rotation(&self) -> u16 {
        self.inner.rotation
    }

    /// The page's size in points after rotation, which is what a viewer lays
    /// out.
    #[must_use]
    pub fn size(&self) -> (f64, f64) {
        self.inner.display_size()
    }

    /// The size in pixels of the bitmap [`Page::render`] produces for these
    /// options, **ignoring `options.region`**: the whole page, at this scale.
    ///
    /// The rounding is not arithmetic a caller can do for themselves from
    /// [`Page::size`] and [`RenderOptions::scale`], which is why this exists
    /// rather than being left as folklore: the sides round *outward*, a
    /// non-finite or non-positive scale is read as 1.0, and a page whose area
    /// would pass `MAX_PAGE_PIXELS` is scaled down to fit. A caller who wants
    /// to tile needs the real answer to all three, because a tile lattice
    /// computed from a wrong page size leaves a strip of the page unrendered
    /// and nothing says so.
    #[must_use]
    pub fn pixel_size(&self, options: &RenderOptions) -> (u32, u32) {
        let (w, h) = self.size();
        tinker_pdf_render::page_pixels(w, h, self.scales(options).1)
    }

    /// The scale asked for and the scale that will be used, in that order.
    ///
    /// One spelling for both, because [`Page::pixel_size`] and [`Page::render`]
    /// have to agree about the answer exactly — a caller tiles by the first and
    /// is handed pixels by the second, and a lattice computed against a
    /// different clamp than the one the renderer applied leaves a strip of the
    /// page nothing ever asks for.
    fn scales(&self, options: &RenderOptions) -> (f64, f64) {
        let (w, h) = self.size();
        let scale = if options.scale.is_finite() && options.scale > 0.0 {
            options.scale
        } else {
            1.0
        };
        // The canvas is clamped for an enormous page; the transform has to be
        // clamped by the same factor or the content is drawn full-size onto a
        // smaller surface, which crops instead of scaling.
        (scale, tinker_pdf_render::page_scale(w, h, scale))
    }

    /// Renders the page to a bitmap.
    ///
    /// The bitmap's size is the page's *displayed* size — the crop box, with
    /// its axes swapped for a quarter-turn `/Rotate` — scaled and **rounded
    /// outward** so a page never loses its last row or column: A4 at 150 dpi
    /// is 1240×1755. [`RenderOptions::region`] narrows it to a rectangle of
    /// those pixels, and then the bitmap is that rectangle's size.
    #[must_use]
    pub fn render(&self, options: &RenderOptions) -> Bitmap {
        let content = cos_pages::content_bytes(&self.doc, &self.inner);
        self.render_layer(options, None, |renderer, resources| {
            interpret(&content, Matrix::IDENTITY, renderer, resources);
            if options.annotations {
                // After the content, because an annotation sits on top of the
                // page rather than under it.
                annots::draw(&self.doc, &self.inner, self.fonts.as_ref(), renderer);
            }
        })
    }

    /// **The one pipeline every render of this page goes through** — the page
    /// itself, a form on it ([`Page::render_form`]) and one of its annotations
    /// ([`Page::render_annotation`]) — differing only in what `paint` draws and
    /// in `frame`, the rectangle of default user space that is the viewport
    /// when `options.region` names none.
    ///
    /// Ruling 5 is the reason there is one: a part of a page is the page with
    /// less in it, never a second implementation, so a part and the page under
    /// it cannot disagree about the scale clamp, the view transform, the canvas,
    /// the warnings or the conversion at the end.
    pub(crate) fn render_layer(
        &self,
        options: &RenderOptions,
        frame: Option<(f64, f64, f64, f64)>,
        paint: impl FnOnce(
            &mut tinker_pdf_render::Renderer<'_, resources::PageResources>,
            &resources::PageResources,
        ),
    ) -> Bitmap {
        let resources = resources::PageResources::new(&self.doc, &self.inner, self.fonts.as_ref());
        self.render_layer_with(options, frame, &resources, paint)
    }

    /// [`Page::render_layer`] over resources the caller keeps — a
    /// [`DisplayList`], whose decoded images, glyph outlines and nested
    /// scopes outlive one render so the next one does not pay for them again.
    pub(crate) fn render_layer_with(
        &self,
        options: &RenderOptions,
        frame: Option<(f64, f64, f64, f64)>,
        resources: &resources::PageResources,
        paint: impl FnOnce(
            &mut tinker_pdf_render::Renderer<'_, resources::PageResources>,
            &resources::PageResources,
        ),
    ) -> Bitmap {
        let (w, h) = self.size();
        let (scale, applied) = self.scales(options);

        // Ruling 2: the caller gets a whole page rather than a fragment, and
        // is told the resolution is not the one they asked for.
        let scaled_down = applied < scale;

        // Ruling 5. The whole page's pixel rectangle is computed first,
        // because it is what a region is a rectangle *of*: the region's
        // coordinates only mean anything against the bitmap the caller would
        // otherwise have got, so the clamp needs that size and not the page's
        // points.
        //
        // `None` is not a special case in what follows — it is the region
        // covering the whole page, whose translation is zero — so a tile and a
        // page take one code path here as well as in the renderer, and there is
        // no un-tiled spelling left for a defect to hide in.
        let (full_width, full_height) = tinker_pdf_render::page_pixels(w, h, applied);
        let full = PixelRegion::new(0, 0, full_width, full_height);
        // A part's own rectangle, as the page's pixels it covers, when the
        // caller named no region. Already trimmed to the page, so it is never
        // "clamped" in `RegionClamped`'s sense: what lies off the page is what
        // the page render does not show either.
        let frame =
            frame.map(|rect| frame_region(self.crop_box(), self.rotation(), applied, rect, full));
        let asked = options.region;
        let view = asked
            .or(frame)
            .unwrap_or(full)
            .clamped_to(full_width, full_height);

        // The rotation and the crop-box origin belong in the transform, not
        // only in the canvas size: sizing for a rotated page and then drawing
        // it upright fills a sideways canvas with clipped, upright content.
        // The region is *not* in the transform: the page is drawn through the
        // one transform whatever part of it is asked for, and the canvas
        // stands at the region's corner of the displayed picture (ruling 5).
        let crop = self.crop_box();
        let base = tinker_pdf_render::page_view_transform(crop, self.rotation(), applied);

        // 11.4.7: the page itself may declare a transparency group, and its
        // `/CS` is the space the *whole page* composites in. Nothing invokes
        // it, so it is read here rather than reaching the device through a
        // `Do` — and, unlike a form's group, it decides the format of the page
        // canvas itself rather than of a buffer over it. The bitmap is
        // converted back for the caller at the end; 11.4.7 says the page group
        // is composited and then converted to the output device's space, which
        // is exactly those two steps.
        let page_space = resources.page_group_space(&self.inner);
        let canvas_format = page_space
            .map(tinker_pdf_render::group_format)
            .unwrap_or(options.format);
        // What the caller is handed, decided before the canvas exists: a page
        // may start with nothing on it only if the format it comes back in can
        // say so. A transparent canvas converted to `Rgb8` at the end would
        // drop an alpha of zero and keep the black stored under it.
        let wanted = if options.allow_cmyk && options.format == PixelFormat::CmykA8 {
            PixelFormat::CmykA8
        } else {
            tinker_pdf_render::page_format(options.format)
        };
        let canvas = if options.transparent && wanted.has_alpha() && canvas_format.has_alpha() {
            tinker_pdf_render::region_canvas_clear(view, canvas_format)
        } else {
            tinker_pdf_render::region_canvas_in(view, canvas_format)
        };

        let mut renderer = tinker_pdf_render::Renderer::new(canvas, base, resources)
            .with_page_size(full_width, full_height)
            .with_antialias(options.antialias);
        if let Some(cancel) = &options.cancel {
            renderer = renderer.with_cancel(cancel.clone());
        }
        paint(&mut renderer, resources);
        let (canvas, mut warnings) = renderer.finish();
        // A glyph a font could not name is reported here rather than by the
        // renderer, which counts only the glyphs it was handed nothing for.
        // `.notdef` *is* an outline, so drawing it — which is what the spec
        // asks for — never reaches that counter, and the page would come out
        // blank in that spot with nothing said about why.
        if !resources.missing_fonts().is_empty()
            && !warnings.contains(&RenderWarning::UnreadableFont)
        {
            warnings.push(RenderWarning::UnreadableFont);
        }
        // Ruling 10: an image that decoded with a damaged row replicated, or
        // short, is drawn *and* named. The decoders have always returned these
        // and the image path has always thrown them away, so a scan missing
        // half its rows rendered identically to a scan of blank paper.
        for (name, reason) in resources.damaged_images() {
            let warning = RenderWarning::DamagedImage { name, reason };
            if !warnings.contains(&warning) {
                warnings.push(warning);
            }
        }
        // And a colour space read with a repair, for the same reason: the
        // colours are drawn, and "read as written" stays distinguishable.
        for (name, reason) in resources.repaired_spaces() {
            let warning = RenderWarning::RepairedColorSpace { name, reason };
            if !warnings.contains(&warning) {
                warnings.push(warning);
            }
        }
        if scaled_down {
            warnings.push(RenderWarning::PageScaledDown {
                requested: scale,
                applied,
            });
        }
        // Ruling 10: a bitmap smaller than the rectangle asked for is a
        // leniency, and a leniency is named. Only when the trim actually
        // changed the ask — a region inside the page reports nothing, which is
        // every tile of a well-formed lattice.
        if let Some(requested) = asked.filter(|requested| *requested != view) {
            warnings.push(RenderWarning::RegionClamped {
                requested,
                applied: view,
            });
        }

        // Back to something a caller can read. A page group composited over
        // ink comes back as light, which is 11.4.7's own last step — unless
        // the caller asked for ink by name *and* said they know it is ink.
        let canvas = if canvas.format == wanted {
            canvas
        } else {
            canvas.extract(canvas.origin(), canvas.width, canvas.height, wanted)
        };

        let mut bitmap = Bitmap {
            width: canvas.width,
            height: canvas.height,
            format: canvas.format,
            stride: canvas.stride,
            data: canvas.data,
            warnings,
            premultiplied: false,
        };
        if options.premultiplied {
            bitmap.premultiply();
        }
        bitmap
    }

    /// The page's link annotations, in `/Annots` order (12.5.6.5).
    ///
    /// Only links. Every other annotation subtype belongs to the annotation
    /// model rather than to navigation.
    #[must_use]
    pub fn links(&self) -> Vec<Link> {
        tinker_pdf_cos::links(&self.doc, self.inner.reference)
    }

    /// Every entry of the page's `/Annots`, in the array's own order (12.5).
    ///
    /// **Total by construction**, up to ruling 1's bound of 4 096 entries per
    /// page: one [`Annotation`] per array entry, however malformed. Past the
    /// bound the list is shortened; [`Page::annotation_list`] is the same
    /// read with the count of what the bound left out, which a read cannot
    /// put on [`Document::warnings`] without changing what the document
    /// reports about itself. The corpus's largest page carries 122.
    ///
    /// A subtype ISO 32000 does not define comes back as
    /// [`AnnotationKind::Other`] carrying the name the file used, a
    /// dictionary with no `/Subtype` as [`AnnotationKind::Unnamed`], and an
    /// entry that is not a dictionary at all as
    /// [`AnnotationKind::Unreadable`]. Nothing is dropped, so a caller
    /// auditing a file can count what this build does not model instead of
    /// wondering what went missing (ruling 10).
    ///
    /// Carries 12.5.2 Table 164's common entries and Table 170's markup ones
    /// — `/Contents`, `/T`, `/M`, `/F`, `/Rect`, `/Popup`, `/Parent`, `/C`,
    /// `/BS` or `/Border`, `/AS`, `/NM`, `/CA`, `/RC`, `/Subj`,
    /// `/CreationDate`, `/IRT`, `/RT`, `/IT` — with 12.5.6.14's rule applied:
    /// a pop-up's text and colour come from its parent. The family's own
    /// entries — `/QuadPoints`, `/InkList`, `/Vertices`, `/L`, `/DA`, `/IC`,
    /// `/CL`, `/FS`, … — are [`Annotation::payload`], one
    /// [`AnnotationPayload`] variant per 12.5.6 family.
    ///
    /// [`Page::links`] is the narrower navigation view over the same array
    /// and is unchanged: it returns `/Link` annotations with their targets
    /// **resolved**, which is a question about destinations rather than about
    /// annotations (ruling 6).
    #[must_use]
    pub fn annotations(&self) -> Vec<Annotation> {
        self.annotation_list().annotations
    }

    /// [`Page::annotations`], with what the listing's two bounds left out
    /// counted in the value it returns.
    ///
    /// [`AnnotationList::dropped`] is how many `/Annots` entries lay past the
    /// 4 096 the listing reads, and [`AnnotationList::incomplete`] how many
    /// annotations were read with an entry left out because the page spent
    /// [`MAX_ANNOTATION_BYTES`] on copies. The first is zero on every page the
    /// corpus held when it was measured, the busiest carrying 122; the census
    /// asserts both are, and the second has not yet been measured there. The
    /// counts are part of the answer rather than warnings,
    /// so reading a page twice says the same thing twice and
    /// [`Document::warnings`] is left as it was.
    #[must_use]
    pub fn annotation_list(&self) -> AnnotationList {
        annotations::of_page(&self.doc, self.inner.reference)
    }

    /// The page's text, every line in **logical** order (ruling 14,
    /// `docs/rulings.md`).
    ///
    /// A page draws right-to-left text in visual order, so a line holding a
    /// right-to-left character is put back into the order it is read in:
    /// marks kept with their base, the line sorted along its baseline, and
    /// UAX #9's rule L2 applied to it. A line with none is exactly as the
    /// content stream showed it. [`TextPage::plain_text`],
    /// [`TextPage::search`], [`Page::structured_text`] and every
    /// [`TextWriter`] format read this one extraction, so they agree.
    ///
    /// [`Page::text_with`] is the opt-out.
    #[must_use]
    pub fn text(&self) -> TextPage {
        self.text_with(&TextOptions::default())
    }

    /// The page's text, ordered as `options` asks.
    ///
    /// With [`TextOptions::default`] this is [`Page::text`]. With
    /// [`TextOptions::content_order`] every line's characters are in the order
    /// the content stream showed them, which is what [`Page::text`] returned
    /// before ruling 14.
    #[must_use]
    pub fn text_with(&self, options: &TextOptions) -> TextPage {
        let mut page = self.text_in_content_order();
        if !options.content_order {
            text_order::into_logical_order(&mut page);
        }
        page
    }

    /// What the content stream showed, in the order it showed it.
    fn text_in_content_order(&self) -> TextPage {
        let content = cos_pages::content_bytes(&self.doc, &self.inner);
        // Text extraction needs no glyph outlines — the widths come from the
        // font dictionary — so no provider is consulted here.
        let resources = resources::PageResources::new(&self.doc, &self.inner, None);

        let mut device = TextDevice::new();
        // Text is reported in PDF user space, y upward, which is the space the
        // page's own boxes are in; a device transform is the renderer's job.
        interpret(&content, Matrix::IDENTITY, &mut device, &resources);

        // Ruling 2 applies to text as much as to pixels: extraction reports
        // what it had to tolerate rather than returning a shorter string and
        // leaving the caller to wonder.
        for name in resources.missing_fonts() {
            device.warn(TextWarning::UnknownFont { name });
        }
        device.finish()
    }

    /// What a serialisation of [`Page::text`] needs to know about the page:
    /// its index, its crop box — the space the text's coordinates are in —
    /// and its `/Rotate`, which those coordinates do not have applied.
    ///
    /// ```no_run
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// # let bytes = std::fs::read("document.pdf")?;
    /// use tinker_pdf::{TextFormat, TextWriter};
    /// let doc = tinker_pdf::Document::open(bytes)?;
    /// let mut writer = TextWriter::new(TextFormat::Json);
    /// for page in doc.pages() {
    ///     writer.page(&page.text_frame(), &page.text());
    /// }
    /// println!("{}", writer.finish());
    /// # Ok(())
    /// # }
    /// ```
    #[must_use]
    pub fn text_frame(&self) -> PageFrame {
        PageFrame {
            index: self.index(),
            bounds: self.crop_box(),
            rotation: self.rotation(),
        }
    }

    /// The page's text in **structure order**, joined with the document's
    /// structure tree (14.7.4, 14.8).
    ///
    /// `None` when the document has no structure tree, which is the same
    /// answer [`Document::structure`] gives and for the same reason.
    ///
    /// This is a *second view* over the extraction [`Page::text`] already
    /// produces, not a second extractor: the same [`TextPage`] is built, and
    /// [`TextPage::plain_text`] on it is unchanged by a byte. What differs is
    /// the order the characters come back in, that `/ActualText` replaces what
    /// it encloses (14.9.4), that `/Alt` and `/E` surface, and that content
    /// the structure tree does not claim is **counted** rather than appended —
    /// see [`StructuredText::orphans`].
    #[must_use]
    pub fn structured_text(&self) -> Option<StructuredText> {
        let tree = structure::bind(&self.doc)?;
        Some(tree.text_for_page(self.index(), &self.text()))
    }
}

/// A rectangle of the page's default user space as the pixels of the page's
/// own render it covers: its corners through the page's view transform — the
/// same one `Page::render` draws with — bounded, rounded outward and trimmed to
/// the page.
///
/// A rectangle with a non-finite corner is the whole page, which is what a
/// form with no usable `/BBox` draws over; one wholly off the page is no
/// pixels, which is what the page render shows of it.
fn frame_region(
    crop: (f64, f64, f64, f64),
    rotation: u16,
    applied: f64,
    rect: (f64, f64, f64, f64),
    full: PixelRegion,
) -> PixelRegion {
    let view = tinker_pdf_render::page_view_transform(crop, rotation, applied);
    let (x0, y0, x1, y1) = rect;
    let corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)].map(|(x, y)| view.apply(x, y));
    if corners
        .iter()
        .any(|(x, y)| !x.is_finite() || !y.is_finite())
    {
        return full;
    }
    let lo = |pick: fn(&(f64, f64)) -> f64| corners.iter().map(pick).fold(f64::INFINITY, f64::min);
    let hi =
        |pick: fn(&(f64, f64)) -> f64| corners.iter().map(pick).fold(f64::NEG_INFINITY, f64::max);
    // `floor`, `ceil` and the clamp are all exact (ruling 4), and a clamped
    // value is inside `0..=limit`, so the casts cannot wrap.
    let within = |v: f64, limit: u32| v.clamp(0.0, f64::from(limit)) as u32;
    let left = within(lo(|c| c.0).floor(), full.width);
    let right = within(hi(|c| c.0).ceil(), full.width);
    let top = within(lo(|c| c.1).floor(), full.height);
    let bottom = within(hi(|c| c.1).ceil(), full.height);
    PixelRegion::new(
        left,
        top,
        right.saturating_sub(left),
        bottom.saturating_sub(top),
    )
}

impl core::fmt::Debug for Page {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("Page")
            .field("index", &self.index())
            .field("size", &self.size())
            .field("rotation", &self.rotation())
            .finish()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sniffing_recognizes_a_header() {
        assert!(Document::sniff(b"%PDF-1.7\n..."));
        assert!(
            Document::sniff(b"junk before the header %PDF-1.4"),
            "leading junk is routine"
        );
        assert!(!Document::sniff(b"not a pdf at all"));
        assert!(!Document::sniff(b""));
    }

    #[test]
    fn opening_nonsense_reports_it_rather_than_panicking() {
        // Empty input is its own answer: it is a caller's bug far more often
        // than a bad document, and it used to be reported as `NotAPdf`, which
        // sent people to look at the file.
        assert_eq!(Document::open(b"".to_vec()).err(), Some(OpenError::Empty));
        assert_eq!(
            Document::open(b"hello".to_vec()).err(),
            Some(OpenError::NotAPdf)
        );
    }

    #[test]
    fn build_info_is_reachable() {
        let info = build_info();
        assert_eq!(info.version, VERSION);
        assert!(info.spec.contains("32000"));
    }
}
