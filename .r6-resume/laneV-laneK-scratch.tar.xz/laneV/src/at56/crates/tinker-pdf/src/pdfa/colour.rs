//! The colour rule group: ISO 19005-1 6.2.2, 6.2.3, 6.2.9 and 6.4, and their
//! siblings in parts 2 to 4 (milestone 5 of `docs/design/pdfa.md`).
//!
//! # The clause this group is really about
//!
//! ISO 19005 does not forbid `DeviceRGB`. It forbids a file whose colours
//! cannot be reproduced, which is a different and much more specific thing: a
//! device colour space names a value with no meaning until something says what
//! device it is a value *for*, and the output intent is that something. So the
//! rule is a relation between two facts that live at opposite ends of the
//! file — an operator in a content stream, and an ICC profile embedded in the
//! catalog — and neither half is a finding on its own.
//!
//! That shape is why this group reaches for two machineries, both counted as
//! [`super::RuleGroup::Colour`]: [`super::content`]'s walk, for what the pages
//! actually paint with, and `tinker-pdf-color`'s ICC reader, for what the
//! destination profile says it is a profile *of*.
//!
//! # Where ICC staging actually falls, which is not where it was expected
//!
//! `docs/design/pdfa.md` staged "colour rules that need to look inside a
//! profile" behind `docs/design/icc.md`. That design has since landed
//! `icc::Profile::parse`, so the header fields these rules need — the data
//! colour space signature, and through it the channel count — are available
//! and are read. What is **not** available is a profile *validator*:
//! `Profile::parse` exists to build a colour transform and refuses a profile
//! it cannot build one from, including v4 profiles whose only route to the
//! connection space is an `mAB ` tag. Refusing to render is right; refusing to
//! conform is not, and a rule that reported every such profile would report
//! conforming files. So a destination profile this build cannot read makes the
//! colour space of the intent **unknown** rather than wrong, the rules that
//! depend on knowing it do not fire, and [`super::STAGED`] names the refusal.
//!
//! # Injections, counted, of the workspace's 3 599 tests
//!
//! Each of the three readings the corpus forced on this group was reverted and
//! the suite counted, because a rule the corpus taught and no test protects is
//! a rule the next change will quietly undo:
//!
//! - a transparency group's blending space no longer excusing a device space:
//!   **1** test, and thirteen conforming corpus files back in the
//!   false-positive column;
//! - an exact comparison of a constant alpha against one, instead of the
//!   tolerance: **1** test, and one corpus file;
//! - part 4's page-level output intents not read: **1** test, and three corpus
//!   files;
//! - the group entered without checking the request, which is the laziness
//!   requirement rather than a rule: **2** tests.

use std::collections::{BTreeMap, BTreeSet};

use tinker_pdf_color::icc;
use tinker_pdf_cos::{pages, CosDocument, Dict, ObjRef, Object};

use super::{clauses, content, FindingKind, Flavour, Machinery, Part, Raw, RuleGroup};

/// How many pages the `/Group` sweep visits.
const MAX_PAGES: usize = 1 << 14;

/// How many output intents are read.
const MAX_INTENTS: usize = 64;

/// The output-intent subtype ISO 19005 gives its own intent, in every part.
///
/// The name is `GTS_PDFA1` in parts 2, 3 and 4 as well as in part 1 — the
/// suffix is part of the registered name rather than a version number, and a
/// build that looked for `GTS_PDFA2` would find nothing in any conforming
/// file.
const PDFA_OUTPUT_INTENT: &[u8] = b"GTS_PDFA1";

/// The four rendering intents ISO 32000-1 8.6.5.8 defines.
const RENDERING_INTENTS: &[&[u8]] = &[
    b"AbsoluteColorimetric",
    b"RelativeColorimetric",
    b"Perceptual",
    b"Saturation",
];

/// How far from 1 a constant alpha may be and still mean opaque.
///
/// Not a nicety and not invented here: `6-4-t03-pass-b.pdf` writes `/CA
/// 1.0000001` and `/ca 0.9999999` and is annotated `pass`, with a title that
/// says in those words what it is testing. A producer that wrote a real number
/// meaning "fully opaque" and landed one part in ten million away has not made
/// the file transparent, and a rule with an exact comparison reports it.
pub(super) const ALPHA_TOLERANCE: f64 = 1e-5;

/// The blend modes ISO 19005-1 6.4 leaves a part 1 file.
///
/// Part 1 has no transparency, so the only blend modes it admits are the two
/// that mean "do not blend". `/Compatible` is 11.3.5's deprecated spelling of
/// `/Normal` and is admitted for the same reason.
const OPAQUE_BLEND_MODES: &[&[u8]] = &[b"Normal", b"Compatible"];

/// Runs every colour rule that applies to `flavour`.
pub(super) fn rules(
    doc: &CosDocument,
    machinery: &Machinery,
    flavour: Option<Flavour>,
    out: &mut Vec<Raw>,
) {
    if !machinery.reach(RuleGroup::Colour) {
        return;
    }
    let part = flavour.map(|f| f.part);
    let destination = output_intents(doc, part, out);
    let mut used = Used::default();
    scan(doc, &mut used);
    gather_state_intents(doc, &mut used);
    gather_group_spaces(doc, &mut used);
    if part.is_some() && part != Some(Part::One) {
        gather_blending_spaces(doc, &mut used);
    }
    device_spaces(&destination, &used, out);
    if part == Some(Part::One) {
        annotation_colours(doc, &destination, out);
    }
    icc_spaces(doc, &used, part, out);
    rendering_intents(&used, out);
    xobject_entries(doc, &used, out);
    transfer_functions(doc, &used, out);
    if part == Some(Part::One) {
        transparency(doc, &used, out);
    }
    undefined_operators(&used, out);
    if part.is_some() && part != Some(Part::One) {
        separations_agree(doc, &used, out);
        colorants_described(doc, &used, out);
    }
}

/// ISO 19005-2/3/4 6.2.4.4, in veraPDF's statement of rule 6.2.4.4-2: "All
/// Separation arrays within a single PDF/A-2 file (including those in
/// Colorants dictionaries) that have the same name shall have the same
/// tintTransform and alternateSpace. In evaluating equivalence, the PDF
/// objects shall be compared, rather than the computational result of the use
/// of those PDF objects. Compression and whether or not an object is direct or
/// indirect shall be ignored."
///
/// **The clause defines its own equality**, which is what `PDFA_STAGED` said
/// this build had not written down: objects, not functions — so two sampled
/// functions that compute the same colour from different tables are
/// different, and the same function written once directly and once by
/// reference, or once deflated and once not, is the same. [`Comparison::same`]
/// is that sentence. Part 1 states no such rule.
fn separations_agree(doc: &CosDocument, used: &Used, out: &mut Vec<Raw>) {
    let mut reported: BTreeSet<&[u8]> = BTreeSet::new();
    let mut work = 0;
    for (index, (name, alternate, tint, at)) in used.separations.iter().enumerate() {
        if reported.contains(name.as_slice()) {
            continue;
        }
        let Some((_, first_alternate, first_tint, _)) = used.separations[..index]
            .iter()
            .find(|(other, ..)| other == name)
        else {
            continue;
        };
        let mut comparison = Comparison {
            doc,
            assumed: BTreeSet::new(),
            work: &mut work,
        };
        if !comparison.same(first_alternate, alternate, 0) || !comparison.same(first_tint, tint, 0)
        {
            reported.insert(name);
            out.push(Raw {
                rule: clauses::SEPARATIONS,
                object: *at,
                kind: FindingKind::SeparationsDisagree {
                    colorant: String::from_utf8_lossy(name).into_owned(),
                },
            });
        }
    }
}

/// One question 6.2.4.4 asks — are these two `/Separation` arrays' members
/// the same object? — and what answering it has cost the rule so far.
struct Comparison<'a> {
    doc: &'a CosDocument,
    /// Pairs of indirect objects this question is already comparing, or has
    /// compared. Meeting one again answers "the same" at once.
    ///
    /// **That is sound because the answer is a conjunction.** Every step of
    /// [`Comparison::same`] is "these parts, and those, and those": a pair
    /// already entered is either still being compared, and its own answer
    /// will carry any difference beneath it to the top, or it was compared
    /// and found the same — or found different, and then the question's
    /// answer is already "different", whatever this second visit says. So
    /// a pair costs its work once per question, however many paths lead to
    /// it, and a reference cycle ends here too. Without it, two chains of
    /// equal stitching functions, each level naming the next thirty-two times,
    /// cost 32^6 comparisons of their bottoms.
    ///
    /// It is per question, never per document: an assumption made while one
    /// pair of arrays was being compared is not evidence about another.
    assumed: BTreeSet<(ObjRef, ObjRef)>,
    /// The rule's work so far, across every question it asks of the file.
    work: &'a mut usize,
}

impl Comparison<'_> {
    /// Whether two PDF objects are the same object in 6.2.4.4's sense:
    /// compared as objects, with direct against indirect and compression
    /// ignored.
    ///
    /// Numbers compare by value, so `1` and `1.0` are one number. A stream
    /// compares by its dictionary less the entries that describe its encoding
    /// (`/Length`, `/Filter`, `/DecodeParms`, `/DL`) and by its decoded bytes.
    /// A comparison this build cannot finish — a stream that will not decode,
    /// a nesting past [`MAX_COMPARE_DEPTH`], a rule past
    /// [`MAX_COMPARE_WORK`] — answers "the same": a finding has to be one the
    /// file shows, never one the reader failed to rule out.
    fn same(&mut self, a: &Object, b: &Object, depth: u32) -> bool {
        if depth > MAX_COMPARE_DEPTH || !self.spend(1) {
            return true;
        }
        if let (Some(x), Some(y)) = (a.as_objref(), b.as_objref()) {
            if x == y || !self.assumed.insert((x, y)) {
                return true;
            }
        }
        let doc = self.doc;
        let (left, right) = (doc.resolve(a), doc.resolve(b));
        match (left.as_ref(), right.as_ref()) {
            (Object::Null, Object::Null) => true,
            (Object::Bool(x), Object::Bool(y)) => x == y,
            (Object::Int(_) | Object::Real(_), Object::Int(_) | Object::Real(_)) => {
                left.as_number() == right.as_number()
            }
            (Object::String(x), Object::String(y)) => x.bytes == y.bytes,
            (Object::Name(x), Object::Name(y)) => x == y,
            (Object::Array(x), Object::Array(y)) => {
                x.len() == y.len() && x.iter().zip(y).all(|(p, q)| self.same(p, q, depth + 1))
            }
            (Object::Dict(x), Object::Dict(y)) => self.same_dict(x, y, &[], depth),
            (Object::Stream(x), Object::Stream(y)) => {
                let encoding = [
                    doc.intern(b"Length"),
                    doc.intern(b"Filter"),
                    doc.intern(b"DecodeParms"),
                    doc.intern(b"DL"),
                ];
                if !self.same_dict(&x.dict, &y.dict, &encoding, depth) {
                    return false;
                }
                match (a.as_objref(), b.as_objref()) {
                    (Some(x), Some(y)) => match (doc.stream_decoded(x), doc.stream_decoded(y)) {
                        // The decoded bytes are the rule's work too, a unit
                        // a kibibyte, so a file of many large equal streams
                        // spends the budget rather than the reader's time.
                        (Ok(p), Ok(q)) => !self.spend(p.len() / 1024) || p == q,
                        _ => true,
                    },
                    _ => true,
                }
            }
            _ => false,
        }
    }

    /// Two dictionaries with the same keys, `ignored` aside, and the same
    /// values.
    fn same_dict(
        &mut self,
        x: &Dict,
        y: &Dict,
        ignored: &[tinker_pdf_cos::Name],
        depth: u32,
    ) -> bool {
        let keys = |d: &Dict| -> BTreeSet<tinker_pdf_cos::Name> {
            d.entries()
                .iter()
                .map(|(key, _)| *key)
                .filter(|key| !ignored.contains(key))
                .collect()
        };
        let (left, right) = (keys(x), keys(y));
        left == right
            && left.iter().all(|key| match (x.get(*key), y.get(*key)) {
                (Some(p), Some(q)) => self.same(p, q, depth + 1),
                _ => false,
            })
    }

    /// Charges `units` to the rule's budget: false once it is spent, and from
    /// then on every comparison answers at once.
    fn spend(&mut self, units: usize) -> bool {
        *self.work = self.work.saturating_add(units);
        *self.work <= MAX_COMPARE_WORK
    }
}

/// The process colorants a `/DeviceN` space may name without describing
/// them: DeviceCMYK's four (ISO 32000-1 8.6.6.5), and `/None`.
const PROCESS_COLORANTS: &[&[u8]] = &[b"Cyan", b"Magenta", b"Yellow", b"Black", b"None"];

/// ISO 19005-2/3/4 6.2.4.4, in veraPDF's statement of rule 6.2.4.4-1: "For
/// any spot colour used in a DeviceN or NChannel colour space, an entry in
/// the Colorants dictionary shall be present." A spot colour is a colorant
/// that is not a process one: DeviceCMYK's four, `/None`, and the components
/// an `NChannel` space's `/Process` dictionary names — the same reading the
/// writer's `ArchivalRefusal::UndescribedColorant` refuses at the call.
fn colorants_described(doc: &CosDocument, used: &Used, out: &mut Vec<Raw>) {
    let mut reported: BTreeSet<Vec<u8>> = BTreeSet::new();
    for (members, at) in &used.device_n {
        let names = members.get(1).map(|n| doc.resolve(n));
        let Some(names) = names.as_deref().and_then(Object::as_array) else {
            continue;
        };
        let attributes = members.get(4).map(|a| doc.resolve(a));
        let attributes = attributes.as_deref().and_then(Object::as_dict);
        let colorants = attributes.map(|a| doc.resolve_key(a, doc.intern(b"Colorants")));
        let colorants = colorants.as_deref().and_then(Object::as_dict);
        let process: Vec<Vec<u8>> = attributes
            .map(|a| doc.resolve_key(a, doc.intern(b"Process")))
            .as_deref()
            .and_then(Object::as_dict)
            .map(|p| doc.resolve_key(p, doc.intern(b"Components")))
            .as_deref()
            .and_then(Object::as_array)
            .map(|components| {
                components
                    .iter()
                    .filter_map(|c| doc.resolve(c).as_name())
                    .filter_map(|n| doc.name_bytes(n).map(|b| b.to_vec()))
                    .collect()
            })
            .unwrap_or_default();
        for name in names {
            let Some(name) = doc.resolve(name).as_name() else {
                continue;
            };
            let Some(bytes) = doc.name_bytes(name) else {
                continue;
            };
            if PROCESS_COLORANTS.contains(&bytes.as_ref())
                || process.iter().any(|p| p.as_slice() == bytes.as_ref())
                || colorants.is_some_and(|c| c.contains_key(name))
                || reported.contains(bytes.as_ref())
            {
                continue;
            }
            reported.insert(bytes.to_vec());
            out.push(Raw {
                rule: clauses::SEPARATIONS,
                object: *at,
                kind: FindingKind::ColorantUndescribed {
                    colorant: String::from_utf8_lossy(&bytes).into_owned(),
                },
            });
        }
    }
}

/// ISO 19005-1 6.2.10, ISO 19005-2/3/4 6.2.2: "Content streams shall not
/// contain any operators not defined in ISO 32000-1 even if such operators are
/// bracketed by the BX/EX compatibility operators" (part 1: "in PDF
/// Reference"; part 4: "in ISO 32000-2:2020"), as veraPDF's published rules
/// 6.2.10-1 and 6.2.2-1 quote them.
///
/// **No operand stack is needed for this.** `PDFA_STAGED` held the rule back
/// on the reading that deciding an operator is forbidden needs the operands it
/// was given; an operator outside Table A.1 is forbidden whatever it was given,
/// and the tokenizer that already walks every page, form and appearance names
/// each one. One finding per distinct operator, naming the first object whose
/// content used it.
fn undefined_operators(used: &Used, out: &mut Vec<Raw>) {
    for (operator, container) in &used.undefined {
        out.push(Raw {
            rule: clauses::CONTENT_STREAMS,
            object: Some(*container),
            kind: FindingKind::OperatorUndefined {
                operator: String::from_utf8_lossy(operator).into_owned(),
            },
        });
    }
}

// ---- 6.2.2 / 6.2.3 The output intent --------------------------------------

/// What the file's PDF/A output intent says its destination device is.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Destination {
    /// No output intent with `/S /GTS_PDFA1`.
    Absent,
    /// One, whose profile declares this data colour space (the ICC signature
    /// at header offset 16).
    Space([u8; 4]),
    /// One, whose profile this build could not read — see the module note on
    /// why that is not the same as a profile that is wrong.
    Unreadable,
}

/// ISO 19005-1 6.2.2, and its siblings.
///
/// Three requirements this build reads out of the clause, and the third is the
/// interesting one:
///
/// 1. `/OutputIntents`, when present, is an array of dictionaries;
/// 2. an entry whose `/S` is `/GTS_PDFA1` carries a `/DestOutputProfile` that
///    is a stream, and an `/OutputConditionIdentifier` (ISO 32000-1 14.11.5
///    Table 365 makes the identifier required of every output intent);
/// 3. if there is more than one such entry, **they all name the same
///    profile** — a file with two answers to "what device is this for" has
///    given none.
fn output_intents(doc: &CosDocument, part: Option<Part>, out: &mut Vec<Raw>) -> Destination {
    // Part 4's page-level fallback is applied at every exit, not only at the
    // end: the first version returned early when the catalog carried no
    // `/OutputIntents` at all, which is exactly the shape of the file the
    // fallback exists for. Three conforming fixtures were reported for it.
    let page_level = || {
        if part == Some(Part::Four) {
            page_destination(doc)
        } else {
            Destination::Absent
        }
    };

    let Some(catalog) = doc.catalog() else {
        return page_level();
    };
    let catalog_ref = doc.trailer().get_ref(doc.intern(b"Root"));
    let intents = doc.resolve_key(&catalog, doc.intern(b"OutputIntents"));
    if intents.is_null() {
        return page_level();
    }
    let Some(entries) = intents.as_array() else {
        out.push(Raw {
            rule: clauses::OUTPUT_INTENT,
            object: catalog_ref,
            kind: FindingKind::OutputIntentMalformed {
                key: "OutputIntents".to_string(),
            },
        });
        return page_level();
    };

    let mut profiles: BTreeSet<ObjRef> = BTreeSet::new();
    let mut destination = Destination::Absent;
    for entry in entries.iter().take(MAX_INTENTS) {
        let at = entry.as_objref().or(catalog_ref);
        let resolved = doc.resolve(entry);
        let Some(intent) = resolved.as_dict() else {
            out.push(Raw {
                rule: clauses::OUTPUT_INTENT,
                object: at,
                kind: FindingKind::OutputIntentMalformed {
                    key: "OutputIntents".to_string(),
                },
            });
            continue;
        };
        if name_of(doc, intent, b"S").as_deref() != Some(PDFA_OUTPUT_INTENT) {
            // ISO 32000-1 14.11.5 admits other output intents — `GTS_PDFX`,
            // `ISO_PDFE1` — beside the PDF/A one, and this clause is about the
            // PDF/A one. Judging the others would be enforcing a standard the
            // file did not claim.
            continue;
        }
        if doc
            .resolve_key(intent, doc.intern(b"OutputConditionIdentifier"))
            .as_string()
            .is_none()
        {
            out.push(Raw {
                rule: clauses::OUTPUT_INTENT,
                object: at,
                kind: FindingKind::OutputIntentMalformed {
                    key: "OutputConditionIdentifier".to_string(),
                },
            });
        }

        let Some(profile_ref) = intent.get_ref(doc.intern(b"DestOutputProfile")) else {
            out.push(Raw {
                rule: clauses::OUTPUT_INTENT,
                object: at,
                kind: FindingKind::DestOutputProfileMissing,
            });
            continue;
        };
        profiles.insert(profile_ref);
        if let Ok(bytes) = doc.stream_decoded(profile_ref) {
            for (field, found) in header_defects(&bytes, OUTPUT_CLASSES, OUTPUT_SPACES, part) {
                out.push(Raw {
                    rule: clauses::OUTPUT_INTENT,
                    object: Some(profile_ref),
                    kind: FindingKind::IccProfileHeader { field, found },
                });
            }
        }
        destination = profile_space(doc, profile_ref);
    }

    if profiles.len() > 1 {
        out.push(Raw {
            rule: clauses::OUTPUT_INTENT,
            object: catalog_ref,
            kind: FindingKind::OutputIntentsDisagree,
        });
    }

    // **ISO 19005-4 moved the output intent onto the page.** Part 4's 6.2.3
    // admits an `/OutputIntents` array in a *page* dictionary as well as in
    // the catalog, and `6-2-3-t05-pass-a.pdf` is exactly that file: no
    // catalog-level intent, a PDF/A intent on the page, annotated `pass` with
    // a title saying so. Parts 1 to 3 have no such provision, so the page
    // sweep runs for part 4 alone rather than for whichever part happens to
    // have a page.
    //
    // Only the *destination* is taken from a page-level intent. The shape
    // rules above are not re-run over it: what part 4 requires of a
    // page-level intent is a reading this build has not established, and
    // reporting against a guess is what `super::STAGED` exists to avoid.
    if destination == Destination::Absent {
        destination = page_level();
    }

    destination
}

/// The device classes a destination profile may declare: output and monitor.
const OUTPUT_CLASSES: &[&[u8; 4]] = &[b"prtr", b"mntr"];

/// The data colour spaces a destination profile may declare.
const OUTPUT_SPACES: &[&[u8; 4]] = &[b"RGB ", b"CMYK", b"GRAY"];

/// The device classes an `ICCBased` colour space's profile may declare: input
/// and colour-space conversion as well.
const ICC_BASED_CLASSES: &[&[u8; 4]] = &[b"prtr", b"mntr", b"scnr", b"spac"];

/// The data colour spaces an `ICCBased` colour space's profile may declare.
const ICC_BASED_SPACES: &[&[u8; 4]] = &[b"RGB ", b"CMYK", b"GRAY", b"Lab "];

/// What a profile's header says that the clause does not admit, as
/// `(field, found)`.
///
/// **The header, and only the header.** `PDFA_STAGED` held this rule back
/// because `icc::Profile::parse` is a transform builder that refuses profiles
/// which conform perfectly well — a v4 profile whose only route to the
/// connection space is an `mAB ` tag — so "cannot be parsed" was never "does
/// not conform". The three things the clause names sit at fixed offsets of
/// ICC.1's 128-byte header — the version at byte 8, the device class at 12,
/// the data colour space at 16 — and reading them needs no transform. The
/// sentences are veraPDF's statements of rules 6.2.2-1 (part 1), 6.2.3-1
/// (parts 2 to 4) and 6.2.3.2-1 / 6.2.4.2-1 (`ICCBased`), and their test
/// conditions give the version bound: below 3.0 under part 1, whose
/// reference is ICC.1:1998-09, and below 5.0 under the later parts.
fn header_defects(
    bytes: &[u8],
    classes: &[&[u8; 4]],
    spaces: &[&[u8; 4]],
    part: Option<Part>,
) -> Vec<(String, String)> {
    let mut out = Vec::new();
    let (Some(version), Some(class), Some(space)) =
        (bytes.get(8..10), bytes.get(12..16), bytes.get(16..20))
    else {
        out.push(("header".to_string(), format!("{} bytes", bytes.len())));
        return out;
    };
    let major = version.first().copied().unwrap_or_default();
    let minor = version.get(1).copied().unwrap_or_default() >> 4;
    let below = if part == Some(Part::One) { 3 } else { 5 };
    if major >= below {
        out.push(("version".to_string(), format!("{major}.{minor}")));
    }
    if !classes.iter().any(|admitted| admitted.as_slice() == class) {
        out.push((
            "device class".to_string(),
            String::from_utf8_lossy(class).into_owned(),
        ));
    }
    if !spaces.iter().any(|admitted| admitted.as_slice() == space) {
        out.push((
            "colour space".to_string(),
            String::from_utf8_lossy(space).into_owned(),
        ));
    }
    out
}

/// The destination profile of a part 4 page-level output intent, if there is
/// one.
fn page_destination(doc: &CosDocument) -> Destination {
    for page in pages::collect_upto(doc, MAX_PAGES) {
        let Ok(object) = doc.get(page.reference) else {
            continue;
        };
        let Some(dict) = object.as_dict() else {
            continue;
        };
        let intents = doc.resolve_key(dict, doc.intern(b"OutputIntents"));
        let Some(entries) = intents.as_array() else {
            continue;
        };
        for entry in entries.iter().take(MAX_INTENTS) {
            let resolved = doc.resolve(entry);
            let Some(intent) = resolved.as_dict() else {
                continue;
            };
            if name_of(doc, intent, b"S").as_deref() != Some(PDFA_OUTPUT_INTENT) {
                continue;
            }
            if let Some(profile) = intent.get_ref(doc.intern(b"DestOutputProfile")) {
                return profile_space(doc, profile);
            }
        }
    }
    Destination::Absent
}

/// The data colour space of the profile behind `reference`.
///
/// The reach into `tinker-pdf-color`. A profile that will not parse is
/// [`Destination::Unreadable`] rather than a finding, for the reason the module
/// note gives: this parser refuses profiles it cannot build a transform from,
/// and "cannot render" is not "does not conform".
fn profile_space(doc: &CosDocument, reference: ObjRef) -> Destination {
    let Ok(bytes) = doc.stream_decoded(reference) else {
        return Destination::Unreadable;
    };
    match icc::Profile::parse(&bytes) {
        Ok(profile) => Destination::Space(profile.space),
        Err(_) => Destination::Unreadable,
    }
}

// ---- what the pages paint with --------------------------------------------

/// What one walk of the content streams found, for every colour rule at once.
///
/// `pub(crate)`, with the fields another standard reads, because ISO 15930's
/// print rules ask what a page paints with the same question ISO 19005's
/// colour group asks (`crate::pdfx`), and one walk answers both.
#[derive(Default)]
pub(crate) struct Used {
    /// Device colour spaces painted with, and one object that did.
    pub(crate) devices: BTreeMap<&'static str, Option<ObjRef>>,
    /// Device colour spaces a `/Default…` entry in the resources standing over
    /// them excuses (ISO 32000-1 8.6.5.6).
    pub(crate) defaulted: BTreeSet<&'static str>,
    /// `ICCBased` streams the pages selected.
    pub(crate) icc_streams: BTreeSet<ObjRef>,
    /// The other device-independent families the pages selected —
    /// `CalGray`, `CalRGB`, `Lab` — and one object that did. No ISO 19005
    /// rule reads it; PDF/X-3's profile requirement does.
    pub(crate) independent: BTreeMap<&'static str, Option<ObjRef>>,
    /// Rendering intents named, by the `ri` operator or an `/ExtGState`.
    intents: BTreeMap<Vec<u8>, Option<ObjRef>>,
    /// Extended graphics states the pages selected.
    ext_g_states: BTreeSet<ObjRef>,
    /// Form XObjects the pages invoked.
    pub(crate) forms: BTreeSet<ObjRef>,
    /// Image XObjects the pages drew.
    images: BTreeSet<ObjRef>,
    /// XObjects the pages drew that are neither a form nor an image, which
    /// 8.8.2 leaves exactly one of: a PostScript XObject.
    pub(crate) postscript: BTreeSet<ObjRef>,
    /// Device-independent blending colour spaces a transparency group named,
    /// by the device family each stands in for (11.6.6).
    group_spaces: BTreeSet<&'static str>,
    /// Operators no table of ISO 32000 defines, each with the first object
    /// whose content used it.
    pub(crate) undefined: BTreeMap<Vec<u8>, ObjRef>,
    /// Every `/Separation` array met — in a space the pages use, or in a
    /// `/DeviceN` space's `/Colorants` — as `(name, alternate, tint transform,
    /// where)`.
    separations: Vec<(Vec<u8>, Object, Object, Option<ObjRef>)>,
    /// Every `/DeviceN` space met, as its array and where.
    device_n: Vec<(Vec<Object>, Option<ObjRef>)>,
}

/// How many `/Separation` and `/DeviceN` arrays one document contributes to
/// the consistency rules.
const MAX_SEPARATIONS: usize = 256;

/// How deep two tint transforms are compared before the comparison gives up
/// and calls them the same — a stitching function nests functions, and a
/// nesting deeper than this is not a colour.
const MAX_COMPARE_DEPTH: u32 = 16;

/// How much work the consistency rule spends comparing, across every pair of
/// arrays it compares in one document: a unit an object compared and a unit a
/// kibibyte of decoded stream. Remembering the pairs already compared makes a
/// question cost what its two objects hold rather than how many paths reach
/// them; this bounds what they may hold. A tint transform is tens of units,
/// and two hundred and fifty-six of them a few thousand.
const MAX_COMPARE_WORK: usize = 1 << 18;

/// Every operator ISO 32000-1 Annex A Table A.1 lists — seventy-three, the
/// same set PDF Reference 1.4 (ISO 19005-1's reference) and ISO 32000-2
/// (ISO 19005-4's) define. `PS` is not among them, which is how veraPDF's
/// statement of the rule reads its prohibition: "In earlier versions of the
/// PDF format a PostScript operator "PS" was defined. As this operator is not
/// defined in PDF Reference its use is implicitly prohibited".
const DEFINED_OPERATORS: &[&[u8]] = &[
    b"b", b"B", b"b*", b"B*", b"BDC", b"BI", b"BMC", b"BT", b"BX", b"c", b"cm", b"CS", b"cs", b"d",
    b"d0", b"d1", b"Do", b"DP", b"EI", b"EMC", b"ET", b"EX", b"f", b"F", b"f*", b"G", b"g", b"gs",
    b"h", b"i", b"ID", b"j", b"J", b"K", b"k", b"l", b"m", b"M", b"MP", b"n", b"q", b"Q", b"re",
    b"RG", b"rg", b"ri", b"s", b"S", b"SC", b"sc", b"SCN", b"scn", b"sh", b"T*", b"Tc", b"Td",
    b"TD", b"Tf", b"Tj", b"TJ", b"TL", b"Tm", b"Tr", b"Ts", b"Tw", b"Tz", b"v", b"w", b"W", b"W*",
    b"y", b"'", b"\"",
];

/// How many distinct undefined operators one document contributes.
const MAX_UNDEFINED_OPERATORS: usize = 64;

/// The three uncalibrated spaces, spelled as the operators and the names spell
/// them.
const DEVICE_GRAY: &str = "DeviceGray";
pub(crate) const DEVICE_RGB: &str = "DeviceRGB";
const DEVICE_CMYK: &str = "DeviceCMYK";

/// One walk, filling [`Used`].
pub(crate) fn scan(doc: &CosDocument, used: &mut Used) {
    content::walk(doc, &mut |op| {
        if !DEFINED_OPERATORS.contains(&op.operator)
            && (used.undefined.len() < MAX_UNDEFINED_OPERATORS
                || used.undefined.contains_key(op.operator))
        {
            used.undefined
                .entry(op.operator.to_vec())
                .or_insert(op.container);
        }
        match op.operator {
            // 8.6.8: the colour operators that select a device space and a
            // value in it, in one operator.
            b"g" | b"G" => {
                used.devices.entry(DEVICE_GRAY).or_insert(None);
            }
            b"rg" | b"RG" => {
                used.devices.entry(DEVICE_RGB).or_insert(None);
            }
            b"k" | b"K" => {
                used.devices.entry(DEVICE_CMYK).or_insert(None);
            }
            // 8.6.8: `cs` names a space, either one of the four built-in names
            // or a resource.
            b"cs" | b"CS" => {
                let Some(name) = op.first_name() else {
                    return;
                };
                if let Some(space) = device_name(name) {
                    used.devices.entry(space).or_insert(None);
                    return;
                }
                let Some(resources) = op.resources else {
                    return;
                };
                colour_space_resource(doc, resources, name, used);
            }
            b"ri" => {
                if let Some(name) = op.first_name() {
                    used.intents.entry(name.to_vec()).or_insert(None);
                }
            }
            b"gs" => {
                let (Some(name), Some(resources)) = (op.first_name(), op.resources) else {
                    return;
                };
                if let Some(reference) = content::lookup(doc, resources, b"ExtGState", name) {
                    used.ext_g_states.insert(reference);
                }
            }
            b"Do" => {
                let (Some(name), Some(resources)) = (op.first_name(), op.resources) else {
                    return;
                };
                let Some(reference) = content::lookup(doc, resources, b"XObject", name) else {
                    return;
                };
                let Ok(object) = doc.get(reference) else {
                    return;
                };
                let Some(stream) = object.as_stream() else {
                    return;
                };
                match name_of(doc, &stream.dict, b"Subtype").as_deref() {
                    Some(b"Form") => {
                        used.forms.insert(reference);
                    }
                    Some(b"Image") => {
                        used.images.insert(reference);
                        image_space(doc, &stream.dict, reference, used);
                    }
                    // 8.8.2 defines three subtypes and this is the third. It
                    // used to be swallowed here, which is how a PostScript
                    // XObject reached a page unreported.
                    Some(b"PS") | None => {
                        used.postscript.insert(reference);
                    }
                    _ => {}
                }
            }
            _ => {}
        }
        // 8.6.5.6: a `/Default…` entry in the resources' `/ColorSpace`
        // sub-dictionary replaces the device space it is named for, which is
        // the escape hatch the clause itself offers. Recorded per walk rather
        // than per operator scope, which is a simplification and named as one:
        // a `/DefaultRGB` on one page excuses `DeviceRGB` on all of them here,
        // where the clause scopes it to the resource dictionary it is in.
        if let Some(resources) = op.resources {
            let spaces = doc.resolve_key(resources, doc.intern(b"ColorSpace"));
            if let Some(spaces) = spaces.as_dict() {
                for (key, space) in [
                    (&b"DefaultGray"[..], DEVICE_GRAY),
                    (b"DefaultRGB", DEVICE_RGB),
                    (b"DefaultCMYK", DEVICE_CMYK),
                ] {
                    if spaces.contains_key(doc.intern(key)) {
                        used.defaulted.insert(space);
                    }
                }
            }
        }
    });
}

/// The device space a built-in colour-space name denotes, if it is one.
fn device_name(name: &[u8]) -> Option<&'static str> {
    match name {
        b"DeviceGray" | b"G" => Some(DEVICE_GRAY),
        b"DeviceRGB" | b"RGB" => Some(DEVICE_RGB),
        b"DeviceCMYK" | b"CMYK" => Some(DEVICE_CMYK),
        _ => None,
    }
}

/// A colour space named in the resources: a device name, an `ICCBased` array,
/// or one of the families whose base or alternate space is what matters.
fn colour_space_resource(doc: &CosDocument, resources: &Dict, name: &[u8], used: &mut Used) {
    let spaces = doc.resolve_key(resources, doc.intern(b"ColorSpace"));
    let Some(spaces) = spaces.as_dict() else {
        return;
    };
    let value = doc.resolve_key(spaces, doc.intern(name));
    let at = spaces.get_ref(doc.intern(name));
    colour_space(doc, &value, at, used, 0);
}

/// How deep a colour space's base or alternate chain is followed.
///
/// `/Indexed` over `/Separation` over `/DeviceN` over an alternate is legal and
/// nests; a file that nests it a thousand deep is not describing a colour.
const MAX_SPACE_DEPTH: u32 = 8;

/// One colour space object, recorded for whichever rule is about it.
fn colour_space(
    doc: &CosDocument,
    value: &Object,
    at: Option<ObjRef>,
    used: &mut Used,
    depth: u32,
) {
    if depth > MAX_SPACE_DEPTH {
        return;
    }
    match value {
        Object::Name(name) => {
            if let Some(space) = doc.name_bytes(*name).and_then(|n| device_name(&n)) {
                used.devices.entry(space).or_insert(at);
            }
        }
        Object::Array(members) => {
            let Some(family) = members
                .first()
                .and_then(|first| doc.resolve(first).as_name())
                .and_then(|name| doc.name_bytes(name))
            else {
                return;
            };
            match family.as_ref() {
                b"ICCBased" => {
                    if let Some(stream) = members.get(1).and_then(Object::as_objref) {
                        used.icc_streams.insert(stream);
                    }
                }
                b"CalGray" => {
                    used.independent.entry("CalGray").or_insert(at);
                }
                b"CalRGB" => {
                    used.independent.entry("CalRGB").or_insert(at);
                }
                b"Lab" => {
                    used.independent.entry("Lab").or_insert(at);
                }
                // 8.6.6.3 and 8.6.6.4: the value a `/Separation` or `/DeviceN`
                // produces lives in its **alternate** space, and 8.6.6.2 says
                // the same of an `/Indexed` space's base. So a `/Separation`
                // over `DeviceCMYK` uses `DeviceCMYK`, which is the reading
                // that makes 6.2.3.4's fixtures make sense.
                b"Separation" => {
                    record_separation(doc, members, at, used);
                    if let Some(alternate) = members.get(2) {
                        let resolved = doc.resolve(alternate);
                        colour_space(doc, &resolved, at, used, depth + 1);
                    }
                }
                b"DeviceN" => {
                    if used.device_n.len() < MAX_SEPARATIONS {
                        used.device_n.push((members.clone(), at));
                    }
                    // 6.2.4.4: "All Separation arrays … (including those in
                    // Colorants dictionaries)".
                    let attributes = members.get(4).map(|a| doc.resolve(a));
                    if let Some(colorants) = attributes
                        .as_deref()
                        .and_then(Object::as_dict)
                        .map(|a| doc.resolve_key(a, doc.intern(b"Colorants")))
                    {
                        if let Some(colorants) = colorants.as_dict() {
                            for (_, value) in colorants.entries() {
                                let resolved = doc.resolve(value);
                                if let Some(separation) = resolved.as_array() {
                                    record_separation(doc, separation, at, used);
                                }
                            }
                        }
                    }
                    if let Some(alternate) = members.get(2) {
                        let resolved = doc.resolve(alternate);
                        colour_space(doc, &resolved, at, used, depth + 1);
                    }
                }
                b"Indexed" | b"I" => {
                    if let Some(base) = members.get(1) {
                        let resolved = doc.resolve(base);
                        colour_space(doc, &resolved, at, used, depth + 1);
                    }
                }
                b"Pattern" => {
                    if let Some(under) = members.get(1) {
                        let resolved = doc.resolve(under);
                        colour_space(doc, &resolved, at, used, depth + 1);
                    }
                }
                _ => {
                    if let Some(space) = device_name(&family) {
                        used.devices.entry(space).or_insert(at);
                    }
                }
            }
        }
        _ => {}
    }
}

/// One `/Separation` array, kept for the consistency rule.
fn record_separation(doc: &CosDocument, members: &[Object], at: Option<ObjRef>, used: &mut Used) {
    if used.separations.len() >= MAX_SEPARATIONS {
        return;
    }
    let is_separation = members
        .first()
        .and_then(|first| doc.resolve(first).as_name())
        .and_then(|name| doc.name_bytes(name))
        .is_some_and(|name| name.as_ref() == b"Separation");
    let (Some(name), Some(alternate), Some(tint)) =
        (members.get(1), members.get(2), members.get(3))
    else {
        return;
    };
    let Some(name) = doc.resolve(name).as_name().and_then(|n| doc.name_bytes(n)) else {
        return;
    };
    if is_separation {
        used.separations
            .push((name.to_vec(), alternate.clone(), tint.clone(), at));
    }
}

/// An image XObject's `/ColorSpace`, which is a colour space like any other.
fn image_space(doc: &CosDocument, dict: &Dict, at: ObjRef, used: &mut Used) {
    // 8.9.5.2: an image mask has no colour space, it has a stencil. Reading
    // one as `DeviceGray` would report every stencil in the corpus.
    if doc
        .resolve_key(dict, doc.intern(b"ImageMask"))
        .as_bool()
        .unwrap_or(false)
    {
        return;
    }
    let value = doc.resolve_key(dict, doc.intern(b"ColorSpace"));
    colour_space(doc, &value, Some(at), used, 0);
}

/// The blending colour space of every transparency group the file renders.
///
/// **The corpus taught this rule, and it is the second stand-in the clause
/// admits.** `6-2-4-3-t04-pass-a.pdf` paints in `DeviceRGB` with no matching
/// output intent and is annotated `pass`; its own title says why — *"the
/// transparency group on page level defines ICCBased RGB colour space"*.
/// 11.6.6 makes a group's `/CS` the space its contents are composited in, so a
/// device-independent one pins down what the device values in it mean, exactly
/// as `/DefaultRGB` does.
///
/// **A simplification, named as one.** A group's `/CS` is recorded for the
/// whole document rather than for the scope it encloses, so an RGB group on
/// page one excuses `DeviceRGB` on page two. The clause scopes it to the group
/// itself. The error is towards accepting, which is the direction a validator
/// should err in when it cannot tell — and `6-2-4-3-t04-pass-i.pdf`, whose
/// page group is `DeviceRGB` and whose form group is `ICCBased` CMYK, is the
/// fixture that shows the difference between the two readings.
fn gather_group_spaces(doc: &CosDocument, used: &mut Used) {
    let mut dicts: Vec<Dict> = Vec::new();
    for page in pages::collect_upto(doc, MAX_PAGES) {
        if let Some(dict) = doc
            .get(page.reference)
            .ok()
            .and_then(|o| o.as_dict().cloned())
        {
            dicts.push(dict);
        }
    }
    for reference in &used.forms {
        if let Some(stream) = doc
            .get(*reference)
            .ok()
            .and_then(|o| o.as_stream().cloned())
        {
            dicts.push(stream.dict);
        }
    }
    for dict in &dicts {
        let group = doc.resolve_key(dict, doc.intern(b"Group"));
        let Some(group) = group.as_dict() else {
            continue;
        };
        if name_of(doc, group, b"S").as_deref() != Some(b"Transparency") {
            continue;
        }
        let space = doc.resolve_key(group, doc.intern(b"CS"));
        if let Some(family) = independent_family(doc, &space) {
            used.group_spaces.insert(family);
        }
    }
}

/// The device family a **device-independent** colour space stands in for, if
/// it is one.
///
/// A device space returns `None` and that is the point: a transparency group
/// whose `/CS` is `DeviceRGB` has not said what the values mean, so it excuses
/// nothing.
fn independent_family(doc: &CosDocument, space: &Object) -> Option<&'static str> {
    let members = space.as_array()?;
    let family = members
        .first()
        .and_then(|first| doc.resolve(first).as_name())
        .and_then(|name| doc.name_bytes(name))?;
    match family.as_ref() {
        b"CalGray" => Some(DEVICE_GRAY),
        b"CalRGB" => Some(DEVICE_RGB),
        b"ICCBased" => {
            let stream = members.get(1).and_then(Object::as_objref)?;
            let object = doc.get(stream).ok()?;
            let components = doc
                .resolve_key(&object.as_stream()?.dict, doc.intern(b"N"))
                .as_int()?;
            match components {
                1 => Some(DEVICE_GRAY),
                3 => Some(DEVICE_RGB),
                4 => Some(DEVICE_CMYK),
                _ => None,
            }
        }
        _ => None,
    }
}

// ---- 6.2.3.3 / 6.2.4.3 Uncalibrated colour spaces -------------------------

/// ISO 19005-1 6.2.3.3, and its siblings.
///
/// **Two readings, named as such**, because the clause distinguishes the three
/// device spaces and this build's reading of how is worth being explicit
/// about:
///
/// - **any** device space needs a PDF/A output intent to be present at all, or
///   a `/Default…` space standing in for it;
/// - `DeviceRGB` additionally needs the destination profile to be an RGB
///   profile and `DeviceCMYK` a CMYK one, while `DeviceGray` is admitted under
///   any of them — a grey value is a value on the neutral axis of whatever
///   device the intent names, and does not need the intent to be grey.
///
/// One finding per space rather than per operator: a page that sets
/// `DeviceRGB` five hundred times has one defect, and five hundred findings
/// saying so is a list nobody reads.
fn device_spaces(destination: &Destination, used: &Used, out: &mut Vec<Raw>) {
    for (space, at) in &used.devices {
        if used.defaulted.contains(space) || used.group_spaces.contains(space) {
            continue;
        }
        match destination {
            Destination::Absent => out.push(Raw {
                rule: clauses::DEVICE_SPACES,
                object: *at,
                kind: FindingKind::DeviceColourWithoutOutputIntent {
                    space: (*space).to_string(),
                },
            }),
            // The profile is there and this build cannot read it, so it cannot
            // say whether the space matches. Staged, not guessed.
            Destination::Unreadable => {}
            Destination::Space(signature) => {
                let admitted = match *space {
                    DEVICE_RGB => signature == b"RGB ",
                    DEVICE_CMYK => signature == b"CMYK",
                    _ => true,
                };
                if !admitted {
                    out.push(Raw {
                        rule: clauses::DEVICE_SPACES,
                        object: *at,
                        kind: FindingKind::DeviceColourNotInOutputIntent {
                            space: (*space).to_string(),
                            profile: String::from_utf8_lossy(signature).trim().to_string(),
                        },
                    });
                }
            }
        }
    }
}

// ---- 6.2.3.3 / 6.3.2: an annotation's own colours -------------------------

/// The most objects this rule will look at, so a file with a damaged
/// cross-reference table cannot turn a validation into a sweep (ruling 1).
/// The syntax group bounds its own walk the same way and for the same reason.
const MAX_ANNOTATION_OBJECTS: usize = 200_000;

/// ISO 19005-1 6.5.3 and its siblings, from the colour side.
///
/// `/C` and `/IC` are an annotation's border and interior colours, and ISO
/// 32000-1 12.5.2 says the *number of components* names the space: one is
/// `DeviceGray`, three `DeviceRGB`, four `DeviceCMYK`, and none at all means
/// no colour. So they are device colours like any other and the same clause
/// governs them — a `DeviceRGB` border under a CMYK output intent is a colour
/// nobody can reproduce, exactly as it would be in a content stream.
///
/// **This lives in the colour group rather than with the other annotation
/// rules**, and the split is by machinery rather than by subject: deciding it
/// needs [`Destination`], which is the output intent's profile read through
/// `tinker-pdf-color`. The annotation group reaches for nothing and stays that
/// way; four Isartor fixtures are the whole population of this rule, and the
/// clause they cite is the annotation one either way.
///
/// Grey is admitted under every destination, for the reason
/// [`device_spaces`] already gives: a value on the neutral axis is
/// reproducible on any device.
///
/// **Part 1 only, and the restriction is the corpus's own.** The four fixtures
/// that test this are Isartor's, under ISO 19005-1 6.5.3, and no later part
/// has a counterpart. Running it on part 4 anyway reported
/// `6-3-3-t01-pass-d` — a `Projection` annotation carrying `/C [1 0 0]` in a
/// file with no output intent at all, annotated **pass**. Whatever ISO 19005-4
/// does with an annotation's own colour, it is not what part 1 does, and a
/// rule extended past its evidence reports conforming files. `super::STAGED`
/// names the gap rather than this build guessing at it.
fn annotation_colours(doc: &CosDocument, destination: &Destination, out: &mut Vec<Raw>) {
    let mut seen: BTreeSet<u32> = BTreeSet::new();
    for (num, entry) in doc.xref().iter().take(MAX_ANNOTATION_OBJECTS) {
        let gen = match entry {
            tinker_pdf_cos::XrefEntry::Free { .. } => continue,
            tinker_pdf_cos::XrefEntry::Offset { gen, .. } => gen,
            tinker_pdf_cos::XrefEntry::InStream { .. } => 0,
        };
        if !seen.insert(num) {
            continue;
        }
        let reference = ObjRef::new(num, gen);
        let Ok(object) = doc.get(reference) else {
            continue;
        };
        let Some(dict) = object.as_dict() else {
            continue;
        };
        let is_annotation = doc
            .resolve_key(dict, doc.intern(b"Type"))
            .as_name()
            .and_then(|name| doc.name_bytes(name))
            .is_some_and(|name| name.as_ref() == b"Annot");
        if !is_annotation {
            continue;
        }
        for key in [&b"C"[..], b"IC"] {
            let value = doc.resolve_key(dict, doc.intern(key));
            let Some(components) = value.as_array() else {
                continue;
            };
            let space = match components.len() {
                // `/C []` is 12.5.2's "no colour", and one component is grey.
                0 | 1 => continue,
                3 => DEVICE_RGB,
                4 => DEVICE_CMYK,
                // Any other length is not a colour this clause can name, and
                // reporting it under a colour clause would be reporting the
                // wrong defect.
                _ => continue,
            };
            match destination {
                Destination::Absent => out.push(Raw {
                    rule: clauses::ANNOTATION_DICTS,
                    object: Some(reference),
                    kind: FindingKind::DeviceColourWithoutOutputIntent {
                        space: space.to_string(),
                    },
                }),
                // The profile is there and unreadable, so the question cannot
                // be asked in either direction. Staged, not guessed.
                Destination::Unreadable => {}
                Destination::Space(signature) => {
                    let admitted = match space {
                        DEVICE_RGB => signature == b"RGB ",
                        DEVICE_CMYK => signature == b"CMYK",
                        _ => true,
                    };
                    if !admitted {
                        out.push(Raw {
                            rule: clauses::ANNOTATION_DICTS,
                            object: Some(reference),
                            kind: FindingKind::DeviceColourNotInOutputIntent {
                                space: space.to_string(),
                                profile: String::from_utf8_lossy(signature).trim().to_string(),
                            },
                        });
                    }
                }
            }
        }
    }
}

// ---- 6.2.3.2 / 6.2.4.2 ICCBased colour spaces -----------------------------

/// ISO 19005-1 6.2.3.2: an `ICCBased` stream's `/N` says how many components
/// the space has, and it shall agree with the profile.
///
/// The second half is the one that needs the profile's own header, and it is
/// the clearest example of what `docs/design/icc.md` landing bought this
/// group: the channel count follows from the data colour space signature, so a
/// three-component profile declared `/N 4` is a finding rather than a guess. A
/// profile this build cannot read leaves the second half unasked; the first —
/// `/N` present and one of the three values ISO 32000-1 8.6.5.5 admits — is
/// asked either way.
fn icc_spaces(doc: &CosDocument, used: &Used, part: Option<Part>, out: &mut Vec<Raw>) {
    for reference in &used.icc_streams {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(stream) = object.as_stream() else {
            continue;
        };
        let declared = doc.resolve_key(&stream.dict, doc.intern(b"N")).as_int();
        let Some(declared) = declared.filter(|n| matches!(n, 1 | 3 | 4)) else {
            out.push(Raw {
                rule: clauses::ICC_SPACES,
                object: Some(*reference),
                kind: FindingKind::IccStreamMalformed {
                    key: "N".to_string(),
                },
            });
            continue;
        };
        let Ok(bytes) = doc.stream_decoded(*reference) else {
            continue;
        };
        for (field, found) in header_defects(&bytes, ICC_BASED_CLASSES, ICC_BASED_SPACES, part) {
            out.push(Raw {
                rule: clauses::ICC_SPACES,
                object: Some(*reference),
                kind: FindingKind::IccProfileHeader { field, found },
            });
        }
        let Ok(profile) = icc::Profile::parse(&bytes) else {
            continue;
        };
        let components = match &profile.space {
            b"GRAY" => 1,
            b"RGB " | b"Lab " | b"XYZ " | b"YCbr" | b"HSV " | b"HLS " | b"CMY " => 3,
            b"CMYK" => 4,
            // A signature this build has not tabulated says nothing about the
            // count, and a rule that assumed one would be reporting its own
            // table rather than the file.
            _ => continue,
        };
        if declared != components {
            out.push(Raw {
                rule: clauses::ICC_SPACES,
                object: Some(*reference),
                kind: FindingKind::IccStreamMalformed {
                    key: "N".to_string(),
                },
            });
        }
    }
}

// ---- 6.2.9 / 6.2.6 Rendering intents --------------------------------------

/// ISO 19005-1 6.2.9: a rendering intent shall be one of the four ISO 32000-1
/// 8.6.5.8 defines.
///
/// Both spellings are gathered by the same walk — the `ri` operator and an
/// `/ExtGState`'s `/RenderingIntent` — because they are the same statement
/// written in two places and a rule that knew only one would pass the other.
fn rendering_intents(used: &Used, out: &mut Vec<Raw>) {
    for (intent, at) in &used.intents {
        if RENDERING_INTENTS.contains(&intent.as_slice()) {
            continue;
        }
        out.push(Raw {
            rule: clauses::RENDERING_INTENTS,
            object: *at,
            kind: FindingKind::RenderingIntentUnknown {
                declared: String::from_utf8_lossy(intent).into_owned(),
            },
        });
    }
}

// ---- 6.2.4, 6.2.5, 6.2.7, 6.2.8: what a graphics object may not carry -----

/// ISO 19005-1 6.2.4, 6.2.5 and 6.2.7, and their siblings: the entries an
/// XObject used for rendering may not have.
///
/// Every one of these is a prohibition on a **dictionary**, which is why they
/// arrive together and why none of them needs an interpreter: what decides
/// them is a key being present, and in one case a boolean being true.
///
/// - **`/Alternates`** (6.2.4) names other versions of the same picture, and
///   which one a reader shows is the reader's choice rather than the file's.
/// - **`/OPI`** (6.2.4 for an image, 6.2.5 for a form) is a link to a
///   high-resolution original held somewhere else, which is the whole of what
///   archiving forbids: a file whose appearance depends on something not in it.
/// - **`/Interpolate`** (6.2.4) asks a reader to smooth a picture on the way
///   up, and 8.9.5.1 leaves how entirely to the reader. `false` is the default
///   and is fine; `true` is a rendering nobody can reproduce.
/// - **A PostScript XObject** (6.2.7), by `/Subtype /PS` or by the `/Subtype2`
///   that makes a form one, is a program this format cannot bound.
///
/// The subject is the object the page drew, so a prohibited entry on an
/// XObject nothing invokes is not reported — the "used for rendering"
/// qualifier every rule in this group honours.
fn xobject_entries(doc: &CosDocument, used: &Used, out: &mut Vec<Raw>) {
    for (reference, is_image) in used
        .images
        .iter()
        .map(|r| (r, true))
        .chain(used.forms.iter().map(|r| (r, false)))
    {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(stream) = object.as_stream() else {
            continue;
        };
        let dict = &stream.dict;

        if !doc.resolve_key(dict, doc.intern(b"OPI")).is_null() {
            out.push(Raw {
                rule: clauses::XOBJECTS,
                object: Some(*reference),
                kind: FindingKind::ExternalContentForbidden {
                    key: "OPI".to_string(),
                },
            });
        }
        // 8.10.2's `/Subtype2 /PS` makes a form a PostScript XObject, and
        // 8.8.2's `/PS` is one outright. The second is caught where the walk
        // sorts XObjects by subtype; this is the first.
        if name_of(doc, dict, b"Subtype2").as_deref() == Some(b"PS") {
            out.push(Raw {
                rule: clauses::XOBJECTS,
                object: Some(*reference),
                kind: FindingKind::PostScriptXObjectForbidden,
            });
        }

        if !is_image {
            continue;
        }
        if !doc.resolve_key(dict, doc.intern(b"Alternates")).is_null() {
            out.push(Raw {
                rule: clauses::IMAGES,
                object: Some(*reference),
                kind: FindingKind::ExternalContentForbidden {
                    key: "Alternates".to_string(),
                },
            });
        }
        if doc
            .resolve_key(dict, doc.intern(b"Interpolate"))
            .as_bool()
            .unwrap_or(false)
        {
            out.push(Raw {
                rule: clauses::IMAGES,
                object: Some(*reference),
                kind: FindingKind::ImageInterpolated,
            });
        }
        // An image states its own rendering intent, and 8.6.5.8's four are the
        // only ones there are. The `ri` operator's are judged by
        // `rendering_intents`; this is the same closed set on the other
        // surface an intent reaches a page through.
        if let Some(intent) = name_of(doc, dict, b"Intent") {
            if !RENDERING_INTENTS.contains(&intent.as_slice()) {
                out.push(Raw {
                    rule: clauses::RENDERING_INTENTS,
                    object: Some(*reference),
                    kind: FindingKind::RenderingIntentUnknown {
                        declared: String::from_utf8_lossy(&intent).into_owned(),
                    },
                });
            }
        }
    }

    for reference in &used.postscript {
        out.push(Raw {
            rule: clauses::XOBJECTS,
            object: Some(*reference),
            kind: FindingKind::PostScriptXObjectForbidden,
        });
    }
}

/// ISO 19005-1 6.2.8 and its siblings: an extended graphics state carries no
/// transfer function.
///
/// A transfer function remaps component values on the way to the device, so a
/// file that states one has an appearance that depends on a reader applying
/// it — and 10.4's own text says a reader may ignore one entirely. Either way
/// the page is not reproducible, which is what the clause is about.
///
/// **`/TR` is forbidden however it is spelled and `/TR2` is forbidden unless
/// it is `/Default`**, and that asymmetry is the corpus's: the Isartor suite
/// has four `/TR` fixtures — an array, a function, `/Identity` and `/Default`
/// — and all four fail, against three `/TR2` fixtures where only `/Default`
/// is admitted. So `/TR /Default` is a finding and `/TR2 /Default` is not,
/// which no reading of "other than Default" alone would have given.
fn transfer_functions(doc: &CosDocument, used: &Used, out: &mut Vec<Raw>) {
    for reference in &used.ext_g_states {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(state) = object.as_dict() else {
            continue;
        };
        if !doc.resolve_key(state, doc.intern(b"TR")).is_null() {
            out.push(Raw {
                rule: clauses::GRAPHICS_STATE,
                object: Some(*reference),
                kind: FindingKind::TransferFunctionForbidden {
                    key: "TR".to_string(),
                },
            });
        }
        let second = doc.resolve_key(state, doc.intern(b"TR2"));
        if !second.is_null() {
            let default = second
                .as_name()
                .and_then(|name| doc.name_bytes(name))
                .is_some_and(|name| name.as_ref() == b"Default");
            if !default {
                out.push(Raw {
                    rule: clauses::GRAPHICS_STATE,
                    object: Some(*reference),
                    kind: FindingKind::TransferFunctionForbidden {
                        key: "TR2".to_string(),
                    },
                });
            }
        }
    }
}

// ---- 6.4 Transparency, in part 1 only -------------------------------------

/// ISO 19005-1 6.4: a part 1 file has no transparency at all.
///
/// Five ways to have some, and each is its own finding because they are
/// different things to fix: a transparency group on a page or a form, a soft
/// mask in a graphics state or on an XObject the pages draw, a blend mode that
/// is not one of the two meaning "do not blend", and a constant alpha below
/// one.
///
/// **Parts 2 to 4 permit transparency** and constrain it instead — the group's
/// colour space, the blend modes, the mask — and none of that runs here.
/// `super::STAGED` names it.
///
/// `pub(crate)` because the 2003 PDF/X levels forbid transparency outright as
/// well (`crate::pdfx`), and one reading of "no transparency" is better than
/// two that drift.
pub(crate) fn transparency(doc: &CosDocument, used: &Used, out: &mut Vec<Raw>) {
    for page in pages::collect_upto(doc, MAX_PAGES) {
        let Ok(object) = doc.get(page.reference) else {
            continue;
        };
        let Some(dict) = object.as_dict() else {
            continue;
        };
        if is_transparency_group(doc, dict) {
            out.push(Raw {
                rule: clauses::TRANSPARENCY,
                object: Some(page.reference),
                kind: FindingKind::TransparencyForbidden {
                    feature: "Group".to_string(),
                },
            });
        }
    }

    for reference in &used.forms {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(stream) = object.as_stream() else {
            continue;
        };
        if is_transparency_group(doc, &stream.dict) {
            out.push(Raw {
                rule: clauses::TRANSPARENCY,
                object: Some(*reference),
                kind: FindingKind::TransparencyForbidden {
                    feature: "Group".to_string(),
                },
            });
        }
    }

    // Rule 6.4-2, as veraPDF's published statement quotes ISO 19005-1 6.4
    // (with Cor.2:2011): "An XObject dictionary shall not contain the SMask
    // key." An image's own soft mask is transparency as surely as a graphics
    // state's, and until this loop only the graphics state's was judged. The
    // key at all, not its value: `/SMask` on an XObject has no `/None`
    // spelling the way a graphics state's has, and the rule's test condition
    // is `containsSMask == false`.
    for reference in used.images.iter().chain(used.forms.iter()) {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(stream) = object.as_stream() else {
            continue;
        };
        if stream.dict.contains_key(doc.intern(b"SMask")) {
            out.push(Raw {
                rule: clauses::TRANSPARENCY,
                object: Some(*reference),
                kind: FindingKind::TransparencyForbidden {
                    feature: "SMask".to_string(),
                },
            });
        }
    }

    for reference in &used.ext_g_states {
        let Ok(object) = doc.get(*reference) else {
            continue;
        };
        let Some(state) = object.as_dict() else {
            continue;
        };
        let mask = doc.resolve_key(state, doc.intern(b"SMask"));
        let none = mask
            .as_name()
            .and_then(|name| doc.name_bytes(name))
            .is_some_and(|name| name.as_ref() == b"None");
        if !mask.is_null() && !none {
            out.push(Raw {
                rule: clauses::TRANSPARENCY,
                object: Some(*reference),
                kind: FindingKind::TransparencyForbidden {
                    feature: "SMask".to_string(),
                },
            });
        }

        // 11.6.3: `/BM` is a name or an array of names, the array being the
        // reader's fallback list. Every member has to be admitted, because a
        // reader that supported the first one would blend.
        let modes = doc.resolve_key(state, doc.intern(b"BM"));
        let mut blend: Vec<Vec<u8>> = Vec::new();
        match modes.as_ref() {
            Object::Name(name) => {
                if let Some(bytes) = doc.name_bytes(*name) {
                    blend.push(bytes.to_vec());
                }
            }
            Object::Array(members) => {
                for member in members.iter().take(MAX_INTENTS) {
                    if let Some(bytes) = doc
                        .resolve(member)
                        .as_name()
                        .and_then(|name| doc.name_bytes(name))
                    {
                        blend.push(bytes.to_vec());
                    }
                }
            }
            _ => {}
        }
        if blend
            .iter()
            .any(|mode| !OPAQUE_BLEND_MODES.contains(&mode.as_slice()))
        {
            out.push(Raw {
                rule: clauses::TRANSPARENCY,
                object: Some(*reference),
                kind: FindingKind::TransparencyForbidden {
                    feature: "BM".to_string(),
                },
            });
        }

        for key in [&b"CA"[..], b"ca"] {
            let alpha = doc.resolve_key(state, doc.intern(key)).as_number();
            if let Some(alpha) = alpha {
                if alpha < 1.0 - ALPHA_TOLERANCE {
                    out.push(Raw {
                        rule: clauses::TRANSPARENCY,
                        object: Some(*reference),
                        kind: FindingKind::TransparencyForbidden {
                            feature: String::from_utf8_lossy(key).into_owned(),
                        },
                    });
                }
            }
        }
    }
}

// ---- 6.2.10 / 6.2.9: transparency needs a blending space ------------------

/// ISO 19005-2 6.2.10 and ISO 19005-4 6.2.9: a device blending space is a
/// device colour like any other.
///
/// **Part 1 forbids transparency; parts 2 to 4 admit it and condition it.**
/// What they condition is what 6.2.3.3 conditions every device colour on:
/// blending happens *in* a colour space, so a page that blends in `DeviceRGB`
/// under a CMYK destination has composited numbers nobody can reproduce —
/// the same defect, on the same clause's terms, as painting in `DeviceRGB`
/// there.
///
/// So this records the blending space as a **use** rather than reporting it,
/// and [`device_spaces`] judges it with everything else. Two things follow
/// that a rule of its own would have got wrong: the finding is one a reader
/// already knows, and a page that both blends and paints in `DeviceRGB` says
/// so **once** — one defect reported twice under one clause is worse than
/// once, and a first draft of this did exactly that.
///
/// The inverse is already here and stays: an *independent* blending space
/// excuses a device colour ([`gather_group_spaces`]), because a group that
/// says what its own values mean can reproduce them.
///
/// # Why the reading comes from fixtures rather than from the clause
///
/// ISO 19005-2 and -4 are sold and this repository has no copy. What it has is
/// 118 annotated fixtures across the two parts — a published statement by the
/// people who wrote the conformance suite, admissible under ruling 13, and the
/// same evidence the annotation group was built from. The check on the reading
/// is the census: the `pass` side must not move.
///
/// **There is no "is anything transparent" guard, and a counted injection is
/// why.** A first draft opened with one, over a helper that answered whether
/// any graphics state or group in the document was transparent. It could not
/// change an answer: this walk reads only a `/Group` whose `/S` is
/// `/Transparency`, and a document carrying one of those is transparent by
/// that helper's own definition — so removing the guard failed nothing,
/// because nothing it guarded against could happen. Both are gone. A line
/// that looks load-bearing and is not is worse than no line.
fn gather_blending_spaces(doc: &CosDocument, used: &mut Used) {
    let mut dicts: Vec<(Dict, Option<ObjRef>)> = Vec::new();
    for page in pages::collect_upto(doc, MAX_PAGES) {
        if let Some(dict) = doc
            .get(page.reference)
            .ok()
            .and_then(|o| o.as_dict().cloned())
        {
            dicts.push((dict, Some(page.reference)));
        }
    }
    // An appearance stream's own group counts too: the suite states it as its
    // own fixture, "DeviceRGB is used as blending color space of the
    // transparency group in the annotation's appearance stream".
    for reference in &used.forms {
        if let Some(stream) = doc
            .get(*reference)
            .ok()
            .and_then(|o| o.as_stream().cloned())
        {
            dicts.push((stream.dict, Some(*reference)));
        }
    }
    for (dict, at) in &dicts {
        let group = doc.resolve_key(dict, doc.intern(b"Group"));
        let Some(group) = group.as_dict() else {
            continue;
        };
        if name_of(doc, group, b"S").as_deref() != Some(b"Transparency") {
            continue;
        }
        // 11.6.6 lets `/CS` be a name or an array. The array forms are
        // device-independent and `gather_group_spaces` has taken them already;
        // what is left is one of the three device names.
        let space = doc.resolve_key(group, doc.intern(b"CS"));
        let Some(family) = space
            .as_name()
            .and_then(|name| doc.name_bytes(name))
            .map(|name| name.to_vec())
        else {
            continue;
        };
        let named = match family.as_slice() {
            b"DeviceGray" => DEVICE_GRAY,
            b"DeviceRGB" => DEVICE_RGB,
            b"DeviceCMYK" => DEVICE_CMYK,
            _ => continue,
        };
        used.devices.entry(named).or_insert(*at);
    }
}

/// Whether a page or form dictionary carries a transparency group (11.6.6).
fn is_transparency_group(doc: &CosDocument, dict: &Dict) -> bool {
    let group = doc.resolve_key(dict, doc.intern(b"Group"));
    group
        .as_dict()
        .and_then(|group| name_of(doc, group, b"S"))
        .is_some_and(|subtype| subtype == b"Transparency")
}

// ---- shared ---------------------------------------------------------------

/// A dictionary entry that is a name, as bytes.
fn name_of(doc: &CosDocument, dict: &Dict, key: &[u8]) -> Option<Vec<u8>> {
    doc.resolve_key(dict, doc.intern(key))
        .as_name()
        .and_then(|name| doc.name_bytes(name))
        .map(|bytes| bytes.to_vec())
}

/// Whether an `/ExtGState` naming a rendering intent is gathered by the walk.
///
/// Called from [`scan`] through the extended-graphics-state resources, so that
/// [`rendering_intents`] sees both spellings. Kept beside the graphics-state
/// rules rather than inside the walk, because what a state dictionary means is
/// this group's business and not the walker's.
fn gather_state_intents(doc: &CosDocument, used: &mut Used) {
    let states: Vec<ObjRef> = used.ext_g_states.iter().copied().collect();
    for reference in states {
        let Ok(object) = doc.get(reference) else {
            continue;
        };
        let Some(state) = object.as_dict() else {
            continue;
        };
        if let Some(intent) = name_of(doc, state, b"RenderingIntent") {
            used.intents.entry(intent).or_insert(Some(reference));
        }
    }
}
