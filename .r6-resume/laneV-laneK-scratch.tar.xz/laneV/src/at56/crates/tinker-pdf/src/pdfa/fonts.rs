//! The font rule group: ISO 19005-1 6.3, ISO 19005-2/3 6.2.11 and
//! ISO 19005-4 6.2.10 (milestone 5 of `docs/design/pdfa.md`).
//!
//! # "Used for rendering" is the clause's own qualifier, and it is load-bearing
//!
//! Nearly every sentence in these clauses begins the same way: *for all fonts
//! **used for rendering** in a conforming file*. The first version of this
//! module read that as decoration and judged every dictionary in the
//! cross-reference table whose `/Type` was `/Font`. The corpus disagreed
//! within one run, in two different ways and both of them instructive:
//!
//! - an interactive form's `/DR` names `/Helvetica`, `/Helvetica-Bold` and
//!   `/ZapfDingbats` — three of the standard 14, none embedded, none drawn
//!   with — and the suite annotates those files `pass`. A default-resource
//!   font is a font a *future* appearance stream might use, not one this file
//!   renders;
//! - a fixture whose own title reads *"Type1 font that is used for rendering
//!   is not embedded; **the text rendering mode is 3**"* is annotated `pass`,
//!   and so is a CIDFont with no `/CIDToGIDMap` under the same qualifier.
//!   Mode 3 is 9.3.6's invisible mode: the glyphs are positioned and not
//!   painted, so nothing about the face reaches the page.
//!
//! So this group finds out what is drawn before it judges anything, and that
//! is what [`usage`] does: the page content streams, the form XObjects they
//! invoke and the annotation appearance streams they carry are tokenized, the
//! text rendering mode and the selected font are tracked through `q`/`Q`, and
//! a font enters the set the rules run over only when a text-showing operator
//! ran with it selected at a mode other than 3.
//!
//! # What this group reaches for
//!
//! Two machineries past the COS document, and both are counted as
//! [`super::RuleGroup::Fonts`]: `tinker-pdf-content`'s tokenizer, for the
//! usage scan above, and `tinker-pdf-font`, for the two rules that ask a
//! question only the font program can answer — whether the bytes behind
//! `/FontFile2` are an `sfnt` at all, and whether a `/FontFile3` marked
//! `/Type1C` really carries CFF. Both are the leaves the renderer already
//! trusts. A validator with a second font parser would be checking files
//! against a reading of the font formats nothing else in the engine shares.
//!
//! **Injection, counted.** Making rendering mode 3 count as rendering — one
//! comparison in [`Scan::stream`] — fails **2 of the workspace's 3 581 tests**:
//! `a_font_drawn_only_at_rendering_mode_three_is_not_used_for_rendering` and
//! `the_rendering_mode_is_restored_by_q_like_the_rest_of_the_graphics_state`.
//! It also puts two conforming corpus files back into the false-positive
//! column, which is the measurement the two tests stand in for.
//!
//! # What is staged, and the evidence for staging it
//!
//! The Unicode rule (6.3.8 / 6.2.11.7) is the sharpest limit here and
//! [`super::STAGED`] carries the reason: `6-3-8-t01-fail-b.pdf` and
//! `6-3-8-t01-pass-e.pdf` have **byte-identical font dictionaries** — the same
//! two Type 1 fonts, the same `/Encoding` dictionary, neither with a
//! `/ToUnicode` — and opposite annotations. Whatever separates them is not in
//! the font dictionary, so no rule over font dictionaries can find it. What
//! *is* determinable is checked; the rest is named rather than guessed.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::Arc;

use tinker_pdf_cos::{CosDocument, Dict, ObjRef, Object};

use super::content;

use super::{clauses, FindingKind, Flavour, Level, Machinery, Part, Raw, RuleGroup};

/// How many font programs are parsed in one document.
const MAX_PROGRAM_PARSES: usize = 4096;

/// The `/Subtype` values a `/FontFile3` stream may declare (ISO 32000-1 9.9
/// Table 126, as ISO 19005-1 6.3.4 admits them).
const FONT_FILE3_SUBTYPES: &[&[u8]] = &[b"Type1C", b"CIDFontType0C", b"OpenType"];

/// The two base encodings ISO 19005-1 6.3.7 admits on a non-symbolic TrueType
/// font.
const ADMITTED_ENCODINGS: &[&[u8]] = &[b"WinAnsiEncoding", b"MacRomanEncoding"];

/// The named encodings ISO 32000-1 Annex D defines, whose code-to-glyph-name
/// tables are published and whose glyph names are Unicode-mappable.
///
/// A font that names one of these has said what every code means without a
/// `/ToUnicode`, which is the exemption ISO 19005-1 6.3.8 turns on.
const PREDEFINED_ENCODINGS: &[&[u8]] = &[
    b"WinAnsiEncoding",
    b"MacRomanEncoding",
    b"MacExpertEncoding",
    b"StandardEncoding",
];

/// Runs every font rule that applies to `flavour`.
pub(super) fn rules(
    doc: &Arc<CosDocument>,
    machinery: &Machinery,
    flavour: Option<Flavour>,
    out: &mut Vec<Raw>,
) {
    if !machinery.reach(RuleGroup::Fonts) {
        return;
    }
    run(doc, flavour, out);
}

/// The font rules, once the group has been reached for.
///
/// Split from [`rules`] so that the PDF/UA validator, which reads the same
/// fonts under ISO 14289's numbering (`docs/design/pdfua.md`, "one rule, two
/// standards"), runs them behind its own counted reach rather than counting
/// a second one.
pub(crate) fn run(doc: &Arc<CosDocument>, flavour: Option<Flavour>, out: &mut Vec<Raw>) {
    widths(doc, out);
    let mut budget = MAX_PROGRAM_PARSES;
    for reference in usage(doc) {
        let Ok(object) = doc.get(reference) else {
            continue;
        };
        let Some(dict) = object.as_dict() else {
            continue;
        };
        font(doc, flavour, dict, reference, &mut budget, out);
    }
}

/// The embedding rule alone, over the fonts the pages draw with: no program
/// is parsed, and no other font rule runs.
///
/// For ISO 15930, whose application notes ask one thing of a font — that it
/// is embedded (`crate::pdfx`) — and ask it in the sentence ISO 19005-1 6.3.4
/// uses. The findings are this module's own, `FontNotEmbedded` among them,
/// read exactly as [`run`] reads them: a Type 3 font has no program to embed,
/// a composite font's program is its descendant's, and a `/FontFile3 null` is
/// a key present and a program absent. A zero parse budget is what keeps the
/// programs closed.
pub(crate) fn embedding(doc: &CosDocument, out: &mut Vec<Raw>) {
    let mut budget = 0usize;
    for reference in usage(doc) {
        let Ok(object) = doc.get(reference) else {
            continue;
        };
        let Some(dict) = object.as_dict() else {
            continue;
        };
        let subtype = name_of(doc, dict, b"Subtype").unwrap_or_default();
        let (descriptor_owner, at, program_subtype) = match subtype.as_slice() {
            b"Type3" => continue,
            b"Type0" => {
                let descendants = doc.resolve_key(dict, doc.intern(b"DescendantFonts"));
                let Some(first) = descendants.as_array().and_then(|values| values.first()) else {
                    continue;
                };
                let at = first.as_objref().unwrap_or(reference);
                let resolved = doc.resolve(first);
                let Some(descendant) = resolved.as_dict() else {
                    continue;
                };
                let descendant_subtype = name_of(doc, descendant, b"Subtype").unwrap_or_default();
                (descendant.clone(), at, descendant_subtype)
            }
            _ => (dict.clone(), reference, subtype.clone()),
        };
        let descriptor = doc.resolve_key(&descriptor_owner, doc.intern(b"FontDescriptor"));
        match descriptor.as_dict() {
            Some(descriptor) => {
                embedded_program(doc, descriptor, &program_subtype, at, &mut budget, out);
            }
            None => out.push(Raw {
                rule: clauses::FONT_EMBEDDING,
                object: Some(at),
                kind: FindingKind::FontNotEmbedded {
                    subtype: String::from_utf8_lossy(&program_subtype).into_owned(),
                },
            }),
        }
    }
}

// ---- what the file actually draws with ------------------------------------

/// Every font a text-showing operator drew with at a visible rendering mode.
///
/// The walk itself is [`super::content`], shared with the colour group; this
/// is the visitor over it. Returned as an ordered set so the findings come out
/// in object-number order whatever order the pages happened to reach them in —
/// a verdict is compared by tests and read by people, and both want it stable.
pub(crate) fn usage(doc: &CosDocument) -> BTreeSet<ObjRef> {
    let mut rendered = BTreeSet::new();
    content::walk(doc, &mut |op| {
        if !matches!(op.operator, b"Tj" | b"TJ" | b"'" | b"\"") {
            return;
        }
        if op.mode == content::RENDER_MODE_INVISIBLE {
            return;
        }
        let (Some(name), Some(resources)) = (op.font, op.resources) else {
            return;
        };
        if let Some(reference) = content::lookup(doc, resources, b"Font", name) {
            rendered.insert(reference);
        }
    });
    rendered
}

// ---- the rules ------------------------------------------------------------

/// One font dictionary, dispatched on its `/Subtype`.
fn font(
    doc: &CosDocument,
    flavour: Option<Flavour>,
    dict: &Dict,
    at: ObjRef,
    budget: &mut usize,
    out: &mut Vec<Raw>,
) {
    let subtype = name_of(doc, dict, b"Subtype").unwrap_or_default();
    subset_tag(doc, dict, at, out);
    unicode(doc, flavour, dict, &subtype, at, out);

    match subtype.as_slice() {
        b"Type0" => composite(doc, flavour, dict, at, budget, out),
        // 9.6.5: a Type 3 font's glyphs *are* content streams, so there is no
        // program to embed and no descriptor to embed it in. The embedding
        // clause has nothing to say about one, and a rule that reported every
        // Type 3 font as unembedded would be reporting the format rather than
        // a defect. Part 4 forbids Type 3 fonts outright; that is 6.2.10.2's
        // rule rather than this one's, and `super::STAGED` names it.
        b"Type3" => {}
        _ => simple(doc, flavour, dict, &subtype, at, budget, out),
    }
}

// ---- 6.3.4 / 6.2.11.4.1 Embedding -----------------------------------------

/// A simple font: Type 1, its multiple-master variant, or TrueType.
fn simple(
    doc: &CosDocument,
    flavour: Option<Flavour>,
    dict: &Dict,
    subtype: &[u8],
    at: ObjRef,
    budget: &mut usize,
    out: &mut Vec<Raw>,
) {
    encoding(doc, flavour, dict, subtype, at, out);
    let descriptor = doc.resolve_key(dict, doc.intern(b"FontDescriptor"));
    let Some(descriptor) = descriptor.as_dict() else {
        // **The standard 14 land here, and that is the whole point of the
        // clause.** ISO 32000-1 9.6.2.2 lets a font dictionary for one of the
        // fourteen omit both the descriptor and the widths, because the
        // reader is expected to supply them. ISO 19005 has no such list: a
        // file whose appearance depends on a face the reader happens to own
        // is the thing the standard exists to prevent, so a font with no
        // descriptor has no embedded program and is reported as one.
        out.push(Raw {
            rule: clauses::FONT_EMBEDDING,
            object: Some(at),
            kind: FindingKind::FontNotEmbedded {
                subtype: String::from_utf8_lossy(subtype).into_owned(),
            },
        });
        return;
    };
    embedded_program(doc, descriptor, subtype, at, budget, out);
}

/// The descriptor's font-file keys, against the `/Subtype` that named it.
///
/// ISO 19005-1 6.3.4: every font used for rendering shall have an embedded
/// program, and the program shall be the kind the font dictionary says it is.
/// Three findings come out of that one sentence and they are different
/// problems: nothing is embedded at all, something is embedded under a key
/// this font subtype does not admit, or the right key holds bytes that are not
/// the format it names.
fn embedded_program(
    doc: &CosDocument,
    descriptor: &Dict,
    subtype: &[u8],
    at: ObjRef,
    budget: &mut usize,
    out: &mut Vec<Raw>,
) {
    let mut embedded = false;
    for key in [&b"FontFile"[..], b"FontFile2", b"FontFile3"] {
        // `get_ref` rather than `resolve_key`, and deliberately: a stream is
        // an indirect object by construction (7.3.8), so an entry that is not
        // a reference is not a program. One corpus fixture writes
        // `/FontFile3 null`, which is a key present and a program absent —
        // and reading that as "embedded" was the defect this line avoids.
        let Some(program_ref) = descriptor.get_ref(doc.intern(key)) else {
            continue;
        };
        let Some(program) = doc.get(program_ref).ok() else {
            continue;
        };
        let Some(stream) = program.as_stream() else {
            continue;
        };
        embedded = true;
        let program_subtype = name_of(doc, &stream.dict, b"Subtype").unwrap_or_default();

        // The stream's own `/Subtype` first, then the pairing. The order is
        // not arbitrary: a `/FontFile3 /Type42C` is wrong whatever font names
        // it, and reporting it as "a TrueType font may not use /FontFile3"
        // would name the font's fault rather than the stream's. Checked the
        // other way round, every bad stream subtype was reported as a bad
        // pairing and the finding pointed at the wrong object.
        if key == b"FontFile3" && !FONT_FILE3_SUBTYPES.contains(&program_subtype.as_slice()) {
            out.push(Raw {
                rule: clauses::FONT_EMBEDDING,
                object: Some(at),
                kind: FindingKind::FontProgramSubtypeMismatch {
                    key: "FontFile3".to_string(),
                    declared: String::from_utf8_lossy(&program_subtype).into_owned(),
                },
            });
            continue;
        }
        if !admits(subtype, key, &program_subtype) {
            out.push(Raw {
                rule: clauses::FONT_EMBEDDING,
                object: Some(at),
                kind: FindingKind::FontProgramSubtypeMismatch {
                    key: String::from_utf8_lossy(key).into_owned(),
                    declared: String::from_utf8_lossy(subtype).into_owned(),
                },
            });
            continue;
        }

        // The reach. Everything above this line is the object graph; this is
        // the font program, and it is half of why the group exists as a group.
        if *budget == 0 {
            continue;
        }
        *budget -= 1;
        let Ok(bytes) = doc.stream_decoded(program_ref) else {
            // A stream whose filter chain will not run is a defect the syntax
            // group and the reader's own warnings already speak about. Saying
            // it a third time under a font clause would be attributing a
            // filter's problem to a font.
            continue;
        };
        if !parses_as(key, &program_subtype, &bytes) {
            out.push(Raw {
                rule: clauses::FONT_EMBEDDING,
                object: Some(at),
                kind: FindingKind::FontProgramUnreadable {
                    key: String::from_utf8_lossy(key).into_owned(),
                },
            });
        }
    }

    if !embedded {
        out.push(Raw {
            rule: clauses::FONT_EMBEDDING,
            object: Some(at),
            kind: FindingKind::FontNotEmbedded {
                subtype: String::from_utf8_lossy(subtype).into_owned(),
            },
        });
    }
}

/// Whether a font of this `/Subtype` may carry its program under `key`.
///
/// ISO 32000-1 9.9 Table 126 pairs them: `/FontFile` is Type 1, `/FontFile2`
/// is TrueType, and `/FontFile3` is everything with its own `/Subtype`. A
/// `/FontFile3` marked `/OpenType` is admitted for every font kind, which is
/// Table 126's own note — an OpenType wrapper can hold either outline format
/// and the wrapper is what the key names.
fn admits(font_subtype: &[u8], key: &[u8], program_subtype: &[u8]) -> bool {
    if key == b"FontFile3" && program_subtype == b"OpenType" {
        return true;
    }
    match font_subtype {
        b"Type1" | b"MMType1" => key == b"FontFile" || program_subtype == b"Type1C",
        b"TrueType" | b"CIDFontType2" => key == b"FontFile2",
        b"CIDFontType0" => key == b"FontFile3" && program_subtype == b"CIDFontType0C",
        // A `/Subtype` this build does not know is not a font-file problem,
        // and reporting one would turn "we have not heard of this" into "the
        // file is wrong".
        _ => true,
    }
}

/// Whether the bytes are the format the key and the stream's `/Subtype` claim.
///
/// This is the only place in the validator where a document's bytes are handed
/// to a parser that could be slow, and every one of these returns `None`
/// rather than panicking on rubbish — they are the same entry points the
/// renderer uses on the same untrusted input (ruling 1).
fn parses_as(key: &[u8], program_subtype: &[u8], bytes: &[u8]) -> bool {
    match (key, program_subtype) {
        (b"FontFile", _) => tinker_pdf_font::Type1::parse(bytes).is_some(),
        (b"FontFile2", _) | (b"FontFile3", b"OpenType") => {
            tinker_pdf_font::Sfnt::parse(bytes).is_some()
        }
        (b"FontFile3", b"Type1C" | b"CIDFontType0C") => {
            tinker_pdf_font::Cff::parse(bytes).is_some()
        }
        // An unknown pairing has already been reported as one; parsing it
        // against a format nobody named would report the same defect twice.
        _ => true,
    }
}

// ---- 6.3.5 / 6.2.11.4.2 Font subsets --------------------------------------

/// The six-letter subset tag.
///
/// ISO 32000-1 9.6.4 gives the shape — six upper-case letters, a `+`, then the
/// font's own name — and ISO 19005-1 6.3.5 requires a subset to use it. Only
/// the *shape* is checked: whether two subsets of one face were given the same
/// tag is a document-wide question this rule does not ask.
///
/// **A reading.** A `/BaseFont` with no `+` in it is not a subset and is not
/// reported. A `+` anywhere in the name is taken as a subset tag's, which is
/// what makes `AB+Arial` a finding. The alternative reading — only a `+` at
/// index six counts — would pass it silently, and passing it silently is the
/// defect the clause is about.
fn subset_tag(doc: &CosDocument, dict: &Dict, at: ObjRef, out: &mut Vec<Raw>) {
    let Some(base) = name_of(doc, dict, b"BaseFont") else {
        return;
    };
    if !base.contains(&b'+') {
        return;
    }
    let shaped = base.len() > 7
        && base[6] == b'+'
        && base[..6].iter().all(u8::is_ascii_uppercase)
        && !base[7..].contains(&b'+');
    if !shaped {
        out.push(Raw {
            rule: clauses::FONT_SUBSETS,
            object: Some(at),
            kind: FindingKind::SubsetTagMalformed {
                declared: String::from_utf8_lossy(&base).into_owned(),
            },
        });
    }
}

// ---- 6.3.7 / 6.2.11.6 Character encodings ---------------------------------

/// The symbolic flag, ISO 32000-1 9.8.2 Table 123 bit position 3.
const FLAG_SYMBOLIC: i64 = 1 << 2;

/// ISO 19005-1 6.3.7, and its siblings.
///
/// The clause is about **TrueType** fonts and only TrueType fonts, which is
/// worth saying because the obvious generalisation — every simple font's
/// encoding must be one of the two — is not what it says and would report
/// every conforming Type 1 font in the corpus. A Type 1 font's encoding is
/// built into the program and 9.6.6.2 lets the dictionary override it by name
/// or by difference; the clause leaves that alone.
///
/// Two requirements, in opposite directions:
///
/// 1. a **symbolic** font's `/Encoding` shall not be present, because the
///    program's own `cmap` is the mapping and a dictionary entry would be a
///    second, disagreeing one;
/// 2. a **non-symbolic** font's `/Encoding` shall be present and shall be
///    `/WinAnsiEncoding` or `/MacRomanEncoding`.
///
/// **A reading, named as one.** Part 1 is read as forbidding `/Differences` on
/// a non-symbolic TrueType font and parts 2 to 4 as permitting it: parts 2 and
/// 3 moved the clause and softened its wording, and this build could not
/// establish from the text available that the prohibition survived the move.
/// The stricter half runs only where the reading is certain.
fn encoding(
    doc: &CosDocument,
    flavour: Option<Flavour>,
    dict: &Dict,
    subtype: &[u8],
    at: ObjRef,
    out: &mut Vec<Raw>,
) {
    if subtype != b"TrueType" {
        return;
    }
    let flags = doc
        .resolve_key(dict, doc.intern(b"FontDescriptor"))
        .as_dict()
        .map_or(0, |descriptor| {
            doc.resolve_key(descriptor, doc.intern(b"Flags"))
                .as_int()
                .unwrap_or(0)
        });

    let value = doc.resolve_key(dict, doc.intern(b"Encoding"));
    if flags & FLAG_SYMBOLIC != 0 {
        if !value.is_null() {
            out.push(Raw {
                rule: clauses::FONT_ENCODINGS,
                object: Some(at),
                kind: FindingKind::SymbolicFontHasEncoding,
            });
        }
        return;
    }

    let (declared, differences) = match value.as_ref() {
        Object::Name(name) => (
            doc.name_bytes(*name)
                .map(|n| n.to_vec())
                .unwrap_or_default(),
            false,
        ),
        Object::Dict(encoding) => (
            name_of(doc, encoding, b"BaseEncoding").unwrap_or_default(),
            encoding.contains_key(doc.intern(b"Differences")),
        ),
        _ => (Vec::new(), false),
    };

    if !ADMITTED_ENCODINGS.contains(&declared.as_slice()) {
        out.push(Raw {
            rule: clauses::FONT_ENCODINGS,
            object: Some(at),
            kind: FindingKind::EncodingNotStandard {
                declared: String::from_utf8_lossy(&declared).into_owned(),
            },
        });
    } else if differences && flavour.map(|f| f.part) == Some(Part::One) {
        out.push(Raw {
            rule: clauses::FONT_ENCODINGS,
            object: Some(at),
            kind: FindingKind::EncodingDifferencesForbidden,
        });
    }
}

// ---- 6.3.8 / 6.2.11.7 Unicode character maps ------------------------------

/// The determinable half of ISO 19005-1 6.3.8.
///
/// The clause requires every glyph a level A or level U file renders to be
/// mappable to Unicode. `/ToUnicode` is one way to say so and not the only
/// one: a simple font naming one of Annex D's predefined encodings has already
/// said what every code means, and a composite font whose `/Encoding` names a
/// predefined CMap other than the two identity ones carries its mapping in the
/// character collection that CMap belongs to.
///
/// So this rule fires on a font that has **none** of the three, which is the
/// part of the clause a font dictionary can answer. The part it cannot is
/// staged, and [`super::STAGED`] carries the evidence: two fixtures with
/// identical font dictionaries and opposite annotations, differing only in
/// which glyph of a `/Differences` array the page draws.
///
/// **Part 4 is included, and that is a reading.** ISO 19005-4 has no level U —
/// it has E and F — and this build reads it as having absorbed the Unicode
/// requirement into the base part rather than dropped it, because the suite
/// files fixtures under `6.2.10.7 Unicode character maps` and annotates one of
/// them `pass`.
fn unicode(
    doc: &CosDocument,
    flavour: Option<Flavour>,
    dict: &Dict,
    subtype: &[u8],
    at: ObjRef,
    out: &mut Vec<Raw>,
) {
    let required = matches!(
        flavour,
        Some(Flavour {
            part: Part::Four,
            ..
        }) | Some(Flavour {
            level: Some(Level::A | Level::U),
            ..
        })
    );
    if !required || dict.contains_key(doc.intern(b"ToUnicode")) {
        return;
    }
    let mapped = match subtype {
        // Two routes, and the corpus named the second one for us.
        //
        // The first is a predefined CMap that is not one of the two identity
        // ones: the identity CMaps map a code to itself and say nothing about
        // text, and a CID-keyed CFF program has no glyph names to fall back
        // on.
        //
        // The second is the **character collection** the descendant CIDFont
        // declares. Adobe publishes a `…-UCS2` CMap for each of the published
        // collections, so a CID in `Adobe-Japan1` has a Unicode value whether
        // or not the file spells it out — which is why three fixtures whose
        // own titles read *"Type 0 font whose descendant CIDFont uses the
        // Adobe-Korea1 character collection does not include a ToUnicode
        // entry"* are annotated `pass`. `Adobe-Identity` is not one of them:
        // it is the collection that means "these CIDs mean whatever this file
        // says they mean", and this file says nothing.
        b"Type0" => {
            name_of(doc, dict, b"Encoding")
                .is_some_and(|name| name != b"Identity-H" && name != b"Identity-V")
                || published_collection(doc, dict)
        }
        // A TrueType program maps codes to glyph *indices* through its own
        // `cmap`, and an index is not a character. So the dictionary is the
        // only place a TrueType font can say what its codes mean: a named
        // encoding from Annex D, or an encoding dictionary whose
        // `/Differences` are glyph names.
        b"TrueType" => match doc.resolve_key(dict, doc.intern(b"Encoding")).as_ref() {
            Object::Name(name) => doc
                .name_bytes(*name)
                .is_some_and(|n| PREDEFINED_ENCODINGS.contains(&n.as_ref())),
            Object::Dict(_) => true,
            _ => false,
        },
        // **Type 1, its multiple-master variant and Type 3 are exempt, and
        // that is a reading the corpus forced.** `6-3-8-t01-pass-e.pdf`
        // carries a symbolic Type 1 font with no `/Encoding` and no
        // `/ToUnicode` and is annotated `pass`; the first version of this rule
        // reported it. The reason it conforms is that a Type 1 program is
        // keyed by glyph *name*, and a glyph name is a route to Unicode
        // through the Adobe Glyph List. Whether a particular name is on that
        // list is the staged half of this clause — `super::STAGED` says so —
        // and the difference between the two fixtures that made this rule
        // wrong is exactly one such name.
        _ => true,
    };
    if !mapped {
        out.push(Raw {
            rule: clauses::FONT_UNICODE,
            object: Some(at),
            kind: FindingKind::ToUnicodeMissing,
        });
    }
}

/// Whether a Type 0 font's descendant declares one of the published Adobe
/// character collections.
///
/// The list is the set Adobe publishes a `…-UCS2` mapping for. It is data
/// about the registry rather than about any file, and `Adobe-Identity` is
/// deliberately absent: a CID in `Adobe-Identity` has no published meaning.
fn published_collection(doc: &CosDocument, dict: &Dict) -> bool {
    const COLLECTIONS: &[&[u8]] = &[b"Japan1", b"Japan2", b"GB1", b"CNS1", b"Korea1", b"KR"];
    let descendants = doc.resolve_key(dict, doc.intern(b"DescendantFonts"));
    let Some(first) = descendants.as_array().and_then(<[Object]>::first) else {
        return false;
    };
    let descendant = doc.resolve(first);
    let Some(descendant) = descendant.as_dict() else {
        return false;
    };
    let info = doc.resolve_key(descendant, doc.intern(b"CIDSystemInfo"));
    let Some(info) = info.as_dict() else {
        return false;
    };
    let registry = doc.resolve_key(info, doc.intern(b"Registry"));
    let ordering = doc.resolve_key(info, doc.intern(b"Ordering"));
    let (Some(registry), Some(ordering)) = (registry.as_string(), ordering.as_string()) else {
        return false;
    };
    registry.bytes.as_slice() == b"Adobe" && COLLECTIONS.contains(&ordering.bytes.as_slice())
}

// ---- 6.3.3.2 / 6.2.11.3.2 CIDFonts ----------------------------------------

/// A Type 0 font and the CIDFont under it.
///
/// ISO 32000-1 9.7.4 makes `/DescendantFonts` a one-element array, and every
/// rule below is about that element rather than about the Type 0 dictionary
/// that names it — which is why the findings carry the *descendant's* object
/// number where there is one.
fn composite(
    doc: &CosDocument,
    flavour: Option<Flavour>,
    dict: &Dict,
    at: ObjRef,
    budget: &mut usize,
    out: &mut Vec<Raw>,
) {
    let reading = match flavour.map(|f| f.part) {
        Some(Part::One) | None => CMapReading::PDF_A_1,
        Some(_) => CMapReading::TABLE_118,
    };
    for (object, kind) in cmap_findings(doc, dict, at, reading) {
        let rule = match kind {
            FindingKind::CidSystemInfoMismatch { .. } => clauses::CID_SYSTEM_INFO,
            _ => clauses::CMAPS,
        };
        out.push(Raw {
            rule,
            object: Some(object),
            kind,
        });
    }
    let descendants = doc.resolve_key(dict, doc.intern(b"DescendantFonts"));
    let Some(values) = descendants.as_array() else {
        return;
    };
    let Some(first) = values.first() else {
        return;
    };
    let reference = first.as_objref().unwrap_or(at);
    let resolved = doc.resolve(first);
    let Some(descendant) = resolved.as_dict() else {
        return;
    };
    let subtype = name_of(doc, descendant, b"Subtype").unwrap_or_default();

    cid_system_info(doc, descendant, reference, out);
    if subtype == b"CIDFontType2" {
        cid_to_gid(doc, descendant, reference, out);
    }
    subset_tag(doc, descendant, reference, out);

    let descriptor = doc.resolve_key(descendant, doc.intern(b"FontDescriptor"));
    match descriptor.as_dict() {
        Some(descriptor) => {
            embedded_program(doc, descriptor, &subtype, reference, budget, out);
        }
        None => out.push(Raw {
            rule: clauses::FONT_EMBEDDING,
            object: Some(reference),
            kind: FindingKind::FontNotEmbedded {
                subtype: String::from_utf8_lossy(&subtype).into_owned(),
            },
        }),
    }
}

/// ISO 32000-1 9.7.3 Table 114, as ISO 19005-1 6.3.3.2 requires it.
///
/// The three entries are checked by *type* and not only by presence, because a
/// `/Registry` that is a name rather than a string is the defect the clause is
/// about as much as a missing one is: a consumer looking the character
/// collection up in a registry has nothing to look up either way.
fn cid_system_info(doc: &CosDocument, descendant: &Dict, at: ObjRef, out: &mut Vec<Raw>) {
    let info = doc.resolve_key(descendant, doc.intern(b"CIDSystemInfo"));
    let Some(info) = info.as_dict() else {
        out.push(Raw {
            rule: clauses::CID_FONTS,
            object: Some(at),
            kind: FindingKind::CidSystemInfoIncomplete {
                key: "CIDSystemInfo".to_string(),
            },
        });
        return;
    };
    for (key, wants_string) in [
        (&b"Registry"[..], true),
        (b"Ordering", true),
        (b"Supplement", false),
    ] {
        let value = doc.resolve_key(info, doc.intern(key));
        let ok = if wants_string {
            value.as_string().is_some()
        } else {
            value.as_int().is_some()
        };
        if !ok {
            out.push(Raw {
                rule: clauses::CID_FONTS,
                object: Some(at),
                kind: FindingKind::CidSystemInfoIncomplete {
                    key: String::from_utf8_lossy(key).into_owned(),
                },
            });
        }
    }
}

/// ISO 19005-1 6.3.3.2's `/CIDToGIDMap` requirement.
///
/// ISO 32000-1 9.7.4.2 gives `/CIDToGIDMap` the default `/Identity` when it is
/// absent, so a CIDFontType2 without one is a legal PDF. ISO 19005-1 6.3.3.2
/// nonetheless requires the entry, and the corpus confirms the reading from
/// the other side: the fixture that omits it is annotated `pass` **only
/// because the font is drawn at text rendering mode 3**, and its own title
/// says so in those words. A font this scan sees drawn visibly has been drawn,
/// and the entry is required of it.
fn cid_to_gid(doc: &CosDocument, descendant: &Dict, at: ObjRef, out: &mut Vec<Raw>) {
    let value = doc.resolve_key(descendant, doc.intern(b"CIDToGIDMap"));
    let ok = match value.as_ref() {
        Object::Name(name) => doc
            .name_bytes(*name)
            .is_some_and(|n| n.as_ref() == b"Identity"),
        Object::Stream(_) => true,
        _ => false,
    };
    if ok {
        return;
    }
    let declared = match value.as_ref() {
        Object::Name(name) => doc
            .name_bytes(*name)
            .map(|n| String::from_utf8_lossy(&n).into_owned())
            .unwrap_or_default(),
        Object::Null => String::new(),
        other => format!("{other:?}"),
    };
    out.push(Raw {
        rule: clauses::CID_FONTS,
        object: Some(at),
        kind: FindingKind::CidToGidMapMalformed { declared },
    });
}

// ---- 6.3.6 / 6.2.11.5 / 6.2.10.5 Font metrics -----------------------------

/// How many distinct codes one font contributes to the width rule.
const MAX_CODES_PER_FONT: usize = 1 << 12;

/// How many fonts the width rule reads programs for.
const MAX_WIDTH_FONTS: usize = 1 << 10;

/// The tolerance veraPDF's published test gives the comparison, in 1/1000
/// em: `Math.abs(widthFromFontProgram - widthFromDictionary) <= 1`.
const WIDTH_TOLERANCE: f64 = 1.0;

/// One font the pages drew with at a visible rendering mode, and the codes.
struct Drawn {
    /// The page or form scope it was drawn in, which is what decides which
    /// glyph of the program a code selects.
    scope: crate::resources::PageResources,
    /// The resource name it was drawn under, in that scope.
    name: Vec<u8>,
    codes: BTreeSet<u32>,
}

/// ISO 19005-1 6.3.6, ISO 19005-2/3 6.2.11.5, ISO 19005-4 6.2.10.5: "For
/// every font embedded in a conforming file and used for rendering, the glyph
/// width information in the font dictionary and in the embedded font program
/// shall be consistent" — veraPDF's statement of rules 6.3.6-1, 6.2.11.5-1 and
/// 6.2.10.5-1, judged per glyph with a tolerance of one thousandth of an em.
///
/// **The mapping is the engine's, not a second one.** `PDFA_STAGED` held this
/// rule back because the code-to-glyph mapping is where a rule goes wrong — a
/// symbolic TrueType font reaches its glyph through a (3,0) subtable offset
/// into the private-use area, a composite one through `/CIDToGIDMap` — and a
/// rule that got either wrong "would report conforming files by the hundred".
/// So it asks [`crate::resources::PageResources::selection`], the one the
/// renderer and the subsetter both draw with, and judges a code only where
/// that answer is **stated** by the font: a glyph a reader reaches by 9.6.6.4's
/// closing guess is one another reader may not reach, and a width compared
/// against it is a width compared against a guess. `.notdef` is not judged
/// either; drawing it is a defect of its own.
///
/// The dictionary's width is judged only where the dictionary states one —
/// `/Widths` or `/W` — not a `/MissingWidth` or `/DW` default, which veraPDF's
/// `widthFromDictionary == null` exempts. A Type 1 program, whose charstrings
/// are addressed by name rather than by a glyph index, is not judged; nor is
/// a Type 3 font, which has no program.
fn widths(doc: &Arc<CosDocument>, out: &mut Vec<Raw>) {
    let mut drawn: BTreeMap<ObjRef, Drawn> = BTreeMap::new();
    content::walk(doc, &mut |op| {
        if !matches!(op.operator, b"Tj" | b"TJ" | b"'" | b"\"")
            || op.mode == content::RENDER_MODE_INVISIBLE
        {
            return;
        }
        let (Some(name), Some(resources)) = (op.font, op.resources) else {
            return;
        };
        let Some(reference) = content::lookup(doc, resources, b"Font", name) else {
            return;
        };
        if !drawn.contains_key(&reference) {
            if drawn.len() >= MAX_WIDTH_FONTS {
                return;
            }
            drawn.insert(
                reference,
                Drawn {
                    scope: crate::resources::PageResources::from_dict(doc, resources.clone(), None),
                    name: name.to_vec(),
                    codes: BTreeSet::new(),
                },
            );
        }
        let Some(entry) = drawn.get_mut(&reference) else {
            return;
        };
        for token in op.operands {
            if let tinker_pdf_content::Token::String(bytes) = token {
                for (code, _, _) in
                    tinker_pdf_content::FontSource::decode(&entry.scope, &entry.name, bytes)
                {
                    if entry.codes.len() < MAX_CODES_PER_FONT {
                        entry.codes.insert(code);
                    }
                }
            }
        }
    });

    for (reference, entry) in &drawn {
        let Some(font) = tinker_pdf_cos::font::at(doc, *reference) else {
            continue;
        };
        let Some(program) = font.program() else {
            continue;
        };
        let Ok(bytes) = doc.stream_decoded(program.stream) else {
            continue;
        };
        let Some(metrics) = ProgramMetrics::read(&bytes) else {
            continue;
        };
        let id = tinker_pdf_content::FontSource::font_id(&entry.scope, &entry.name);
        for code in &entry.codes {
            let (dictionary, stated) = font.width_of(*code);
            if !stated {
                continue;
            }
            let Some(selection) = entry.scope.selection(id, *code) else {
                continue;
            };
            if !selection.stated || selection.glyph == 0 {
                continue;
            }
            let Some(program) = metrics.advance(selection.glyph) else {
                continue;
            };
            if (program - dictionary).abs() > WIDTH_TOLERANCE {
                out.push(Raw {
                    rule: clauses::FONT_METRICS,
                    object: Some(*reference),
                    kind: FindingKind::GlyphWidthInconsistent {
                        code: *code,
                        dictionary: dictionary.round() as i64,
                        program: program.round() as i64,
                    },
                });
                // One per font: the first disagreement says the dictionary
                // and the program describe different faces, and a finding
                // per glyph would be the same statement many times.
                break;
            }
        }
    }
}

/// A font program's advances in 1/1000 em, whichever outline format it is.
enum ProgramMetrics<'a> {
    /// `glyf` outlines: `hmtx` in font units over `head`'s units per em, for
    /// the `maxp` glyph count's glyphs — `hmtx` repeats its last advance for
    /// every index past `numberOfHMetrics`, and an index past the count is a
    /// glyph the program does not have, whose "advance" is no statement.
    TrueType(tinker_pdf_font::Sfnt<'a>, f64, u16),
    /// CFF outlines, bare or inside an OpenType wrapper: charstring widths
    /// through the font matrix. Boxed: a parsed CFF carries its indexes and
    /// dictionaries, and one value of this type lives per font for a moment.
    Cff(Box<tinker_pdf_font::Cff<'a>>),
}

impl<'a> ProgramMetrics<'a> {
    fn read(bytes: &'a [u8]) -> Option<ProgramMetrics<'a>> {
        const GLYF: u32 = 0x676C_7966;
        const HEAD: u32 = 0x6865_6164;
        const CFF: u32 = 0x4346_4620;
        const MAXP: u32 = 0x6D61_7870;
        if let Some(sfnt) = tinker_pdf_font::Sfnt::parse(bytes) {
            if sfnt.table(GLYF).is_some() {
                let head = sfnt.table(HEAD)?;
                let units = u16::from_be_bytes([*head.get(18)?, *head.get(19)?]);
                if units == 0 {
                    return None;
                }
                let maxp = sfnt.table(MAXP)?;
                let glyphs = u16::from_be_bytes([*maxp.get(4)?, *maxp.get(5)?]);
                return Some(ProgramMetrics::TrueType(sfnt, f64::from(units), glyphs));
            }
            return tinker_pdf_font::Cff::parse(sfnt.table(CFF)?)
                .map(|cff| ProgramMetrics::Cff(Box::new(cff)));
        }
        tinker_pdf_font::Cff::parse(bytes).map(|cff| ProgramMetrics::Cff(Box::new(cff)))
    }

    fn advance(&self, glyph: u16) -> Option<f64> {
        match self {
            ProgramMetrics::TrueType(sfnt, units, glyphs) => {
                if glyph >= *glyphs {
                    return None;
                }
                Some(f64::from(sfnt.advance(glyph)?) * 1000.0 / units)
            }
            ProgramMetrics::Cff(cff) => {
                let scale = cff.font_matrix_for(glyph).first().copied()?;
                Some(cff.advance(glyph)? * scale * 1000.0)
            }
        }
    }
}

// ---- the encoding CMap of a composite font ---------------------------------

/// ISO 32000-1 9.7.5.2 Table 118: the predefined CMaps, by name.
///
/// **The names, not the data.** `PDFA_STAGED`'s 6.3.3.3 row stages the CMap
/// rules because the predefined *tables* are built in only behind the
/// `cmap-predefined` feature, and a verdict that changed with a cargo feature
/// would not be a verdict. Whether a name is on this list does not need the
/// tables: it is sixty-one strings, transcribed from veraPDF's published
/// rules 7.21.3.3-1 and -3 (`veraPDF-validation-profiles` wiki at `109b482`,
/// PDF/UA part 1), whose test conditions enumerate Table 118 name by name, and
/// the same list stands in ISO 32000-2's Table 116 (rules 8.4.5.4-1 and -3).
pub(crate) const PREDEFINED_CMAPS: &[&[u8]] = &[
    b"Identity-H",
    b"Identity-V",
    b"GB-EUC-H",
    b"GB-EUC-V",
    b"GBpc-EUC-H",
    b"GBpc-EUC-V",
    b"GBK-EUC-H",
    b"GBK-EUC-V",
    b"GBKp-EUC-H",
    b"GBKp-EUC-V",
    b"GBK2K-H",
    b"GBK2K-V",
    b"UniGB-UCS2-H",
    b"UniGB-UCS2-V",
    b"UniGB-UTF16-H",
    b"UniGB-UTF16-V",
    b"B5pc-H",
    b"B5pc-V",
    b"HKscs-B5-H",
    b"HKscs-B5-V",
    b"ETen-B5-H",
    b"ETen-B5-V",
    b"ETenms-B5-H",
    b"ETenms-B5-V",
    b"CNS-EUC-H",
    b"CNS-EUC-V",
    b"UniCNS-UCS2-H",
    b"UniCNS-UCS2-V",
    b"UniCNS-UTF16-H",
    b"UniCNS-UTF16-V",
    b"83pv-RKSJ-H",
    b"90ms-RKSJ-H",
    b"90ms-RKSJ-V",
    b"90msp-RKSJ-H",
    b"90msp-RKSJ-V",
    b"90pv-RKSJ-H",
    b"Add-RKSJ-H",
    b"Add-RKSJ-V",
    b"EUC-H",
    b"EUC-V",
    b"Ext-RKSJ-H",
    b"Ext-RKSJ-V",
    b"H",
    b"V",
    b"UniJIS-UCS2-H",
    b"UniJIS-UCS2-V",
    b"UniJIS-UCS2-HW-H",
    b"UniJIS-UCS2-HW-V",
    b"UniJIS-UTF16-H",
    b"UniJIS-UTF16-V",
    b"KSC-EUC-H",
    b"KSC-EUC-V",
    b"KSCms-UHC-H",
    b"KSCms-UHC-V",
    b"KSCms-UHC-HW-H",
    b"KSCms-UHC-HW-V",
    b"KSCpc-EUC-H",
    b"UniKS-UCS2-H",
    b"UniKS-UCS2-V",
    b"UniKS-UTF16-H",
    b"UniKS-UTF16-V",
];

/// How many tokens of an embedded CMap program are read for its `/WMode`
/// and its `usecmap`.
const MAX_CMAP_TOKENS: usize = 1 << 16;

/// The two CMaps ISO 19005-1 lets a file leave unembedded.
const IDENTITY_CMAPS: &[&[u8]] = &[b"Identity-H", b"Identity-V"];

/// Which reading of the encoding-CMap clauses a standard takes.
///
/// **ISO 19005-1 is the strict one, and in two directions.** Its 6.3.3.3
/// says "All CMaps used within a conforming file, except Identity-H and
/// Identity-V, shall be embedded" — every predefined CMap of Table 118
/// included — and its 6.3.3.1 makes the collections' `/Registry` and
/// `/Ordering` identical with no word on `/Supplement`, and it states no rule
/// about one CMap referencing another. ISO 19005-2 to -4 and both parts of
/// ISO 14289 admit Table 118, add the `/Supplement` ordering and forbid a
/// reference outside the table. Each sentence is veraPDF's published
/// statement of the rule (6.3.3.1-1, 6.3.3.3-1 and -2 for part 1; 6.2.11.3.1-1
/// and 6.2.11.3.3-1 to -3 for parts 2 and 3; 6.2.10.3.x for part 4; 7.21.3.x
/// and 8.4.5.x for PDF/UA).
#[derive(Clone, Copy, Debug)]
pub(crate) struct CMapReading {
    /// The CMaps a file may name without embedding.
    unembedded: &'static [&'static [u8]],
    /// Whether the CIDFont's `/Supplement` may not exceed the CMap's.
    supplement: bool,
    /// Whether a CMap's reference to another is judged.
    references: bool,
}

impl CMapReading {
    /// ISO 19005-1's reading.
    pub(crate) const PDF_A_1: CMapReading = CMapReading {
        unembedded: IDENTITY_CMAPS,
        supplement: false,
        references: false,
    };

    /// Every later standard's: Table 118, `/Supplement`, references.
    pub(crate) const TABLE_118: CMapReading = CMapReading {
        unembedded: PREDEFINED_CMAPS,
        supplement: true,
        references: true,
    };
}

/// What is wrong with a composite font's encoding CMap, as `(object, kind)`.
///
/// Four requirements ISO 14289-1 states at 7.21.3.1 and 7.21.3.3, and ISO
/// 14289-2 at 8.4.5.3.1 and 8.4.5.4, in the words of veraPDF's published rules
/// for them:
///
/// - a CMap not in Table 118 is embedded (7.21.3.3-1);
/// - an embedded CMap's dictionary `/WMode` is "identical to the WMode value
///   in the embedded CMap stream" (-2), both 0 when unwritten (Table 120);
/// - a CMap references no CMap outside Table 118 (-3), whether by the stream
///   dictionary's `/UseCMap` or by the program's own `usecmap`;
/// - an embedded CMap's character collection is the CIDFont's: `/Registry`
///   and `/Ordering` identical and the CIDFont's `/Supplement` not exceeding
///   the CMap's (7.21.3.1). Decided only where both dictionaries carry a
///   `/CIDSystemInfo`; a predefined CMap's collection is in the tables this
///   build does not carry by default, and the identity CMaps admit any.
///
/// Returned as kinds rather than pushed as findings, because the clause is
/// the caller's: the same four sentences are numbered differently by each
/// standard that asks them.
pub(crate) fn cmap_findings(
    doc: &CosDocument,
    font: &Dict,
    at: ObjRef,
    reading: CMapReading,
) -> Vec<(ObjRef, FindingKind)> {
    let mut out = Vec::new();
    let key = doc.intern(b"Encoding");
    let encoding = doc.resolve_key(font, key);
    match encoding.as_ref() {
        Object::Name(name) => {
            let name = doc
                .name_bytes(*name)
                .map(|n| n.to_vec())
                .unwrap_or_default();
            if !reading.unembedded.contains(&name.as_slice()) {
                out.push((
                    at,
                    FindingKind::CMapNotEmbedded {
                        name: String::from_utf8_lossy(&name).into_owned(),
                    },
                ));
            }
        }
        Object::Stream(stream) => {
            // 7.3.8: a stream is indirect, so the entry is a reference.
            let reference = font.get_ref(key).unwrap_or(at);
            let program = doc.stream_decoded(reference).unwrap_or_default();
            let (program_mode, used) = cmap_program(&program);
            let dictionary_mode = doc
                .resolve_key(&stream.dict, doc.intern(b"WMode"))
                .as_int()
                .unwrap_or(0);
            if dictionary_mode != program_mode {
                out.push((
                    reference,
                    FindingKind::CMapWritingModeMismatch {
                        dictionary: dictionary_mode,
                        program: program_mode,
                    },
                ));
            }
            let mut referenced: Vec<Vec<u8>> = used.into_iter().collect();
            match doc
                .resolve_key(&stream.dict, doc.intern(b"UseCMap"))
                .as_ref()
            {
                Object::Name(name) => {
                    referenced.extend(doc.name_bytes(*name).map(|n| n.to_vec()));
                }
                Object::Stream(parent) => {
                    referenced.push(name_of(doc, &parent.dict, b"CMapName").unwrap_or_default())
                }
                _ => {}
            }
            for name in referenced.into_iter().filter(|_| reading.references) {
                if !PREDEFINED_CMAPS.contains(&name.as_slice()) {
                    out.push((
                        reference,
                        FindingKind::CMapReferenceNotStandard {
                            name: String::from_utf8_lossy(&name).into_owned(),
                        },
                    ));
                }
            }
            let descendant = doc
                .resolve_key(font, doc.intern(b"DescendantFonts"))
                .as_array()
                .and_then(<[Object]>::first)
                .map(|first| doc.resolve(first));
            let descendant_info = descendant
                .as_deref()
                .and_then(Object::as_dict)
                .map(|d| doc.resolve_key(d, doc.intern(b"CIDSystemInfo")));
            let cmap_info = doc.resolve_key(&stream.dict, doc.intern(b"CIDSystemInfo"));
            if let (Some(font_info), Some(cmap_info)) = (
                descendant_info.as_deref().and_then(Object::as_dict),
                cmap_info.as_dict(),
            ) {
                for key in collection_disagreements(doc, font_info, cmap_info, reading.supplement) {
                    out.push((
                        at,
                        FindingKind::CidSystemInfoMismatch {
                            key: key.to_string(),
                        },
                    ));
                }
            }
        }
        _ => {}
    }
    out
}

/// What an embedded CMap's own program says: its `/WMode` (0 when it writes
/// none, Table 120's default) and every name it `usecmap`s.
fn cmap_program(program: &[u8]) -> (i64, BTreeSet<Vec<u8>>) {
    use tinker_pdf_content::{Token, Tokenizer};
    let mut mode = None;
    let mut used = BTreeSet::new();
    let mut previous: Vec<Token> = Vec::new();
    let mut tokenizer = Tokenizer::new(program);
    let mut seen = 0usize;
    while let Some(token) = tokenizer.next_token() {
        seen += 1;
        if seen > MAX_CMAP_TOKENS {
            break;
        }
        if let Token::Operator(operator) = &token {
            match (operator.as_slice(), previous.as_slice()) {
                // `/WMode 1 def`: the first definition is the CMap's own.
                (b"def", [.., Token::Name(key), Token::Number(value)])
                    if key.as_slice() == b"WMode" && mode.is_none() =>
                {
                    mode = Some(*value as i64);
                }
                (b"usecmap", [.., Token::Name(name)]) => {
                    used.insert(name.clone());
                }
                _ => {}
            }
            previous.clear();
            continue;
        }
        if previous.len() >= 2 {
            previous.remove(0);
        }
        previous.push(token);
    }
    (mode.unwrap_or(0), used)
}

/// Which of `/Registry`, `/Ordering` and `/Supplement` break 7.21.3.1's
/// relationship between a CIDFont's collection and its CMap's.
fn collection_disagreements(
    doc: &CosDocument,
    font: &Dict,
    cmap: &Dict,
    supplement: bool,
) -> Vec<&'static str> {
    let mut out = Vec::new();
    for key in ["Registry", "Ordering"] {
        let a = doc.resolve_key(font, doc.intern(key.as_bytes()));
        let b = doc.resolve_key(cmap, doc.intern(key.as_bytes()));
        let same = match (a.as_string(), b.as_string()) {
            (Some(a), Some(b)) => a.bytes == b.bytes,
            _ => false,
        };
        if !same {
            out.push(key);
        }
    }
    if !supplement {
        return out;
    }
    let font_supplement = doc.resolve_key(font, doc.intern(b"Supplement")).as_int();
    let cmap_supplement = doc.resolve_key(cmap, doc.intern(b"Supplement")).as_int();
    if !matches!((font_supplement, cmap_supplement), (Some(a), Some(b)) if a <= b) {
        out.push("Supplement");
    }
    out
}

// ---- shared ---------------------------------------------------------------

/// A dictionary entry that is a name, as bytes.
fn name_of(doc: &CosDocument, dict: &Dict, key: &[u8]) -> Option<Vec<u8>> {
    doc.resolve_key(dict, doc.intern(key))
        .as_name()
        .and_then(|name| doc.name_bytes(name))
        .map(|bytes| bytes.to_vec())
}
