//! Image parts: 9.1.5's four formats, all four of which reach the page.
//!
//! # XPS has no image element
//!
//! Milestone 1 measured every package Windows writes and found the same shape
//! in all of them: a raster arrives as a `<Path>` whose `Fill` is an
//! `<ImageBrush>`, usually behind a `{StaticResource}`. There is no `<Image>`
//! element in ECMA-388 at all. So this module is not "the image reader" — it is
//! the half of [`super::brush`] that needs the *package*, and it exists
//! separately for the reason [`super::font::Fonts`] does, quoted here because
//! the two are the same trade: [`Package::read_part`] hands back a borrow of
//! the package and the painter is already holding one for the markup it walks,
//! so an image resolved *while* drawing would need the page's bytes copied out
//! first, and a fixed page part is the one part of this format whose size the
//! file chooses. A pass over the markup before the walk costs time proportional
//! to the part and **no** memory.
//!
//! # Almost nothing here decodes a picture
//!
//! Gap 29 built the pass-through this consumes, and its whole argument carries
//! over unchanged: a JPEG's bytes are placed verbatim by `ImageData::Jpeg`, and
//! a non-interlaced PNG's IDAT is zlib-compressed predictor-filtered scanlines,
//! which is what `/FlateDecode` with `/Predictor 15` expects. So a page's peak
//! cost is a multiple of the *part* rather than *w × h × 3*, and a ten-page
//! report with a photograph on every page costs what the package costs.
//!
//! **JPEG XR is the exception, and it is not one this engine chose.** No
//! `/Filter` in ISO 32000-2 Table 6 reads an ITU-T T.832 codestream —
//! `/JPXDecode` is JPEG 2000, a different format with a different syntax — so
//! there is no route to choose and every JPEG XR image costs its pixels. That
//! is stated here rather than buried in [`jxr_image`] because it is the one
//! place a caller's peak memory depends on which of 9.1.5's formats a package
//! happened to use.
//!
//! `png_image` is the one door, and it decides for itself which of the two
//! routes a given PNG takes — Adam7 and interleaved alpha cannot pass through.
//! Gap 29 milestone 6 found that "an indexed file decoded instead of passed
//! through" moves a byte hash and three route assertions **while every rendered
//! comparison still passes**, so the tests here assert the *route*, not only the
//! picture.
//!
//! # 13.4.1's resolution, and why it is not decoration
//!
//! An `ImageBrush` states its `Viewbox` in the image's **own** units, and the
//! real package in the design section says
//! `Viewbox="0,0,4.00055837631226,4.00055837631226"` for a 384-pixel PNG. Four
//! units is 384 pixels only if the image is 96 dots to the inch, so the
//! resolution is what makes an `Absolute` viewbox mean anything. 13.4.1 makes 96
//! the default and lets the image state otherwise; a reader that assumed 96 for
//! a 300 dpi scan would draw it at three times its intended size.

use std::collections::{HashMap, HashSet};

use tinker_pdf_color::icc;
use tinker_pdf_cos::{
    jpeg_shape, jxr_image, png_image, tiff_image, CompressedImage, DocumentBuilder,
    ImageColorSpace, ImageData, ImageFilter, PngRoute,
};
use tinker_pdf_filters::Limits as FilterLimits;
use tinker_pdf_xml::{Doctype, Event, Source};

use super::markup::Trouble;
use super::opc::{Package, PartName};
use super::{dialect_of, Limits, XpsElementDefect};

/// 13.4.1's default, in dots per inch. One XPS unit is 1/96 inch, so an image
/// at 96 dpi is one pixel to the unit.
const DEFAULT_DPI: f64 = 96.0;

/// What 9.1.5 admits, and what it does not.
///
/// Recognised from the **content type** and from the **magic bytes**, and those
/// are two rules rather than one. 7.2.3.5's content type is what OPC says
/// decides a part's format, and a package may state one that is wrong or state
/// none at all; the magic bytes are what the part actually is. A TIFF that this
/// build cannot draw has to be refused whichever of the two says so, because
/// refusing on one and drawing on the other is how a `.tiff` renamed `.png`
/// reaches a JPEG decoder.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    /// ISO/IEC 15948, through gap 29's pass-through.
    Png,
    /// ISO/IEC 10918, placed verbatim.
    Jpeg,
    /// 9.1.5's TIFF. No decoder in this engine, refused by name.
    Tiff,
    /// 9.1.5.1's JPEG XR — the format the specification recommends and nothing
    /// outside Microsoft's stack implements. No decoder here either.
    JpegXr,
}

impl Kind {
    /// From the magic bytes alone.
    fn from_magic(bytes: &[u8]) -> Option<Kind> {
        if bytes.starts_with(&[0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A]) {
            return Some(Kind::Png);
        }
        if bytes.starts_with(&[0xFF, 0xD8, 0xFF]) {
            return Some(Kind::Jpeg);
        }
        // TIFF is either endianness, and the answer to "42" decides which.
        if bytes.starts_with(b"II\x2A\x00") || bytes.starts_with(b"MM\x00\x2A") {
            return Some(Kind::Tiff);
        }
        // JPEG XR: the same two byte orders, then 0xBC and a version.
        if bytes.starts_with(&[0x49, 0x49, 0xBC]) || bytes.starts_with(&[0x4D, 0x4D, 0xBC]) {
            return Some(Kind::JpegXr);
        }
        None
    }

    /// From a content type, matched case-insensitively per 7.2.3.5.
    fn from_media(media: &str) -> Option<Kind> {
        // The parameter after a semicolon is not part of the comparison.
        let media = media.split(';').next().unwrap_or(media).trim();
        for (name, kind) in [
            ("image/png", Kind::Png),
            ("image/jpeg", Kind::Jpeg),
            ("image/tiff", Kind::Tiff),
            ("image/vnd.ms-photo", Kind::JpegXr),
            ("image/jxr", Kind::JpegXr),
        ] {
            if media.eq_ignore_ascii_case(name) {
                return Some(kind);
            }
        }
        None
    }
}

/// One image part, placed on the document and measured.
pub struct Image {
    /// The `/XObject` resource name the cell of a tiling pattern shows.
    pub resource: Vec<u8>,
    /// Pixels across and down, from the image's own header — never from the
    /// markup, which states a viewbox and not a size.
    pub px: (f64, f64),
    /// Dots per inch, horizontally and vertically, defaulting to 13.4.1's 96.
    pub dpi: (f64, f64),
    /// What this part reached the document **approximately**, if anything.
    ///
    /// The success channel for ruling 10, and it exists because `place_one`
    /// returns `Result<Image, XpsElementDefect>`: a refusal has the `Err` side
    /// and a leniency had nowhere to go, so a disagreement between 7.2.3.5's
    /// content type and the magic bytes was resolved silently. It rides here
    /// instead and `paint.rs`'s `State::tile` pushes it into the page's
    /// defects, where `warn` deduplicates it — this is set once per *part* and
    /// read once per *use*, so a page tiling one picture forty times says it
    /// once.
    pub lenience: Option<XpsElementDefect>,
}

impl Image {
    /// The image's size in XPS units, which is what an `Absolute` `Viewbox` is
    /// stated in.
    ///
    /// One XPS unit is 1/96 inch, so this is the pixel count scaled by 96 over
    /// the image's own resolution: a 384-pixel image at 96 dpi is four units,
    /// and the same image at 192 dpi is two.
    #[must_use]
    pub fn units(&self) -> (f64, f64) {
        (
            self.px.0 * DEFAULT_DPI / self.dpi.0,
            self.px.1 * DEFAULT_DPI / self.dpi.1,
        )
    }
}

/// Every image part a synthesised document has placed, keyed by the part an
/// `ImageSource` resolved to.
///
/// One per document, for [`super::font::Fonts`]'s reason: `add_page` copies the
/// document's whole resource table into every page, so two pages naming one
/// `/XI0` for two different pictures would be one picture.
#[derive(Default)]
pub struct Images {
    placed: HashMap<PartName, Result<Image, XpsElementDefect>>,
    /// Which route each PNG took, for the tests. See [`Images::route`].
    routes: HashMap<PartName, PngRoute>,
    next: usize,
}

impl Images {
    /// Places every image the `ImageBrush`es of one fixed page part name.
    ///
    /// # Errors
    /// [`Trouble::Exhausted`] when one page names more distinct images than the
    /// package could hold parts, which refuses the package for
    /// [`super::font::Fonts::load`]'s reason: a page naming eight thousand
    /// pictures is not a page whose pictures eight thousand lookups would find.
    pub fn load(
        &mut self,
        package: &mut Package<'_>,
        page: &PartName,
        builder: &mut DocumentBuilder,
        limits: &Limits,
    ) -> Result<(), Trouble> {
        let wanted = match package.read_part(page) {
            Ok(bytes) => image_references(bytes, page, limits)?,
            Err(_) => return Ok(()),
        };
        if wanted.len() > limits.max_parts {
            return Err(Trouble::Exhausted);
        }
        for (name, profile) in wanted {
            if self.placed.contains_key(&name) {
                continue;
            }
            let placed = self.place_one(package, &name, profile.as_ref(), builder, limits);
            self.placed.insert(name, placed);
        }
        Ok(())
    }

    /// The image an `ImageSource` on `page` names.
    ///
    /// Pure: resolution is arithmetic over two strings and the lookup is the
    /// table [`Images::load`] filled, so the drawing walk never needs the
    /// package.
    ///
    /// # Errors
    /// One [`XpsElementDefect`] per way an `ImageSource` can fail to be a
    /// picture, each by its own name.
    pub fn get(&self, page: &PartName, uri: &str) -> Result<&Image, XpsElementDefect> {
        // 9.1.5's `ImageSource` may carry a `{ColorConvertedBitmap picture
        // profile}` wrapper. The picture is what this names; the profile went
        // into the document as an `/ICCBased` space when the part was placed,
        // and the samples are values in it. A wrapper this build does not know
        // is still refused, because its references cannot be told apart.
        let reference = match colour_converted_bitmap(uri) {
            Some((picture, _)) => picture,
            None if uri.trim_start().starts_with('{') => {
                return Err(XpsElementDefect::ImageProfileUnsupported)
            }
            None => source_reference(uri),
        };
        let name = page
            .resolve(reference)
            .ok_or(XpsElementDefect::ImageUnresolved)?;
        match self.placed.get(&name) {
            Some(Ok(image)) => Ok(image),
            Some(Err(defect)) => Err(*defect),
            None => Err(XpsElementDefect::ImageUnresolved),
        }
    }

    /// Reads the ICC profile a `{ColorConvertedBitmap}` names and registers it
    /// as an `/ICCBased` space, returning the resource name and channel count.
    ///
    /// The same three narrowings [`super::profiles`] makes for a
    /// `ContextColor`, for the same reasons and with the same names: a part
    /// that is not there, a header §7.2 cannot read, and a channel count
    /// Table 66 does not spell. The space is registered under `XCS…` rather
    /// than `CS…` so the two passes cannot collide on a name — they run over
    /// the same page and both allocate from zero.
    fn place_profile(
        &mut self,
        package: &mut Package<'_>,
        part: &PartName,
        builder: &mut DocumentBuilder,
    ) -> Result<(Vec<u8>, u8), XpsElementDefect> {
        if !package.has(part) {
            return Err(XpsElementDefect::ColourProfileUnresolved);
        }
        let bytes = package
            .read_part(part)
            .map_err(|_| XpsElementDefect::ColourProfileUnresolved)?;
        let channels = icc::data_space(bytes)
            .and_then(icc::channels)
            .ok_or(XpsElementDefect::ColourProfileUnresolved)?;
        if !matches!(channels, 1 | 3 | 4) {
            return Err(XpsElementDefect::ColourProfileChannels);
        }
        let profile = bytes.to_vec();
        let resource = format!("XCS{}", self.next).into_bytes();
        if !builder.add_icc_color_space(&resource, &profile, channels) {
            return Err(XpsElementDefect::ColourProfileUnresolved);
        }
        Ok((resource, channels))
    }

    fn place_one(
        &mut self,
        package: &mut Package<'_>,
        name: &PartName,
        profile: Option<&PartName>,
        builder: &mut DocumentBuilder,
        limits: &Limits,
    ) -> Result<Image, XpsElementDefect> {
        if !package.has(name) {
            return Err(XpsElementDefect::ImageUnresolved);
        }
        // The profile is read and registered **before** the picture's bytes,
        // because both borrow the package and the picture's borrow is held for
        // the rest of this function. What is kept is the resource name the
        // space went in under and its channel count; `in_icc_space` needs no
        // more than that, and nothing here evaluates the profile.
        let icc = match profile {
            Some(part) => Some(self.place_profile(package, part, builder)?),
            None => None,
        };
        // Read and copied before the bytes, because both borrow the package.
        let declared = match package.media_type(name) {
            Ok(Some(media)) => Kind::from_media(media),
            // A part with no content type is not one 7.2.3.5 resolved, and
            // nothing may be assumed about it from its name.
            _ => None,
        };
        let bytes = package
            .read_part(name)
            .map_err(|_| XpsElementDefect::ImageUnresolved)?;
        let actual = Kind::from_magic(bytes);

        // **The pre-emptive refusal loop is gone, and its absence is the
        // wiring.** It refused a format *before* either identification rule
        // had decided what the part was, so a `Kind` named there could never
        // reach a decoder however it was identified. TIFF left it when a TIFF
        // decoder arrived; JPEG XR was the last one in it, and it leaves for
        // the same reason. There is now no format 9.1.5 admits that this
        // function declines before looking.
        //
        // What remains is the ordinary agreement between the two rules, and
        // the one case where they disagree.
        let (kind, lenience) = match (declared, actual) {
            // They agree, or only one of them spoke — and silence from a rule
            // is not disagreement with it. A part 7.2.3.5 resolved to no
            // content type has one witness, and so has one whose first bytes
            // are no signature `from_magic` knows; a single witness is
            // believed, because the alternative is refusing every part that
            // one of the two rules happens not to cover.
            (Some(a), Some(b)) if a == b => (a, None),
            (Some(a), None) => (a, None),
            (None, Some(b)) => (b, None),
            // They disagree about two formats this build can draw. The bytes
            // win, because a decoder reads bytes — and the leniency is named,
            // which is ruling 10 and is what this arm owed for three
            // milestones.
            //
            // **The name rides the success side**, on `Image::lenience`, for
            // the reason the gap existed at all: this function returns
            // `Result<Image, XpsElementDefect>`, so its `Err` is a *refusal*
            // and a leniency reported there would lose the picture. The push
            // into the page's defects is `paint.rs`'s `State::tile`.
            //
            // **This arm is fully ordinary now.** It was nearly dead when TIFF
            // and JPEG XR were both refused before the two rules were
            // compared, so only PNG-versus-JPEG could arrive. Wiring TIFF made
            // it ordinary for three formats. Wiring JPEG XR — and deleting the
            // loop that used to refuse it — makes every one of 9.1.5's four
            // formats reachable on both sides, so twelve ordered pairs take it
            // where two did. Pinned by
            // `a_content_type_that_disagrees_with_the_bytes_is_drawn_from_the_bytes_and_named`
            // in `tests/xps_images.rs`.
            (Some(_), Some(b)) => (b, Some(XpsElementDefect::ImageMediaTypeMismatch)),
            (None, None) => return Err(XpsElementDefect::ImageFormatUnsupported),
        };

        let resource = format!("XI{}", self.next).into_bytes();
        let image = match kind {
            Kind::Jpeg => {
                let (w, h, _) = jpeg_shape(bytes).ok_or(XpsElementDefect::ImageUnreadable)?;
                let data = match &icc {
                    Some((space, channels)) => {
                        in_icc_space(ImageData::Jpeg(bytes), space, *channels, (w, h))
                            .ok_or(XpsElementDefect::ImageProfileUnsupported)?
                    }
                    None => ImageData::Jpeg(bytes),
                };
                if !builder.add_image(&resource, &data) {
                    return Err(XpsElementDefect::ImageUnreadable);
                }
                Image {
                    resource,
                    px: (f64::from(w), f64::from(h)),
                    dpi: jfif_dpi(bytes).unwrap_or((DEFAULT_DPI, DEFAULT_DPI)),
                    lenience,
                }
            }
            Kind::Png => {
                let png = png_image(bytes, &FilterLimits::new(limits.max_synthesised))
                    .map_err(|_| XpsElementDefect::ImageUnreadable)?;
                self.routes.insert(name.clone(), png.route());
                let data = png.image();
                let (w, h) = shape_of(&data).ok_or(XpsElementDefect::ImageUnreadable)?;
                let data = match &icc {
                    Some((space, channels)) => in_icc_space(data, space, *channels, (w, h))
                        .ok_or(XpsElementDefect::ImageProfileUnsupported)?,
                    None => data,
                };
                if !builder.add_image(&resource, &data) {
                    return Err(XpsElementDefect::ImageUnreadable);
                }
                Image {
                    resource,
                    px: (f64::from(w), f64::from(h)),
                    dpi: phys_dpi(bytes).unwrap_or((DEFAULT_DPI, DEFAULT_DPI)),
                    lenience,
                }
            }
            // 9.1.5's TIFF. Most of one reaches the page as its own bytes:
            // four of TIFF 6.0's codings already have a `/Filter` name, so a
            // single-strip file of any of them is placed rather than decoded
            // ([`tinker_pdf_cos::tiff_image`]).
            Kind::Tiff => {
                let tiff = tiff_image(bytes, &FilterLimits::new(limits.max_synthesised))
                    .map_err(|_| XpsElementDefect::ImageUnreadable)?;
                let data = tiff.image();
                let (w, h) = (tiff.width(), tiff.height());
                // A resolution the file states, in the units it states them
                // in; 13.4.1's 96 where it states none. The other two formats
                // read their own headers for this and TIFF's is read off the
                // directory, which is why all three defaults sit here rather
                // than in the decoders.
                let dpi = tiff.dpi().unwrap_or((DEFAULT_DPI, DEFAULT_DPI));
                let data = match &icc {
                    Some((space, channels)) => in_icc_space(data, space, *channels, (w, h))
                        .ok_or(XpsElementDefect::ImageProfileUnsupported)?,
                    None => data,
                };
                if !builder.add_image(&resource, &data) {
                    return Err(XpsElementDefect::ImageUnreadable);
                }
                Image {
                    resource,
                    px: (f64::from(w), f64::from(h)),
                    dpi,
                    lenience,
                }
            }
            // 9.1.5.1's JPEG XR, the format OPC recommends and nothing
            // outside Microsoft's stack implements. Always decoded: see the
            // module note on why there is no pass-through route for it.
            //
            // `jxr_image` does the three rearrangements PDF needs — the BGR
            // rows permuted into `/DeviceRGB` order, 16-bit samples swapped
            // from A.7.3's little-endian to 8.9.5.2's big-endian, and A.3.2's
            // alpha split out into an `/SMask` — so what arrives here is
            // already an image XObject's worth of samples.
            Kind::JpegXr => {
                let jxr = jxr_image(bytes, &FilterLimits::new(limits.max_synthesised))
                    .map_err(|_| XpsElementDefect::ImageUnreadable)?;
                let data = jxr.image();
                let (w, h) = (jxr.width(), jxr.height());
                // Annex A's `WIDTH_RESOLUTION` and `HEIGHT_RESOLUTION` where
                // the file states them, 13.4.1's 96 where it does not — the
                // same rule the other three formats follow, and the reason
                // all four defaults sit in this file rather than in four
                // decoders.
                let dpi = jxr.dpi().unwrap_or((DEFAULT_DPI, DEFAULT_DPI));
                let data = match &icc {
                    Some((space, channels)) => in_icc_space(data, space, *channels, (w, h))
                        .ok_or(XpsElementDefect::ImageProfileUnsupported)?,
                    None => data,
                };
                if !builder.add_image(&resource, &data) {
                    return Err(XpsElementDefect::ImageUnreadable);
                }
                Image {
                    resource,
                    px: (f64::from(w), f64::from(h)),
                    dpi,
                    lenience,
                }
            }
        };
        self.next += 1;
        Ok(image)
    }

    /// Whether an image part took the pass-through route or the decode.
    ///
    /// For the tests, and only for them: gap 29 milestone 6 found the route is
    /// invisible to every rendered comparison, so a test that cannot read it
    /// cannot assert it.
    #[must_use]
    pub fn route(&self, page: &PartName, uri: &str) -> Option<PngRoute> {
        let name = page.resolve(source_reference(uri))?;
        self.routes.get(&name).copied()
    }
}

/// The `/Width` and `/Height` an [`ImageData`] carries.
fn shape_of(data: &ImageData<'_>) -> Option<(u32, u32)> {
    match data {
        ImageData::Compressed(image) => Some((image.width, image.height)),
        ImageData::Rgb8 { width, height, .. } | ImageData::Gray8 { width, height, .. } => {
            Some((*width, *height))
        }
        ImageData::Jpeg(bytes) => jpeg_shape(bytes).map(|(w, h, _)| (w, h)),
        _ => None,
    }
}

/// PNG's `pHYs` (11.3.5.3), which states pixels per metre.
///
/// `None` when the chunk is absent or says the unit is unknown, which 13.4.1
/// turns into the 96 dpi default rather than into a refusal: an image with no
/// stated resolution is ordinary, and every PNG this repository writes is one.
fn phys_dpi(bytes: &[u8]) -> Option<(f64, f64)> {
    let mut at = 8usize;
    while at + 8 <= bytes.len() {
        let len = u32::from_be_bytes(bytes.get(at..at + 4)?.try_into().ok()?) as usize;
        let kind = bytes.get(at + 4..at + 8)?;
        if kind == b"pHYs" {
            let data = bytes.get(at + 8..at + 8 + len)?;
            if data.len() < 9 || data[8] != 1 {
                // Unit 0 is "unknown", which states an aspect ratio and not a
                // resolution, so it says nothing about how large the image is.
                return None;
            }
            let x = u32::from_be_bytes(data.get(0..4)?.try_into().ok()?);
            let y = u32::from_be_bytes(data.get(4..8)?.try_into().ok()?);
            if x == 0 || y == 0 {
                return None;
            }
            // Per metre to per inch.
            return Some((f64::from(x) * 0.0254, f64::from(y) * 0.0254));
        }
        if kind == b"IDAT" || kind == b"IEND" {
            // `pHYs` must precede the image data, so there is none.
            return None;
        }
        at = at.checked_add(12)?.checked_add(len)?;
    }
    None
}

/// JFIF's APP0 density (JFIF 1.02, clause 5), which states either dots per inch
/// or dots per centimetre.
///
/// `None` for a JPEG with no JFIF segment or one whose units field says the
/// numbers are an aspect ratio, for `phys_dpi`'s reason.
fn jfif_dpi(bytes: &[u8]) -> Option<(f64, f64)> {
    // The APP0 segment, when there is one, follows SOI immediately.
    if bytes.get(2..4)? != [0xFF, 0xE0] {
        return None;
    }
    let segment = bytes.get(4..)?;
    if segment.get(2..7)? != b"JFIF\0" {
        return None;
    }
    let units = *segment.get(9)?;
    let x = u16::from_be_bytes(segment.get(10..12)?.try_into().ok()?);
    let y = u16::from_be_bytes(segment.get(12..14)?.try_into().ok()?);
    if x == 0 || y == 0 {
        return None;
    }
    match units {
        1 => Some((f64::from(x), f64::from(y))),
        // Per centimetre.
        2 => Some((f64::from(x) * 2.54, f64::from(y) * 2.54)),
        // 0 is an aspect ratio and not a resolution.
        _ => None,
    }
}

/// An `ImageSource`'s part reference, with any fragment dropped.
fn source_reference(uri: &str) -> &str {
    uri.split('#').next().unwrap_or(uri)
}

/// Restates an image in a registered `/ICCBased` space (8.9.5.4).
///
/// Every route above hands `add_image` an [`ImageData`], and what a
/// `{ColorConvertedBitmap}` changes is one field of it: the samples are the
/// same bytes, and what moves is the statement about what they *mean*. So this
/// is a rewrite of the colour space and nothing else — no sample is touched,
/// no profile is evaluated, and the reader does the colour management exactly
/// as it does for a `ContextColor`.
///
/// The JPEG arm is the one that changes shape rather than a field: a
/// pass-through JPEG reaches the writer as [`ImageData::Jpeg`], which carries
/// no colour space because a JPEG states its own. 8.9.5.4 lets an image
/// dictionary say otherwise, so it becomes a [`CompressedImage`] whose
/// `/Filter` is `/DCTDecode` and whose `/ColorSpace` is the profile's — the
/// same bytes, with the space the package asked for.
fn in_icc_space<'a>(
    data: ImageData<'a>,
    resource: &'a [u8],
    channels: u8,
    shape: (u32, u32),
) -> Option<ImageData<'a>> {
    let space = ImageColorSpace::Icc {
        resource,
        components: channels,
    };
    Some(match data {
        ImageData::Compressed(image) => ImageData::Compressed(CompressedImage {
            color_space: space,
            ..image
        }),
        ImageData::Jpeg(bytes) => ImageData::Compressed(CompressedImage {
            width: shape.0,
            height: shape.1,
            bits_per_component: 8,
            color_space: space,
            filter: Some(ImageFilter::Dct),
            data: bytes,
            color_key_mask: None,
            soft_mask: None,
        }),
        ImageData::Rgb8 {
            width,
            height,
            data,
        }
        | ImageData::Gray8 {
            width,
            height,
            data,
        } => ImageData::Compressed(CompressedImage {
            width,
            height,
            bits_per_component: 8,
            color_space: space,
            filter: None,
            data,
            color_key_mask: None,
            soft_mask: None,
        }),
        // `ImageData` is `#[non_exhaustive]`, so a road added later arrives
        // here. **It refuses rather than passing the image through**, because
        // passing it through would draw the samples in whatever space the
        // variant states while the package said they are values in a profile —
        // which is the one outcome this whole path exists to prevent, and it
        // would be silent.
        _ => return None,
    })
}

/// 9.1.5's `{ColorConvertedBitmap <image> <profile>}` wrapper, split into the
/// two parts it names.
///
/// The syntax is a brace, the keyword, and **two** whitespace-separated
/// references: the picture, and the ICC profile its samples are values in.
/// Anything else in the braces is a wrapper this build does not know, and it
/// returns `None` rather than guessing which reference is which — a wrapper
/// with three references is not this one, and reading its first two would be
/// drawing a picture in a profile the file did not pair it with.
///
/// The keyword is matched case-sensitively, as 9.1.5 spells it. A fragment on
/// either reference is dropped the way [`source_reference`] drops one.
fn colour_converted_bitmap(uri: &str) -> Option<(&str, &str)> {
    let inner = uri.trim().strip_prefix('{')?.strip_suffix('}')?;
    let rest = inner.trim().strip_prefix("ColorConvertedBitmap")?;
    // A keyword that merely *starts* with the name is a different wrapper.
    if !rest.starts_with(char::is_whitespace) {
        return None;
    }
    let mut parts = rest.split_whitespace();
    let image = parts.next()?;
    let profile = parts.next()?;
    if parts.next().is_some() {
        return None;
    }
    Some((source_reference(image), source_reference(profile)))
}

/// Every part an `ImageBrush` of one fixed page part names, deduplicated and in
/// markup order.
///
/// The order is load-bearing for [`super::font::Fonts`]'s reason: it decides
/// which image gets `/XI0`, and a resource name that depended on a hash's
/// iteration order would make the synthesised document differ between two runs
/// over one package — which the determinism fingerprint hashes.
type ImageReference = (PartName, Option<PartName>);

fn image_references(
    bytes: &[u8],
    page: &PartName,
    limits: &Limits,
) -> Result<Vec<ImageReference>, Trouble> {
    let Ok(source) = Source::new(bytes) else {
        return Ok(Vec::new());
    };
    let mut out: Vec<ImageReference> = Vec::new();
    let mut seen: HashSet<PartName> = HashSet::new();
    for event in source.reader_with(&limits.xml, Doctype::Refuse) {
        let element = match event {
            Ok(Event::Start(element)) => element,
            Ok(_) => continue,
            // Markup that will not read is the painter's to report, and it
            // will: this pass answers with what it found and the drawing walk
            // meets the same failure a moment later.
            Err(_) => break,
        };
        if element.local() != "ImageBrush" || dialect_of(element.namespace()).is_none() {
            continue;
        }
        let Some(uri) = element.attribute(None, "ImageSource") else {
            continue;
        };
        // 9.1.5's `{ColorConvertedBitmap picture profile}` names two parts in
        // one attribute, and both are read here for `Images::load`'s reason:
        // `read_part` borrows the package and the drawing walk is already
        // holding a borrow, so every part a page needs is read in this pass.
        let (reference, profile) = match colour_converted_bitmap(uri) {
            Some((picture, profile)) => (picture, page.resolve(profile)),
            // A wrapper that is not one this build knows names no part it can
            // resolve, and guessing which of its references is the picture is
            // how a page ends up drawn in a profile the file did not pair it
            // with.
            None if uri.trim_start().starts_with('{') => continue,
            None => (source_reference(uri), None),
        };
        let Some(name) = page.resolve(reference) else {
            continue;
        };
        if seen.insert(name.clone()) {
            out.push((name, profile));
            if out.len() > limits.max_parts {
                return Err(Trouble::Exhausted);
            }
        }
    }
    Ok(out)
}
