//! ECMA-388 15's colours and brushes (gap 30, milestone 6).
//!
//! # Two spellings of every colour, from one corpus
//!
//! Milestone 1 measured `Fill="#FF000000"` and `Color="#FFDC143C"` from WPF
//! against `Fill="#000000"` and `Color="#dc143c"` from the XPS object model —
//! six digits, lower case — for the **same page**. So a reader that takes one
//! length or one case refuses half of what Microsoft writes. 15.2.4 adds two
//! more forms nobody in the corpus uses and a real producer may:
//! `#RGB`/`#ARGB`, and `sc#` with floating-point scRGB components.
//!
//! # The asymmetry this module lives on
//!
//! Gap 30's design section splits an element's failure in two, and the halves
//! are not symmetric:
//!
//! - **geometry unreadable** — the element is *not painted*, because a missing
//!   shape is visible as a missing shape;
//! - **paint unreadable** — the element *is* painted, in the neutral
//!   placeholder grey, because the shape and its position are known and only
//!   the colour is not.
//!
//! That is gap 07's lesson:
//! that gap's headline defect was a gradient-stroked rule painting **solid
//! black, silently**, and black is a plausible colour where the placeholder
//! grey is not. Everything in this module that cannot be painted returns
//! [`BrushError`] and the caller paints grey and warns *by name*, and the
//! names are distinct — an unresolved `{StaticResource}`, an `ImageBrush` this
//! milestone does not draw and a colour string that is not one are three
//! different things about a document and collapsing them would make the report
//! useless for the one question it exists to answer.

use tinker_pdf_cos::{DeviceSpace, Function, Shading};

use super::markup::{self, Node};

/// How many periods of a repeating gradient are actually drawn.
///
/// PDF 8.7.4.5.3 has `/Extend` and no repeat, so `Reflect` and `Repeat` are
/// built by replicating the function along an extended axis. Eight periods
/// each way is 17 copies of a linear gradient and 9 of a radial, which is
/// past the edge of any page a gradient of that period could be stated on —
/// and past that the `/Extend` pads, which is what `Pad` does anyway.
const SPREAD_COPIES: usize = 8;

/// An sRGB colour with an alpha, which is every colour 15.2.4 can spell.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Colour {
    /// Red, green and blue, each from zero to one.
    ///
    /// For a `ContextColor` this is 8.6.5.5's default-`/Alternate` reading of
    /// the components — see [`ContextColour`]. Every other form states it
    /// directly.
    pub rgb: [f64; 3],
    /// Alpha, from zero to one. 15.2.4's `#RRGGBB` form has none and means
    /// one.
    pub alpha: f64,
}

/// 15.2.5's `ContextColor <uri> a,c1,…,cn`, parsed and not resolved.
///
/// # Why this is a [`Paint`] and not a field on [`Colour`]
///
/// A `ContextColor` becomes a PDF `/ICCBased` colour space, and a colour space
/// is a property of the **operator that sets a colour**, not of a number. A
/// gradient *stop* cannot have one at all: 8.7.4.5's shading states one space
/// for the whole function and a stop is not free to pick its own. So a stop
/// is converted to sRGB through its profile — 18.3.1.2's own rule — while a
/// `SolidColorBrush` carries the components verbatim through here and loses
/// nothing.
///
/// The part is carried unresolved for [`Paint::Image`]'s reason: reading it
/// needs the package, and this module is pure.
#[derive(Clone, Debug, PartialEq)]
pub struct ContextColour {
    /// The profile part, verbatim. Resolved against the fixed page's own name.
    pub profile: String,
    /// The components, in the profile's own space, in the order stated.
    ///
    /// One to [`super::MAX_XPS_COLOUR_CHANNELS`] of them. The alpha is **not**
    /// among them: 15.2.5 puts it first in the list and it is a coverage, not
    /// a colour component, so it is lifted into [`Colour::alpha`] where every
    /// other form keeps it.
    pub components: Vec<f64>,
    /// 8.6.5.5's default-`/Alternate` reading of those components, for the
    /// callers that cannot name a colour space and for a profile part that is
    /// not there.
    pub fallback: [f64; 3],
}

/// Why a brush did not become paint.
///
/// Two variants and not one, because the caller reports them under different
/// names and a reader of the report has to be able to tell "this file says
/// something I cannot read" from "this file says something this build does not
/// draw yet".
/// One variant, and it used to be two.
///
/// The second was `Unsupported` — "it is a brush and this build does not paint
/// it" — and nothing produces it any more. An `ImageBrush` became a tiling
/// pattern, a gradient learned to stroke and to set text through a shading
/// pattern, a `VisualBrush` became a pattern whose cell is a drawing, and a
/// `ContextColor` became an `/ICCBased` colour space. What is left is the
/// file being wrong rather than this build being short, so the distinction
/// the two names carried no longer exists and keeping it would be a refusal
/// with nothing behind it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BrushError {
    /// The markup is not 15's brush syntax.
    Syntax,
}

/// What an element paints with.
#[derive(Clone, Debug, PartialEq)]
pub enum Paint {
    /// A colour, as `r g b`.
    Solid([f64; 3]),
    /// 15.2.5's `ContextColor`: components in a profile's own space, which
    /// becomes a PDF `/ICCBased` colour space carrying that same profile.
    ///
    /// A translation and not a conversion — see [`ContextColour`].
    Context(Box<ContextColour>),
    /// A gradient, and the matrix mapping its own space into the element's.
    Gradient {
        /// The shading, ready for [`tinker_pdf_cos::DocumentBuilder::add_shading`].
        shading: Shading,
        /// Shading space into the space the element draws in.
        matrix: [f64; 6],
        /// The stops' **alphas**, where they differ, as a second shading over
        /// the same geometry and the same `matrix`: one output, the alpha, in
        /// `/DeviceGray`.
        ///
        /// 8.7.4.5's shading carries colour and no alpha, so a gradient whose
        /// stops are not all equally opaque is two shadings — the colours, and
        /// the alphas painted as a grey for 11.6.5.2's `/Luminosity` soft mask
        /// to read back over the colours. 18.3.2 interpolates colour and alpha
        /// separately, each between its enclosing stops, which is exactly what
        /// a mask over a ramp composes to. `None` where every stop carries one
        /// alpha, which [`Brush::alpha`] states instead.
        alphas: Option<Box<Shading>>,
    },
    /// An `ImageBrush` (15.3), which becomes a PDF tiling pattern.
    ///
    /// The `ImageSource` is carried **unresolved**, because resolving it needs
    /// the package and this module is pure -- [`super::image::Images`] holds the
    /// table and [`super::paint`] does the lookup. That split is not tidiness:
    /// `Package::read_part` hands back a borrow the painter is already holding,
    /// which is why images are resolved in a pass before the drawing walk.
    Image(Box<ImageTile>),
    /// A `VisualBrush` (15.4), which becomes a PDF tiling pattern whose cell is
    /// a **drawing** rather than a picture.
    ///
    /// The subtree is carried unresolved for [`Paint::Image`]'s reason, one step
    /// further along: a picture needs the package looked up once, and a visual
    /// needs the *drawing walk* re-entered from inside a brush -- with the
    /// fonts, the pictures, the resource dictionaries in scope and the element
    /// budget all of which live in [`super::paint`]. Answering with the subtree
    /// unresolved is what keeps this module pure, and it is the shape
    /// [`Paint::Image`] already set.
    Visual(Box<VisualTile>),
}

/// Where a tile goes, which 15.3 states in six values.
///
/// One value rather than six fields on each of the two brushes that state
/// them: an `ImageBrush` and a `VisualBrush` differ in **what** they tile and
/// in nothing about where, and two copies would be two places for the relative
/// units to stop being read.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Placement {
    /// `Viewbox`, as `x y width height` in the source's own units.
    pub viewbox: [f64; 4],
    /// `Viewport`, as `x y width height` in the element's units.
    pub viewport: [f64; 4],
    /// Whether `Viewbox` is absolute or a fraction of the source.
    pub viewbox_units: Units,
    /// Whether `Viewport` is absolute or a fraction of the filled box.
    pub viewport_units: Units,
    /// `TileMode` (15.3.1).
    pub tile: TileMode,
    /// `Transform`, which maps the brush's space into the element's.
    pub transform: [f64; 6],
}

/// A `VisualBrush`, parsed but not painted (15.4).
#[derive(Clone, Debug, PartialEq)]
pub struct VisualTile {
    /// The one drawable under `VisualBrush.Visual`.
    pub visual: Node,
    /// The `x:Key` this brush was reached through, when it was reached through
    /// one at all.
    ///
    /// Carried for the cycle guard and for nothing else: a `VisualBrush` whose
    /// own subtree names it again through a `{StaticResource}` is a cycle that
    /// no single lookup chain can see, because each lookup starts afresh.
    pub key: Option<String>,
    /// Where the tile goes.
    pub placement: Placement,
}

/// An `ImageBrush`, parsed but not resolved (15.3).
///
/// Both rectangles are kept, and they are **two different spaces**. `viewbox`
/// is stated in the image's own units, so a 384-pixel PNG at 96 dpi is four
/// units across; `viewport` is stated in the element's. The mapping between
/// them is what becomes the pattern's `/Matrix`, and a build that swapped them
/// would draw the picture at the reciprocal of its intended size -- which is why
/// they are separate fields with separate tests rather than one `[f64; 8]`.
#[derive(Clone, Debug, PartialEq)]
pub struct ImageTile {
    /// `ImageSource`, verbatim. Resolved against the fixed page part's own name.
    pub source: String,
    /// Where the tile goes.
    pub placement: Placement,
}

/// 15.3's `ViewboxUnits` and `ViewportUnits`.
///
/// Two independent attributes with one grammar. Milestone 1 measured
/// `Absolute` on both in all eight real packages, so the relative form is
/// exercised only by fixtures this repository wrote -- recorded rather than
/// left for a reader to assume otherwise.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Units {
    /// The rectangle is stated in the space it names -- image units for a
    /// viewbox, element units for a viewport.
    Absolute,
    /// The rectangle is a fraction of that space's own extent.
    RelativeToBoundingBox,
}

/// 15.3.1's `TileMode`, in all five spellings.
///
/// Five values and **five rules**: `None` draws the image once and leaves the
/// rest of the shape unpainted, `Tile` repeats it, and the three flips reflect
/// alternate cells. PDF's tiling patterns have no flip at all (8.7.3.1 gives a
/// cell, two steps and a matrix), so a flip has to be built by making the
/// *cell* four times the image and drawing the image into it four ways.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TileMode {
    /// Draw the image once and leave the rest of the shape unpainted.
    None,
    /// Repeat it in both directions.
    Tile,
    /// Repeat it, mirroring alternate columns.
    FlipX,
    /// Repeat it, mirroring alternate rows.
    FlipY,
    /// Repeat it, mirroring alternate columns and rows.
    FlipXY,
}

/// A brush, resolved.
#[derive(Clone, Debug, PartialEq)]
pub struct Brush {
    /// What it paints.
    pub paint: Paint,
    /// The constant alpha to apply, from the colour's own alpha and the
    /// brush's `Opacity` multiplied together.
    pub alpha: f64,
    /// Whether something about the brush reached the page **approximately**:
    /// a `ContextColor` stop, or a `ColorInterpolationMode` this build does not
    /// interpolate in. Reported by name rather than left silent. Stops whose
    /// alphas differ are **not** among them since they became a soft mask —
    /// see [`Paint::Gradient::alphas`].
    pub approximated: bool,
}

impl Brush {
    /// An opaque solid colour.
    fn solid(colour: Colour) -> Brush {
        Brush {
            paint: Paint::Solid(colour.rgb),
            alpha: colour.alpha,
            approximated: false,
        }
    }
}

// ---- 15.2.4, colours --------------------------------------------------------

/// Reads a colour.
///
/// # Errors
/// [`BrushError::Syntax`] for anything that is not 15.2.4's grammar,
/// A `ContextColor` answers 8.6.5.5's default-`/Alternate` reading of its
/// components; the colour space it also names is [`from_attribute`]'s to
/// carry, because a number cannot hold one.
pub fn colour(text: &str) -> Result<Colour, BrushError> {
    let text = text.trim();
    // 15.2.5's `ContextColor` is a colour like any other **here**: what it
    // adds is a colour space, and a colour space belongs to the operator that
    // sets a colour rather than to the number. `colour` answers the number —
    // 8.6.5.5's default-`/Alternate` reading of it — and the callers that can
    // name a space call `context_colour` for the rest.
    if let Some(rest) = text.strip_prefix("ContextColor") {
        return context_colour(rest).map(|(colour, _)| colour);
    }
    if let Some(values) = text.strip_prefix("sc#") {
        return sc_rgb(values);
    }
    let Some(digits) = text.strip_prefix('#') else {
        return Err(BrushError::Syntax);
    };
    if !digits.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err(BrushError::Syntax);
    }
    let nibble = |at: usize| -> f64 {
        f64::from(
            digits
                .as_bytes()
                .get(at)
                .and_then(|b| char::from(*b).to_digit(16))
                .unwrap_or(0),
        )
    };
    let short = |at: usize| nibble(at) * 17.0 / 255.0;
    let long = |at: usize| (nibble(at) * 16.0 + nibble(at + 1)) / 255.0;
    match digits.len() {
        3 => Ok(Colour {
            rgb: [short(0), short(1), short(2)],
            alpha: 1.0,
        }),
        4 => Ok(Colour {
            rgb: [short(1), short(2), short(3)],
            alpha: short(0),
        }),
        6 => Ok(Colour {
            rgb: [long(0), long(2), long(4)],
            alpha: 1.0,
        }),
        8 => Ok(Colour {
            rgb: [long(2), long(4), long(6)],
            alpha: long(0),
        }),
        _ => Err(BrushError::Syntax),
    }
}

/// 15.2.5's `ContextColor <uri> a,c1,…,cn`.
///
/// # There is no sRGB fallback in the syntax, and one is not invented
///
/// 15.2.5 states a profile part, an alpha and the components — and **nothing
/// else**. A consumer without the profile has the numbers and no statement
/// about what they mean, so this build does not guess at a colour: it hands
/// the components to the PDF unchanged inside an `/ICCBased` space carrying
/// the same profile, and the reader does the colour management. That is a
/// translation rather than a conversion, and it is exact.
///
/// The `rgb` filled in here is **not** that answer. It is the reading PDF
/// itself gives an `/ICCBased` space whose stream a reader cannot use: 8.6.5.5
/// says such a space falls back to `/Alternate`, and that `/Alternate`
/// defaults by component count to `DeviceGray`, `DeviceRGB` or `DeviceCMYK`.
/// So the fallback is not invented here either — it is the one PDF already
/// specifies for exactly this situation, and it is only ever reached where the
/// part is missing, or where a gradient stop — which cannot name a colour
/// space at all — has a profile this build cannot evaluate.
pub fn context_colour(rest: &str) -> Result<(Colour, ContextColour), BrushError> {
    // A profile URI has to be separated from the keyword by whitespace;
    // `ContextColorx` is not a `ContextColor` and `#ContextColor` is not a
    // colour at all.
    if !rest.starts_with([' ', '\t', '\r', '\n']) {
        return Err(BrushError::Syntax);
    }
    let rest = rest.trim_start();
    let (profile, values) = rest
        .split_once(char::is_whitespace)
        .ok_or(BrushError::Syntax)?;
    if profile.is_empty() {
        return Err(BrushError::Syntax);
    }
    let numbers = markup::numbers(values).ok_or(BrushError::Syntax)?;
    // 15.2.5 puts the alpha first and always states it, so a list of one is an
    // alpha and no colour.
    let (alpha, components) = numbers.split_first().ok_or(BrushError::Syntax)?;
    if components.is_empty() || components.len() > super::MAX_XPS_COLOUR_CHANNELS {
        return Err(BrushError::Syntax);
    }
    if !components.iter().all(|value| value.is_finite()) {
        return Err(BrushError::Syntax);
    }
    let fallback = device_reading(components);
    Ok((
        Colour {
            rgb: fallback,
            alpha: alpha.clamp(0.0, 1.0),
        },
        ContextColour {
            profile: profile.to_string(),
            components: components.to_vec(),
            fallback,
        },
    ))
}

/// 8.6.5.5's default `/Alternate` for an `/ICCBased` space of `n` components,
/// evaluated.
///
/// This is what a PDF reader does with a profile it cannot use, and it is
/// reached here for the two cases where neither an `/ICCBased` space nor the
/// profile's own answer is to be had: a gradient stop whose profile cannot be
/// evaluated, and a profile part that is not in the package. Nothing about it
/// is this build's invention — the *rule* is PDF's and the numbers are the
/// file's.
///
/// A component count that is none of one, three or four has no default
/// alternate at all, and PDF has no colour space for it that does not need a
/// tint transform this build would have to invent. It answers mid-grey and the
/// caller names the narrowing.
fn device_reading(components: &[f64]) -> [f64; 3] {
    let at = |index: usize| {
        components
            .get(index)
            .copied()
            .unwrap_or(0.0)
            .clamp(0.0, 1.0)
    };
    match components.len() {
        1 => [at(0); 3],
        3 => [at(0), at(1), at(2)],
        // 8.6.4.4's subtractive reading, which is the one `DeviceCMYK` states.
        4 => {
            let k = at(3);
            [
                1.0 - (at(0) + k).min(1.0),
                1.0 - (at(1) + k).min(1.0),
                1.0 - (at(2) + k).min(1.0),
            ]
        }
        _ => [crate::cbz::PLACEHOLDER_GREY; 3],
    }
}

/// 15.2.4's `sc#` form: three or four **scRGB** components as reals.
///
/// scRGB is linear-light and its components legitimately run outside `[0, 1]`,
/// so a reader that clamped first and converted second would move every
/// out-of-gamut colour to a different one than the transfer function does.
/// The alpha is *not* transferred — it is a coverage and not a light level.
fn sc_rgb(values: &str) -> Result<Colour, BrushError> {
    let numbers = markup::numbers(values).ok_or(BrushError::Syntax)?;
    let (alpha, components) = match numbers.as_slice() {
        [r, g, b] => (1.0, [*r, *g, *b]),
        [a, r, g, b] => (a.clamp(0.0, 1.0), [*r, *g, *b]),
        _ => return Err(BrushError::Syntax),
    };
    Ok(Colour {
        rgb: components.map(srgb_transfer),
        alpha,
    })
}

/// IEC 61966-2-1's transfer function inverted: sRGB to linear light.
fn srgb_decode(encoded: f64) -> f64 {
    let value = encoded.clamp(0.0, 1.0);
    if value <= 0.040_45 {
        value / 12.92
    } else {
        ((value + 0.055) / 1.055).powf(2.4)
    }
}

/// IEC 61966-2-1's transfer function, linear light to sRGB.
fn srgb_transfer(linear: f64) -> f64 {
    let value = linear.clamp(0.0, 1.0);
    if value <= 0.003_130_8 {
        value * 12.92
    } else {
        1.055 * value.powf(1.0 / 2.4) - 0.055
    }
}

// ---- 15.1, brushes ----------------------------------------------------------

/// Reads a brush from an attribute value — the `Fill="#FF000000"` form.
///
/// A `{StaticResource …}` never reaches here: the caller resolves it first,
/// because the answer is an *element* and not a string.
///
/// # Errors
/// As [`colour`].
pub fn from_attribute(text: &str) -> Result<Brush, BrushError> {
    tinted(text)
}

/// A colour as a brush, carrying its colour space where it has one.
///
/// The one place `ContextColor` differs from every other 15.2.4 colour, and it
/// is deliberately not inside [`colour`]: `colour` answers a *number*, which is
/// what a gradient stop and a mask need, and this answers a **paint**, which is
/// what an element that can name a colour space needs.
fn tinted(text: &str) -> Result<Brush, BrushError> {
    let text = text.trim();
    if let Some(rest) = text.strip_prefix("ContextColor") {
        let (colour, context) = context_colour(rest)?;
        return Ok(Brush {
            paint: Paint::Context(Box::new(context)),
            alpha: colour.alpha,
            approximated: false,
        });
    }
    colour(text).map(Brush::solid)
}

/// Reads a brush from an element — the `<SolidColorBrush …/>` form and the
/// two gradients.
///
/// `bbox` is the box a `MappingMode="RelativeToBoundingBox"` gradient is
/// stated in fractions of, which is the geometry the brush is about to fill.
/// `None` where there is no such box, which makes a relative gradient
/// unreadable rather than a gradient over a box this reader invented.
///
/// # Errors
/// [`BrushError::Syntax`] for markup that is not 15's, and
/// Every failure is [`BrushError::Syntax`]: there is no brush in section 15
/// this build declines to paint.
pub fn from_node(node: &Node, bbox: Option<[f64; 4]>) -> Result<Brush, BrushError> {
    from_node_resolving(node, bbox, &unresolved)
}

/// [`from_node`], with the profiles a `ContextColor` gradient stop is
/// converted through.
///
/// # Errors
/// As [`from_node`].
pub fn from_node_resolving(
    node: &Node,
    bbox: Option<[f64; 4]>,
    resolve: Resolve<'_>,
) -> Result<Brush, BrushError> {
    if !node.xps {
        return Err(BrushError::Syntax);
    }
    match node.local.as_str() {
        "SolidColorBrush" => {
            let mut brush = tinted(node.attr("Color").ok_or(BrushError::Syntax)?)?;
            brush.alpha *= opacity_of(node)?;
            Ok(brush)
        }
        "LinearGradientBrush" | "RadialGradientBrush" => {
            gradient(node, bbox, Channel::Colour, resolve)
        }
        "ImageBrush" => image_brush(node, bbox),
        "VisualBrush" => visual_brush(node, bbox),
        _ => Err(BrushError::Syntax),
    }
}

// ---- 14.3, a brush used as an alpha channel ---------------------------------

/// Which of a gradient's two channels a shading is built from.
///
/// 15.4's `GradientStop` states a colour *and* an alpha, and PDF's 8.7.4.5
/// shading states colour only — there is no alpha shading. So the two channels
/// of one gradient become two shadings, and which one is wanted is the
/// caller's question rather than the gradient's.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Channel {
    /// The stops' colours, in `/DeviceRGB`.
    Colour,
    /// The stops' **alphas**, as a grey in `/DeviceGray`. 14.3's opacity mask
    /// is a brush used as an alpha channel, and a `/Luminosity` soft mask
    /// (11.6.5.2) is where PDF keeps one — so an alpha of 0.4 is painted as
    /// the grey 0.4 and read back as its own luminosity.
    Alpha,
}

impl Channel {
    fn space(self) -> DeviceSpace {
        match self {
            Channel::Colour => DeviceSpace::Rgb,
            Channel::Alpha => DeviceSpace::Gray,
        }
    }

    fn components(self, colour: Colour) -> Vec<f64> {
        match self {
            Channel::Colour => colour.rgb.to_vec(),
            Channel::Alpha => vec![colour.alpha],
        }
    }
}

/// 14.3's `OpacityMask`, read as the alpha it states.
///
/// **Three shapes and not one**, because the alpha a brush carries lives
/// somewhere different in each of them and PDF has a different construction for
/// each place. Collapsing them would mean picking one and being wrong about the
/// other two: a luminosity mask over a picture reads its *colours*, and an
/// alpha mask over a gradient reads the one constant alpha a shading can carry.
#[derive(Clone, Debug, PartialEq)]
pub enum Mask {
    /// The alpha is one number over the whole element: a `SolidColorBrush`, or
    /// a gradient every one of whose stops carries the same alpha.
    ///
    /// No soft mask at all. 11.6.4.4's `/ca` and `/CA` say exactly this, and a
    /// form XObject carrying a flat grey would say it again at the cost of an
    /// object — which is the same argument [`super::paint`] makes about a
    /// `Canvas` opacity over children that do not overlap.
    Uniform(f64),
    /// The alpha varies across the element, and is painted as a grey for
    /// 11.6.5.2's `/Luminosity` to read back.
    Luminosity {
        /// The shading, over `/DeviceGray`, whose one output is the alpha.
        shading: Shading,
        /// Shading space into the space the element draws in.
        matrix: [f64; 6],
        /// The brush's own `Opacity`, which multiplies every stop's alpha.
        opacity: f64,
    },
    /// The alpha is what painting the brush produces — a picture's own alpha,
    /// or a drawing's coverage — which nothing but the painting can supply.
    /// So the brush is painted as it stands and 11.6.5.2's `/Alpha` reads the
    /// result.
    Alpha {
        /// The brush, as the paint it would be anywhere else. Only
        /// [`Paint::Image`] and [`Paint::Visual`] reach here; the other two
        /// carry their alpha somewhere a shading or a constant can hold it.
        paint: Paint,
        /// The brush's own `Opacity`.
        opacity: f64,
    },
}

/// Reads a brush as 14.3's opacity mask.
///
/// # Errors
/// As [`from_node`].
pub fn mask_from_node(node: &Node, bbox: Option<[f64; 4]>) -> Result<Mask, BrushError> {
    if !node.xps {
        return Err(BrushError::Syntax);
    }
    match node.local.as_str() {
        "SolidColorBrush" => {
            let colour = colour(node.attr("Color").ok_or(BrushError::Syntax)?)?;
            Ok(Mask::Uniform(colour.alpha * opacity_of(node)?))
        }
        "LinearGradientBrush" | "RadialGradientBrush" => {
            // The alphas are all a mask reads, and a stop's alpha is the
            // markup's whatever its profile says about its colour.
            let stops = stops_of(node, &unresolved)?;
            let opacity = opacity_of(node)?;
            // Every stop carrying one alpha is a gradient that does not vary
            // where a mask reads it, whatever it does with colour — so it is
            // the uniform case, and building a shading for it would be a form
            // XObject holding a flat grey.
            if stops
                .iter()
                .all(|stop| stop.colour.alpha == stops[0].colour.alpha)
            {
                return Ok(Mask::Uniform(stops[0].colour.alpha * opacity));
            }
            let brush = gradient(node, bbox, Channel::Alpha, &unresolved)?;
            match brush.paint {
                Paint::Gradient {
                    shading, matrix, ..
                } => Ok(Mask::Luminosity {
                    shading,
                    matrix,
                    opacity,
                }),
                // `gradient` answers a gradient element with a gradient.
                _ => Err(BrushError::Syntax),
            }
        }
        "ImageBrush" => Ok(Mask::Alpha {
            paint: image_brush(node, bbox)?.paint,
            opacity: opacity_of(node)?,
        }),
        "VisualBrush" => Ok(Mask::Alpha {
            paint: visual_brush(node, bbox)?.paint,
            opacity: opacity_of(node)?,
        }),
        _ => Err(BrushError::Syntax),
    }
}

/// Reads an `ImageBrush` (15.3).
///
/// `bbox` is the box a `RelativeToBoundingBox` viewport is stated in fractions
/// of -- the geometry about to be filled. `None` makes a relative viewport
/// unreadable rather than a picture placed over a box this reader invented,
/// which is `gradient`'s rule and for the same reason.
fn image_brush(node: &Node, bbox: Option<[f64; 4]>) -> Result<Brush, BrushError> {
    let source = node.attr("ImageSource").ok_or(BrushError::Syntax)?;
    let placement = placement_of(node, bbox)?;
    Ok(Brush {
        paint: Paint::Image(Box::new(ImageTile {
            source: source.to_string(),
            placement,
        })),
        alpha: opacity_of(node)?,
        approximated: false,
    })
}

/// Reads a `VisualBrush` (15.4).
///
/// The `Visual` is carried as **markup**, for [`Paint::Image`]'s reason one
/// step further along: painting it means re-entering the drawing walk, which
/// needs the package for the fonts and pictures the subtree may name, and this
/// module is pure. What is read here is everything a tile needs *around* the
/// subtree, which is 15.3's own vocabulary and the same six values an
/// `ImageBrush` states.
fn visual_brush(node: &Node, bbox: Option<[f64; 4]>) -> Result<Brush, BrushError> {
    // 15.4's `Visual` is a property element holding exactly one drawable. A
    // brush stating none paints nothing, which is not the same as a brush this
    // build cannot paint -- so it is `Syntax` and takes the placeholder grey by
    // name rather than being drawn as an empty cell nobody asked for.
    let visual = node
        .children
        .iter()
        .find(|child| child.xps && child.local == "VisualBrush.Visual")
        .and_then(|property| property.children.iter().find(|child| child.xps))
        .ok_or(BrushError::Syntax)?;
    // The box a `RelativeToBoundingBox` viewport is a fraction of is the box
    // being *filled* — the element's, exactly as for an `ImageBrush` — and not
    // the visual's own. It has to be threaded, because 15.3 makes
    // `RelativeToBoundingBox` the **default** for both unit attributes: a
    // build that passed `None` here would refuse every `VisualBrush` that did
    // not spell `ViewportUnits="Absolute"` out, which is nearly all of them.
    let placement = placement_of(node, bbox)?;
    Ok(Brush {
        paint: Paint::Visual(Box::new(VisualTile {
            visual: visual.clone(),
            key: node.key.clone(),
            placement,
        })),
        alpha: opacity_of(node)?,
        approximated: false,
    })
}

/// The six values 15.3 states about where a tile goes, shared by both brushes
/// that state them.
fn placement_of(node: &Node, bbox: Option<[f64; 4]>) -> Result<Placement, BrushError> {
    // 15.3 makes both rectangles required; there is no sensible default for
    // "which part of the source" or "where it goes".
    let viewbox = rect(node.attr("Viewbox").ok_or(BrushError::Syntax)?)?;
    let viewport = rect(node.attr("Viewport").ok_or(BrushError::Syntax)?)?;
    let viewbox_units = units_of(node, "ViewboxUnits")?;
    let viewport_units = units_of(node, "ViewportUnits")?;
    if viewport_units == Units::RelativeToBoundingBox && bbox.is_none() {
        return Err(BrushError::Syntax);
    }
    let tile = match node.attr("TileMode") {
        None | Some("None") => TileMode::None,
        Some("Tile") => TileMode::Tile,
        Some("FlipX") => TileMode::FlipX,
        Some("FlipY") => TileMode::FlipY,
        Some("FlipXY") => TileMode::FlipXY,
        Some(_) => return Err(BrushError::Syntax),
    };
    let transform = transform_of(node)?;

    // A viewbox or viewport with no extent paints nothing at all, and a
    // pattern whose cell is degenerate is one the writer refuses anyway. Said
    // here so the refusal names the brush rather than the pattern.
    if viewbox[2] <= 0.0 || viewbox[3] <= 0.0 || viewport[2] <= 0.0 || viewport[3] <= 0.0 {
        return Err(BrushError::Syntax);
    }
    Ok(Placement {
        viewbox,
        viewport,
        viewbox_units,
        viewport_units,
        tile,
        transform,
    })
}

/// `x,y,width,height`, which 15.3 writes as four numbers.
fn rect(text: &str) -> Result<[f64; 4], BrushError> {
    let values = markup::numbers(text).ok_or(BrushError::Syntax)?;
    if values.len() != 4 || !values.iter().all(|v| v.is_finite()) {
        return Err(BrushError::Syntax);
    }
    Ok([values[0], values[1], values[2], values[3]])
}

/// One of the two `*Units` attributes.
fn units_of(node: &Node, attribute: &str) -> Result<Units, BrushError> {
    match node.attr(attribute) {
        None | Some("RelativeToBoundingBox") => Ok(Units::RelativeToBoundingBox),
        Some("Absolute") => Ok(Units::Absolute),
        Some(_) => Err(BrushError::Syntax),
    }
}

/// A brush's own `Transform`, in either the attribute or the element form.
fn transform_of(node: &Node) -> Result<[f64; 6], BrushError> {
    if let Some(text) = node.attr("Transform") {
        return markup::matrix(text).ok_or(BrushError::Syntax);
    }
    let wanted = format!("{}.Transform", node.local);
    let Some(property) = node
        .children
        .iter()
        .find(|child| child.xps && child.local == wanted)
    else {
        return Ok([1.0, 0.0, 0.0, 1.0, 0.0, 0.0]);
    };
    let matrix = property
        .children
        .iter()
        .find(|child| child.xps && child.local == "MatrixTransform")
        .ok_or(BrushError::Syntax)?;
    markup::matrix(matrix.attr("Matrix").ok_or(BrushError::Syntax)?).ok_or(BrushError::Syntax)
}

/// 15.1's `Opacity`, which every brush may carry and which defaults to one.
fn opacity_of(node: &Node) -> Result<f64, BrushError> {
    match node.attr("Opacity") {
        None => Ok(1.0),
        Some(text) => {
            let value = markup::number(text).ok_or(BrushError::Syntax)?;
            (0.0..=1.0)
                .contains(&value)
                .then_some(value)
                .ok_or(BrushError::Syntax)
        }
    }
}

/// 15.4.1's `SpreadMethod`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Spread {
    Pad,
    Reflect,
    Repeat,
}

fn spread_of(node: &Node) -> Result<Spread, BrushError> {
    // The object model drops the attribute when it is the default and WPF
    // writes it out, so both packages of one page disagree about whether it is
    // there at all. Absent means `Pad`.
    match node.attr("SpreadMethod") {
        None => Ok(Spread::Pad),
        Some(text) => match text.trim() {
            "Pad" => Ok(Spread::Pad),
            "Reflect" => Ok(Spread::Reflect),
            "Repeat" => Ok(Spread::Repeat),
            _ => Err(BrushError::Syntax),
        },
    }
}

/// One `GradientStop`.
#[derive(Clone, Copy, Debug)]
struct Stop {
    offset: f64,
    colour: Colour,
    /// Whether the stop stated a `ContextColor` its profile could not convert.
    ///
    /// 8.7.4.5's shading names **one** colour space for the whole function, so
    /// a stop cannot carry a space of its own the way a solid fill can: it is
    /// converted to sRGB through its profile (18.3.1.2), and where that cannot
    /// be done it takes 8.6.5.5's default-`/Alternate` reading and the
    /// gradient says it approximated. Recorded here rather than inferred from
    /// the colour, because the reading is a perfectly ordinary RGB triple once
    /// it is made and nothing about the number remembers where it came from.
    contextual: bool,
}

/// What turns a `ContextColor` into the sRGB its profile says it is: the
/// painter's profiles, evaluated. `None` where the profile is not there or
/// cannot be evaluated.
///
/// A parameter rather than a lookup this module does, because the profiles
/// are the package's and this module is pure.
pub type Resolve<'a> = &'a dyn Fn(&ContextColour) -> Option<[f64; 3]>;

/// A [`Resolve`] that resolves nothing, for a caller with no profiles.
#[must_use]
pub fn unresolved(_: &ContextColour) -> Option<[f64; 3]> {
    None
}

/// 15.4.2's stop list, from either spelling of the property element.
///
/// A `ContextColor` stop is converted to sRGB through `resolve` — 18.3.1.2's
/// own first step, *"convert the color values to sRGB first"*, which applies
/// wherever a stop is sRGB or scRGB and is this build's choice where none is,
/// since no print ticket's blending space is read. A stop `resolve` cannot
/// convert keeps 8.6.5.5's default-`/Alternate` reading and the gradient says
/// it approximated.
fn stops_of(node: &Node, resolve: Resolve<'_>) -> Result<Vec<Stop>, BrushError> {
    let property = format!("{}.GradientStops", node.local);
    let mut out = Vec::new();
    let mut push = |stop: &Node| -> Result<(), BrushError> {
        if !stop.xps || stop.local != "GradientStop" {
            return Ok(());
        }
        let text = stop.attr("Color").ok_or(BrushError::Syntax)?;
        let mut colour = colour(text)?;
        let offset = markup::number(stop.attr("Offset").ok_or(BrushError::Syntax)?)
            .ok_or(BrushError::Syntax)?;
        let mut contextual = false;
        if let Some(rest) = text.trim().strip_prefix("ContextColor") {
            let (_, tint) = context_colour(rest)?;
            match resolve(&tint) {
                Some(rgb) => colour.rgb = rgb,
                None => contextual = true,
            }
        }
        out.push(Stop {
            offset: offset.clamp(0.0, 1.0),
            colour,
            contextual,
        });
        Ok(())
    };
    for child in &node.children {
        if child.xps && child.local == property {
            for stop in &child.children {
                push(stop)?;
            }
        } else {
            push(child)?;
        }
    }
    if out.is_empty() {
        return Err(BrushError::Syntax);
    }
    // A stable sort, so two stops at one offset keep the order the file wrote
    // them in — which is what decides which side of a hard stop each colour
    // lands on.
    out.sort_by(|a, b| a.offset.total_cmp(&b.offset));
    Ok(out)
}

fn gradient(
    node: &Node,
    bbox: Option<[f64; 4]>,
    channel: Channel,
    resolve: Resolve<'_>,
) -> Result<Brush, BrushError> {
    let stops = stops_of(node, resolve)?;
    let spread = spread_of(node)?;
    // Stops whose alphas differ vary across the element, which one constant
    // alpha cannot say: they become a second shading, of the alphas, which the
    // painter reads back as a soft mask over the colours.
    let varying = channel == Channel::Colour
        && stops
            .iter()
            .any(|stop| stop.colour.alpha != stops[0].colour.alpha);
    // A `ContextColor` stop, which cannot carry its own colour space into
    // a shading — see `Stop::contextual`. Named rather than left silent,
    // because the same colour on a solid fill *is* exact and a reader
    // comparing the two is entitled to know which one lost something.
    //
    // 18.3.1.2's `ScRgbLinearInterpolation`: the stops converted to scRGB —
    // linear light — and interpolated there. The shading's `/DeviceRGB` is
    // sRGB, so each interval is written as a sampled function of the sRGB
    // the linear blend comes to; `SRgbLinearInterpolation`, the default, is
    // the shading's own interpolation and needs nothing. A value that is
    // neither is blended as the default, and named.
    let mode = node.attr("ColorInterpolationMode").map(str::trim);
    let linear_light = mode == Some("ScRgbLinearInterpolation");
    let approximated = stops.iter().any(|stop| stop.contextual)
        || !matches!(
            mode,
            None | Some("SRgbLinearInterpolation" | "ScRgbLinearInterpolation")
        );
    // A varying alpha is the soft mask's to state, so the constant is the
    // brush's own `Opacity` alone; a uniform one is that times the stops' one
    // alpha.
    let alpha = if varying {
        opacity_of(node)?
    } else {
        stops[0].colour.alpha * opacity_of(node)?
    };

    let relative = match node.attr("MappingMode") {
        None | Some("Absolute") => false,
        Some("RelativeToBoundingBox") => true,
        Some(_) => return Err(BrushError::Syntax),
    };
    // A relative gradient is stated in fractions of the box it fills, so
    // without a box there is nothing to be a fraction of — and inventing one
    // would put the gradient somewhere this file never said.
    let unit = if relative {
        let [x0, y0, x1, y1] = bbox.ok_or(BrushError::Syntax)?;
        if x1 <= x0 || y1 <= y0 {
            return Err(BrushError::Syntax);
        }
        [x1 - x0, 0.0, 0.0, y1 - y0, x0, y0]
    } else {
        markup::IDENTITY
    };
    let brush_transform = super::geometry::transform_of(node, &node.local)
        .map_err(|_| BrushError::Syntax)?
        .unwrap_or(markup::IDENTITY);

    let shade = |channel: Channel| match node.local.as_str() {
        "LinearGradientBrush" => linear(node, &stops, spread, channel, linear_light),
        _ => radial(node, &stops, spread, channel, linear_light),
    };
    let (shading, inner) = shade(channel)?;
    // The same geometry and the same matrix, so the mask lies exactly over
    // the colours it fades.
    let alphas = if varying {
        Some(Box::new(shade(Channel::Alpha)?.0))
    } else {
        None
    };
    let matrix = markup::concat(inner, markup::concat(unit, brush_transform));
    if !matrix.iter().all(|v| markup::usable(*v)) {
        return Err(BrushError::Syntax);
    }

    Ok(Brush {
        paint: Paint::Gradient {
            shading,
            matrix,
            alphas,
        },
        alpha,
        approximated,
    })
}

/// 15.4.3's `LinearGradientBrush`, as a type 2 shading.
fn linear(
    node: &Node,
    stops: &[Stop],
    spread: Spread,
    channel: Channel,
    linear_light: bool,
) -> Result<(Shading, [f64; 6]), BrushError> {
    let start = node
        .attr("StartPoint")
        .and_then(markup::pair)
        .ok_or(BrushError::Syntax)?;
    let end = node
        .attr("EndPoint")
        .and_then(markup::pair)
        .ok_or(BrushError::Syntax)?;
    if start == end {
        return Err(BrushError::Syntax);
    }

    let base = ramp(stops, channel, linear_light);
    let (function, coords) = match spread {
        Spread::Pad => (base, [start.0, start.1, end.0, end.1]),
        _ => {
            // The axis grows by `SPREAD_COPIES` periods each way and the
            // function repeats over it, so the whole extended axis is still
            // `t` from zero to one and the sub-function boundaries land
            // exactly on the period boundaries.
            let (dx, dy) = (end.0 - start.0, end.1 - start.1);
            let copies = SPREAD_COPIES * 2 + 1;
            let from = (
                start.0 - dx * SPREAD_COPIES as f64,
                start.1 - dy * SPREAD_COPIES as f64,
            );
            let to = (
                end.0 + dx * SPREAD_COPIES as f64,
                end.1 + dy * SPREAD_COPIES as f64,
            );
            let mirrored =
                |index: usize| spread == Spread::Reflect && (index % 2) != (SPREAD_COPIES % 2);
            (
                replicate(&base, copies, &mirrored),
                [from.0, from.1, to.0, to.1],
            )
        }
    };
    if !coords.iter().all(|v| markup::usable(*v)) {
        return Err(BrushError::Syntax);
    }
    Ok((
        Shading::Axial {
            color_space: channel.space(),
            coords,
            function,
            extend: (true, true),
        },
        markup::IDENTITY,
    ))
}

/// 15.4.4's `RadialGradientBrush`, as a type 3 shading between the
/// `GradientOrigin` at radius zero and the `Center` at `RadiusX`.
///
/// An XPS radial gradient is an **ellipse** and a PDF type 3 shading blends
/// between **circles**, so the difference is carried in the matrix rather than
/// in the geometry: the shading is stated over a circle of radius `RadiusX`
/// and the space it lives in is scaled about the centre so that circle becomes
/// the ellipse the file stated. The focal point is un-scaled on the way in for
/// the same reason.
fn radial(
    node: &Node,
    stops: &[Stop],
    spread: Spread,
    channel: Channel,
    linear_light: bool,
) -> Result<(Shading, [f64; 6]), BrushError> {
    let centre = node
        .attr("Center")
        .and_then(markup::pair)
        .ok_or(BrushError::Syntax)?;
    let rx = markup::number(node.attr("RadiusX").ok_or(BrushError::Syntax)?)
        .ok_or(BrushError::Syntax)?;
    let ry = markup::number(node.attr("RadiusY").ok_or(BrushError::Syntax)?)
        .ok_or(BrushError::Syntax)?;
    if rx <= 0.0 || ry <= 0.0 {
        return Err(BrushError::Syntax);
    }
    // 15.4.4: the origin defaults to the centre, which makes the gradient
    // concentric.
    let origin = match node.attr("GradientOrigin") {
        Some(text) => markup::pair(text).ok_or(BrushError::Syntax)?,
        None => centre,
    };

    // Into the space in which the outer circle is a circle of radius `rx`.
    let unscale = [1.0, 0.0, 0.0, rx / ry, 0.0, 0.0];
    let focal = markup::apply(
        markup::concat(
            [1.0, 0.0, 0.0, 1.0, -centre.0, -centre.1],
            markup::concat(unscale, [1.0, 0.0, 0.0, 1.0, centre.0, centre.1]),
        ),
        origin,
    );
    let ellipse = markup::concat(
        [1.0, 0.0, 0.0, 1.0, -centre.0, -centre.1],
        markup::concat(
            [1.0, 0.0, 0.0, ry / rx, 0.0, 0.0],
            [1.0, 0.0, 0.0, 1.0, centre.0, centre.1],
        ),
    );

    let base = ramp(stops, channel, linear_light);
    let (function, coords) = match spread {
        Spread::Pad => (base, [focal.0, focal.1, 0.0, centre.0, centre.1, rx]),
        _ => {
            // Only outward: the inner circle has radius zero, so there is
            // nothing between it and the focal point to repeat.
            let copies = SPREAD_COPIES + 1;
            let far = rx * copies as f64;
            let centre_out = (
                focal.0 + (centre.0 - focal.0) * copies as f64,
                focal.1 + (centre.1 - focal.1) * copies as f64,
            );
            let mirrored = |index: usize| spread == Spread::Reflect && index % 2 == 1;
            (
                replicate(&base, copies, &mirrored),
                [focal.0, focal.1, 0.0, centre_out.0, centre_out.1, far],
            )
        }
    };
    if !coords.iter().all(|v| markup::usable(*v)) || !ellipse.iter().all(|v| markup::usable(*v)) {
        return Err(BrushError::Syntax);
    }
    Ok((
        Shading::Radial {
            color_space: channel.space(),
            coords,
            function,
            extend: (true, true),
        },
        ellipse,
    ))
}

/// How many samples one stop interval of a linear-light ramp is written as.
///
/// Not a bound — nothing is refused at it — but a resolution: the sRGB a
/// linear blend comes to is concave, steepest near black, and 7.10.2's
/// interpolation between 256 samples of it stays within 0.0018 of the curve
/// there — measured over every interval, under half the step an eight-bit
/// output can show — and far closer elsewhere.
const LINEAR_LIGHT_SAMPLES: u32 = 256;

/// One stop interval interpolated in linear light, as 7.10.2's sampled
/// function of the sRGB it comes to: 18.3.1.2's `ScRgbLinearInterpolation`.
fn linear_light_piece(from: &[f64], to: &[f64]) -> Function {
    let last = f64::from(LINEAR_LIGHT_SAMPLES - 1);
    let from: Vec<f64> = from.iter().map(|c| srgb_decode(*c)).collect();
    let to: Vec<f64> = to.iter().map(|c| srgb_decode(*c)).collect();
    let mut samples = Vec::with_capacity(LINEAR_LIGHT_SAMPLES as usize * from.len());
    for index in 0..LINEAR_LIGHT_SAMPLES {
        let s = f64::from(index) / last;
        for (a, b) in from.iter().zip(&to) {
            let encoded = srgb_transfer(a + s * (b - a));
            samples.push((encoded * 65535.0).round() as u16);
        }
    }
    Function::Sampled {
        domain: vec![[0.0, 1.0]],
        range: vec![[0.0, 1.0]; from.len()],
        size: vec![LINEAR_LIGHT_SAMPLES],
        samples,
    }
}

/// One period of the gradient, as a function over `[0, 1]`.
///
/// Stops that do not reach the ends are extended flat, because 15.4.2 makes
/// the colour before the first stop and after the last one that stop's own —
/// which is a statement about the gradient and not about `/Extend`.
///
/// `linear_light` is 18.3.1.2's `ScRgbLinearInterpolation`, which changes
/// how the **colours** are blended between stops and not the alpha: an alpha
/// is a coverage, not a light level.
fn ramp(stops: &[Stop], channel: Channel, linear_light: bool) -> Function {
    let mut offsets: Vec<f64> = Vec::with_capacity(stops.len() + 2);
    let mut colours: Vec<Vec<f64>> = Vec::with_capacity(stops.len() + 2);
    if stops[0].offset > 0.0 {
        offsets.push(0.0);
        colours.push(channel.components(stops[0].colour));
    }
    for stop in stops {
        offsets.push(stop.offset);
        colours.push(channel.components(stop.colour));
    }
    let last = stops[stops.len() - 1];
    if last.offset < 1.0 {
        offsets.push(1.0);
        colours.push(channel.components(last.colour));
    }

    // 7.10.4 wants `/Bounds` strictly increasing and strictly inside the
    // domain, and 15.4.2 permits two stops at one offset — that is how a hard
    // edge is spelled. The edge is kept by separating the two by the smallest
    // step that is still a distinct PDF real rather than by dropping one of
    // them, which would turn a hard edge into a ramp across the whole
    // gradient.
    const NUDGE: f64 = 1.0e-6;
    for at in 1..offsets.len() {
        if offsets[at] <= offsets[at - 1] {
            offsets[at] = (offsets[at - 1] + NUDGE).min(1.0);
        }
    }

    let mut pieces: Vec<Function> = Vec::new();
    let mut bounds: Vec<f64> = Vec::new();
    for at in 1..offsets.len() {
        pieces.push(if linear_light && channel == Channel::Colour {
            linear_light_piece(&colours[at - 1], &colours[at])
        } else {
            Function::Exponential {
                domain: [0.0, 1.0],
                c0: colours[at - 1].clone(),
                c1: colours[at].clone(),
                n: 1.0,
            }
        });
        if at + 1 < offsets.len() {
            bounds.push(offsets[at]);
        }
    }
    if pieces.len() == 1 {
        return pieces.remove(0);
    }
    if pieces.is_empty() {
        // One stop, or several at one offset: a gradient with no extent is a
        // flat colour, which is what 15.4.2 makes it.
        return Function::Exponential {
            domain: [0.0, 1.0],
            c0: colours[0].clone(),
            c1: colours[0].clone(),
            n: 1.0,
        };
    }
    let encode = vec![[0.0, 1.0]; pieces.len()];
    Function::Stitching {
        domain: [0.0, 1.0],
        functions: pieces,
        bounds,
        encode,
    }
}

/// `copies` periods of `base` end to end, each forward or mirrored.
///
/// This is the whole of `Repeat` and `Reflect`: the two differ in nothing but
/// which copies run backwards, so building them from one function with one
/// predicate is what stops them from being two implementations that agree by
/// accident.
fn replicate(base: &Function, copies: usize, mirrored: &dyn Fn(usize) -> bool) -> Function {
    let step = 1.0 / copies as f64;
    Function::Stitching {
        domain: [0.0, 1.0],
        functions: vec![base.clone(); copies],
        bounds: (1..copies).map(|index| index as f64 * step).collect(),
        encode: (0..copies)
            .map(|index| {
                if mirrored(index) {
                    [1.0, 0.0]
                } else {
                    [0.0, 1.0]
                }
            })
            .collect(),
    }
}
