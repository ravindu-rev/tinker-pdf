//! Resolving a page's resources for the interpreter and the renderer.
//!
//! The two seams — `FontSource` for the interpreter, `GlyphSource` for the
//! renderer — exist so those crates never see a PDF dictionary. This is where
//! the dictionaries actually get read.

use std::collections::HashMap;
use std::sync::{Arc, Mutex, RwLock};

use tinker_pdf_color::{ColorSpace, Function};
use tinker_pdf_content::{Device, FontSource, Layer, MarkedProps, Matrix, PathSegment, Rgb};
use tinker_pdf_cos::{
    decode_text_string, font as cos_font, limits, pages as cos_pages, CosDocument, Dict, Name,
    ObjRef, Object,
};
use tinker_pdf_filters::{
    ccitt_decode, jbig2_decode, jpeg_decode, CcittParams, Jbig2Params, JpegColor,
    Warning as FilterWarning, MAX_JBIG2_SYMBOL_PIXELS, MAX_JBIG2_WORK_MULTIPLE,
};
use tinker_pdf_font::{base_glyph_name, cff::Cff, glyf, BaseEncoding, Outline, Sfnt, Type1};
use tinker_pdf_raster::canvas::{Canvas, Color};
use tinker_pdf_render::{
    DecodedImage, GlyphSource, Mesh, MeshParams, PatternPaint, Shading, TilingPattern,
};

use crate::fonts::{self, FontProvider, FontRequest};
use crate::optional::OptionalContent;

/// Extracted glyph outlines, keyed by font identity and character code.
///
/// `None` records that a glyph was looked for and is not there, so a missing
/// one costs the extraction attempt once rather than on every occurrence.
/// Beside it, the font the extraction reported as resolving no glyph for the
/// code, if it did — so a later render that meets the code from the cache
/// says what the first one said ([`PageResources::for_one_render`]).
type OutlineCache = HashMap<(u64, u32), (Option<Arc<Outline>>, Option<String>)>;

/// A decoded image, or the codec that could not decode it, and the damage the
/// decode tolerated as `(resource name, what was tolerated)`.
///
/// The failure is kept in the words the decode used and the damage beside
/// the picture, because both are reported **per render**: a render that meets
/// the image from the cache reports what the decode reported, rather than
/// nothing (the damage) or the resource name standing in for a codec (the
/// failure, which is what a cached `None` used to come back as).
struct CachedImage {
    image: Result<Arc<DecodedImage>, String>,
    damage: Vec<(String, String)>,
    /// What [`PageResources::repaired_spaces`] gained under the image's name
    /// while it decoded, said again by every render that meets the image
    /// here, as `damage` is.
    repairs: Vec<(String, String)>,
}

/// What a page's resources work out once and every render of the page can
/// reuse: font programs, decoded images, compiled ICC transforms, glyph
/// outlines and the nested scopes of forms.
///
/// Behind one `Arc` so a retained page can give each render resources of its
/// own — fresh lists of what that render had to tolerate — over the same
/// caches ([`PageResources::for_one_render`]).
#[derive(Default)]
struct Caches {
    /// The embedded font program of each font, by the id the interpreter uses.
    ///
    /// **Decoded on first use, not at construction.** A font program is an
    /// inflate of a stream that is routinely a megabyte, and since a form
    /// XObject's own `/Resources` became a scope of their own there is one of
    /// these per form rather than one per page — a document of nine hundred
    /// objects went from 537 ms to 24.7 s doing it eagerly, and one corpus
    /// file stopped making progress at all. Most scopes are opened to resolve
    /// an image or a pattern and never ask for a glyph.
    ///
    /// `None` is cached as firmly as a hit: a font with no embedded program
    /// must not be looked up again on every glyph.
    programs: Mutex<HashMap<u64, Option<Arc<Vec<u8>>>>>,
    /// Decoded images, kept because a page may draw one many times.
    images: Mutex<HashMap<Vec<u8>, CachedImage>>,
    /// Compiled ICC transforms, by the profile stream's object number.
    ///
    /// A transform is three 4 096-entry tables, and a page may name the same
    /// `ICCBased` space at every one of a thousand `cs` operators. The `None`
    /// is cached too: a profile that would not parse must be refused once
    /// rather than re-read and re-refused a thousand times.
    icc: Mutex<IccCache>,
    /// Outlines already extracted, keyed by font and code.
    outlines: RwLock<OutlineCache>,
    /// Nested scopes already built, by the form's own object number.
    ///
    /// A page may invoke one form a thousand times — a stamp, a rule, a
    /// letterhead — and building its resources is not cheap: every font in the
    /// dictionary is parsed and the optional-content configuration is bound
    /// again. Two pdf.js corpus files stopped making progress at all when this
    /// was rebuilt per invocation, which is what put the cache here.
    ///
    /// Keyed by the XObject's reference rather than by the resource name,
    /// because two names can reach one form and a name means nothing outside
    /// the dictionary it was looked up in. `None` is cached too: "this form
    /// brought no resources" is an answer worth not recomputing.
    form_scopes: Mutex<HashMap<u64, Option<Arc<PageResources>>>>,
}

/// Compiled ICC transforms, by the profile stream's object number and
/// generation.
///
/// The `None` is cached as deliberately as the `Some`: a profile that will
/// not parse must be refused once rather than re-read at every `cs`.
type IccCache = HashMap<(u32, u16), Option<Arc<tinker_pdf_color::icc::Transform>>>;

/// Which glyph of an embedded program a code selects, and on whose authority.
///
/// The second half is what [`crate::subset`] rests on, and it is the whole
/// reason this is a struct rather than a `u16`. 9.6.6.4 ends its selection
/// order with a guess — *read the code as the glyph index* — which is what
/// every reader does with a subset font whose producer dropped the `cmap`, and
/// which is **not** a statement the font made. Two readers guessing are free
/// to guess differently: this one reads the code, another reads the
/// `/Differences` name through a `post` table the subsetter drops.
///
/// A glyph kept on the strength of a guess is therefore a glyph some other
/// reader may not draw, and — much worse — a glyph *dropped* because the guess
/// went elsewhere is a glyph that reader draws and no longer has. So
/// subsetting refuses a font any of whose shown codes landed here, and leaves
/// its program whole.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Selection {
    /// The glyph index in the embedded program.
    pub glyph: u16,
    /// Whether a mapping the font itself states chose it — its `cmap` through
    /// a character, its `/CIDToGIDMap` through a CID, or its CFF charset
    /// through a name — rather than 9.6.6.4's closing guess.
    pub stated: bool,
}

impl Selection {
    fn stated(glyph: u16) -> Selection {
        Selection {
            glyph,
            stated: true,
        }
    }

    fn guessed(glyph: u16) -> Selection {
        Selection {
            glyph,
            stated: false,
        }
    }
}

/// Everything one page's rendering needs from its resources.
pub struct PageResources {
    doc: Arc<CosDocument>,
    fonts: HashMap<Vec<u8>, Arc<cos_font::Font>>,
    font_ids: HashMap<Vec<u8>, u64>,
    /// Which glyph a code selects, per font, resolved lazily.
    resources: Option<Dict>,
    /// Everything worked out once and reusable by every render: programs,
    /// images, ICC transforms, outlines, form scopes. Shared, so
    /// [`PageResources::for_one_render`] can hand a render its own lists of
    /// what it tolerated over the same caches.
    caches: Arc<Caches>,
    /// Resource names that named no font this build could resolve, and — when
    /// glyphs were being drawn — names whose font resolved no glyph for a
    /// code the page used.
    missing_fonts: Mutex<Vec<String>>,
    /// Images that decoded with something tolerated, as `(resource name,
    /// what the decoder tolerated)`. Ruling 10: the leaf crate says what it
    /// forgave, and this is where the object it happened in gets attached.
    damaged_images: Mutex<Vec<(String, String)>>,
    /// Colour spaces whose parameters were read the nearest way that means
    /// something, as `(resource name, what was repaired)` — reported as
    /// [`tinker_pdf_render::RenderWarning::RepairedColorSpace`] (ruling 10).
    repaired_spaces: Mutex<Vec<(String, String)>>,
    /// While [`crate::Page::images`] decodes one image, what the decoders
    /// tolerated for **that** image, so the leniency lands on the
    /// [`crate::PageImage`] it happened to rather than only on the page's
    /// list above — which dedups by resource name, and which `images` has no
    /// bitmap to carry out on (ruling 10). `None` when nothing is capturing.
    image_capture: Mutex<Option<Vec<String>>>,
    /// The font the glyph lookup under way reported as resolving no glyph,
    /// taken by [`GlyphSource::outline`] into the cache entry beside the
    /// outline so a render that meets it there can say it again.
    unresolved: Mutex<Option<String>>,
    /// The host's substitute faces, kept so a resource dictionary *inside*
    /// this one can be read with the same configuration.
    ///
    /// A tiling pattern's `/Resources` (8.7.3.2) is read into a
    /// `PageResources` of its own, and without this the cell would be the one
    /// place in a document where a `FontProvider` the caller installed does
    /// not apply — text inside a pattern would silently lose its substitute
    /// face while the same text beside it kept one.
    provider: Option<Arc<dyn FontProvider>>,
    /// Which optional-content layers the document's default configuration
    /// shows (8.11).
    ///
    /// Bound here, once, rather than looked up per `BDC`: the catalog is
    /// already in reach through `doc`, the answer cannot change during a
    /// render — this build has no layer-toggle API to change it with — and a
    /// page that marks every drawing operator would otherwise walk
    /// `/OCProperties` thousands of times for one constant.
    optional: Arc<OptionalContent>,
}

/// Applies `/Decode [1 0]` to already-decoded samples.
///
/// The general `/Decode` machinery works on raw samples before colour
/// conversion, which the JPEG and CCITT paths have already done by the time
/// they return. Reversal is the only form either of them meets in practice —
/// `/Decode [1 0]` on a fax, `[1 0 1 0 1 0]` on a JPEG — and inverting the
/// output is exactly equivalent for those. Any other range is left alone
/// rather than approximated.
fn invert_if_decode_reverses(decode: &[(f64, f64)], rgb: &mut [u8]) {
    if decode.is_empty() || !decode.iter().all(|(a, b)| *a > *b) {
        return;
    }
    for value in rgb.iter_mut() {
        *value = 255 - *value;
    }
}

/// What an inline image is called in a warning. It has no resource name to be
/// called anything else by, which is also why it is not cached.
pub(crate) const INLINE_NAME: &str = "inline";

/// What an inline image's filter chain produced: samples, or the still-coded
/// bytes of a codec that returns its own pixels.
pub(crate) enum InlineSamples {
    /// Samples for the sample loop; `fax` when they are a fax's packed
    /// one-bit samples, whatever `/BitsPerComponent` said.
    Samples {
        /// The samples.
        bytes: Vec<u8>,
        /// Whether a CCITT decode produced them.
        fax: bool,
    },
    /// A JPEG, for [`jpeg_samples`].
    Jpeg(Vec<u8>),
    /// A JPEG 2000 codestream, for [`PageResources::jpx_samples`].
    Jpx(Vec<u8>),
}

/// A JPEG's pixels, ready to blit (7.4.8).
///
/// Shared by the XObject path and the inline one so the two differ in nothing
/// but where the still-coded bytes came from — the ceiling, the colour
/// conversion and the `/Decode` reversal included.
///
/// A JPEG carries its own dimensions and its own colour, so it never joins the
/// generic sample loop; `/Decode` therefore has to be applied to the converted
/// output rather than to raw samples, which is what
/// [`invert_if_decode_reverses`] is for.
fn jpeg_image(
    raw: &[u8],
    decode: &[(f64, f64)],
    interpolate: bool,
) -> Result<DecodedImage, String> {
    let image = jpeg_samples(raw)?;
    let mut rgb = jpeg_to_rgb(&image);
    invert_if_decode_reverses(decode, &mut rgb);
    Ok(DecodedImage {
        width: image.width,
        height: image.height,
        rgb,
        alpha: Vec::new(),
        stencil: false,
        interpolate,
    })
}

/// A JPEG's samples, decoded and **not** converted: one byte a component, in
/// the components the frame carries — YCbCr already turned into RGB and an
/// Adobe-inverted CMYK already turned back into ink values, which are the
/// decoder's to undo, and nothing else (7.4.8).
///
/// The one decode both [`jpeg_image`] and [`crate::Page::images`] make, under
/// the one ceiling.
fn jpeg_samples(raw: &[u8]) -> Result<tinker_pdf_filters::JpegImage, String> {
    jpeg_decode(raw, 1 << 28).map_err(|e| format!("{e:?}"))
}

/// What a JBIG2 image's decode is allowed to cost, as the pixels
/// [`Jbig2Params::work_ceiling`] measures it against: the image's own
/// `/Width` x `/Height`, plus a floor that holds one shared dictionary.
///
/// **Not the output ceiling.** The decoder is handed `MAX_DECODED_STREAM` for
/// every image, which is a bound on any stream rather than a statement about
/// this one, and [`MAX_JBIG2_WORK_MULTIPLE`] times the 2^30 pixels it holds was
/// a budget of 17 179 869 184 units: sixteen copies of a 117-byte dictionary
/// deciding symbols past its marker, 2 078 bytes in all, decoded for 10.2 s in
/// release and were not refused. The image is what the page asked for, so its
/// area is the scale.
///
/// **The floor is for `/JBIG2Globals`.** A global dictionary is decoded whole
/// for every image that names it (7.4.7), and an image may be a small mask on a
/// page whose glyphs a dictionary shared by two hundred pages holds, so the
/// image's area alone would refuse a document for the shape its producer
/// chose. One dictionary may decode `MAX_JBIG2_SYMBOL_PIXELS` pixels, each of
/// them an arithmetic decision; the integers that size and export its symbols
/// and the copy a text region takes of them are less than that again. So the
/// floor is that cap twice over, in units — 134 217 728, which at sixteen units
/// a pixel is 8 388 608 pixels, about one 300 dpi A4 page — and a dictionary the
/// cap admits is never refused by the budget, whatever image names it.
fn jbig2_work_ceiling(width: u32, height: u32) -> u64 {
    let globals = 2 * MAX_JBIG2_SYMBOL_PIXELS / MAX_JBIG2_WORK_MULTIPLE;
    (u64::from(width) * u64::from(height)).saturating_add(globals)
}

/// Rewrites an inline image's dictionary into the long spellings the shared
/// image path reads (8.9.7, Table 93).
///
/// Name by name rather than by text substitution. A search for `"/Fl "` finds
/// neither `/F/Fl` nor `[/AHx/Fl]`, and both are ordinary PDF — 7.2.2 makes
/// the `/` its own delimiter, so no producer is obliged to write the space
/// that search depends on. The consequence was silent and total: the whole
/// `/Filter` entry stayed a two-letter name nothing matched, so a compressed
/// inline image was sampled straight out of its compressed bytes, and `/DP`
/// written tight against its dictionary took the predictor down with it.
fn expand_inline_abbreviations(dict: &[u8]) -> Vec<u8> {
    // Every abbreviation of Table 93 and of Table 6, keys and values both:
    // `/CS /G` is a colour space named the short way, and `/F /AHx` a filter.
    const ABBREVIATIONS: &[(&[u8], &[u8])] = &[
        (b"BPC", b"BitsPerComponent"),
        (b"CS", b"ColorSpace"),
        (b"D", b"Decode"),
        (b"DP", b"DecodeParms"),
        (b"F", b"Filter"),
        (b"H", b"Height"),
        (b"IM", b"ImageMask"),
        (b"I", b"Interpolate"),
        (b"W", b"Width"),
        (b"G", b"DeviceGray"),
        (b"RGB", b"DeviceRGB"),
        (b"CMYK", b"DeviceCMYK"),
        (b"AHx", b"ASCIIHexDecode"),
        (b"A85", b"ASCII85Decode"),
        (b"LZW", b"LZWDecode"),
        (b"Fl", b"FlateDecode"),
        (b"RL", b"RunLengthDecode"),
        (b"CCF", b"CCITTFaxDecode"),
        (b"DCT", b"DCTDecode"),
    ];
    // 7.2.2: everything that ends a name. A regular character is anything
    // else — `#` included, so an escaped name is read whole, matches no
    // abbreviation and comes back out exactly as it went in.
    const DELIMITERS: &[u8] = b"()<>[]{}/%";
    let is_regular = |b: u8| !b.is_ascii_whitespace() && b != 0 && !DELIMITERS.contains(&b);

    let mut out: Vec<u8> = Vec::with_capacity(dict.len() + 32);
    out.extend_from_slice(b"<< ");
    let mut i = 0usize;
    while let Some(&byte) = dict.get(i) {
        if byte != b'/' {
            out.push(byte);
            i += 1;
            continue;
        }
        let start = i + 1;
        let mut end = start;
        while dict.get(end).copied().is_some_and(is_regular) {
            end += 1;
        }
        let name = dict.get(start..end).unwrap_or_default();
        let long = ABBREVIATIONS
            .iter()
            .find(|(short, _)| *short == name)
            .map_or(name, |(_, long)| *long);
        out.push(b'/');
        out.extend_from_slice(long);
        // No separator is added: whatever ended the short name — white space,
        // a delimiter or the end of the dictionary — ends the long one too.
        i = end;
    }
    out.extend_from_slice(b" >>");
    out
}

/// 11.6.6's `/CS`, reduced to the blending space a compositor needs.
///
/// By component count, plus `/Lab` named separately because its components are
/// not in `0..1` and no count would say so. An `ICCBased` space reaches here as
/// `ColorSpace::Approximated`, which is 8.6.5.5's alternate-space reading and
/// carries exactly the count this needs; what the profile would have said about
/// the *meaning* of those components is `docs/design/icc.md`'s.
fn group_space(space: tinker_pdf_color::ColorSpace) -> tinker_pdf_content::GroupSpace {
    use tinker_pdf_content::GroupSpace;
    if matches!(space, tinker_pdf_color::ColorSpace::Lab { .. }) {
        return GroupSpace::Lab;
    }
    match space.components() {
        1 => GroupSpace::Gray,
        4 => GroupSpace::Cmyk,
        // Three, or anything a group has no business declaring, reads as RGB —
        // which is what this build composites in, so an unexpected count is
        // the case that needs no warning rather than the one that does.
        _ => GroupSpace::Rgb,
    }
}

/// Table 90's default `/Decode` pair for component `c` of an image in
/// `space`, where it is not `[0 1]` and so not what a sample's fraction
/// already is: a `/Lab` sample spans `L*` over `0..100` and `a*`, `b*` over
/// the space's `/Range` (8.6.5.4, Table 90).
///
/// Until October 2026 an image in `/Lab` with no `/Decode` read every
/// sample as a fraction of one, so `L*` ran 0 to 1 and the image was all but
/// black. Every other space's default is `[0 1]` — an `/Indexed` one's is
/// its index range, which the sample loop reads as the index itself.
fn default_decode(space: &ColorSpace, c: usize) -> Option<(f64, f64)> {
    match space {
        ColorSpace::Lab { range } => match c {
            0 => Some((0.0, 100.0)),
            1 => Some((range[0], range[1])),
            2 => Some((range[2], range[3])),
            _ => None,
        },
        _ => None,
    }
}

/// The D50 white point, and the default when a CIE-based space names none.
///
/// 8.6.5.2 and 8.6.5.3 make `/WhitePoint` required, so this is the answer for a
/// dictionary that omits it or writes fewer than three numbers — a file that
/// has not described a white point rather than one that described a different
/// one.
const WHITE_D50: [f64; 3] = [0.964_212, 1.0, 0.825_188];

/// `read` of `object` resolved, **where it lies**: an indirect object is the
/// document's cached one and a direct one is `object` itself.
///
/// Not [`CosDocument::resolve`], which hands a direct object back as a fresh
/// `Arc` of a deep copy. That is nothing for a number and everything for a
/// long array, and the readers this serves run once per operator: a review
/// measured a page of 2 000 `/X /P0 BDC EMC` naming one list beside a
/// 1 048 576-entry array at 150 s to extract text from while each `BDC` was
/// handed a copy, against 0.38 s with the list borrowed.
pub(crate) fn read_resolved<R>(
    doc: &CosDocument,
    object: &Object,
    read: impl FnOnce(&Object) -> R,
) -> R {
    if object.as_objref().is_some() {
        read(&doc.resolve(object))
    } else {
        read(object)
    }
}

/// `read` of the value of `key` in `dict`, resolved where it lies
/// ([`read_resolved`]): what [`CosDocument::resolve_key`] answers, `Null` for
/// an absent key, without its copy of a direct value.
///
/// For the readers that take values **out of** a dictionary read where it
/// lies: the dictionary is not copied, and a value under one of the keys
/// they read must not be either, or a long array under `/Alt` costs what it
/// cost beside the keys before.
pub(crate) fn read_key<R>(
    doc: &CosDocument,
    dict: &Dict,
    key: &[u8],
    read: impl FnOnce(&Object) -> R,
) -> R {
    match dict.get(doc.intern(key)) {
        Some(value) => read_resolved(doc, value, read),
        None => read(&Object::Null),
    }
}

impl PageResources {
    /// `read` of the property list this scope's `/Properties` names `name`
    /// (14.6.2), resolved: what `/Tag /name BDC` refers to. `None` when there
    /// is no such list or it is not a dictionary.
    ///
    /// Lent rather than returned, because neither the table nor the list is
    /// copied to answer: each is the document's cached object when it is
    /// indirect and the resource dictionary's own when it is direct (see
    /// [`read_resolved`]). Every named `BDC` on every reading of a page asks,
    /// so a copy here is the list's size times the page's sequences —
    /// `tests/property_list_work.rs` counts it. The same holds for every value
    /// `read` takes out of the list, which is why the readers lent it read
    /// each through [`read_key`] rather than `resolve_key`.
    pub(crate) fn with_property_list<R>(
        &self,
        name: &[u8],
        read: impl FnOnce(&Dict) -> R,
    ) -> Option<R> {
        let resources = self.resources.as_ref()?;
        let table = resources.get(self.doc.intern(b"Properties"))?;
        read_resolved(&self.doc, table, |table| {
            let entry = table.as_dict()?.get(self.doc.intern(name))?;
            read_resolved(&self.doc, entry, |list| list.as_dict().map(read))
        })
    }

    /// The font resource names that could not be resolved.
    #[must_use]
    pub fn missing_fonts(&self) -> Vec<String> {
        self.missing_fonts
            .lock()
            .map(|names| names.clone())
            .unwrap_or_default()
    }

    /// Images that decoded with a leniency, and which leniency (ruling 10).
    #[must_use]
    pub fn damaged_images(&self) -> Vec<(String, String)> {
        self.damaged_images
            .lock()
            .map(|images| images.clone())
            .unwrap_or_default()
    }

    /// Colour spaces read with a repair, and which repair (ruling 10).
    #[must_use]
    pub(crate) fn repaired_spaces(&self) -> Vec<(String, String)> {
        self.repaired_spaces
            .lock()
            .map(|spaces| spaces.clone())
            .unwrap_or_default()
    }

    /// Adds repairs some other pass over the same content met — the
    /// interpretation a retained page recorded — to what this render reports,
    /// as [`PageResources::note_missing_fonts`] does for fonts.
    pub(crate) fn note_repaired_spaces(&self, entries: &[(String, String)]) {
        for entry in entries {
            self.note_repaired_space(entry.clone());
        }
    }

    /// These resources again, for **one render** of a page whose resources
    /// are kept across renders — a retained page's: every cache shared, so
    /// nothing decoded or extracted is paid for twice, and nothing tolerated
    /// yet, so what the render reports is what it met.
    ///
    /// A direct render builds its resources fresh and reports what its own
    /// interpretation and drawing ran into. A retained page's resources
    /// outlive its renders, and their lists used to as well: a cancelled
    /// replay reported a font the recording had met, and a region reported
    /// what a pattern cell drawn by an earlier render had met. What a cache
    /// hit stands for — an image's damage, a glyph its font could not resolve —
    /// is kept in the cache entry and said again by every render that meets
    /// it, as that render's own decode would have.
    #[must_use]
    pub(crate) fn for_one_render(&self) -> PageResources {
        PageResources {
            doc: Arc::clone(&self.doc),
            fonts: self.fonts.clone(),
            font_ids: self.font_ids.clone(),
            resources: self.resources.clone(),
            caches: Arc::clone(&self.caches),
            missing_fonts: Mutex::new(Vec::new()),
            damaged_images: Mutex::new(Vec::new()),
            repaired_spaces: Mutex::new(Vec::new()),
            image_capture: Mutex::new(None),
            unresolved: Mutex::new(None),
            provider: self.provider.clone(),
            optional: Arc::clone(&self.optional),
        }
    }

    /// Adds fonts some other pass over the same content could not resolve —
    /// the interpretation a retained page recorded — to what this render
    /// reports, as though its own interpretation had met them.
    pub(crate) fn note_missing_fonts(&self, names: &[String]) {
        for name in names {
            self.note_missing_font(name.clone());
        }
    }

    /// Reads a page's resource dictionary.
    #[must_use]
    pub fn new(
        doc: &Arc<CosDocument>,
        page: &cos_pages::Page,
        provider: Option<&Arc<dyn FontProvider>>,
    ) -> PageResources {
        let mut fonts = HashMap::new();
        let mut font_ids = HashMap::new();
        let mut resources = None;

        if let Some(dict) = page.resources.as_ref() {
            resources = Some(dict.clone());
            for (name, font) in cos_font::from_resources(doc, dict) {
                if let Some(bytes) = doc.name_bytes(name) {
                    let key = bytes.to_vec();
                    let id = u64::from(name.id());
                    font_ids.insert(key.clone(), id);
                    fonts.insert(key, font);
                }
            }
        }

        PageResources {
            doc: doc.clone(),
            fonts,
            font_ids,
            resources,
            caches: Arc::default(),
            missing_fonts: Mutex::new(Vec::new()),
            damaged_images: Mutex::new(Vec::new()),
            repaired_spaces: Mutex::new(Vec::new()),
            image_capture: Mutex::new(None),
            unresolved: Mutex::new(None),
            provider: provider.cloned(),
            optional: Arc::new(OptionalContent::bind(doc)),
        }
    }

    /// The compiled transform for an `ICCBased` profile stream, or `None`
    /// where the profile cannot be made into one.
    ///
    /// `None` covers three different things, and deliberately does not
    /// distinguish them here: a stream that will not decode, a profile
    /// `Profile::parse` refuses by name, and a profile whose model has no
    /// closed form yet — the `A2B*` lookup tables, which are 140 of the
    /// corpus's 2 750. All three land on 8.6.5.5's alternate-space reading,
    /// which is what the caller was doing before profiles were read at all, so
    /// none of them costs a page anything it had.
    fn icc_transform(
        &self,
        reference: tinker_pdf_cos::ObjRef,
    ) -> Option<Arc<tinker_pdf_color::icc::Transform>> {
        let key = (reference.num, reference.gen);
        if let Ok(cache) = self.caches.icc.lock() {
            if let Some(found) = cache.get(&key) {
                return found.clone();
            }
        }
        let compiled = self
            .doc
            .stream_decoded(reference)
            .ok()
            .and_then(|bytes| tinker_pdf_color::icc::Profile::parse(&bytes).ok())
            .as_ref()
            .and_then(tinker_pdf_color::icc::Transform::compile)
            .map(Arc::new);
        if let Ok(mut cache) = self.caches.icc.lock() {
            cache.insert(key, compiled.clone());
        }
        compiled
    }

    /// The page's own transparency group space (11.4.7), if it declares one.
    ///
    /// A page-level `/Group` is not a form's: nothing invokes it, so there is
    /// no `Do` for the interpreter to notice and no `Group` value to carry.
    /// 11.4.7 makes it the space the *page* composites in, which is why it is
    /// read here and asked for by `Page::render` rather than arriving through
    /// the content stream like every other group.
    #[must_use]
    pub fn page_group_space(
        &self,
        page: &cos_pages::Page,
    ) -> Option<tinker_pdf_content::GroupSpace> {
        let object = self.doc.get(page.reference).ok()?;
        let dict = object.as_dict()?;
        let group = self.doc.resolve_key(dict, self.doc.intern(b"Group"));
        let group = group.as_dict()?;
        // 11.6.6: the subtype is checked rather than the key's presence, for
        // the reason `form_from` checks it — 8.10.3's `/S /Reference` group is
        // a different thing wearing the same key.
        let subtype = self
            .doc
            .resolve_key(group, self.doc.intern(b"S"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n))?;
        if subtype.as_ref() != b"Transparency" {
            return None;
        }
        let cs = group.get(self.doc.intern(b"CS")).cloned()?;
        self.parse_space(&cs, 0, b"Group").map(group_space)
    }

    /// Reads a resource dictionary that is not a page's.
    ///
    /// An annotation's appearance stream carries its own resources, and
    /// resolving its fonts against the page's would find the wrong ones or
    /// none at all.
    #[must_use]
    pub fn from_dict(
        doc: &Arc<CosDocument>,
        dict: Dict,
        provider: Option<&Arc<dyn FontProvider>>,
    ) -> PageResources {
        let mut fonts = HashMap::new();
        let mut font_ids = HashMap::new();

        for (name, font) in cos_font::from_resources(doc, &dict) {
            if let Some(bytes) = doc.name_bytes(name) {
                let key = bytes.to_vec();
                let id = u64::from(name.id());
                font_ids.insert(key.clone(), id);
                fonts.insert(key, font);
            }
        }

        PageResources {
            doc: doc.clone(),
            fonts,
            font_ids,
            resources: Some(dict),
            caches: Arc::default(),
            missing_fonts: Mutex::new(Vec::new()),
            damaged_images: Mutex::new(Vec::new()),
            repaired_spaces: Mutex::new(Vec::new()),
            image_capture: Mutex::new(None),
            unresolved: Mutex::new(None),
            provider: provider.cloned(),
            optional: Arc::new(OptionalContent::bind(doc)),
        }
    }

    /// A pattern resource: its dictionary, and the object it lives in when it
    /// is an indirect one (8.7.3).
    ///
    /// The reference is what a *tiling* pattern needs and a shading pattern
    /// does not — type 1 is a stream and its cell is the stream's bytes, type 2
    /// is a dictionary that may perfectly well be written inline. So both come
    /// back, and both routes read the dictionary through the same lookup:
    /// `/PatternType` deciding the kind is the one thing they must agree on.
    fn pattern_entry(&self, name: &[u8]) -> Option<(Dict, Option<ObjRef>)> {
        let resources = self.resources.as_ref()?;
        let table = self.doc.resolve_key(resources, self.doc.intern(b"Pattern"));
        let table = table.as_dict()?;
        let key = self.doc.intern(name);
        let reference = table.get_ref(key);
        let entry = self.doc.resolve_key(table, key);
        Some((entry.as_dict()?.clone(), reference))
    }

    /// The stream of the tiling pattern `name` selects in this scope, whose
    /// bytes are its cell (8.7.3.2) — the stream [`GlyphSource::tile`]
    /// paints. `None` for a shading pattern, which has no cell, and for a
    /// name this scope does not have.
    ///
    /// For [`crate::subset`], whose walk has to enter a cell the interpreter
    /// never runs: the renderer paints it itself.
    pub(crate) fn tiling_cell(&self, name: &[u8]) -> Option<ObjRef> {
        let (dict, reference) = self.pattern_entry(name)?;
        let kind = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"PatternType"))
            .as_int();
        (kind == Some(1)).then_some(reference).flatten()
    }

    /// The scope a stream's own `/Resources` makes: a tiling pattern's, a
    /// mask group's or a form's, built as [`PageResources::from_dict`]
    /// builds any. `None` when the stream has none, and its names resolve
    /// where it was painted (8.7.3.2, 8.10.1).
    pub(crate) fn own_scope(&self, stream: ObjRef) -> Option<PageResources> {
        let object = self.doc.get(stream).ok()?;
        let own = self
            .doc
            .resolve_key(object.as_dict()?, Name::RESOURCES)
            .as_dict()?
            .clone();
        Some(PageResources::from_dict(
            &self.doc,
            own,
            self.provider.as_ref(),
        ))
    }

    /// A pattern's `/Matrix`, which maps pattern space to the parent content
    /// stream's default space (8.7.3.1).
    fn pattern_matrix(&self, dict: &Dict) -> Matrix {
        self.doc
            .resolve_key(dict, self.doc.intern(b"Matrix"))
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .collect::<Vec<f64>>()
            })
            .and_then(|v| {
                (v.len() >= 6 && v.iter().all(|x| x.is_finite())).then(|| Matrix {
                    a: v[0],
                    b: v[1],
                    c: v[2],
                    d: v[3],
                    e: v[4],
                    f: v[5],
                })
            })
            .unwrap_or(Matrix::IDENTITY)
    }

    /// A tiling pattern's geometry (8.7.3.2, Table 75).
    ///
    /// The cell's pixels are not read here: they are a content stream, and the
    /// renderer decides how large a buffer to draw it into and whether the
    /// lattice is affordable before anything is rasterized.
    fn tiling_pattern(&self, dict: &Dict, matrix: Matrix) -> PatternPaint {
        let number = |key: &[u8]| {
            self.doc
                .resolve_key(dict, self.doc.intern(key))
                .as_number()
                .filter(|v| v.is_finite())
        };

        // Required, and the cell has no extent without it. The corners may be
        // given in either order (7.9.5), as they may on a form's `/BBox`.
        let bbox = self
            .doc
            .resolve_key(dict, self.doc.intern(b"BBox"))
            .as_array()
            .and_then(|values| {
                let n = |i: usize| {
                    values
                        .get(i)
                        .and_then(|v| self.doc.resolve(v).as_number())
                        .filter(|v| v.is_finite())
                };
                let (x0, y0, x1, y1) = (n(0)?, n(1)?, n(2)?, n(3)?);
                Some([x0.min(x1), y0.min(y1), x0.max(x1), y0.max(y1)])
            });
        let Some(bbox) = bbox.filter(|b| b[2] > b[0] && b[3] > b[1]) else {
            return PatternPaint::Unsupported;
        };

        // 8.7.3.2: `/PaintType` 2 is the uncoloured pattern, which takes the
        // colour its `SCN` operands supplied. Anything that is not 2 is
        // coloured -- including a value the file got wrong, because a coloured
        // cell painted in its own colours is the reading that loses nothing.
        let uncolored = self
            .doc
            .resolve_key(dict, self.doc.intern(b"PaintType"))
            .as_int()
            .unwrap_or(1)
            == 2;

        PatternPaint::Tiling(Box::new(TilingPattern {
            matrix,
            bbox,
            // Absent or zero is invalid; the renderer falls back to the cell's
            // own size, which is the only reading that tiles.
            xstep: number(b"XStep").unwrap_or(0.0),
            ystep: number(b"YStep").unwrap_or(0.0),
            uncolored,
        }))
    }

    /// The `/Resources` a form XObject brings with it (8.10.1).
    ///
    /// A form written beside one document and pasted into another carries the
    /// only dictionary its names resolve in — which is why a stamp annotation
    /// whose appearance invokes a second form can name an image the page has
    /// never heard of. A form that omits the key resolves against the invoking
    /// scope, which is what its producer is relying on.
    ///
    /// The `provider` is carried into the nested scope for the reason the
    /// tiling path carries it: without it a form would be the one place in a
    /// document where a `FontProvider` the caller installed does not apply.
    fn form_resources(&self, name: &[u8]) -> Option<Arc<PageResources>> {
        let (dict, reference) = self.xobject(name)?;
        let key = (u64::from(reference.num) << 16) | u64::from(reference.gen);
        if let Ok(cache) = self.caches.form_scopes.lock() {
            if let Some(hit) = cache.get(&key) {
                return hit.clone();
            }
        }
        let built = self.build_form_resources(&dict);
        if let Ok(mut cache) = self.caches.form_scopes.lock() {
            cache.insert(key, built.clone());
        }
        built
    }

    fn build_form_resources(&self, dict: &Dict) -> Option<Arc<PageResources>> {
        let subtype = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Subtype"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n))?;
        if subtype.as_ref() != b"Form" {
            return None;
        }
        let own = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Resources"))
            .as_dict()
            .cloned()?;
        Some(Arc::new(PageResources::from_dict(
            &self.doc,
            own,
            self.provider.as_ref(),
        )))
    }

    /// Whether this scope's `/XObject` dictionary names `name` and, if it
    /// does, the XObject's `/Subtype` — `Some(None)` for one with none.
    ///
    /// The one question `Page::render_form` needs answered that `form` cannot:
    /// `form` answers `None` alike for a name that is not there, an image and a
    /// stream that will not decode, and a caller who asked for one form is owed
    /// the difference.
    pub(crate) fn xobject_subtype(&self, name: &[u8]) -> Option<Option<Vec<u8>>> {
        let (dict, _) = self.xobject(name)?;
        Some(
            self.doc
                .resolve_key(&dict, self.doc.intern(b"Subtype"))
                .as_name()
                .and_then(|n| self.doc.name_bytes(n))
                .map(|bytes| bytes.to_vec()),
        )
    }

    pub(crate) fn xobject(&self, name: &[u8]) -> Option<(Dict, tinker_pdf_cos::ObjRef)> {
        let resources = self.resources.as_ref()?;
        let value = self.doc.resolve_key(resources, self.doc.intern(b"XObject"));
        let dict = value.as_dict()?;
        let reference = dict.get_ref(self.doc.intern(name))?;
        let object = self.doc.get(reference).ok()?;
        let stream = object.as_dict()?.clone();
        Some((stream, reference))
    }

    /// The colour space a resource name selects (8.6.6).
    fn color_space(&self, name: &[u8]) -> Option<ColorSpace> {
        // The device spaces may be named directly without appearing in
        // /ColorSpace at all.
        match name {
            // A bare `/CalGray` or `/CalRGB` name carries no parameter
            // dictionary at all, so there is no white point or gamma to read
            // and the device space *is* the whole of what the file said.
            b"DeviceGray" | b"CalGray" => return Some(ColorSpace::DeviceGray),
            b"DeviceRGB" | b"CalRGB" => return Some(ColorSpace::DeviceRgb),
            b"DeviceCMYK" => return Some(ColorSpace::DeviceCmyk),
            b"Pattern" => return Some(ColorSpace::Pattern { base: None }),
            _ => {}
        }

        // `/G`, `/RGB` and `/CMYK` are Table 93's abbreviations, which an
        // inline image may use and a content stream's `cs` may not — 8.6.8
        // gives `cs` a device space's own name or a `/ColorSpace` resource,
        // and `/G` is a perfectly good resource name. So the resources are
        // asked first and the abbreviation is the fallback. Until October
        // 2026 the abbreviation won, and a page that registered its
        // `/CalGray` as `/G` was drawn in DeviceGray, gamma and white point
        // unread.
        let entry = self.resources.as_ref().and_then(|resources| {
            let table = self
                .doc
                .resolve_key(resources, self.doc.intern(b"ColorSpace"));
            table.as_dict()?.get(self.doc.intern(name)).cloned()
        });
        match entry {
            Some(entry) => self.parse_space(&entry, 0, name),
            None => match name {
                b"G" => Some(ColorSpace::DeviceGray),
                b"RGB" => Some(ColorSpace::DeviceRgb),
                b"CMYK" => Some(ColorSpace::DeviceCmyk),
                _ => None,
            },
        }
    }

    fn parse_space(&self, object: &Object, depth: u32, name: &[u8]) -> Option<ColorSpace> {
        if depth > 8 {
            return None;
        }
        let resolved = self.doc.resolve(object);

        if let Some(name) = resolved.as_name() {
            let bytes = self.doc.name_bytes(name)?;
            return match bytes.as_ref() {
                b"DeviceGray" | b"G" | b"CalGray" => Some(ColorSpace::DeviceGray),
                b"DeviceRGB" | b"RGB" | b"CalRGB" => Some(ColorSpace::DeviceRgb),
                b"DeviceCMYK" | b"CMYK" => Some(ColorSpace::DeviceCmyk),
                b"Pattern" => Some(ColorSpace::Pattern { base: None }),
                _ => None,
            };
        }

        let items = resolved.as_array()?;
        let family = items.first().and_then(Object::as_name)?;
        let family = self.doc.name_bytes(family)?;

        match family.as_ref() {
            b"ICCBased" => {
                let reference = items.get(1).and_then(Object::as_objref);
                let stream = items.get(1).map(|o| self.doc.resolve(o))?;
                let n = stream
                    .as_dict()
                    .and_then(|d| d.get_int(self.doc.intern(b"N")))
                    .unwrap_or(3);
                let components = n.clamp(1, 4) as usize;

                // The profile itself, if it can be read. Cached by object
                // number: a page naming the same space at a thousand `cs`
                // operators compiles it once.
                if let Some(reference) = reference {
                    if let Some(transform) = self.icc_transform(reference) {
                        return Some(ColorSpace::Icc {
                            transform,
                            components,
                        });
                    }
                }

                // 8.6.5.5: a reader may use the alternate space, and the
                // component count is what the data's shape actually is. This
                // is where a profile that would not parse lands, which is
                // exactly where it landed before profiles were read.
                Some(ColorSpace::Approximated { components })
            }
            b"Indexed" | b"I" => {
                let base = self.parse_space(items.get(1)?, depth + 1, name)?;
                let high = items.get(2).and_then(|o| self.doc.resolve(o).as_int())?;
                let lookup = match items.get(3).map(|o| self.doc.resolve(o)) {
                    Some(value) => match value.as_string() {
                        Some(s) => s.bytes.clone(),
                        None => items
                            .get(3)
                            .and_then(Object::as_objref)
                            .and_then(|r| self.doc.stream_decoded(r).ok())
                            .unwrap_or_default(),
                    },
                    None => Vec::new(),
                };
                Some(ColorSpace::Indexed {
                    base: Box::new(base),
                    lookup,
                    high: high.clamp(0, 255) as u32,
                })
            }
            b"Separation" | b"DeviceN" => {
                let components = if family.as_ref() == b"Separation" {
                    1
                } else {
                    self.doc
                        .resolve(items.get(1)?)
                        .as_array()
                        .map_or(1, <[Object]>::len)
                };
                let alternate = self.parse_space(items.get(2)?, depth + 1, name)?;

                // 8.6.6.4: the fourth element converts tint values into the
                // alternate space. Left as the identity, a one-ink Separation
                // feeds its tint straight into a CMYK alternate as cyan, so
                // full-tint black prints cyan — and nothing about the result
                // looks like a bug. Spot colours are everywhere in
                // print-origin files.
                let tint = items
                    .get(3)
                    .and_then(|o| self.parse_function(o, depth + 1))
                    .unwrap_or(Function::Identity);

                Some(ColorSpace::Separation {
                    components,
                    alternate: Box::new(alternate),
                    tint: Box::new(tint),
                })
            }
            // 8.7.3.2: `[/Pattern base]` is the *uncoloured* pattern space.
            // The second element is where the operands of an `scn` that names
            // a `PaintType 2` pattern are measured; a bare `/Pattern` has no
            // second element and no colour. Without this branch the array form
            // resolved to nothing at all, so `cs` left the slot in whatever
            // space preceded it and the operands were read against that.
            b"Pattern" => Some(ColorSpace::Pattern {
                base: items
                    .get(1)
                    .and_then(|o| self.parse_space(o, depth + 1, name))
                    .map(Box::new),
            }),
            // 8.6.5.2 and 8.6.5.3. These were aliased to the device spaces,
            // which read neither the white point nor the gamma and left
            // *nothing* recording that an approximation had happened — unlike
            // an ICC profile this build refuses, where `Approximated` says so
            // on the type.
            b"CalGray" => {
                let params = items.get(1).map(|o| self.doc.resolve(o));
                let dict = params.as_ref().and_then(|p| p.as_dict());
                let white = dict
                    .and_then(|d| self.numbers(d, b"WhitePoint", 3))
                    .map_or(WHITE_D50, |v| [v[0], v[1], v[2]]);
                let gamma = dict
                    .map(|d| self.doc.resolve_key(d, self.doc.intern(b"Gamma")))
                    .and_then(|g| g.as_number())
                    .unwrap_or(1.0);
                Some(ColorSpace::CalGray { white, gamma })
            }
            b"CalRGB" => {
                let params = items.get(1).map(|o| self.doc.resolve(o));
                let dict = params.as_ref().and_then(|p| p.as_dict());
                let white = dict
                    .and_then(|d| self.numbers(d, b"WhitePoint", 3))
                    .map_or(WHITE_D50, |v| [v[0], v[1], v[2]]);
                let gamma = dict
                    .and_then(|d| self.numbers(d, b"Gamma", 3))
                    .map_or([1.0; 3], |v| [v[0], v[1], v[2]]);
                let matrix = dict.and_then(|d| self.numbers(d, b"Matrix", 9)).map_or(
                    // Table 64's default is the identity, which makes the
                    // components XYZ directly.
                    [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                    |v| {
                        let mut m = [0.0; 9];
                        m.copy_from_slice(&v[..9]);
                        m
                    },
                );
                Some(ColorSpace::CalRgb {
                    white,
                    gamma,
                    matrix,
                })
            }
            // 8.6.5.4: L runs 0..100 and a/b roughly -128..127. Aliasing Lab
            // to RGB clamps every component into 0..1, which renders almost
            // the whole space black.
            b"Lab" => {
                let params = items.get(1).map(|o| self.doc.resolve(o));
                let range = params
                    .as_ref()
                    .and_then(|p| p.as_dict())
                    .map(|d| self.doc.resolve_key(d, self.doc.intern(b"Range")))
                    .and_then(|r| {
                        let values: Vec<f64> =
                            r.as_array()?.iter().filter_map(Object::as_number).collect();
                        (values.len() >= 4).then(|| [values[0], values[1], values[2], values[3]])
                    })
                    .unwrap_or([-100.0, 100.0, -100.0, 100.0]);
                // Table 65: `[amin amax bmin bmax]`. A pair written backwards
                // is read as the span it covers — `tinker_pdf_color`'s
                // `within`, which is what stopped it panicking — and that is a
                // leniency, so it is named (ruling 10).
                if range[0] > range[1] || range[2] > range[3] {
                    self.note_repaired_space((
                        String::from_utf8_lossy(name).into_owned(),
                        "LabRangeUnordered".to_string(),
                    ));
                }
                Some(ColorSpace::Lab { range })
            }
            _ => None,
        }
    }

    /// `count` numbers from a dictionary's array-valued key, or `None`.
    ///
    /// Shorter than `count` is `None` rather than a padded array: a
    /// `/WhitePoint` of two numbers is a dictionary that does not describe a
    /// white point, and the clause's default is a better answer than two of
    /// its three axes.
    fn numbers(&self, dict: &tinker_pdf_cos::Dict, key: &[u8], count: usize) -> Option<Vec<f64>> {
        let value = self.doc.resolve_key(dict, self.doc.intern(key));
        let values: Vec<f64> = value
            .as_array()?
            .iter()
            .filter_map(|o| self.doc.resolve(o).as_number())
            .collect();
        (values.len() >= count).then_some(values)
    }

    /// Reads a shading dictionary, wherever it was found.
    ///
    /// Split out of [`GlyphSource::shading`] so a shading *pattern* can reuse
    /// it on the dictionary it resolved itself, rather than duplicating the
    /// nine entries a shading is made of.
    ///
    /// `reference` is what the mesh types need and the gradient types do not:
    /// a type 4 to 7 shading is a **stream** (8.7.4.5.5), and its vertices are
    /// the stream's bytes. A mesh written as a direct dictionary has no
    /// vertices at all, which is reported rather than drawn as an empty area.
    fn read_shading(
        &self,
        dict: &Dict,
        reference: Option<ObjRef>,
        name: &[u8],
    ) -> Result<Option<Shading>, i64> {
        let kind = self
            .doc
            .resolve_key(dict, self.doc.intern(b"ShadingType"))
            .as_int()
            .unwrap_or(0);

        let space = self.doc.resolve_key(dict, self.doc.intern(b"ColorSpace"));
        let space = self
            .parse_space(&space, 0, name)
            .unwrap_or(ColorSpace::DeviceRgb);
        let function = self.function(dict).unwrap_or(Function::Identity);

        let coords = self.doc.resolve_key(dict, self.doc.intern(b"Coords"));
        let coords: Vec<f64> = coords
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .collect()
            })
            .unwrap_or_default();

        let extend = self.doc.resolve_key(dict, self.doc.intern(b"Extend"));
        let extend = extend
            .as_array()
            .map(|a| {
                (
                    a.first().and_then(Object::as_bool).unwrap_or(false),
                    a.get(1).and_then(Object::as_bool).unwrap_or(false),
                )
            })
            .unwrap_or((false, false));

        match kind {
            1 => {
                let domain = self.doc.resolve_key(dict, self.doc.intern(b"Domain"));
                let domain: Vec<f64> = domain
                    .as_array()
                    .map(|a| {
                        a.iter()
                            .filter_map(|o| self.doc.resolve(o).as_number())
                            .collect()
                    })
                    .unwrap_or_default();
                let d = |i: usize, fallback: f64| domain.get(i).copied().unwrap_or(fallback);
                Ok(Some(Shading::FunctionBased {
                    space,
                    function,
                    domain: [d(0, 0.0), d(1, 1.0), d(2, 0.0), d(3, 1.0)],
                }))
            }
            2 if coords.len() >= 4 => Ok(Some(Shading::Axial {
                space,
                function,
                coords: [coords[0], coords[1], coords[2], coords[3]],
                extend,
            })),
            3 if coords.len() >= 6 => Ok(Some(Shading::Radial {
                space,
                function,
                coords: [
                    coords[0], coords[1], coords[2], coords[3], coords[4], coords[5],
                ],
                extend,
            })),
            4..=7 => match self.read_mesh(dict, reference, kind, space, function) {
                Some(mesh) => Ok(Some(Shading::Mesh(Box::new(mesh)))),
                // Ruling 2 and ruling 10: nothing is painted and the type is
                // named, which is the degradation this path has always had.
                None => Err(kind),
            },
            _ => Ok(None),
        }
    }

    /// A mesh shading's vertex stream and the six keys that say how it is
    /// packed (8.7.4.5.5 to 8.7.4.5.8, Tables 79 to 82).
    fn read_mesh(
        &self,
        dict: &Dict,
        reference: Option<ObjRef>,
        kind: i64,
        space: ColorSpace,
        function: Function,
    ) -> Option<Mesh> {
        let data = self.doc.stream_decoded(reference?).ok()?;

        let integer = |key: &[u8]| {
            self.doc
                .resolve_key(dict, self.doc.intern(key))
                .as_int()
                .unwrap_or(0)
        };
        let width = |key: &[u8]| u32::try_from(integer(key)).unwrap_or(0);

        // 8.7.4.5.5: with a `/Function` each vertex carries one parametric
        // value and the function turns it into a colour, so the component
        // count is 1 rather than the space's. Reading the space's count
        // instead cuts the stream up wrongly from the first vertex on.
        let has_function = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Function"))
            .as_dict()
            .is_some()
            || self
                .doc
                .resolve_key(dict, self.doc.intern(b"Function"))
                .as_array()
                .is_some();
        let components = if has_function { 1 } else { space.components() };

        let decode = self.doc.resolve_key(dict, self.doc.intern(b"Decode"));
        let decode: Vec<(f64, f64)> = decode
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .filter(|v| v.is_finite())
                    .collect::<Vec<f64>>()
            })
            .unwrap_or_default()
            .chunks_exact(2)
            .map(|pair| (pair[0], pair[1]))
            .collect();

        let params = MeshParams {
            kind,
            bits_per_coordinate: width(b"BitsPerCoordinate"),
            bits_per_component: width(b"BitsPerComponent"),
            bits_per_flag: width(b"BitsPerFlag"),
            decode,
            vertices_per_row: width(b"VerticesPerRow"),
            components,
        };
        let mesh = tinker_pdf_render::mesh::read_mesh(
            &params,
            &data,
            space,
            has_function.then_some(function),
        )?;
        (!mesh.is_empty()).then_some(mesh)
    }
}

/// The embedded font program of a font resource, if it has one (9.9).
/// The font program to draw a font's glyphs with: the embedded one, or a
/// substitute the host supplied.
///
/// The document's own program always wins. A substitute is a different face
/// with different outlines, and preferring it over what the file carries
/// would change how a correctly embedded document looks.
fn program_for(
    doc: &CosDocument,
    name: &[u8],
    resources: &Dict,
    font: &cos_font::Font,
    provider: Option<&dyn FontProvider>,
) -> Option<Arc<Vec<u8>>> {
    if let Some(embedded) = embedded_program(doc, name, resources) {
        return Some(Arc::new(embedded));
    }

    let provider = provider?;
    if !fonts::is_substitutable(font) {
        return None;
    }
    let dict = fonts::font_dict(doc, resources, name)?;
    provider.substitute(&FontRequest::read(doc, &dict))
}

fn embedded_program(doc: &CosDocument, name: &[u8], resources: &Dict) -> Option<Vec<u8>> {
    let fonts = doc.resolve_key(resources, doc.intern(b"Font"));
    let dict = fonts.as_dict()?;
    let font = doc.resolve_key(dict, doc.intern(name));
    let mut font = font.as_dict()?.clone();

    // A composite font keeps its program on the descendant.
    let descendants = doc.resolve_key(&font, doc.intern(b"DescendantFonts"));
    if let Some(first) = descendants.as_array().and_then(<[Object]>::first) {
        if let Some(dict) = doc.resolve(first).as_dict() {
            font = dict.clone();
        }
    }

    let descriptor = doc.resolve_key(&font, doc.intern(b"FontDescriptor"));
    let descriptor = descriptor.as_dict()?;

    for key in [b"FontFile2".as_slice(), b"FontFile3", b"FontFile"] {
        if let Some(reference) = descriptor.get_ref(doc.intern(key)) {
            if let Ok(bytes) = doc.stream_decoded(reference) {
                if !bytes.is_empty() {
                    return Some(bytes);
                }
            }
        }
    }
    None
}

impl FontSource for PageResources {
    fn decode(&self, font: &[u8], bytes: &[u8]) -> Vec<(u32, String, f64)> {
        let Some(found) = self.fonts.get(font) else {
            // A name the resource dictionary does not define. Recorded so a
            // caller can tell "this page has no text" from "this page has text
            // whose font this build could not resolve".
            if let Ok(mut missing) = self.missing_fonts.lock() {
                let name = String::from_utf8_lossy(font).into_owned();
                if missing.len() < 64 && !missing.contains(&name) {
                    missing.push(name);
                }
            }
            return Vec::new();
        };
        let font = found;
        font.decode(bytes)
            .into_iter()
            .map(|d| (d.code, d.text, d.width))
            .collect()
    }

    fn is_vertical(&self, font: &[u8]) -> bool {
        self.fonts.get(font).is_some_and(|f| f.is_vertical())
    }

    fn vertical_metrics(&self, font: &[u8], code: u32) -> (f64, f64, f64) {
        let Some(found) = self.fonts.get(font) else {
            // Unreachable in practice: an unresolved font decodes to no codes
            // at all, so nothing is ever shown to ask about. 9.7.4.3's default
            // rather than a zero displacement, so that a future caller getting
            // here still advances.
            return (0.0, 880.0, -1000.0);
        };
        // 9.7.4.3 keys /W2 by CID, and this is the same `cid_of` the advance
        // goes through — so the displacement and the position vector cannot
        // end up describing a different CID from the glyph that is drawn.
        found.vertical_metrics(found.cid_of(code))
    }

    fn font_id(&self, font: &[u8]) -> u64 {
        self.font_ids.get(font).copied().unwrap_or(0)
    }

    /// `/BaseFont` as the dictionary writes it; `None` for a name this scope
    /// does not define and for a font that states none (a Type 3 font may
    /// omit it, 9.6.5 Table 110).
    fn font_name(&self, font: &[u8]) -> Option<Arc<str>> {
        let name = self.fonts.get(font)?.base_font();
        (!name.is_empty()).then(|| Arc::from(name))
    }

    fn type3_glyph(&self, font: &[u8], code: u32) -> Option<(Vec<u8>, Matrix)> {
        // 9.6.5: only a Type 3 font has glyph procedures. Every other kind
        // returns None here, which leaves the ordinary outline path untouched.
        let dict = fonts::font_dict(&self.doc, self.resources.as_ref()?, font)?;
        let subtype = dict
            .get_name(self.doc.intern(b"Subtype"))
            .and_then(|n| self.doc.name_bytes(n))?;
        if subtype.as_ref() != b"Type3" {
            return None;
        }

        // A Type 3 font addresses its procedures by name, and the only way to
        // get one is the /Encoding /Differences array — there is no built-in
        // encoding for a font whose glyphs the document invented.
        let encoding = self.doc.resolve_key(&dict, self.doc.intern(b"Encoding"));
        let differences = self
            .doc
            .resolve_key(encoding.as_dict()?, self.doc.intern(b"Differences"));
        let differences = differences.as_array()?;

        let mut current = 0u32;
        let mut name: Option<Name> = None;
        for item in differences {
            match self.doc.resolve(item).as_ref() {
                Object::Int(v) => current = u32::try_from(*v).unwrap_or(0),
                Object::Real(v) => current = *v as u32,
                Object::Name(n) => {
                    if current == code {
                        name = Some(*n);
                        break;
                    }
                    current = current.saturating_add(1);
                }
                _ => {}
            }
        }
        let name = name?;

        let procs = self.doc.resolve_key(&dict, self.doc.intern(b"CharProcs"));
        let reference = procs.as_dict()?.get_ref(name)?;
        let content = self.doc.stream_decoded(reference).ok()?;

        // 9.6.5: /FontMatrix maps glyph space to text space. Unlike every
        // other font it is not 1/1000 by convention — a Type 3 font chooses
        // its own units, and the matrix is required for that reason.
        let matrix = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"FontMatrix"))
            .as_array()
            .and_then(|values| {
                let n = |i: usize| values.get(i).and_then(Object::as_number);
                Some(Matrix {
                    a: n(0)?,
                    b: n(1)?,
                    c: n(2)?,
                    d: n(3)?,
                    e: n(4)?,
                    f: n(5)?,
                })
            })?;

        Some((content, matrix))
    }

    fn form_scope(&self, name: &[u8]) -> Option<Arc<PageResources>> {
        self.form_resources(name)
    }

    fn form(&self, name: &[u8]) -> Option<tinker_pdf_content::Form> {
        let (dict, reference) = self.xobject(name)?;
        let subtype = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"Subtype"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n))?;
        if subtype.as_ref() != b"Form" {
            return None;
        }
        self.form_from(&dict, reference, name)
    }

    fn resolve_color(&self, space: &[u8], components: &[f64]) -> Option<Rgb> {
        let space = self.color_space(space)?;
        let (r, g, b) = space.to_rgb(components);
        Some(Rgb { r, g, b })
    }

    fn color_components(&self, space: &[u8]) -> Option<usize> {
        Some(self.color_space(space)?.components())
    }

    fn resolve_ink(&self, space: &[u8], components: &[f64]) -> Option<[u8; 4]> {
        // 8.6.4.4: DeviceCMYK's own components, clamped as `to_rgb` clamps
        // them. Every other space — an ICC CMYK profile included, whose
        // components are a profile's to interpret — stays light.
        if self.color_space(space)? != ColorSpace::DeviceCmyk {
            return None;
        }
        let byte = |i: usize| {
            let v = components.get(i).copied().unwrap_or(0.0);
            if v.is_finite() {
                (v.clamp(0.0, 1.0) * 255.0).round() as u8
            } else {
                0
            }
        };
        Some([byte(0), byte(1), byte(2), byte(3)])
    }

    fn initial_color(&self, space: &[u8]) -> Option<Vec<f64>> {
        Some(self.color_space(space)?.initial())
    }

    fn ext_g_state_alpha(&self, name: &[u8]) -> Option<(Option<f64>, Option<f64>)> {
        let resources = self.resources.as_ref()?;
        let table = self
            .doc
            .resolve_key(resources, self.doc.intern(b"ExtGState"));
        let entry = self
            .doc
            .resolve_key(table.as_dict()?, self.doc.intern(name));
        let dict = entry.as_dict()?;

        // 8.4.5 Table 58: `ca` is the non-stroking alpha, `CA` the stroking.
        let fill = self
            .doc
            .resolve_key(dict, self.doc.intern(b"ca"))
            .as_number();
        let stroke = self
            .doc
            .resolve_key(dict, self.doc.intern(b"CA"))
            .as_number();
        (fill.is_some() || stroke.is_some()).then_some((fill, stroke))
    }

    fn ext_g_state_blend(&self, name: &[u8]) -> Option<tinker_pdf_content::BlendMode> {
        let resources = self.resources.as_ref()?;
        let table = self
            .doc
            .resolve_key(resources, self.doc.intern(b"ExtGState"));
        let entry = self
            .doc
            .resolve_key(table.as_dict()?, self.doc.intern(name));
        let dict = entry.as_dict()?;

        // 11.3.5: /BM is a name, or an array of names offering fallbacks.
        let value = self.doc.resolve_key(dict, self.doc.intern(b"BM"));
        if let Some(name) = value.as_name().and_then(|n| self.doc.name_bytes(n)) {
            return Some(tinker_pdf_content::BlendMode::from_name(&name));
        }
        let names: Vec<Vec<u8>> = value
            .as_array()?
            .iter()
            .filter_map(|item| self.doc.resolve(item).as_name())
            .filter_map(|n| self.doc.name_bytes(n))
            .map(|n| n.to_vec())
            .collect();
        (!names.is_empty())
            .then(|| tinker_pdf_content::BlendMode::from_names(names.iter().map(Vec::as_slice)))
    }

    fn ext_g_state_soft_mask(&self, name: &[u8]) -> Option<tinker_pdf_content::SoftMask> {
        let resources = self.resources.as_ref()?;
        let table = self
            .doc
            .resolve_key(resources, self.doc.intern(b"ExtGState"));
        let entry = self
            .doc
            .resolve_key(table.as_dict()?, self.doc.intern(name));
        let dict = entry.as_dict()?;

        // 11.6.5.1: `/SMask` is either the name `/None` or a mask dictionary.
        // The key being absent is *not* the same as `/None` — the first
        // leaves whatever mask is in force alone, the second removes it —
        // which is why the whole method returns an `Option` of an enum rather
        // than an `Option` of a mask.
        let value = self.doc.resolve_key(dict, self.doc.intern(b"SMask"));
        if let Some(name) = value.as_name().and_then(|n| self.doc.name_bytes(n)) {
            return (name.as_ref() == b"None").then_some(tinker_pdf_content::SoftMask::None);
        }
        let mask = value.as_dict()?;

        // `/G` is required, and is a form XObject with a transparency group.
        let reference = mask.get_ref(self.doc.intern(b"G"))?;
        let group_dict = self.doc.get(reference).ok()?.as_dict()?.clone();
        let form = self.form_from(&group_dict, reference, name)?;

        // 11.6.5.2: `/S` selects what the rendered group is read as. A name
        // this build does not know is `/Alpha`'s opposite rather than an
        // error, because `/Luminosity` is overwhelmingly the one in the wild
        // and a mask that fails to parse is a mask that hides nothing.
        let luminosity = self
            .doc
            .resolve_key(mask, self.doc.intern(b"S"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n))
            .is_none_or(|s| s.as_ref() != b"Alpha");

        // `/BC` is in the group's own colour space, which is `/Group /CS` on
        // `/G`. Without one the components are read by count, which is what
        // every other unnamed space in this engine does.
        let backdrop = self
            .doc
            .resolve_key(mask, self.doc.intern(b"BC"))
            .as_array()
            .map(|values| {
                let components: Vec<f64> = values
                    .iter()
                    .filter_map(|v| self.doc.resolve(v).as_number())
                    .collect();
                let space = self
                    .doc
                    .resolve_key(&group_dict, self.doc.intern(b"Group"))
                    .as_dict()
                    .and_then(|g| g.get(self.doc.intern(b"CS")).cloned())
                    .and_then(|cs| self.parse_space(&cs, 0, name));
                let (r, g, b) = match space {
                    Some(space) => space.to_rgb(&components),
                    None => by_component_count(&components),
                };
                Rgb { r, g, b }
            });

        // 11.6.5.2: `/TR` is a function, or the name `/Identity`. A name is
        // the identity whatever it says, because the only alternative a
        // reader has for an unknown one is to mask nothing.
        let transfer = self
            .doc
            .resolve_key(mask, self.doc.intern(b"TR"))
            .as_dict()
            .and_then(|_| {
                let entry = self.doc.resolve_key(mask, self.doc.intern(b"TR"));
                self.parse_function(&entry, 0)
            })
            .map(|function| sample_transfer(&function));

        Some(tinker_pdf_content::SoftMask::Group(Box::new(
            tinker_pdf_content::MaskGroup {
                form,
                luminosity,
                backdrop,
                transfer,
            },
        )))
    }

    fn optional_content(&self, name: &[u8]) -> Option<Layer> {
        // 8.11.3.2: `/OC /MC0 BDC` names an entry in the /Properties
        // sub-dictionary of the current resource dictionary. The entry is an
        // optional content group or a membership dictionary; anything else is
        // an ordinary property list and hides nothing.
        // The table and the entry are read where they lie, as
        // `with_property_list` reads them: every `/OC` `BDC` asks.
        let resources = self.resources.as_ref()?;
        let table = resources.get(self.doc.intern(b"Properties"))?;
        read_resolved(&self.doc, table, |table| {
            let entry = table.as_dict()?.get(self.doc.intern(name))?;
            let label = String::from_utf8_lossy(name).into_owned();
            Some(self.optional.layer_of(&self.doc, entry, &label))
        })
    }

    fn xobject_optional_content(&self, name: &[u8]) -> Option<Layer> {
        // 8.11.4.4: an /OC entry on a form or image XObject hides the whole
        // XObject, and is read from the XObject's own dictionary rather than
        // from /Properties.
        let (dict, _) = self.xobject(name)?;
        let entry = dict.get(self.doc.intern(b"OC"))?.clone();
        let label = String::from_utf8_lossy(name).into_owned();
        Some(self.optional.layer_of(&self.doc, &entry, &label))
    }

    fn marked_content_properties(&self, name: &[u8]) -> Option<MarkedProps> {
        // 14.6.2: `/P /MC0 BDC` names an entry in the same /Properties
        // sub-dictionary `optional_content` reads. This is the COS half of
        // the seam — the interpreter never sees a dictionary — and it is the
        // reason the inline and named forms arrive at a device
        // indistinguishable from each other.
        let props = self.with_property_list(name, |dict| self.marked_props(name, dict))?;
        // An `/OC` group, a `/Type /Pagination` artifact list, a producer's
        // private dictionary: every one of them reaches here and says nothing
        // 14.6.2 or 14.9 defines. `None` rather than an empty struct, so the
        // interpreter's own filter and this one cannot disagree.
        (!props.is_empty()).then_some(props)
    }
}

impl PageResources {
    /// What the property list `dict`, named `name`, says to a device: the
    /// body of [`FontSource::marked_content_properties`], run on the list
    /// where it lies.
    fn marked_props(&self, name: &[u8], dict: &Dict) -> MarkedProps {
        // 14.7.4.2: a non-negative integer. Resolved because 7.3.10 lets any
        // value in a *file* dictionary be indirect — which is exactly the
        // difference between this form and the inline one, where it cannot
        // be. Every value here is read where it lies (`read_key`), as the
        // list is: a copy of one is its size at every `BDC`.
        let mcid =
            read_key(&self.doc, dict, b"MCID", Object::as_int).and_then(|n| u32::try_from(n).ok());

        let text = |key: &[u8]| {
            read_key(&self.doc, dict, key, |value| {
                value.as_string().map(|s| decode_text_string(&s.bytes))
            })
        };

        MarkedProps {
            mcid,
            actual_text: text(b"ActualText"),
            alt: text(b"Alt"),
            lang: text(b"Lang"),
            expansion: text(b"E"),
            // 14.7.4.2's stream half of the identifier is not in the property
            // list and cannot be: it is which stream the `BDC` was written
            // in, which only the interpreter knows. It stamps this on the way
            // past.
            stream: 0,
            // ISO 32000-2 14.13.5, Table 409a as the approved errata add it:
            // a named list with an `/MCAF` array associates files with an
            // `/AF` sequence. The name is handed on, not the files, which
            // `Page::marked_content_associated_files` reads in this scope.
            // Asked whether it is an array where it lies, since a direct
            // `/MCAF` is the list's own and as long as the file makes it.
            associated_files: read_key(&self.doc, dict, b"MCAF", |mcaf| mcaf.as_array().is_some())
                .then(|| name.to_vec()),
        }
    }
}

impl GlyphSource for PageResources {
    fn form_scope(&self, name: &[u8]) -> Option<Arc<PageResources>> {
        self.form_resources(name)
    }

    fn outline(&self, font_id: u64, code: u32) -> Option<Outline> {
        if let Ok(cache) = self.caches.outlines.read() {
            if let Some((hit, unresolved)) = cache.get(&(font_id, code)) {
                // What the extraction reported, reported again: this render
                // met the glyph too, and a render of its own would have.
                if let Some(name) = unresolved {
                    self.note_missing_font(name.clone());
                }
                return hit.as_ref().map(|o| (**o).clone());
            }
        }

        if let Ok(mut marker) = self.unresolved.lock() {
            *marker = None;
        }
        let outline = self.extract_outline(font_id, code).map(Arc::new);
        let unresolved = self
            .unresolved
            .lock()
            .ok()
            .and_then(|mut marker| marker.take());
        if let Ok(mut cache) = self.caches.outlines.write() {
            // Bounded: a hostile document could ask for millions of codes.
            if cache.len() < 1 << 16 {
                cache.insert((font_id, code), (outline.clone(), unresolved));
            }
        }
        outline.map(|o| (*o).clone())
    }

    fn shading(&self, name: &[u8]) -> Result<Option<Shading>, i64> {
        let Some(resources) = self.resources.as_ref() else {
            return Ok(None);
        };
        let table = self.doc.resolve_key(resources, self.doc.intern(b"Shading"));
        let Some(table) = table.as_dict() else {
            return Ok(None);
        };
        let key = self.doc.intern(name);
        let reference = table.get_ref(key);
        let entry = self.doc.resolve_key(table, key);
        let Some(dict) = entry.as_dict() else {
            return Ok(None);
        };

        self.read_shading(dict, reference, name)
    }

    fn pattern(&self, name: &[u8]) -> Option<PatternPaint> {
        let (dict, _) = self.pattern_entry(name)?;

        // 8.7.3.3: type 1 is a tiling pattern, type 2 a shading pattern.
        let kind = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"PatternType"))
            .as_int()
            .unwrap_or(0);
        // 8.7.3.1: the pattern matrix maps pattern space to the *default*
        // space of the parent content stream, so the CTM in force at fill time
        // is not part of it. Shared by both kinds, because two readers of one
        // key is how the anchoring comes to be right on one route and wrong on
        // the other.
        let matrix = self.pattern_matrix(&dict);

        match kind {
            1 => Some(self.tiling_pattern(&dict, matrix)),
            2 => {
                let key = self.doc.intern(b"Shading");
                let reference = dict.get_ref(key);
                let shading = self.doc.resolve_key(&dict, key);
                let shading = shading.as_dict()?;
                // A mesh that cannot be read at all is as unpaintable inside a
                // pattern as anywhere else, and reports as an unpainted
                // pattern rather than as a missing one.
                let Ok(Some(shading)) = self.read_shading(shading, reference, name) else {
                    return Some(PatternPaint::Unsupported);
                };
                Some(PatternPaint::Shading(Box::new(shading), matrix))
            }
            _ => Some(PatternPaint::Unsupported),
        }
    }

    fn tile(
        &self,
        name: &[u8],
        request: &tinker_pdf_render::TileRequest,
    ) -> Option<tinker_pdf_render::Tile> {
        let (dict, reference) = self.pattern_entry(name)?;
        // A tiling pattern is a *stream* (8.7.3.2, Table 75): its cell is a
        // content stream. A direct dictionary carrying the keys but no stream
        // has no cell to draw, and declining here is what turns it back into
        // the reported gap it was.
        let content = self.doc.stream_decoded(reference?).ok()?;

        // 8.7.3.2: the cell's own `/Resources`. Gap 11 recorded that a *form*
        // XObject's `/Resources` are consulted nowhere in this engine; a
        // pattern's are, because a cell that names `/F0` almost always means a
        // font the page never heard of — a pattern is a self-contained
        // drawing, where a form is usually written beside the page that
        // invokes it.
        let own = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"Resources"))
            .as_dict()
            .cloned();
        let nested;
        let resources: &PageResources = match own {
            Some(dict) => {
                nested = PageResources::from_dict(&self.doc, dict, self.provider.as_ref());
                &nested
            }
            // Falling back to the page's is what a producer that omits the key
            // is relying on, and it is what every reader does.
            None => self,
        };

        let canvas = Canvas::new(
            request.width,
            request.height,
            request.format,
            Color::TRANSPARENT,
        );
        let mut renderer = tinker_pdf_render::Renderer::new(canvas, request.to_pixels, resources)
            .with_cancel(request.cancel.clone())
            .with_pattern_depth(request.depth)
            .with_antialias(request.antialias);

        // 8.7.3.2: the cell is clipped to its `/BBox`. The buffer is already
        // that box rounded outward, so this only takes back the part of a
        // pixel the rounding gave away -- but a hatch is normally drawn with a
        // line width that deliberately runs past the box so neighbouring cells
        // join, and without the clip that overshoot lands in the next cell's
        // gap.
        let [x0, y0, x1, y1] = request.bbox;
        let box_path = [
            PathSegment::MoveTo { x: x0, y: y0 },
            PathSegment::LineTo { x: x1, y: y0 },
            PathSegment::LineTo { x: x1, y: y1 },
            PathSegment::LineTo { x: x0, y: y1 },
            PathSegment::Close,
        ];
        // Pattern space, because `to_pixels` is the renderer's `base` and the
        // interpreter's CTM starts at the identity below.
        let state = tinker_pdf_content::GraphicsState::new(Matrix::IDENTITY);
        renderer.clip_path(&box_path, &state, false);

        tinker_pdf_content::interpret(&content, Matrix::IDENTITY, &mut renderer, resources);
        let (mut canvas, warnings) = renderer.finish();

        // 8.7.3.3: `PaintType 2`. The cell is a shape and the colour comes
        // from the `SCN` operands, so whatever the content stream said about
        // colour is discarded here rather than intercepted at every paint --
        // which is what makes "colour operators inside it are ignored" true of
        // operators this engine has not implemented yet as well.
        if let Some((r, g, b)) = request.color {
            canvas.recolor(Color::rgb(r, g, b));
        }

        // Ruling 10, and only reachable when the cell had resources of its
        // own: a font the cell could not resolve, or an image it had to
        // tolerate, is a fact about the page and the page is the only place a
        // caller looks.
        if !std::ptr::eq(resources, self) {
            if let (Ok(mut mine), names) = (self.missing_fonts.lock(), resources.missing_fonts()) {
                for name in names {
                    if mine.len() < 64 && !mine.contains(&name) {
                        mine.push(name);
                    }
                }
            }
            if let Ok(mut mine) = self.damaged_images.lock() {
                for entry in resources.damaged_images() {
                    if !mine.contains(&entry) {
                        mine.push(entry);
                    }
                }
            }
            for entry in resources.repaired_spaces() {
                self.note_repaired_space(entry);
            }
        }

        Some(tinker_pdf_render::Tile { canvas, warnings })
    }

    fn inline_image(&self, dict: &[u8], data: &[u8]) -> Result<Option<DecodedImage>, String> {
        let text = expand_inline_abbreviations(dict);

        let mut sink = tinker_pdf_cos::WarningSink::new();
        let parsed = tinker_pdf_cos::parse_object_at(&text, 0, self.doc.names_table(), &mut sink);
        let Some(dict) = parsed.object.as_dict() else {
            return Ok(None);
        };

        self.decode_inline(dict, data).map(Some)
    }

    fn image(&self, name: &[u8]) -> Result<Option<DecodedImage>, String> {
        if let Ok(cache) = self.caches.images.lock() {
            if let Some(hit) = cache.get(name) {
                // What the decode said, said again: a render that meets the
                // image here met it as surely as the one that decoded it.
                for entry in &hit.damage {
                    self.note_damaged_image(entry.clone());
                }
                for entry in &hit.repairs {
                    self.note_repaired_space(entry.clone());
                }
                return match &hit.image {
                    Ok(image) => Ok(Some((**image).clone())),
                    Err(codec) => Err(codec.clone()),
                };
            }
        }

        let label = String::from_utf8_lossy(name).into_owned();
        let decoded = self.decode_image(name);
        // The damage this decode reported: every entry under this name, which
        // only this image's decode (and its soft mask's, part of it) writes.
        let damage: Vec<(String, String)> = self
            .damaged_images
            .lock()
            .map(|damaged| {
                damaged
                    .iter()
                    .filter(|(named, _)| *named == label)
                    .cloned()
                    .collect()
            })
            .unwrap_or_default();
        // And the repairs, by the same rule: the decode names its colour
        // space by the image's name.
        let repairs: Vec<(String, String)> = self
            .repaired_spaces()
            .into_iter()
            .filter(|(named, _)| *named == label)
            .collect();
        let image = match &decoded {
            Ok(image) => Ok(Arc::new(image.clone())),
            Err(codec) => Err(codec.clone()),
        };
        if let Ok(mut cache) = self.caches.images.lock() {
            if cache.len() < 256 {
                cache.insert(
                    name.to_vec(),
                    CachedImage {
                        image,
                        damage,
                        repairs,
                    },
                );
            }
        }
        decoded.map(Some)
    }
}

impl PageResources {
    /// The `/DecodeParms` of a stream, which may be one dictionary or an
    /// array with one entry per filter (7.4.1).
    /// A form XObject read from its own dictionary.
    ///
    /// Split out of [`FontSource::form`] because an ExtGState `/SMask`
    /// reaches a form through `/G` rather than through the `/XObject`
    /// resource table, and a second reader for the same dictionary is how
    /// `/Matrix` or `/BBox` comes to be honoured on one route and not the
    /// other.
    fn form_from(
        &self,
        dict: &Dict,
        reference: ObjRef,
        name: &[u8],
    ) -> Option<tinker_pdf_content::Form> {
        let content = self.doc.stream_decoded(reference).ok()?;
        // 8.10.2: /Matrix maps the form's space into the one that invoked it.
        let matrix = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Matrix"))
            .as_array()
            .and_then(|values| {
                let n = |i: usize| values.get(i).and_then(Object::as_number);
                Some(Matrix {
                    a: n(0)?,
                    b: n(1)?,
                    c: n(2)?,
                    d: n(3)?,
                    e: n(4)?,
                    f: n(5)?,
                })
            })
            .unwrap_or(Matrix::IDENTITY);

        // 8.10.2 requires it; a file that omits it gets an unclipped form
        // rather than no form.
        let bbox = self
            .doc
            .resolve_key(dict, self.doc.intern(b"BBox"))
            .as_array()
            .and_then(|values| {
                let n = |i: usize| values.get(i).and_then(|v| self.doc.resolve(v).as_number());
                // The corners may be given in either order (7.9.5).
                let (x0, y0, x1, y1) = (n(0)?, n(1)?, n(2)?, n(3)?);
                Some([x0.min(x1), y0.min(y1), x0.max(x1), y0.max(y1)])
            });

        // 11.6.6: `/Group` with `/S /Transparency` makes the form a
        // transparency group, which is composited as a unit rather than
        // element by element. Any other subtype — 8.10.3's `/S /Reference`
        // group — is not one, so the name is checked rather than the key's
        // presence.
        let group = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Group"))
            .as_dict()
            .and_then(|group| {
                let subtype = self
                    .doc
                    .resolve_key(group, self.doc.intern(b"S"))
                    .as_name()
                    .and_then(|n| self.doc.name_bytes(n))?;
                if subtype.as_ref() != b"Transparency" {
                    return None;
                }
                // 11.6.6 Table 147: both default to false, and a value that is
                // not a boolean is not a value.
                Some(tinker_pdf_content::Group {
                    isolated: self
                        .doc
                        .resolve_key(group, self.doc.intern(b"I"))
                        .as_bool()
                        .unwrap_or(false),
                    knockout: self
                        .doc
                        .resolve_key(group, self.doc.intern(b"K"))
                        .as_bool()
                        .unwrap_or(false),
                    // 11.6.6: `/CS` names the space the group's contents are
                    // composited in. Resolved through the same seam every
                    // other colour space goes through — the `/BC` backdrop of
                    // a luminosity soft mask already read this key, and read
                    // it this way — then reduced to the shape a compositor
                    // needs.
                    space: group
                        .get(self.doc.intern(b"CS"))
                        .cloned()
                        .and_then(|cs| self.parse_space(&cs, 0, name))
                        .map(group_space),
                })
            });

        Some(tinker_pdf_content::Form {
            content,
            matrix,
            bbox,
            group,
            // 14.7.4.2: the stream's own identity, which is the half of a
            // marked-content identifier the `/MCID` does not carry. Both
            // routes into a form arrive here, so the `/XObject` table and a
            // soft mask's `/G` cannot come to disagree about it.
            stream: crate::structure::stream_id(reference),
        })
    }

    fn decode_parms(&self, dict: &Dict) -> Option<Dict> {
        let value = self.doc.resolve_key(dict, Name::DECODE_PARMS);
        if let Some(d) = value.as_dict() {
            return Some(d.clone());
        }
        // The last filter's parameters are the ones an image codec wants.
        let items = value.as_array()?;
        items
            .iter()
            .rev()
            .find_map(|o| self.doc.resolve(o).as_dict().cloned())
    }

    /// Reads a `/Function` entry, which is one function or an array of them,
    /// one per output component (7.10).
    fn function(&self, dict: &Dict) -> Option<Function> {
        let key = self.doc.intern(b"Function");
        let value = self.doc.resolve_key(dict, key);
        if let Some(items) = value.as_array() {
            // 7.10.1: every member supplies one output component. Reading only
            // the first turns an RGB gradient into a red ramp on black, and
            // does it silently — a one-output function is valid on its own, so
            // nothing downstream can tell the difference.
            let parsed: Vec<Function> = items
                .iter()
                .filter_map(|o| self.parse_function(o, 0))
                .collect();
            return match parsed.len() {
                0 => None,
                1 => parsed.into_iter().next(),
                _ => Some(Function::Array(parsed)),
            };
        }
        // The entry **as written**, not resolved: a type 0 or type 4 function
        // is a stream (7.10.2, 7.10.5), which `parse_function` reaches through
        // its reference — and handed the resolved object it found no reference
        // and read nothing, so every shading whose one function was sampled or
        // a calculator painted as `Function::Identity`'s grey ramp, silently.
        // The array arm above never had the defect: its members are read
        // unresolved.
        dict.get(key).and_then(|raw| self.parse_function(raw, 0))
    }

    fn parse_function(&self, object: &Object, depth: u32) -> Option<Function> {
        if depth > 8 {
            return None;
        }
        let resolved = self.doc.resolve(object);
        let dict = resolved.as_dict()?;

        let numbers = |key: &[u8]| -> Vec<f64> {
            let value = self.doc.resolve_key(dict, self.doc.intern(key));
            value
                .as_array()
                .map(|a| {
                    a.iter()
                        .filter_map(|o| self.doc.resolve(o).as_number())
                        .collect()
                })
                .unwrap_or_default()
        };
        let pairs = |values: &[f64]| -> Vec<(f64, f64)> {
            values.chunks_exact(2).map(|p| (p[0], p[1])).collect()
        };

        let kind = self
            .doc
            .resolve_key(dict, self.doc.intern(b"FunctionType"))
            .as_int()?;

        match kind {
            2 => {
                let c0 = numbers(b"C0");
                let c1 = numbers(b"C1");
                let domain = numbers(b"Domain");
                Some(Function::Exponential {
                    domain: (
                        domain.first().copied().unwrap_or(0.0),
                        domain.get(1).copied().unwrap_or(1.0),
                    ),
                    c0: if c0.is_empty() { vec![0.0] } else { c0 },
                    c1: if c1.is_empty() { vec![1.0] } else { c1 },
                    n: self
                        .doc
                        .resolve_key(dict, self.doc.intern(b"N"))
                        .as_number()
                        .unwrap_or(1.0),
                })
            }
            3 => {
                let value = self.doc.resolve_key(dict, self.doc.intern(b"Functions"));
                let functions: Vec<Function> = value
                    .as_array()
                    .map(|a| {
                        a.iter()
                            .filter_map(|o| self.parse_function(o, depth + 1))
                            .collect()
                    })
                    .unwrap_or_default();
                let domain = numbers(b"Domain");
                Some(Function::Stitching {
                    domain: (
                        domain.first().copied().unwrap_or(0.0),
                        domain.get(1).copied().unwrap_or(1.0),
                    ),
                    functions,
                    bounds: numbers(b"Bounds"),
                    encode: pairs(&numbers(b"Encode")),
                })
            }
            0 | 4 => {
                // Both are streams, so the object handed in is the reference.
                let reference = object.as_objref()?;
                let data = self.doc.stream_decoded(reference).ok()?;
                if kind == 4 {
                    return Some(Function::PostScript {
                        domain: pairs(&numbers(b"Domain")),
                        range: pairs(&numbers(b"Range")),
                        program: tinker_pdf_color::function::parse_postscript(&data),
                    });
                }
                Some(Function::Sampled {
                    domain: pairs(&numbers(b"Domain")),
                    range: pairs(&numbers(b"Range")),
                    size: numbers(b"Size").iter().map(|v| *v as usize).collect(),
                    bits: self
                        .doc
                        .resolve_key(dict, self.doc.intern(b"BitsPerSample"))
                        .as_int()
                        .unwrap_or(8) as u32,
                    encode: pairs(&numbers(b"Encode")),
                    decode: pairs(&numbers(b"Decode")),
                    samples: data,
                })
            }
            _ => None,
        }
    }

    /// Records that a font resolved no glyph for a code it was asked for.
    ///
    /// Step 4 of the fallback order in gap 01 (CFF glyph selection): the
    /// glyph drawn is `.notdef`, and the page says so rather than
    /// silently drawing something else. Only rendering reaches this — text
    /// extraction never asks for an outline — so the same list stays exactly
    /// what its name says for the extraction path, which turns it into
    /// `TextWarning::UnknownFont`.
    fn report_unresolved_glyph(&self, font: &[u8]) {
        let name = String::from_utf8_lossy(font).into_owned();
        if let Ok(mut marker) = self.unresolved.lock() {
            *marker = Some(name.clone());
        }
        self.note_missing_font(name);
    }

    /// Adds a font to what this render could not resolve, once.
    fn note_missing_font(&self, name: String) {
        if let Ok(mut missing) = self.missing_fonts.lock() {
            if missing.len() < 64 && !missing.contains(&name) {
                missing.push(name);
            }
        }
    }

    /// Adds an image's tolerated damage to what this render met, once.
    fn note_damaged_image(&self, entry: (String, String)) {
        if let Ok(mut damaged) = self.damaged_images.lock() {
            if damaged.len() < 64 && !damaged.contains(&entry) {
                damaged.push(entry);
            }
        }
    }

    /// Adds a colour space read with a repair to what this render met, once.
    ///
    /// Once per name and repair rather than per use: the `cs` path asks for
    /// the space at every `sc`, and a page that sets a colour a thousand times
    /// has one space to report.
    fn note_repaired_space(&self, entry: (String, String)) {
        if let Ok(mut repaired) = self.repaired_spaces.lock() {
            if repaired.len() < 64 && !repaired.contains(&entry) {
                repaired.push(entry);
            }
        }
    }

    /// The embedded font program behind a font id, decoded once.
    fn program(&self, font_id: u64) -> Option<Arc<Vec<u8>>> {
        if let Ok(cache) = self.caches.programs.lock() {
            if let Some(hit) = cache.get(&font_id) {
                return hit.clone();
            }
        }
        let name = self
            .font_ids
            .iter()
            .find(|(_, id)| **id == font_id)
            .map(|(name, _)| name.clone());
        let built = name.as_ref().and_then(|name| {
            let font = self.fonts.get(name)?;
            let resources = self.resources.as_ref()?;
            program_for(&self.doc, name, resources, font, self.provider.as_deref())
        });
        if let Ok(mut cache) = self.caches.programs.lock() {
            cache.insert(font_id, built.clone());
        }
        built
    }

    /// The resource name a font id stands for in this scope.
    fn resource_name(&self, font_id: u64) -> Option<Vec<u8>> {
        self.font_ids
            .iter()
            .find(|(_, id)| **id == font_id)
            .map(|(name, _)| name.clone())
    }

    /// This scope's `/Font` subdictionary (7.8.3).
    fn font_table(&self) -> Option<Dict> {
        let resources = self.resources.as_ref()?;
        self.doc
            .resolve_key(resources, self.doc.intern(b"Font"))
            .as_dict()
            .cloned()
    }

    /// The object a font resource name stands for.
    ///
    /// **This is the identity [`crate::subset`] keys glyph usage by, and
    /// [`tinker_pdf_content::Glyph::font_id`] is not.** That id is the
    /// interned *resource name* — `/F1` — which is scope-relative: a form
    /// XObject with its own `/Resources` may bind `/F1` to a different font
    /// from the page that drew it, and the two then share an id. An object
    /// reference is the document's own answer to "which font", and two of them
    /// are equal exactly when the font is.
    ///
    /// `None` for a font written directly into the resource dictionary rather
    /// than by reference: there is no object for a rewrite to address, so
    /// subsetting leaves such a font whole rather than editing a copy of it
    /// that the file does not use.
    pub(crate) fn font_object(&self, font_id: u64) -> Option<ObjRef> {
        let name = self.resource_name(font_id)?;
        self.font_table()?.get_ref(self.doc.intern(&name))
    }

    /// Every font this scope names, by object.
    ///
    /// What makes "this scope was walked and never showed that font" sayable,
    /// which is what lets an embedded program whose text a redaction removed
    /// be cut down to `.notdef` rather than left whole.
    pub(crate) fn font_objects(&self) -> Vec<ObjRef> {
        let Some(table) = self.font_table() else {
            return Vec::new();
        };
        table
            .iter()
            .filter_map(|(_, value)| value.as_objref())
            .collect()
    }

    /// Every font this scope writes **directly** into its `/Font`
    /// subdictionary rather than by reference.
    ///
    /// The complement of [`PageResources::font_objects`], and it exists
    /// because the two together are the whole table: a font with no object has
    /// no identity for [`crate::subset`] to key glyph usage by, so a program it
    /// embeds is one that pass must leave whole — including when some *other*
    /// font reaches the same program by reference, which is the case that
    /// would otherwise lose this one's glyphs.
    pub(crate) fn direct_fonts(&self) -> Vec<Dict> {
        let Some(table) = self.font_table() else {
            return Vec::new();
        };
        table
            .iter()
            .filter_map(|(_, value)| value.as_dict().cloned())
            .collect()
    }

    /// Pulls one glyph's outline out of an embedded font program.
    fn extract_outline(&self, font_id: u64, code: u32) -> Option<Outline> {
        let program = self.program(font_id)?;

        // The font's own character mapping decides which glyph a code means.
        let name = self.resource_name(font_id)?;
        let font = self.fonts.get(&name)?;
        let text = font.text_of(code);
        let ch = text.chars().next();

        if let Some(sfnt) = Sfnt::parse(&program) {
            // An OpenType font may carry its outlines in a `CFF ` table
            // instead of `glyf` — that is what the `OTTO` tag means. The sfnt
            // parser accepts `OTTO`, so such a font took this branch, found
            // no `glyf`, and `glyf::outline` returned an *empty* outline,
            // which the renderer reads as a legitimate space. The whole face
            // drew as blank with nothing reported.
            if sfnt.table(0x676C_7966).is_none() {
                if let Some(table) = sfnt.table(0x4346_4620) {
                    if let Some(cff) = Cff::parse(table) {
                        let chosen = self.cff_selection(&cff, font, &name, code);
                        return self.cff_outline(&cff, chosen.glyph);
                    }
                }
                return None;
            }

            let glyph = self.sfnt_selection(&sfnt, font, &name, code)?.glyph;

            let units = f64::from(sfnt.units_per_em.max(1));
            let outline = glyf::outline(&sfnt, glyph)?;
            return Some(scale(&outline, 1.0 / units));
        }

        if let Some(cff) = Cff::parse(&program) {
            let chosen = self.cff_selection(&cff, font, &name, code);
            return self.cff_outline(&cff, chosen.glyph);
        }

        // 9.9: a `/FontFile` is a Type 1 program. Until this existed the bytes
        // reached the two parsers above, both declined them correctly, and the
        // glyph was silently absent — an embedded Type 1 font drew nothing and
        // said nothing about why.
        if let Some(type1) = Type1::parse(&program) {
            // Type 1 addresses glyphs by *name*: through the encoding the PDF
            // font dictionary specifies, or through the font's own built-in
            // one. The index is not a glyph id.
            let glyph = ch
                .and_then(|c| {
                    let name = tinker_pdf_font::glyph_name_for_char(c)?;
                    type1.glyph_for_name(name.as_bytes())
                })
                .or_else(|| {
                    u8::try_from(code)
                        .ok()
                        .and_then(|b| type1.glyph_for_code(b))
                })?;

            let outline = type1.outline(glyph)?;
            let scale_factor = type1.font_matrix.first().copied().unwrap_or(0.001);
            return Some(scale(&outline, scale_factor));
        }

        None
    }

    /// Which glyph of the embedded program a code selects, and on whose
    /// authority, without drawing anything.
    ///
    /// The **same decision** [`PageResources::extract_outline`] makes, reached
    /// through the same two helpers, because the glyph-usage walk in
    /// [`crate::subset`] has to keep exactly the glyphs this renderer would
    /// draw. A second resolver written beside this one would agree on the
    /// ordinary cases and diverge on the ones that matter — a symbolic face, a
    /// non-identity `/CIDToGIDMap`, a CFF reached by name — and every
    /// divergence is a glyph dropped from a program that still needs it, which
    /// renders as a blank rather than as an error.
    ///
    /// [`Selection::stated`] is what subsetting actually rests on; see its own
    /// documentation.
    ///
    /// `None` where no glyph index exists to keep: no embedded program, a
    /// program neither parser reads, or a Type 1 program — which addresses its
    /// charstrings by name, so the index [`PageResources::extract_outline`]
    /// uses above is an index into *that* font's private ordering and not a
    /// glyph id any subsetter could act on.
    pub(crate) fn selection(&self, font_id: u64, code: u32) -> Option<Selection> {
        let program = self.program(font_id)?;
        let name = self.resource_name(font_id)?;
        let font = self.fonts.get(&name)?;

        if let Some(sfnt) = Sfnt::parse(&program) {
            if sfnt.table(0x676C_7966).is_none() {
                let cff = Cff::parse(sfnt.table(0x4346_4620)?)?;
                return Some(self.cff_selection(&cff, font, &name, code));
            }
            return self.sfnt_selection(&sfnt, font, &name, code);
        }
        if let Some(cff) = Cff::parse(&program) {
            return Some(self.cff_selection(&cff, font, &name, code));
        }
        None
    }

    /// Which glyph of a `glyf`-flavoured program a code selects (9.6.6.4,
    /// 9.7.4.2).
    fn sfnt_selection(
        &self,
        sfnt: &Sfnt<'_>,
        font: &cos_font::Font,
        name: &[u8],
        code: u32,
    ) -> Option<Selection> {
        if font.kind() == cos_font::FontKind::Type0 {
            // `/CIDToGIDMap` is exhaustive by construction — a CID it does not
            // name is one the font does not have — so even the `.notdef` it
            // answers with is the font's own statement rather than a guess.
            return Some(Selection::stated(self.cid_glyph(font, name, code)));
        }

        let text = font.text_of(code);
        let ch = text.chars().next();
        let stated = match ch {
            Some(c) => sfnt.glyph_for_char(c).filter(|g| *g != 0),
            None => None,
        }
        // 9.6.6.4: a symbolic font's codes go through its `cmap`
        // directly rather than through a character — the (3,0)
        // subtable maps the code into the F0xx private-use block,
        // which is what `glyph_for_char` does with a character it is
        // handed. Without this a symbolic face fell straight to the
        // last resort below.
        .or_else(|| {
            char::from_u32(code)
                .and_then(|c| sfnt.glyph_for_char(c))
                .filter(|g| *g != 0)
        });
        if let Some(glyph) = stated {
            return Some(Selection::stated(glyph));
        }

        // The last resort: a subset font whose `cmap` was dropped,
        // where the code is the only glyph number on offer, and the
        // guess every reader makes for it. It used to be correct for
        // a composite font too — an identity `/CIDToGIDMap` makes the
        // code the glyph — but that reading only held while every
        // composite font's CMap was the identity as well. The branch
        // above owns that case now and indexes by CID, which is the
        // same number whenever the old reading was right and the
        // right one whenever it was not.
        Some(Selection::guessed(u16::try_from(code).ok()?))
    }

    /// Which glyph of a CFF program a code selects, the way 9.6.6 says to
    /// choose it.
    fn cff_selection(
        &self,
        cff: &Cff<'_>,
        font: &cos_font::Font,
        resource: &[u8],
        code: u32,
    ) -> Selection {
        match cff_glyph(cff, font, code) {
            Some(glyph) => Selection::stated(glyph),
            None => {
                // Nothing named this glyph. `.notdef` is glyph 0 in every CFF
                // font — usually empty, sometimes a box — and the page reports
                // rather than drawing whichever glyph the code happened to
                // number.
                self.report_unresolved_glyph(resource);
                Selection::guessed(0)
            }
        }
    }

    /// Which glyph of a TrueType program a composite font's code selects
    /// (9.7.4.2).
    ///
    /// A CIDFontType2 addresses its descendant by CID, and `/CIDToGIDMap`
    /// turns that CID into a glyph index. The font program's own `cmap` is
    /// **not** consulted on this path and must not be: a `cmap` answers "which
    /// glyph draws this character", and a composite font's code is not a
    /// character. Until August 2026 it was the only thing consulted here — the
    /// code went through `/ToUnicode` to a character and the character through
    /// the `cmap` — so a document whose CMap was not the identity drew a page
    /// of real glyphs, correctly spaced, that were not the ones it named.
    ///
    /// A CID the map does not name draws `.notdef` and reports, the same way
    /// an unresolvable CFF glyph does. Without the report it is a space, which
    /// is the failure that looks like nothing happened.
    fn cid_glyph(&self, font: &cos_font::Font, resource: &[u8], code: u32) -> u16 {
        let cid = font.cid_of(code);
        let glyph = font.gid_for_cid(cid);
        // CID 0 is `.notdef` by definition and reports nothing; any other CID
        // resolving to glyph 0 is a CID this font does not carry.
        if glyph == 0 && cid != 0 {
            self.report_unresolved_glyph(resource);
        }
        glyph
    }

    /// One glyph of a CFF program, once [`PageResources::cff_selection`] has
    /// chosen it.
    fn cff_outline(&self, cff: &Cff<'_>, glyph: u16) -> Option<Outline> {
        let outline = cff.outline(glyph)?;
        // A CFF font matrix is usually 1/1000 but need not be, and a
        // CID-keyed font may carry a different one per Font DICT.
        let factor = cff.font_matrix_for(glyph).first().copied().unwrap_or(0.001);
        Some(scale(&outline, factor))
    }

    /// Decodes one image XObject to RGB (8.9).
    fn decode_image(&self, name: &[u8]) -> Result<DecodedImage, String> {
        let Some((dict, reference)) = self.xobject(name) else {
            return Err(String::from_utf8_lossy(name).into_owned());
        };
        let label = String::from_utf8_lossy(name).into_owned();
        let mut image = self.decode_image_at(&dict, reference, &label)?;

        // 11.6.5.3: /SMask is a greyscale image whose samples are this one's
        // opacity. Without it every soft-masked image — a drop shadow, a
        // feathered edge, anything composited in a design tool — paints as an
        // opaque rectangle over the page.
        if let Some(mask) = self.soft_mask(&dict) {
            apply_soft_mask(&mut image, &mask);
        }
        Ok(image)
    }

    /// Records that an image decoded with something tolerated (ruling 10).
    fn report_damaged_image(&self, name: &[u8], warning: FilterWarning) {
        if let Ok(mut damaged) = self.damaged_images.lock() {
            let entry = (
                String::from_utf8_lossy(name).into_owned(),
                warning.as_str().to_string(),
            );
            if damaged.len() < 64 && !damaged.contains(&entry) {
                damaged.push(entry);
            }
        }
        if let Ok(mut capture) = self.image_capture.lock() {
            if let Some(caught) = capture.as_mut() {
                // Bounded without a cap: the warning set is closed, and each
                // is kept once.
                let reason = warning.as_str().to_string();
                if !caught.contains(&reason) {
                    caught.push(reason);
                }
            }
        }
    }

    /// Runs `decode`, and returns with its result every leniency
    /// [`Self::report_damaged_image`] heard while it ran — the warnings of the
    /// one image `decode` is decoding. Whatever was capturing before is
    /// restored, so a mask decoded inside an image keeps its own.
    fn capturing<T>(&self, decode: impl FnOnce() -> T) -> (T, Vec<String>) {
        let outer = self
            .image_capture
            .lock()
            .ok()
            .and_then(|mut capture| capture.replace(Vec::new()));
        let result = decode();
        let caught = self
            .image_capture
            .lock()
            .ok()
            .and_then(|mut capture| std::mem::replace(&mut *capture, outer))
            .unwrap_or_default();
        (result, caught)
    }

    /// Decodes a CCITT stream into the packed one-bit samples the sample loop
    /// in [`Self::decode_image_at`] reads (7.4.6).
    ///
    /// **The single entry point for fax data in this file.** The XObject path
    /// reaches it above; gap 08 routes `decode_inline` to this same function
    /// rather than growing a second copy of Table 11's defaults. That matters
    /// more than it looks: `ccitt_decode`'s signature does not change when the
    /// meaning of its bytes changes, so a second call site would be invisible
    /// to the compiler and would go on producing the old shape in silence.
    ///
    /// `/Columns` is the *coding* width and need not be `/Width` — Table 11
    /// defaults it to 1728 whatever the image is — so the decoded rows are
    /// re-laid at the image's own width here. The bits past `/Columns` in a
    /// decoded row are white, so a wider image gains white rather than an edge
    /// that is not in the fax.
    fn ccitt_samples(
        &self,
        dict: &Dict,
        coded: &[u8],
        width: u32,
        height: u32,
        name: &[u8],
    ) -> Vec<u8> {
        let parms = self.decode_parms(dict);
        let int = |key: &[u8]| parms.as_ref().and_then(|p| p.get_int(self.doc.intern(key)));
        let flag = |key: &[u8]| {
            parms
                .as_ref()
                .and_then(|p| p.get_bool(self.doc.intern(key)))
        };

        // Table 11: `/Rows` is the height of the coded image. It is optional,
        // and the image's own `/Height` is what it means when it is absent —
        // which is what this used to pass unconditionally, so a file whose two
        // heights disagreed was decoded at the wrong one.
        let rows = int(b"Rows")
            .filter(|rows| *rows > 0)
            .unwrap_or(i64::from(height))
            .clamp(1, 1 << 16) as u32;
        let params = CcittParams {
            k: int(b"K").unwrap_or(0) as i32,
            columns: int(b"Columns").unwrap_or(1728).clamp(1, 1 << 16) as u32,
            rows,
            black_is_1: flag(b"BlackIs1").unwrap_or(false),
            byte_align: flag(b"EncodedByteAlign").unwrap_or(false),
            // Table 11's other two flags, neither of which was consulted.
            // `/EndOfLine` says an EOL is required before every line, so a
            // missing one is a leniency worth naming rather than a shape the
            // decoder silently absorbs. `/EndOfBlock false` says the data
            // carries no EOFB, which is what makes `/Rows` above the authority
            // on where the image ends instead of a hint the decoder may run
            // past.
            end_of_line: flag(b"EndOfLine").unwrap_or(false),
            end_of_block: flag(b"EndOfBlock").unwrap_or(true),
        };

        // The same ceiling every other stream in the document decodes under.
        // Every row costs at least one bit of input, so the decode is bounded
        // by the coded length long before it reaches this.
        let (packed, warnings) = ccitt_decode(coded, &params, limits::MAX_DECODED_STREAM);
        for warning in warnings {
            // Ruling 10. These were discarded, so a fax with half its rows
            // missing was reported as a clean render of a mostly blank page.
            self.report_damaged_image(name, warning);
        }

        let coded_stride = (params.columns as usize).div_ceil(8);
        let stride = (width as usize).div_ceil(8);
        let white = if params.black_is_1 { 0x00 } else { 0xFF };
        let mut samples = vec![white; (height as usize).saturating_mul(stride)];
        let run = stride.min(coded_stride);
        for y in 0..height as usize {
            let from = y * coded_stride;
            let to = y * stride;
            let (Some(source), Some(target)) =
                (packed.get(from..from + run), samples.get_mut(to..to + run))
            else {
                break;
            };
            target.copy_from_slice(source);
        }
        samples
    }

    /// Decodes a JBIG2 stream into the packed one-bit samples the sample loop
    /// in [`Self::decode_image_at`] reads (ISO 32000-1 7.4.7).
    ///
    /// **The polarity inversion lives here, and nowhere else.** T.88 6.2.2
    /// codes 1 for black; a 1-bit DeviceGray sample is 0 for black. The
    /// decoder returns JBIG2's own sense unconverted — as [`T6Rows`] does for
    /// a fax — so exactly one place in the build knows which convention it is
    /// translating between, and it is the place that also reads `/Decode`,
    /// `/ImageMask` and `/ColorSpace`. A decoder that inverted for itself
    /// would be guessing what its caller wanted, and a second caller would
    /// invert again.
    ///
    /// **It joins the generic sample path deliberately**, for the reason gap
    /// 16 gave when it moved the fax onto it: an image that returns its own
    /// pixels has to reimplement `/Decode`, `/ImageMask` and the colour space
    /// to compose correctly, and a JBIG2 scan is an image mask about as often
    /// as it is a DeviceGray image. Coming out as *samples* means those three
    /// keys are read once, where they have always been read.
    ///
    /// `None` is the refusal: no region decoded, so the caller draws the
    /// placeholder rather than a blank page (ruling 2).
    fn jbig2_samples(
        &self,
        dict: &Dict,
        coded: &[u8],
        width: u32,
        height: u32,
        name: &[u8],
    ) -> Option<Vec<u8>> {
        // 7.4.7: `/JBIG2Globals` is a *stream*, in this image's own
        // `/DecodeParms`, holding the segments shared by every image that
        // names it. It is the ordinary shape for the symbol dictionary of a
        // scanned book, so a build that ignored it would refuse a file whose
        // whole payload is in one place and say nothing about why.
        let globals = self
            .decode_parms(dict)
            .and_then(|parms| match parms.get(self.doc.intern(b"JBIG2Globals")) {
                Some(Object::Ref(r)) => self.doc.stream_decoded(*r).ok(),
                _ => None,
            })
            .unwrap_or_default();

        let mut warnings = Vec::new();
        let params = Jbig2Params {
            globals: &globals,
            width,
            height,
            work_ceiling: Some(jbig2_work_ceiling(width, height)),
        };
        let decoded = jbig2_decode(coded, &params, limits::MAX_DECODED_STREAM, &mut warnings);
        for warning in &warnings {
            // Ruling 10, and it carries most of the information here: the
            // refusal below is one error with no detail, and "no region,
            // because this is a symbol dictionary" and "no region, because
            // the stream was truncated" are different failures.
            self.report_damaged_image(name, *warning);
        }

        let mut samples = decoded.ok()?;
        // The inversion, stated once. Padding bits past the image's width sit
        // in the same byte and flip with it, which is correct: they were 0 for
        // white in JBIG2 and become 1 for white here.
        for byte in &mut samples {
            *byte = !*byte;
        }
        Some(samples)
    }

    /// A JPEG 2000 image's pixels, ready to blit (8.9.5.4).
    ///
    /// **One entry point, and both the XObject path and the inline path go
    /// through it.** That is not tidiness: gap 16 changed the CCITT decoder's
    /// output shape without changing its signature, so a second call site would
    /// have been invisible to the compiler and would have rendered every fax as a
    /// negative at one eighth width with a green suite. Gap 08 was reordered
    /// behind gap 16 for exactly that reason, and its injection showed a parallel
    /// call site being caught *only* by a warning test -- no pixel assertion saw
    /// it. JPX carries the same hazard with more surface.
    ///
    /// # What 8.9.5.4 does with the image dictionary
    ///
    /// A JPX codestream describes itself, and the clause says which of the
    /// dictionary's claims survive that:
    ///
    /// - **`/BitsPerComponent` is ignored.** The codestream's precision wins. A
    ///   file whose dictionary disagrees must not shift its samples, which is why
    ///   this never reads the key.
    /// - **`/ColorSpace` overrides** the codestream's when present, and the
    ///   codestream's applies when it is absent. Note the ordering trap M6 found:
    ///   a palette makes the *output* channel count differ from `Csiz`, so it is
    ///   the output count a `/ColorSpace` must agree with.
    /// - **`/Decode` is ignored**, unlike every other image filter here.
    /// - **`/ImageMask` shall not be combined with JPXDecode**, so a file that
    ///   does is refused by name rather than rendered as a stencil of something.
    /// - **`/SMaskInData`** decides what happens to the codestream's *own*
    ///   opacity channel, which the filters crate has already separated out.
    fn jpx_image(
        raw: &[u8],
        smask_in_data: i64,
        image_mask: bool,
        interpolate: bool,
        warnings: &mut Vec<tinker_pdf_filters::Warning>,
    ) -> Result<DecodedImage, String> {
        if image_mask {
            // 8.9.6.2 makes a stencil one bit per sample with no colour space;
            // 8.9.5.4 forbids the combination outright. Refusing by name beats
            // painting the fill colour through whatever the codestream held.
            return Err("JPXDecode with /ImageMask".to_string());
        }

        let image = Self::jpx_samples(raw, warnings)?;

        let count = (image.width as usize) * (image.height as usize);
        let mut rgb = Vec::with_capacity(count * 3);

        // 16-bit samples arrive big-endian; the renderer wants eight, and taking
        // the high byte is a truncation the clause permits rather than a rounding
        // decision worth inventing.
        let sample = |i: usize, channel: usize| -> u8 {
            let per = usize::from(image.components);
            let at = i * per + channel;
            if image.precision > 8 {
                image.samples.get(at * 2).copied().unwrap_or(0)
            } else {
                image.samples.get(at).copied().unwrap_or(0)
            }
        };

        for i in 0..count {
            match image.components {
                1 => {
                    let g = sample(i, 0);
                    rgb.extend_from_slice(&[g, g, g]);
                }
                3 => rgb.extend_from_slice(&[sample(i, 0), sample(i, 1), sample(i, 2)]),
                4 => {
                    // CMYK, and the conversion is the naive one the colour crate
                    // uses elsewhere rather than a second opinion about ink.
                    let (c, m, y, k) = (
                        f64::from(sample(i, 0)) / 255.0,
                        f64::from(sample(i, 1)) / 255.0,
                        f64::from(sample(i, 2)) / 255.0,
                        f64::from(sample(i, 3)) / 255.0,
                    );
                    let to = |v: f64| {
                        #[allow(clippy::cast_possible_truncation, reason = "clamped to 0..=255")]
                        #[allow(clippy::cast_sign_loss, reason = "clamped to 0..=255")]
                        {
                            ((1.0 - (v + k).min(1.0)) * 255.0).clamp(0.0, 255.0) as u8
                        }
                    };
                    rgb.extend_from_slice(&[to(c), to(m), to(y)]);
                }
                other => {
                    return Err(format!("JPXDecode with {other} components"));
                }
            }
        }

        // `/SMaskInData` (Table 89): 0 means ignore any opacity the codestream
        // carries, 1 means it is present and unpremultiplied, 2 means present and
        // premultiplied. The filters crate separates the channel out and records
        // which; un-premultiplying is deliberately left here, because it is the
        // dictionary that says whether to.
        let alpha = match (smask_in_data, image.opacity.as_ref()) {
            (0, _) | (_, None) => Vec::new(),
            (_, Some(opacity)) => {
                let mut alpha = Vec::with_capacity(count);
                for i in 0..count {
                    let a = if image.precision > 8 {
                        opacity.samples.get(i * 2).copied().unwrap_or(255)
                    } else {
                        opacity.samples.get(i).copied().unwrap_or(255)
                    };
                    alpha.push(a);
                }
                // 2 says the colour is already multiplied by the opacity, so it
                // has to be divided back out before the renderer multiplies it
                // again. Skipping this darkens every transparent edge, which
                // looks like a soft shadow rather than like a bug.
                if smask_in_data == 2 || opacity.premultiplied {
                    for (i, &a) in alpha.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        for channel in 0..3 {
                            let at = i * 3 + channel;
                            if let Some(v) = rgb.get_mut(at) {
                                let restored = (u32::from(*v) * 255) / u32::from(a);
                                #[allow(clippy::cast_possible_truncation, reason = "min 255")]
                                {
                                    *v = restored.min(255) as u8;
                                }
                            }
                        }
                    }
                }
                alpha
            }
        };

        Ok(DecodedImage {
            width: image.width,
            height: image.height,
            rgb,
            alpha,
            stencil: false,
            interpolate,
        })
    }

    /// The final filter a stream dictionary names (7.4), which decides how
    /// its bytes are read.
    fn last_filter(&self, dict: &Dict) -> Option<Vec<u8>> {
        let filters = self.doc.resolve_key(dict, Name::FILTER);
        match filters.as_name() {
            Some(n) => self.doc.name_bytes(n).map(|b| b.to_vec()),
            None => filters
                .as_array()
                .and_then(|a| a.last())
                .and_then(Object::as_name)
                .and_then(|n| self.doc.name_bytes(n))
                .map(|b| b.to_vec()),
        }
    }

    /// An image XObject's samples as the sample loop reads them — **before**
    /// any colour conversion — and the depth they are at, for every final
    /// filter but the two codecs that describe themselves (`/DCTDecode` and
    /// `/JPXDecode`, whose samples come from [`jpeg_samples`] and
    /// [`Self::jpx_samples`]).
    ///
    /// Split out of [`Self::decode_image_at`] so the renderer and
    /// [`crate::Page::images`] read one set of samples through one set of
    /// rules: a fax or a JBIG2 stream is packed one-bit samples in PDF's
    /// polarity whatever `/BitsPerComponent` says, and anything else is the
    /// stream with its filters applied. `geometry` is the dictionary's
    /// width, height and clamped depth.
    fn stream_samples(
        &self,
        dict: &Dict,
        reference: ObjRef,
        last_filter: Option<&[u8]>,
        geometry: (u32, u32, u32),
        name: &[u8],
    ) -> Result<(Vec<u8>, u32), String> {
        let (width, height, bpc) = geometry;
        // CCITT data likewise arrives still coded, and carries its own
        // parameters in /DecodeParms — but unlike a JPEG it decodes to
        // *samples*, one bit per pixel, which is what the image dictionary
        // says it is. So it joins the path below rather than returning its own
        // pixels: `/ImageMask`, `/Decode` and `/ColorSpace` are read once,
        // where they have always been read, and apply to a fax because a fax
        // now arrives there like everything else.
        let fax = matches!(last_filter, Some(b"CCITTFaxDecode") | Some(b"CCF"));
        // JBIG2 takes the same road, and for the same reason (gap 17). Both
        // are bilevel codecs that produce samples rather than pixels, and a
        // scanned page is an `/ImageMask` about as often as it is a DeviceGray
        // image — so composing correctly means arriving where those keys are
        // read, not reimplementing them.
        let jbig2 = matches!(last_filter, Some(b"JBIG2Decode"));
        let data = if jbig2 {
            let raw = self
                .doc
                .stream_image_input(reference)
                .map_err(|_| "JBIG2Decode".to_string())?;
            // The refusal. A stream whose regions this build cannot decode —
            // the symbol-dictionary lineage an OCR pipeline emits — comes back
            // `None`, and the caller draws the neutral placeholder. Returning
            // the blank page it was composited onto would be indistinguishable
            // from a correct decode of a blank scan.
            self.jbig2_samples(dict, &raw, width, height, name)
                .ok_or_else(|| "JBIG2Decode".to_string())?
        } else if fax {
            let raw = self
                .doc
                .stream_image_input(reference)
                .map_err(|_| "CCITTFaxDecode".to_string())?;
            self.ccitt_samples(dict, &raw, width, height, name)
        } else {
            // Everything else decodes to raw samples.
            self.doc
                .stream_decoded(reference)
                .map_err(|_| "undecodable".to_string())?
        };
        // 7.4.6 and 7.4.7: both bilevel codecs produce one bit per pixel,
        // whatever the dictionary claims. Producers that omit
        // `/BitsPerComponent` are common and the clamp already reads an absent
        // key as 1; one that writes 8 would otherwise read each row eight
        // times too wide.
        let bpc = if fax || jbig2 { 1 } else { bpc };
        Ok((data, bpc))
    }

    /// A JPEG 2000 codestream's samples, decoded and **not** converted: the
    /// codestream's own components at its own precision, big-endian pairs
    /// past eight bits, with any opacity channel carried apart (8.9.5.4).
    ///
    /// The one decode both [`Self::jpx_image`] and [`crate::Page::images`]
    /// make, under the one ceiling.
    fn jpx_samples(
        raw: &[u8],
        warnings: &mut Vec<tinker_pdf_filters::Warning>,
    ) -> Result<tinker_pdf_filters::JpxImage, String> {
        tinker_pdf_filters::jpx_decode(
            raw,
            &tinker_pdf_filters::Limits::new(limits::MAX_DECODED_STREAM),
            warnings,
        )
        .map_err(|e| format!("{e:?}"))
    }

    /// Decodes an image from its dictionary, wherever that came from.
    fn decode_image_at(
        &self,
        dict: &Dict,
        reference: tinker_pdf_cos::ObjRef,
        name: &str,
    ) -> Result<DecodedImage, String> {
        let dict = dict.clone();
        let name = name.as_bytes();

        let subtype = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"Subtype"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n));
        if subtype.as_deref() != Some(b"Image".as_slice()) {
            return Err(String::from_utf8_lossy(name).into_owned());
        }

        let int = |key: &[u8]| {
            self.doc
                .resolve_key(&dict, self.doc.intern(key))
                .as_int()
                .unwrap_or(0)
        };
        let width = int(b"Width").clamp(0, 1 << 16) as u32;
        let height = int(b"Height").clamp(0, 1 << 16) as u32;
        if width == 0 || height == 0 {
            return Err("empty".to_string());
        }
        let bpc = int(b"BitsPerComponent").clamp(1, 16) as u32;

        // Table 89: /Interpolate asks for the samples to be smoothed when the
        // image is magnified. Read here rather than in either codec branch,
        // because both of those return before the end of this function — which
        // is how /Decode came to be ignored on exactly the two formats whose
        // producers use it most.
        let interpolate = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"Interpolate"))
            .as_bool()
            .unwrap_or(false);

        // 8.9.5.2: /Decode remaps each component's sample range. Read here
        // rather than after the codec branches, because both of those used to
        // return before reaching it — so `/Decode [1 0]` on a JPEG or a fax
        // did nothing at all, and the image rendered as its own negative
        // without a word.
        let decode: Vec<(f64, f64)> = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"Decode"))
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .collect::<Vec<f64>>()
            })
            .map(|v| v.chunks_exact(2).map(|c| (c[0], c[1])).collect())
            .unwrap_or_default();

        // The final filter decides how the bytes are read.
        let last_filter = self.last_filter(&dict);

        // DCTDecode data comes out of the stream tier still encoded, which is
        // exactly what the JPEG decoder wants.
        if matches!(last_filter.as_deref(), Some(b"DCTDecode") | Some(b"DCT")) {
            // Every filter before the codec, and no further: a producer
            // that deflates its JPEG bytes writes `[/FlateDecode /DCTDecode]`,
            // and handing the undecoded stream to the JPEG decoder made it
            // refuse a perfectly good image.
            let raw = self
                .doc
                .stream_image_input(reference)
                .map_err(|_| "DCTDecode".to_string())?;
            return jpeg_image(&raw, &decode, interpolate);
        }
        if matches!(last_filter.as_deref(), Some(b"JPXDecode")) {
            // Like a JPEG and unlike a fax, a JPX codestream carries its own
            // geometry, precision and colour, so it never joins the generic
            // sample loop below -- 8.9.5.4 is explicit that the dictionary's
            // `/BitsPerComponent` and `/Decode` do not apply to it.
            let raw = self
                .doc
                .stream_image_input(reference)
                .map_err(|_| "JPXDecode".to_string())?;
            let smask_in_data = dict.get_int(self.doc.intern(b"SMaskInData")).unwrap_or(0);
            let mut warnings = Vec::new();
            let image_mask = dict
                .get_bool(self.doc.intern(b"ImageMask"))
                .unwrap_or(false);
            let decoded =
                Self::jpx_image(&raw, smask_in_data, image_mask, interpolate, &mut warnings);
            for warning in &warnings {
                self.report_damaged_image(name, *warning);
            }
            return decoded;
        }

        let (data, bpc) = self.stream_samples(
            &dict,
            reference,
            last_filter.as_deref(),
            (width, height, bpc),
            name,
        )?;

        let space = self.doc.resolve_key(&dict, self.doc.intern(b"ColorSpace"));
        let space = self
            .parse_space(&space, 0, name)
            .unwrap_or(ColorSpace::DeviceGray);
        let n = space.components();

        // 8.9.5.2: an image mask is one bit per sample, painted in the fill
        // colour. Without the fill colour here it reads as black-on-nothing.
        let is_mask = self
            .doc
            .resolve_key(&dict, self.doc.intern(b"ImageMask"))
            .as_bool()
            .unwrap_or(false);

        // 8.9.6.4: colour-key masking. Read before the loop because it is a
        // property of the image and not of a pixel, and applied inside it
        // because it is a test on the *raw* samples.
        let color_key = self.color_key(&dict, n, bpc);

        let mut rgb = Vec::with_capacity((width as usize) * (height as usize) * 3);
        let mut alpha = Vec::new();
        let row_bits = (width as usize) * n * (bpc as usize);
        let row_bytes = row_bits.div_ceil(8);
        let max = ((1u32 << bpc.min(16)) - 1) as f64;
        let mut remembered = if is_mask {
            None
        } else {
            Remembered::for_image(&space, n, bpc)
        };

        for y in 0..height as usize {
            for x in 0..width as usize {
                let mut components = Vec::with_capacity(n);
                let mut samples = 0u128;
                // "Shall be masked ... if min_i <= sample_i <= max_i for *all*
                // i" — one component outside its range paints the pixel, which
                // is why this starts true and is narrowed rather than widened.
                let mut keyed = color_key.is_some();
                for c in 0..n {
                    let bit = y * row_bytes * 8 + (x * n + c) * bpc as usize;
                    let value = read_bits(&data, bit, bpc);
                    samples = Remembered::key(samples, c, value);
                    if let Some(ranges) = &color_key {
                        // An absent range can never match, so a short array
                        // masks nothing rather than everything.
                        let (lo, hi) = ranges.get(c).copied().unwrap_or((1, 0));
                        keyed &= value >= lo && value <= hi;
                    }
                    let raw = match &space {
                        // An indexed space's component is the index itself.
                        ColorSpace::Indexed { .. } => f64::from(value),
                        _ => f64::from(value) / max,
                    };
                    components.push(
                        match decode.get(c).copied().or_else(|| default_decode(&space, c)) {
                            // The interpolation is over the *sample* range, so an
                            // indexed image maps its index rather than a fraction.
                            Some((dmin, dmax)) => match &space {
                                ColorSpace::Indexed { .. } => {
                                    dmin + raw * (dmax - dmin) / max.max(1.0)
                                }
                                _ => dmin + raw * (dmax - dmin),
                            },
                            None => raw,
                        },
                    );
                }

                if is_mask {
                    // A zero sample paints, a one does not (8.9.6.2).
                    let paints = components.first().copied().unwrap_or(0.0) < 0.5;
                    rgb.extend_from_slice(&[0, 0, 0]);
                    alpha.push(if paints { 255 } else { 0 });
                } else {
                    let (r, g, b) = match remembered.as_mut() {
                        Some(table) => table.convert(samples, || space.to_rgb(&components)),
                        None => space.to_rgb(&components),
                    };
                    rgb.extend_from_slice(&[r, g, b]);
                    if color_key.is_some() {
                        alpha.push(if keyed { 0 } else { 255 });
                    }
                }
            }
        }

        Ok(DecodedImage {
            width,
            height,
            rgb,
            alpha,
            stencil: is_mask,
            interpolate,
        })
    }

    /// 8.9.6.4's colour-key mask: one inclusive range of **raw** sample values
    /// per colour component, before `/Decode`.
    ///
    /// `/Mask` has a second form — a reference to a stencil-mask image — which
    /// is a different feature and is not read here. This returns `None` for it,
    /// and for any array that is not exactly `2 x n` integers inside the depth's
    /// range, because a mask that cannot be read has to leave the image opaque:
    /// masking *more* than the file asked for erases pixels that were in it,
    /// and there is no way to tell from the result that anything went wrong.
    ///
    /// Gap 29 is what this was built for. A PNG `tRNS` naming one fully
    /// transparent colour or one run of palette indices maps onto exactly this
    /// array, which is what lets such a file reach a page as its own compressed
    /// bytes instead of being decoded into an `/SMask`.
    fn color_key(&self, dict: &Dict, n: usize, bpc: u32) -> Option<Vec<(u32, u32)>> {
        let value = self.doc.resolve_key(dict, self.doc.intern(b"Mask"));
        let items = value.as_array()?;
        if n == 0 || items.len() != n * 2 {
            return None;
        }

        // "Each integer shall be in the range 0 to 2^BitsPerComponent - 1."
        let ceiling = i64::from((1u32 << bpc.min(16)) - 1);
        let mut ranges = Vec::with_capacity(n);
        for pair in items.chunks_exact(2) {
            let lo = self.doc.resolve(&pair[0]).as_int()?;
            let hi = self.doc.resolve(&pair[1]).as_int()?;
            if lo < 0 || hi < lo || hi > ceiling {
                return None;
            }
            // Both are within `0 ..= ceiling`, which is at most `u32::MAX`.
            ranges.push((lo as u32, hi as u32));
        }
        Some(ranges)
    }

    /// An inline image's samples as its filter chain leaves them (8.9.7), or
    /// the still-coded bytes of a codec that describes itself.
    ///
    /// Split out of [`Self::decode_inline`] so the renderer and
    /// [`crate::Page::images`] run one chain: the one the document would have
    /// built had these bytes been an object.
    fn inline_samples(
        &self,
        dict: &Dict,
        data: &[u8],
        width: u32,
        height: u32,
    ) -> Result<InlineSamples, String> {
        use tinker_pdf_filters::{apply_chain, ChainOutput, ImageCodec, Limits};

        // The filters, in the order they were applied — read here only to name
        // one in a warning, since the chain itself is built by the document.
        let filters_value = self.doc.resolve_key(dict, Name::FILTER);
        let mut filters: Vec<Vec<u8>> = Vec::new();
        if let Some(name) = filters_value.as_name() {
            if let Some(bytes) = self.doc.name_bytes(name) {
                filters.push(bytes.to_vec());
            }
        } else if let Some(items) = filters_value.as_array() {
            for item in items {
                if let Some(bytes) = item.as_name().and_then(|n| self.doc.name_bytes(n)) {
                    filters.push(bytes.to_vec());
                }
            }
        }
        let named = |at: usize| -> String {
            filters.get(at).or_else(|| filters.last()).map_or_else(
                || INLINE_NAME.to_string(),
                |n| String::from_utf8_lossy(n).into_owned(),
            )
        };

        // The chain the document would have built had these bytes been an
        // object. Built there rather than here on purpose: Table 10's
        // predictor defaults, `/EarlyChange` and the per-filter
        // `/DecodeParms` array form then have one implementation instead of
        // two that can drift. This path used to carry the second one, and it
        // passed no predictor at all and hardcoded `/EarlyChange` true.
        let mut chain_warnings = tinker_pdf_cos::WarningSink::new();
        let chain = self.doc.filter_chain(dict, &mut chain_warnings);
        if chain_warnings
            .warnings()
            .iter()
            .any(|w| w.kind == tinker_pdf_cos::WarningKind::FilterUnknown)
        {
            // A filter name this build does not know ends the chain where it
            // appears, so everything after it is still encoded. Reported,
            // rather than sampled as though it were pixels.
            return Err(named(chain.len()));
        }

        // The ceiling every other stream in the document decodes under, not a
        // second number that happens to be smaller. An inline image is
        // attacker-controlled bytes inside a content stream, and a page may
        // hold any number of them, so the bound here is a denial-of-service
        // question rather than a tidiness one — and one that had drifted to
        // half the shared value with nothing naming the relationship.
        let limits = Limits::new(limits::MAX_DECODED_STREAM);
        let report = |warnings: Vec<FilterWarning>| {
            // Ruling 10: what the chain forgave is named, the same way the
            // XObject path names it. An inline image is one object's worth of
            // attacker-controlled bytes inside a content stream, so "it drew"
            // and "it drew cleanly" have to stay apart here too.
            for warning in warnings {
                self.report_damaged_image(INLINE_NAME.as_bytes(), warning);
            }
        };
        // 8.9.7 permits DCT and CCITT inline, and both are ordinary there — a
        // scanned page pasted into a content stream is a fax, and a photograph
        // is a JPEG. Both used to hit a catch-all that returned `Err`, so both
        // drew the grey placeholder and reported a codec this build has in
        // fact had all along.
        let (bytes, fax) = match apply_chain(data, &chain, &limits) {
            Ok(ChainOutput::Bytes(decoded)) => {
                report(decoded.warnings);
                (decoded.data, false)
            }
            Ok(ChainOutput::EncodedImage {
                kind: ImageCodec::Dct,
                data,
                warnings,
            }) => {
                report(warnings);
                return Ok(InlineSamples::Jpeg(data));
            }
            Ok(ChainOutput::EncodedImage {
                kind: ImageCodec::Ccitt,
                data,
                warnings,
            }) => {
                report(warnings);
                // Gap 16's single entry point, not a second call site. A fax
                // decodes to packed one-bit *samples*, so it joins the loop
                // below and gains `/ImageMask`, `/Decode` and `/ColorSpace`
                // with it. `ccitt_decode`'s signature says nothing about the
                // shape of what it returns, so a copy of this made here would
                // have gone on producing the old byte-per-pixel shape with
                // nothing in the build able to notice.
                (
                    self.ccitt_samples(dict, &data, width, height, INLINE_NAME.as_bytes()),
                    true,
                )
            }
            Ok(ChainOutput::EncodedImage {
                kind: ImageCodec::Jpx,
                data,
                warnings,
            }) => {
                report(warnings);
                // 8.9.7 does not list JPXDecode among the inline abbreviations
                // and `/JPXDecode` cannot be spelled in a content stream's
                // dictionary, so this arm is reachable only through a file
                // that writes the full name. It exists anyway: the cost is one
                // arm, and the alternative is a second call site drifting from
                // the XObject path's.
                return Ok(InlineSamples::Jpx(data));
            }
            // JBIG2 stays a gated capability wherever it appears (ruling 2),
            // inline included -- and unlike JPX it has no inline path at all,
            // since `/JBIG2Globals` cannot be an indirect reference inside a
            // content stream.
            Ok(ChainOutput::EncodedImage { .. }) => {
                return Err(named(chain.len().saturating_sub(1)))
            }
            Err(_) => return Err(named(chain.len())),
        };
        Ok(InlineSamples::Samples { bytes, fax })
    }

    /// Decodes an inline image's samples (8.9.7).
    ///
    /// Separate from [`Self::decode_image_at`] because an inline image has no
    /// object number: its bytes are in hand rather than behind a stream tier,
    /// so the filter chain is run here instead of by the document.
    fn decode_inline(&self, dict: &Dict, data: &[u8]) -> Result<DecodedImage, String> {
        let int = |key: &[u8]| {
            self.doc
                .resolve_key(dict, self.doc.intern(key))
                .as_int()
                .unwrap_or(0)
        };
        let width = int(b"Width").clamp(0, 1 << 16) as u32;
        let height = int(b"Height").clamp(0, 1 << 16) as u32;
        if width == 0 || height == 0 {
            return Err("inline".to_string());
        }

        let is_mask = self
            .doc
            .resolve_key(dict, self.doc.intern(b"ImageMask"))
            .as_bool()
            .unwrap_or(false);
        // 8.9.6.2: a mask is one bit per sample whatever /BPC claims.
        let bpc = if is_mask {
            1
        } else {
            int(b"BitsPerComponent").clamp(1, 16) as u32
        };

        // Table 93 abbreviates /Interpolate to /I, and the caller has already
        // rewritten the short form, so only the long one is looked for here.
        let interpolate = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Interpolate"))
            .as_bool()
            .unwrap_or(false);

        // 8.9.5.2. Read before the chain rather than after it, because the DCT
        // branch below returns its own pixels and would otherwise never see
        // this — which is the mistake the XObject path made until gap 16.
        let decode: Vec<(f64, f64)> = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Decode"))
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .collect::<Vec<f64>>()
            })
            .map(|v| v.chunks_exact(2).map(|c| (c[0], c[1])).collect())
            .unwrap_or_default();

        let (bytes, fax) = match self.inline_samples(dict, data, width, height)? {
            InlineSamples::Samples { bytes, fax } => (bytes, fax),
            // The same decoder, through the same helper, as an image XObject:
            // a JPEG returns its own dimensions and its own colour, so it does
            // not join the sample loop below.
            InlineSamples::Jpeg(data) => return jpeg_image(&data, &decode, interpolate),
            InlineSamples::Jpx(data) => {
                // The same entry point the XObject path takes, for the same
                // reason gap 16 gave the fax one and gap 08 was reordered
                // behind it: a second call site here would not change any
                // signature, so nothing in the build could notice it drifting
                // from 8.9.5.4's rules about which of the dictionary's claims
                // survive a codestream that describes itself.
                let smask_in_data = dict.get_int(self.doc.intern(b"SMaskInData")).unwrap_or(0);
                let image_mask = dict
                    .get_bool(self.doc.intern(b"ImageMask"))
                    .unwrap_or(false);
                let mut jpx_warnings = Vec::new();
                let decoded = Self::jpx_image(
                    &data,
                    smask_in_data,
                    image_mask,
                    interpolate,
                    &mut jpx_warnings,
                );
                for warning in &jpx_warnings {
                    self.report_damaged_image(INLINE_NAME.as_bytes(), *warning);
                }
                return decoded;
            }
        };
        // 7.4.6: fax output is one bit per pixel whatever the dictionary
        // claims, exactly as on the XObject path.
        let bpc = if fax { 1 } else { bpc };

        let space = self.doc.resolve_key(dict, self.doc.intern(b"ColorSpace"));
        let space = self
            .parse_space(&space, 0, INLINE_NAME.as_bytes())
            .unwrap_or(ColorSpace::DeviceGray);
        let n = if is_mask { 1 } else { space.components() };

        let row_bytes = ((width as usize) * n * (bpc as usize)).div_ceil(8);
        let max = ((1u32 << bpc.min(16)) - 1) as f64;
        let mut rgb = Vec::with_capacity((width as usize) * (height as usize) * 3);
        let mut alpha = Vec::new();
        let mut remembered = if is_mask {
            None
        } else {
            Remembered::for_image(&space, n, bpc)
        };

        for y in 0..height as usize {
            for x in 0..width as usize {
                let mut components = Vec::with_capacity(n);
                let mut samples = 0u128;
                for c in 0..n {
                    let bit = y * row_bytes * 8 + (x * n + c) * bpc as usize;
                    let value = read_bits(&bytes, bit, bpc);
                    samples = Remembered::key(samples, c, value);
                    let raw = match &space {
                        ColorSpace::Indexed { .. } => f64::from(value),
                        _ => f64::from(value) / max,
                    };
                    components.push(
                        match decode.get(c).copied().or_else(|| default_decode(&space, c)) {
                            Some((dmin, dmax)) => match &space {
                                ColorSpace::Indexed { .. } => {
                                    dmin + raw * (dmax - dmin) / max.max(1.0)
                                }
                                _ => dmin + raw * (dmax - dmin),
                            },
                            None => raw,
                        },
                    );
                }

                if is_mask {
                    let paints = components.first().copied().unwrap_or(0.0) < 0.5;
                    rgb.extend_from_slice(&[0, 0, 0]);
                    alpha.push(if paints { 255 } else { 0 });
                } else {
                    let (r, g, b) = match remembered.as_mut() {
                        Some(table) => table.convert(samples, || space.to_rgb(&components)),
                        None => space.to_rgb(&components),
                    };
                    rgb.extend_from_slice(&[r, g, b]);
                }
            }
        }

        Ok(DecodedImage {
            width,
            height,
            rgb,
            alpha,
            stencil: is_mask,
            interpolate,
        })
    }

    /// The `/SMask` of an image, decoded (11.6.5.3).
    fn soft_mask(&self, dict: &Dict) -> Option<DecodedImage> {
        let reference = dict.get_ref(self.doc.intern(b"SMask"))?;
        let object = self.doc.get(reference).ok()?;
        let mask = object.as_dict()?.clone();
        // A mask that is itself masked is not a thing the spec allows, and
        // decoding it through the top-level entry point would recurse.
        self.decode_image_at(&mask, reference, "SMask").ok()
    }
}

// ---- extraction: the samples before conversion -----------------------------
//
// `crate::Page::images` reads here. Every sample it hands out comes from the
// same four functions the renderer's decode calls — `stream_samples`,
// `jpeg_samples`, `jpx_samples`, `inline_samples` — so the two cannot disagree
// about what an image's samples are. What differs is only what happens next:
// the renderer converts, and this describes.

impl PageResources {
    /// An image XObject as [`crate::PageImage`] reports it, or `None` when
    /// the dictionary is not `/Subtype /Image`.
    pub(crate) fn extract_image(
        &self,
        dict: &Dict,
        reference: ObjRef,
        name: &[u8],
    ) -> Option<crate::PageImage> {
        let subtype = self
            .doc
            .resolve_key(dict, self.doc.intern(b"Subtype"))
            .as_name()
            .and_then(|n| self.doc.name_bytes(n));
        if subtype.as_deref() != Some(b"Image".as_slice()) {
            return None;
        }
        Some(self.extract_at(dict, reference, name, 0))
    }

    /// An image dictionary and its stream, described; `depth` is 1 for a mask
    /// or soft mask, which carries no mask of its own (11.6.5.3, 8.9.6.3).
    fn extract_at(
        &self,
        dict: &Dict,
        reference: ObjRef,
        name: &[u8],
        depth: u32,
    ) -> crate::PageImage {
        let (width, height, stencil, bpc) = self.geometry(dict);
        let space = if stencil {
            None
        } else {
            dict.get(self.doc.intern(b"ColorSpace"))
                .map(|space| self.describe_space(space, false, 0))
        };
        let mut image = crate::PageImage {
            reference: Some(reference),
            name: name.to_vec(),
            width,
            height,
            bits_per_component: bpc as u8,
            components: components_of(stencil, space.as_ref()),
            color_space: space,
            decode: self.decode_array(dict),
            stencil,
            samples: Vec::new(),
            codec: crate::SampleCodec::Stream,
            mask: None,
            soft_mask: None,
            placements: Vec::new(),
            refused: None,
            warnings: Vec::new(),
        };
        if width == 0 || height == 0 {
            image.refused = Some("empty".to_string());
            return image;
        }

        let last = self.last_filter(dict);
        let ((), warnings) = self.capturing(|| match last.as_deref() {
            Some(b"DCTDecode" | b"DCT") => {
                image.codec = crate::SampleCodec::Dct;
                let decoded = self
                    .doc
                    .stream_image_input(reference)
                    .map_err(|_| "DCTDecode".to_string())
                    .and_then(|raw| jpeg_samples(&raw));
                match decoded {
                    Ok(jpeg) => take_jpeg(&mut image, jpeg),
                    Err(why) => image.refused = Some(why),
                }
            }
            Some(b"JPXDecode") => {
                image.codec = crate::SampleCodec::Jpx;
                let mut warnings = Vec::new();
                let decoded = self
                    .doc
                    .stream_image_input(reference)
                    .map_err(|_| "JPXDecode".to_string())
                    .and_then(|raw| Self::jpx_samples(&raw, &mut warnings));
                for warning in &warnings {
                    self.report_damaged_image(name, *warning);
                }
                match decoded {
                    Ok(jpx) => take_jpx(&mut image, jpx),
                    Err(why) => image.refused = Some(why),
                }
            }
            other => {
                image.codec = match other {
                    Some(b"CCITTFaxDecode" | b"CCF") => crate::SampleCodec::CcittFax,
                    Some(b"JBIG2Decode") => crate::SampleCodec::Jbig2,
                    _ => crate::SampleCodec::Stream,
                };
                match self.stream_samples(dict, reference, other, (width, height, bpc), name) {
                    Ok((data, bits)) => take_samples(&mut image, data, bits),
                    Err(why) => image.refused = Some(why),
                }
            }
        });
        image.warnings = warnings;

        if depth == 0 {
            let mask_key = self.doc.intern(b"Mask");
            // 8.9.6.3 and 8.9.6.4: `/Mask` is a stencil-mask stream or a
            // colour-key *array*, and a reference can name either — so what
            // decides is the object the reference reaches, not that it is one.
            // `color_key` resolves the entry, as the renderer's decode does,
            // so an indirect `[0 0]` is a colour key here as it is there. It
            // used to be taken for a stencil mask that would not open, and
            // dropped, while the render of the same image honoured it.
            let stencil = match dict.get(mask_key) {
                Some(Object::Ref(r)) => self
                    .doc
                    .get(*r)
                    .ok()
                    .filter(|object| object.as_array().is_none())
                    .map(|object| (object, *r)),
                _ => None,
            };
            if let Some((object, r)) = stencil {
                if let Some(mask) = object.as_dict() {
                    image.mask = Some(crate::ImageMask::Stencil(Box::new(self.extract_at(
                        mask,
                        r,
                        b"",
                        depth + 1,
                    ))));
                }
            } else if dict.get(mask_key).is_some() {
                image.mask = self
                    .color_key(dict, usize::from(image.components), bpc)
                    .map(crate::ImageMask::ColorKey);
            }
            if let Some(r) = dict.get_ref(self.doc.intern(b"SMask")) {
                let mask = self.doc.get(r).ok();
                if let Some(mask) = mask.as_deref().and_then(Object::as_dict) {
                    image.soft_mask = Some(Box::new(self.extract_at(mask, r, b"", depth + 1)));
                }
            }
        }
        image
    }

    /// An inline image (8.9.7) as [`crate::PageImage`] reports it, or `None`
    /// when its dictionary is not one.
    pub(crate) fn extract_inline(&self, dict: &[u8], data: &[u8]) -> Option<crate::PageImage> {
        let text = expand_inline_abbreviations(dict);
        let mut sink = tinker_pdf_cos::WarningSink::new();
        let parsed = tinker_pdf_cos::parse_object_at(&text, 0, self.doc.names_table(), &mut sink);
        let dict = parsed.object.as_dict()?;

        let (width, height, stencil, bpc) = self.geometry(dict);
        let space = if stencil {
            None
        } else {
            dict.get(self.doc.intern(b"ColorSpace"))
                .map(|space| self.describe_space(space, true, 0))
        };
        let mut image = crate::PageImage {
            reference: None,
            name: Vec::new(),
            width,
            height,
            bits_per_component: bpc as u8,
            components: components_of(stencil, space.as_ref()),
            color_space: space,
            decode: self.decode_array(dict),
            stencil,
            samples: Vec::new(),
            codec: crate::SampleCodec::Stream,
            mask: None,
            soft_mask: None,
            placements: Vec::new(),
            refused: None,
            warnings: Vec::new(),
        };
        if width == 0 || height == 0 {
            image.refused = Some("empty".to_string());
            return Some(image);
        }
        let ((), warnings) =
            self.capturing(|| match self.inline_samples(dict, data, width, height) {
                Ok(InlineSamples::Samples { bytes, fax }) => {
                    if fax {
                        image.codec = crate::SampleCodec::CcittFax;
                    }
                    take_samples(&mut image, bytes, if fax { 1 } else { bpc });
                }
                Ok(InlineSamples::Jpeg(bytes)) => {
                    image.codec = crate::SampleCodec::Dct;
                    match jpeg_samples(&bytes) {
                        Ok(jpeg) => take_jpeg(&mut image, jpeg),
                        Err(why) => image.refused = Some(why),
                    }
                }
                Ok(InlineSamples::Jpx(bytes)) => {
                    image.codec = crate::SampleCodec::Jpx;
                    let mut warnings = Vec::new();
                    match Self::jpx_samples(&bytes, &mut warnings) {
                        Ok(jpx) => take_jpx(&mut image, jpx),
                        Err(why) => image.refused = Some(why),
                    }
                    for warning in &warnings {
                        self.report_damaged_image(INLINE_NAME.as_bytes(), *warning);
                    }
                }
                Err(why) => image.refused = Some(why),
            });
        image.warnings = warnings;
        // 8.9.7: an inline image's `/Mask` can only be the colour-key array,
        // since there is nothing inline a reference could name.
        if dict.get(self.doc.intern(b"Mask")).is_some() {
            image.mask = self
                .color_key(dict, usize::from(image.components), bpc)
                .map(crate::ImageMask::ColorKey);
        }
        Some(image)
    }

    /// `/Width`, `/Height`, `/ImageMask` and the depth, read as the renderer's
    /// decode reads them: the geometry clamped to what it will allocate, and a
    /// stencil mask one bit a sample whatever `/BitsPerComponent` says
    /// (8.9.6.2).
    fn geometry(&self, dict: &Dict) -> (u32, u32, bool, u32) {
        let int = |key: &[u8]| {
            self.doc
                .resolve_key(dict, self.doc.intern(key))
                .as_int()
                .unwrap_or(0)
        };
        let width = int(b"Width").clamp(0, 1 << 16) as u32;
        let height = int(b"Height").clamp(0, 1 << 16) as u32;
        let stencil = self
            .doc
            .resolve_key(dict, self.doc.intern(b"ImageMask"))
            .as_bool()
            .unwrap_or(false);
        let bpc = if stencil {
            1
        } else {
            int(b"BitsPerComponent").clamp(1, 16) as u32
        };
        (width, height, stencil, bpc)
    }

    /// `/Decode` as written, in pairs (8.9.5.2).
    fn decode_array(&self, dict: &Dict) -> Vec<(f64, f64)> {
        self.doc
            .resolve_key(dict, self.doc.intern(b"Decode"))
            .as_array()
            .map(|a| {
                a.iter()
                    .filter_map(|o| self.doc.resolve(o).as_number())
                    .collect::<Vec<f64>>()
            })
            .map(|v| v.chunks_exact(2).map(|c| (c[0], c[1])).collect())
            .unwrap_or_default()
    }

    /// A colour space as an image states it, described rather than
    /// evaluated (8.6).
    ///
    /// `inline` admits 8.9.7's one extra spelling: an inline image may name a
    /// space in the page's `/ColorSpace` resources, which an image XObject's
    /// dictionary may not (8.6.3). Depth-capped like the renderer's own
    /// parser, since an `/Indexed` base and a tint alternate are spaces too.
    fn describe_space(&self, object: &Object, inline: bool, depth: u32) -> crate::ImageSpace {
        use crate::ImageSpace;
        let unreadable = |family: &[u8]| ImageSpace::Unreadable {
            family: family.to_vec(),
        };
        if depth > 8 {
            return unreadable(b"");
        }
        let resolved = self.doc.resolve(object);

        if let Some(name) = resolved.as_name() {
            let Some(bytes) = self.doc.name_bytes(name) else {
                return unreadable(b"");
            };
            return match bytes.as_ref() {
                b"DeviceGray" | b"G" => ImageSpace::DeviceGray,
                b"DeviceRGB" | b"RGB" => ImageSpace::DeviceRgb,
                b"DeviceCMYK" | b"CMYK" => ImageSpace::DeviceCmyk,
                other if inline => {
                    let entry = self.resources.as_ref().and_then(|resources| {
                        let table = self
                            .doc
                            .resolve_key(resources, self.doc.intern(b"ColorSpace"));
                        table.as_dict()?.get(self.doc.intern(other)).cloned()
                    });
                    match entry {
                        // A resource entry is the space itself, so it is read
                        // as an XObject's would be: it cannot name another.
                        Some(entry) => self.describe_space(&entry, false, depth + 1),
                        None => unreadable(other),
                    }
                }
                other => unreadable(other),
            };
        }

        let Some(items) = resolved.as_array() else {
            return unreadable(b"");
        };
        let Some(family) = items
            .first()
            .and_then(Object::as_name)
            .and_then(|n| self.doc.name_bytes(n))
        else {
            return unreadable(b"");
        };
        let parameters = || {
            items
                .get(1)
                .map(|o| self.doc.resolve(o))
                .and_then(|p| p.as_dict().cloned())
        };
        let triple = |dict: Option<&Dict>, key: &[u8], default: [f64; 3]| {
            dict.and_then(|d| self.numbers(d, key, 3))
                .map_or(default, |v| [v[0], v[1], v[2]])
        };
        match family.as_ref() {
            b"ICCBased" => {
                let stream = items.get(1).and_then(Object::as_objref);
                let header = items.get(1).map(|o| self.doc.resolve(o));
                let dict = header.as_deref().and_then(Object::as_dict);
                let components = dict
                    .and_then(|d| d.get_int(self.doc.intern(b"N")))
                    .unwrap_or(0)
                    .clamp(0, 255) as u8;
                let alternate = dict
                    .and_then(|d| d.get(self.doc.intern(b"Alternate")))
                    .map(|a| Box::new(self.describe_space(a, inline, depth + 1)));
                let profile = stream
                    .and_then(|r| self.doc.stream_decoded(r).ok())
                    .unwrap_or_default();
                ImageSpace::Icc {
                    components,
                    profile,
                    alternate,
                }
            }
            b"Indexed" | b"I" => {
                let base = items.get(1).map_or_else(
                    || unreadable(b""),
                    |b| self.describe_space(b, inline, depth + 1),
                );
                let high = items
                    .get(2)
                    .and_then(|o| self.doc.resolve(o).as_int())
                    .unwrap_or(0)
                    .clamp(0, 255) as u8;
                let lookup = match items.get(3).map(|o| self.doc.resolve(o)) {
                    Some(value) => match value.as_string() {
                        Some(s) => s.bytes.clone(),
                        None => items
                            .get(3)
                            .and_then(Object::as_objref)
                            .and_then(|r| self.doc.stream_decoded(r).ok())
                            .unwrap_or_default(),
                    },
                    None => Vec::new(),
                };
                ImageSpace::Indexed {
                    base: Box::new(base),
                    high,
                    lookup,
                }
            }
            b"Separation" => ImageSpace::Separation {
                colorant: items
                    .get(1)
                    .and_then(|o| self.doc.resolve(o).as_name())
                    .and_then(|n| self.doc.name_bytes(n))
                    .map(|b| b.to_vec())
                    .unwrap_or_default(),
                alternate: Box::new(items.get(2).map_or_else(
                    || unreadable(b""),
                    |a| self.describe_space(a, inline, depth + 1),
                )),
            },
            b"DeviceN" => ImageSpace::DeviceN {
                colorants: items
                    .get(1)
                    .map(|o| self.doc.resolve(o))
                    .and_then(|names| {
                        names.as_array().map(|names| {
                            names
                                .iter()
                                .take(limits::MAX_ARRAY_LEN)
                                .filter_map(|n| {
                                    self.doc
                                        .resolve(n)
                                        .as_name()
                                        .and_then(|n| self.doc.name_bytes(n))
                                        .map(|b| b.to_vec())
                                })
                                .collect()
                        })
                    })
                    .unwrap_or_default(),
                alternate: Box::new(items.get(2).map_or_else(
                    || unreadable(b""),
                    |a| self.describe_space(a, inline, depth + 1),
                )),
            },
            b"CalGray" => {
                let dict = parameters();
                ImageSpace::CalGray {
                    white: triple(dict.as_ref(), b"WhitePoint", WHITE_D50),
                    gamma: dict
                        .as_ref()
                        .map(|d| self.doc.resolve_key(d, self.doc.intern(b"Gamma")))
                        .and_then(|g| g.as_number())
                        .unwrap_or(1.0),
                }
            }
            b"CalRGB" => {
                let dict = parameters();
                let mut matrix = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0];
                if let Some(values) = dict.as_ref().and_then(|d| self.numbers(d, b"Matrix", 9)) {
                    matrix.copy_from_slice(&values[..9]);
                }
                ImageSpace::CalRgb {
                    white: triple(dict.as_ref(), b"WhitePoint", WHITE_D50),
                    gamma: triple(dict.as_ref(), b"Gamma", [1.0; 3]),
                    matrix,
                }
            }
            b"Lab" => {
                let dict = parameters();
                let range = dict
                    .as_ref()
                    .and_then(|d| self.numbers(d, b"Range", 4))
                    .map_or([-100.0, 100.0, -100.0, 100.0], |v| [v[0], v[1], v[2], v[3]]);
                ImageSpace::Lab {
                    white: triple(dict.as_ref(), b"WhitePoint", WHITE_D50),
                    range,
                }
            }
            other => unreadable(other),
        }
    }
}

/// Values a pixel of an image with this space, as far as it says: one for a
/// stencil mask and for a space nothing describes, which is the count the
/// renderer's own fallback to grey reads the samples with.
fn components_of(stencil: bool, space: Option<&crate::ImageSpace>) -> u8 {
    if stencil {
        return 1;
    }
    space.and_then(crate::ImageSpace::components).unwrap_or(1)
}

/// Keeps as many samples as the geometry lays out and no more (8.9.3): rows
/// of `width × components × bits`, each padded to a byte.
fn take_samples(image: &mut crate::PageImage, mut data: Vec<u8>, bits: u32) {
    image.bits_per_component = bits as u8;
    let row_bits = u64::from(image.width)
        .saturating_mul(u64::from(image.components))
        .saturating_mul(u64::from(bits));
    let wanted = row_bits.div_ceil(8).saturating_mul(u64::from(image.height));
    if let Ok(wanted) = usize::try_from(wanted) {
        data.truncate(wanted);
    }
    image.samples = data;
}

/// A JPEG's own geometry and samples, which describe the image rather than
/// the dictionary.
fn take_jpeg(image: &mut crate::PageImage, jpeg: tinker_pdf_filters::JpegImage) {
    image.width = jpeg.width;
    image.height = jpeg.height;
    image.components = match jpeg.color {
        JpegColor::Gray => 1,
        JpegColor::Rgb => 3,
        JpegColor::Cmyk | JpegColor::CmykInverted => 4,
    };
    take_samples(image, jpeg.data, 8);
}

/// A JPEG 2000 codestream's own geometry, components, precision and
/// samples (8.9.5.4).
fn take_jpx(image: &mut crate::PageImage, jpx: tinker_pdf_filters::JpxImage) {
    image.width = jpx.width;
    image.height = jpx.height;
    image.components = jpx.components;
    let bits = if jpx.precision > 8 { 16 } else { 8 };
    take_samples(image, jpx.samples, bits);
}

/// Applies a soft mask's luminance as the image's per-sample opacity
/// (11.6.5.3).
///
/// The mask has its own dimensions and need not match the image's, so it is
/// sampled by position rather than by index — a 2x2 mask over a 512x512 image
/// is legal and common, because a mask only has to carry as much detail as its
/// gradient needs.
fn apply_soft_mask(image: &mut DecodedImage, mask: &DecodedImage) {
    if image.width == 0 || image.height == 0 || mask.width == 0 || mask.height == 0 {
        return;
    }

    let samples = (image.width as usize).saturating_mul(image.height as usize);
    let mut alpha = Vec::with_capacity(samples);

    for y in 0..image.height as usize {
        // Nearest-neighbour: a mask is a smooth ramp far more often than not,
        // and interpolating it would cost more than it buys.
        let my = y * mask.height as usize / image.height as usize;
        for x in 0..image.width as usize {
            let mx = x * mask.width as usize / image.width as usize;
            let at = (my * mask.width as usize + mx) * 3;
            // The mask is greyscale, so any channel is its value.
            let value = mask.rgb.get(at).copied().unwrap_or(255);

            // An image that already had alpha keeps the more opaque
            // constraint of the two rather than losing one of them.
            let existing = image
                .alpha
                .get(y * image.width as usize + x)
                .copied()
                .unwrap_or(255);
            alpha.push(((u16::from(existing) * u16::from(value)) / 255) as u8);
        }
    }

    image.alpha = alpha;
}

/// Reads `bits` bits starting at bit offset `at`, big-endian.
fn read_bits(data: &[u8], at: usize, bits: u32) -> u32 {
    let mut value = 0u32;
    for i in 0..bits.min(16) {
        let index = at + i as usize;
        let byte = data.get(index / 8).copied().unwrap_or(0);
        let bit = (byte >> (7 - (index % 8))) & 1;
        value = (value << 1) | u32::from(bit);
    }
    value
}

/// How many conversions one image remembers at once.
///
/// A fixed table rather than a cap on anything a document states: it bounds
/// what [`Remembered`] holds, 4 096 slots of a key and a colour each, and a
/// picture with more colours than that converts some of them more than once.
const REMEMBERED_COLOURS: usize = 4096;

/// One image's colour conversions, remembered by the raw samples that asked
/// for them.
///
/// An image reaches [`ColorSpace::to_rgb`] once a pixel, and for a space other
/// than the device spaces that runs a tint transform, a profile or a power —
/// a `/DeviceN` tint transform sampled across eight colorants weighs 256
/// corners of its table (7.10.2), and an `/ICCBased` profile interpolates a
/// lookup table of its own. A picture repeats its colours, so a conversion is
/// remembered by the samples it was asked for, in a slot those samples choose.
/// The slot keeps the samples beside the answer, so two colours that share a
/// slot convert again rather than answer for each other: every pixel is the
/// one `to_rgb` gives, and only the work is shared.
///
/// *Added on review of lane 5C, 3 October 2026*, when a sampled function of
/// several inputs began to be read across all of them: one evaluation of an
/// eight-input table costs what 7.10.2 makes it cost, and this is what keeps
/// an image from paying it at every pixel of a colour it has already drawn.
struct Remembered {
    slots: Vec<Option<Conversion>>,
}

/// One remembered conversion: the samples, packed by [`Remembered::key`], and
/// the colour `to_rgb` gave them.
type Conversion = (u128, (u8, u8, u8));

impl Remembered {
    /// A table for an image of `n` components of `bpc` bits each in `space`,
    /// or `None` where it would not pay or the samples do not fit one key —
    /// a device space converts in a few operations, and a key holds eight
    /// samples of sixteen bits.
    fn for_image(space: &ColorSpace, n: usize, bpc: u32) -> Option<Self> {
        let cheap = matches!(
            space,
            ColorSpace::DeviceGray
                | ColorSpace::DeviceRgb
                | ColorSpace::DeviceCmyk
                | ColorSpace::Approximated { .. }
                | ColorSpace::Pattern { .. }
        );
        (!cheap && n <= 8 && bpc <= 16).then(|| Self {
            slots: vec![None; REMEMBERED_COLOURS],
        })
    }

    /// Adds the `index`th sample of a pixel to its key. A sample is at most
    /// sixteen bits — [`read_bits`] reads no more — and a table exists only
    /// for at most eight of them, so nothing is shifted out.
    fn key(key: u128, index: usize, sample: u32) -> u128 {
        if index >= 8 {
            return key;
        }
        key | (u128::from(sample & 0xFFFF) << (16 * index))
    }

    /// The colour the samples `key` stand for, converted by `convert` unless
    /// this table holds it already.
    fn convert(&mut self, key: u128, convert: impl FnOnce() -> (u8, u8, u8)) -> (u8, u8, u8) {
        let at = Self::slot(key);
        if let Some(Some((held, colour))) = self.slots.get(at) {
            if *held == key {
                return *colour;
            }
        }
        let colour = convert();
        if let Some(slot) = self.slots.get_mut(at) {
            *slot = Some((key, colour));
        }
        colour
    }

    /// The slot a key's colour is kept in: Fibonacci hashing of the key's two
    /// halves folded together, shifted to leave as many bits as the table is
    /// a power of two.
    fn slot(key: u128) -> usize {
        let folded = (key as u64) ^ ((key >> 64) as u64);
        let shift = 64 - REMEMBERED_COLOURS.trailing_zeros();
        (folded.wrapping_mul(0x9E37_79B9_7F4A_7C15) >> shift) as usize
    }
}

/// Components read as a colour by how many of them there are.
///
/// 11.6.5.2 puts `/BC` in the mask group's own colour space, which a file may
/// simply not declare. One component is grey, three RGB, four CMYK — the same
/// reading the interpreter applies to an `sc` whose space it could not
/// resolve, and the only one available without a declaration.
fn by_component_count(components: &[f64]) -> (u8, u8, u8) {
    let space = match components.len() {
        1 => ColorSpace::DeviceGray,
        4 => ColorSpace::DeviceCmyk,
        _ => ColorSpace::DeviceRgb,
    };
    space.to_rgb(components)
}

/// A soft mask's `/TR` sampled to 256 entries (11.6.5.2).
///
/// Evaluated once here rather than per pixel: the function may be a Type 4
/// PostScript calculator, and running one for every pixel of a page-sized
/// mask is minutes of work. Its domain and range are both `[0 1]` by
/// definition, so 256 samples reproduce every value an 8-bit mask can hold
/// with no interpolation at all — the table is exact, not an approximation.
fn sample_transfer(function: &Function) -> [u8; 256] {
    let mut table = [0u8; 256];
    for (i, slot) in table.iter_mut().enumerate() {
        let input = f64::from(i as u16) / 255.0;
        let value = function.eval(&[input]).first().copied().unwrap_or(input);
        // A function may return anything; the mask cannot.
        let value = if value.is_finite() { value } else { input };
        *slot = (value.clamp(0.0, 1.0) * 255.0).round() as u8;
    }
    table
}

fn jpeg_to_rgb(image: &tinker_pdf_filters::JpegImage) -> Vec<u8> {
    let count = (image.width as usize) * (image.height as usize);
    let mut out = Vec::with_capacity(count * 3);

    match image.color {
        JpegColor::Gray => {
            for i in 0..count {
                let v = image.data.get(i).copied().unwrap_or(0);
                out.extend_from_slice(&[v, v, v]);
            }
        }
        JpegColor::Rgb => out.extend_from_slice(&image.data),
        JpegColor::Cmyk | JpegColor::CmykInverted => {
            let space = ColorSpace::DeviceCmyk;
            for i in 0..count {
                let at =
                    |c: usize| f64::from(image.data.get(i * 4 + c).copied().unwrap_or(0)) / 255.0;
                let (r, g, b) = space.to_rgb(&[at(0), at(1), at(2), at(3)]);
                out.extend_from_slice(&[r, g, b]);
            }
        }
    }

    out.resize(count * 3, 255);
    out
}

/// Which glyph of a CFF program a character code selects.
///
/// The character code is not a glyph index and never was. Until August 2026
/// this function did not exist and its two callers used the code as one, so a
/// document embedding a Type 1 face as `/FontFile3 /Subtype /Type1C` — how
/// they have been embedded since PDF 1.2 — drew whatever glyph sat at that
/// position, or nothing at all when the font was subsetted small enough that
/// the position did not exist.
///
/// The order below is the one real files need, because real files omit
/// things. Each step is tried in turn and the first that names a glyph in
/// this font wins:
///
/// 1. the document's `/Encoding` gives a name, and the charset gives the
///    glyph — 9.6.6 makes the PDF's encoding win over the font's;
/// 2. the font program's own built-in encoding gives the glyph directly;
/// 3. the standard encoding's name for the code, through the charset;
/// 4. nothing, which the caller turns into `.notdef` plus a report.
///
/// Step 1 is tried whenever the dictionary named an encoding *and* that name
/// reaches a glyph. A name that reaches nothing falls through to step 2
/// rather than stopping there: 9.6.6 is about which encoding is authoritative,
/// not about refusing to look at a font that plainly disagrees with it, and a
/// subset font whose `/Differences` were written against the unsubsetted
/// original is a file that exists.
fn cff_glyph(cff: &Cff<'_>, font: &cos_font::Font, code: u32) -> Option<u16> {
    if font.kind() == cos_font::FontKind::Type0 {
        // 9.7.4.2: a composite font addresses its descendant by CID. A
        // CID-keyed program maps the CID through its charset; a plain CFF
        // inside a CIDFontType0 has no such map and the CID is the glyph.
        let cid = font.cid_of(code);
        return if cff.is_cid() {
            cff.gid_for_cid(cid)
        } else {
            u16::try_from(cid).ok()
        };
    }
    // A CID-keyed program under a simple font dictionary is malformed, and
    // the only reading of a one-byte code left is as a CID.
    if cff.is_cid() {
        return cff.gid_for_cid(code);
    }

    let byte = u8::try_from(code).ok();
    font.glyph_name(code)
        .and_then(|name| cff.gid_for_name(name))
        .or_else(|| byte.and_then(|c| cff.gid_for_code(c)))
        .or_else(|| {
            let name = base_glyph_name(BaseEncoding::Standard, byte?)?;
            cff.gid_for_name(name)
        })
}

/// Scales an outline from font units into em units.
fn scale(outline: &Outline, factor: f64) -> Outline {
    use tinker_pdf_font::Segment;
    let s = |v: f64| v * factor;
    Outline {
        segments: outline
            .segments
            .iter()
            .map(|segment| match *segment {
                Segment::MoveTo { x, y } => Segment::MoveTo { x: s(x), y: s(y) },
                Segment::LineTo { x, y } => Segment::LineTo { x: s(x), y: s(y) },
                Segment::QuadTo { cx, cy, x, y } => Segment::QuadTo {
                    cx: s(cx),
                    cy: s(cy),
                    x: s(x),
                    y: s(y),
                },
                Segment::CurveTo {
                    c1x,
                    c1y,
                    c2x,
                    c2y,
                    x,
                    y,
                } => Segment::CurveTo {
                    c1x: s(c1x),
                    c1y: s(c1y),
                    c2x: s(c2x),
                    c2y: s(c2y),
                    x: s(x),
                    y: s(y),
                },
                Segment::Close => Segment::Close,
            })
            .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::{expand_inline_abbreviations, PageResources, Remembered};
    use tinker_pdf_color::ColorSpace;
    use tinker_pdf_content::FontSource;

    /// An image's colour is converted once however many pixels repeat it, and
    /// two colours whose samples share a slot each get their own answer — the
    /// table shares work, never a colour. A device space, and a pixel of more
    /// samples than a key holds, are converted directly.
    #[test]
    fn an_images_repeated_colour_is_converted_once() {
        let lab = ColorSpace::Lab {
            range: [-100.0, 100.0, -100.0, 100.0],
        };
        let mut table = Remembered::for_image(&lab, 3, 8).expect("a Lab image is remembered");
        let key = |samples: [u32; 3]| {
            samples
                .iter()
                .enumerate()
                .fold(0u128, |key, (index, sample)| {
                    Remembered::key(key, index, *sample)
                })
        };
        let first = key([10, 20, 30]);
        let mut calls = 0;
        for _ in 0..1000 {
            let colour = table.convert(first, || {
                calls += 1;
                (1, 2, 3)
            });
            assert_eq!(colour, (1, 2, 3));
        }
        assert_eq!(calls, 1, "a thousand pixels of one colour, converted once");

        let slot = Remembered::slot(first);
        let neighbour = (0..=255u32)
            .flat_map(|a| (0..=255u32).map(move |b| [a, b, 7]))
            .map(key)
            .find(|other| *other != first && Remembered::slot(*other) == slot)
            .expect("some colour shares the slot");
        assert_eq!(table.convert(neighbour, || (4, 5, 6)), (4, 5, 6));
        assert_eq!(
            table.convert(first, || (1, 2, 3)),
            (1, 2, 3),
            "the first colour converts again rather than answering as its neighbour"
        );

        assert!(Remembered::for_image(&ColorSpace::DeviceCmyk, 4, 8).is_none());
        assert!(Remembered::for_image(&lab, 9, 8).is_none());
    }

    fn expand(dict: &str) -> String {
        String::from_utf8(expand_inline_abbreviations(dict.as_bytes()))
            .expect("ascii in, ascii out")
    }

    /// Table 93's short keys expand whatever follows them.
    ///
    /// 7.2.2 makes `/` a delimiter in its own right, so a producer is free to
    /// write `/F/Fl` with nothing between the two names — and the substitution
    /// this replaced searched for `"/Fl "`, which is not in that string. The
    /// whole `/Filter` entry then stayed the name `/F`, matched no branch, and
    /// the compressed bytes were sampled as though they were pixels.
    #[test]
    fn an_abbreviation_expands_against_a_delimiter_as_well_as_a_space() {
        assert_eq!(
            expand("/W 4/H 4/CS/RGB/BPC 8/F/Fl"),
            "<< /Width 4/Height 4/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/FlateDecode >>"
        );
        assert_eq!(
            expand("/F[/AHx/Fl]/DP[null<</Predictor 15>>]"),
            "<< /Filter[/ASCIIHexDecode/FlateDecode]/DecodeParms[null<</Predictor 15>>] >>"
        );
    }

    /// A name that is not an abbreviation comes back exactly as it went in,
    /// including one carrying a `#` escape — which is a regular character in a
    /// name (7.3.5) and must not end it.
    #[test]
    fn a_name_that_is_not_an_abbreviation_is_untouched() {
        assert_eq!(expand("/Whirlpool"), "<< /Whirlpool >>");
        assert_eq!(expand("/CS /Sep#20A"), "<< /ColorSpace /Sep#20A >>");
        // `/D` is `/Decode` and `/DP` is `/DecodeParms`: the longer name is
        // read whole rather than as the shorter one plus a stray `P`.
        assert_eq!(
            expand("/D[1 0]/DP<<>>"),
            "<< /Decode[1 0]/DecodeParms<<>> >>"
        );
    }

    /// A one-page document whose `/ColorSpace` dictionary is given verbatim.
    fn resources_of(color_spaces: &str) -> PageResources {
        let content = "0 0 1 1 re f";
        let bytes = format!(
            "%PDF-1.7\n\
1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n\
2 0 obj\n<< /Type /Pages /Count 1 /Kids [3 0 R] >>\nendobj\n\
3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 10 10]\n\
   /Resources << /ColorSpace << {color_spaces} >> >> /Contents 4 0 R >>\nendobj\n\
4 0 obj\n<< /Length {} >>\nstream\n{content}\nendstream\nendobj\n\
trailer\n<< /Size 5 /Root 1 0 R >>\n%%EOF\n",
            content.len() + 1
        );

        let doc = crate::Document::open(bytes.into_bytes()).expect("it opens");
        let page = doc.page(0).expect("a page");
        PageResources::new(&page.doc, &page.inner, None)
    }

    /// 8.7.3.2: `[/Pattern base]` is the uncoloured pattern space, and `base`
    /// is where the operands of an `scn` that names a `PaintType 2` pattern
    /// are measured.
    ///
    /// The array form resolved to nothing at all before this, so those
    /// operands could not be read in any space and an uncoloured pattern had
    /// no colour to take. The two spaces below read the same three numbers
    /// differently, so a binder that fell back to RGB for both fails on the
    /// second.
    #[test]
    fn an_uncoloured_pattern_space_resolves_through_its_underlying_space() {
        let res = resources_of(
            "/Prgb [ /Pattern /DeviceRGB ] \
             /Pcmyk [ /Pattern /DeviceCMYK ] \
             /Pbare /Pattern",
        );

        assert_eq!(res.color_components(b"Prgb"), Some(3));
        assert_eq!(
            res.resolve_color(b"Prgb", &[1.0, 0.0, 0.0]),
            Some(tinker_pdf_content::Rgb { r: 255, g: 0, b: 0 }),
        );

        assert_eq!(res.color_components(b"Pcmyk"), Some(4));
        assert_eq!(
            res.resolve_color(b"Pcmyk", &[1.0, 0.0, 0.0, 0.0]),
            Some(tinker_pdf_content::Rgb {
                r: 0,
                g: 255,
                b: 255
            }),
            "cyan, not red — the operands are inks here"
        );

        // 8.7.3.1: a *coloured* pattern space has no underlying space and no
        // colour of its own, which is the black every pattern used to paint.
        assert_eq!(
            res.resolve_color(b"Pbare", &[1.0, 0.0, 0.0]),
            Some(tinker_pdf_content::Rgb { r: 0, g: 0, b: 0 }),
        );
    }

    /// A page's resources built over `DocumentEditor::view` resolve an object
    /// the editor has only just allocated; built over the editor's own
    /// document they cannot, because that document never had it.
    ///
    /// This is the resolution path a redaction that copies a form per
    /// placement needs: `PageResources` holds an `Arc<CosDocument>`, and the
    /// view is one in which the copy exists at the number the editor gave it.
    #[test]
    fn resources_over_an_editors_view_resolve_what_it_allocated() {
        use std::sync::Arc;
        use tinker_pdf_cos::{
            pages, CosDocument, Dict, DocumentBuilder, DocumentEditor, Name, Object, StreamData,
        };

        let mut builder = DocumentBuilder::new();
        builder.add_page(100.0, 100.0, |page| {
            page.fill_rect(10.0, 10.0, 20.0, 20.0, 0.0);
        });
        let doc = Arc::new(CosDocument::open(builder.finish()).expect("it opens"));
        let mut editor = DocumentEditor::new(Arc::clone(&doc));

        let form = editor.allocate();
        let mut dict = Dict::new();
        dict.insert(Name::TYPE, Object::Name(editor.intern(b"XObject")));
        dict.insert(
            editor.intern(b"Subtype"),
            Object::Name(editor.intern(b"Form")),
        );
        dict.insert(
            editor.intern(b"BBox"),
            Object::Array(vec![
                Object::Int(0),
                Object::Int(0),
                Object::Int(10),
                Object::Int(10),
            ]),
        );
        editor.put_stream(
            form,
            StreamData {
                dict,
                data: b"0 0 1 rg 0 0 10 10 re f".to_vec(),
            },
        );
        let page_ref = editor.page_refs()[0];
        let Some(Object::Dict(mut page)) = editor.get(page_ref) else {
            panic!("a page dictionary");
        };
        let mut resources = page.get_dict(Name::RESOURCES).cloned().unwrap_or_default();
        let mut xobjects = Dict::new();
        xobjects.insert(editor.intern(b"Fm9"), Object::Ref(form));
        resources.insert(editor.intern(b"XObject"), Object::Dict(xobjects));
        page.insert(Name::RESOURCES, Object::Dict(resources));
        editor.put(page_ref, Object::Dict(page));

        let view = editor.view().expect("the view opens");
        let viewed = &pages::collect(&view)[0];

        let over_view = PageResources::new(&view, viewed, None);
        let (form_dict, reference) = over_view.xobject(b"Fm9").expect("the form resolves");
        assert_eq!(reference, form);
        assert_eq!(
            form_dict
                .get_name(view.intern(b"Subtype"))
                .and_then(|n| view.name_bytes(n))
                .as_deref(),
            Some(b"Form".as_slice())
        );

        // The same page dictionary over the document the editor was opened
        // with names the form and cannot reach it.
        let over_original = PageResources::new(&editor.shared_document(), viewed, None);
        assert!(over_original.xobject(b"Fm9").is_none());
    }
}
