//! The content-stream interpreter (8.2, 9.4).
//!
//! Operands accumulate on a stack until an operator consumes them. An operator
//! that arrives with the wrong operand count is skipped and the stack cleared,
//! which is what keeps one malformed instruction from desynchronizing the rest
//! of the page.

use crate::device::{Device, Glyph, ImageRef, MarkedProps, PathSegment};
use crate::state::{GraphicsState, LineCap, LineJoin, Matrix, Rgb, TextRenderMode};
use crate::tokenizer::{Token, Tokenizer};
use core::mem;
use std::sync::Arc;
use tinker_pdf_cos::decode_text_string;

/// Everything the interpreter needs from a page's resources.
///
/// This is the seam that keeps the crate free of PDF dictionaries: the
/// interpreter knows *which* font or colour space a stream selected, and the
/// caller says what that name means. Every method has a default, so an
/// implementation supplies only what it has.
/// A form XObject the interpreter is about to run (8.10).
///
/// The bounding box travels with the content rather than being fetched
/// separately, and `form` returns this struct rather than a tuple, so that
/// adding it forced every implementor to supply it. A defaulted accessor
/// would have compiled everywhere and quietly clipped nothing — which is
/// exactly how `GlyphSource::image` once stopped drawing every image in every
/// document with the whole suite green.
#[derive(Clone, Debug)]
pub struct Form {
    /// The decoded content stream.
    pub content: Vec<u8>,
    /// `/Matrix`, mapping form space into the space that invoked it.
    pub matrix: Matrix,
    /// `/BBox` in form space, as `[x0, y0, x1, y1]`.
    ///
    /// 8.10.2 makes it required and says the form is clipped to it. `None`
    /// means the file omitted it, in which case there is nothing to clip to
    /// and the form is drawn unclipped rather than dropped.
    pub bbox: Option<[f64; 4]>,
    /// `/Group` with `/S /Transparency` (11.6.6), when the form is one.
    pub group: Option<Group>,
    /// The form's own indirect reference, packed as `num << 16 | gen`, and
    /// `0` when the caller reached the stream without one.
    ///
    /// 14.7.4.2 numbers marked-content sequences **within a content stream**,
    /// so an `/MCID` only identifies a sequence beside the stream it was
    /// written in: two forms on one page may each write `/MCID 0`, and a
    /// structure join keyed on the identifier alone hands both sequences to
    /// both elements. This is the other half of that key, and it travels with
    /// the content for the same reason [`Form::bbox`] does — adding it as a
    /// field forced every implementor to supply it rather than inherit a
    /// defaulted accessor that would have compiled everywhere and silently
    /// gone on collapsing the pair.
    ///
    /// A plain integer, not a COS reference: ruling 8 keeps object types out
    /// of this crate, and an identity is all a device needs. Packing rather
    /// than the object number alone because 7.3.10 makes `num gen` the
    /// reference, and a regenerated object reuses the number.
    pub stream: u64,
}

/// A transparency group XObject's attributes (11.6.6).
///
/// 11.6.6 lets `/CS` name the space the group's contents are composited in,
/// and [`Group::space`] below carries it: grey, RGB and CMYK groups each
/// composite in their own, which is what `CmykA8` exists for. `/Lab` is the
/// one that does not, and it is reported by name rather than silently
/// composited in RGB.
///
/// This comment used to say the colour space was *deliberately absent* and
/// that the engine composited in RGB throughout. That stopped being true when
/// the field three lines below was added, and it stayed here — which is the
/// direction of documentation drift that is hardest to catch, because a reader
/// checking the claim against the struct sees the contradiction and a reader
/// checking the struct against the claim does not.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Group {
    /// `/I`: the group composites against a transparent backdrop rather than
    /// against what is already on the page (11.4.4).
    pub isolated: bool,
    /// `/K`: each element composites against the group's *initial* backdrop
    /// rather than against the elements before it (11.4.5).
    pub knockout: bool,
    /// `/CS`: the space the group's contents are composited in (11.6.6).
    ///
    /// `None` where the group declares no space, which 11.6.6 permits — the
    /// group then inherits the space it is composited into.
    pub space: Option<GroupSpace>,
}

/// Which of 11.6.6's blending spaces a group's `/CS` names.
///
/// The *shape* of the space rather than the space itself, and deliberately so.
/// A blend formula in 11.3.5 acts on component values, so what a compositor
/// needs from `/CS` is how many components there are and whether they are
/// subtractive — not the palette, the tint transform or the profile that
/// decides what those components *mean*. Keeping it to that also keeps
/// [`Group`] `Copy`, which every save and restore of the graphics state relies
/// on.
///
/// Exact conversion between these — which is what makes a CMYK group blend
/// like one rather than merely be named as one — is `docs/design/icc.md`'s
/// stage 1.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GroupSpace {
    /// One component, additive.
    Gray,
    /// Three components, additive.
    Rgb,
    /// Four components, subtractive.
    Cmyk,
    /// CIE L*a*b*, whose components are not in `0..1` at all.
    Lab,
}

impl GroupSpace {
    /// Whether compositing this group in RGB is the same arithmetic as
    /// compositing it in its own space.
    ///
    /// True for grey and RGB, and the grey case is worth stating rather than
    /// assuming: a separable blend applied per channel to `R = G = B` produces
    /// `R' = G' = B'` equal to the same blend applied to the single grey
    /// channel, because each channel's formula is the same function of the
    /// same two numbers. Subtractive components are a different formula, and
    /// `/Lab`'s are not even in the unit interval.
    #[must_use]
    pub fn blends_as_rgb(self) -> bool {
        matches!(self, GroupSpace::Gray | GroupSpace::Rgb)
    }

    /// What to call it in a warning.
    #[must_use]
    pub fn name(self) -> &'static str {
        match self {
            GroupSpace::Gray => "DeviceGray",
            GroupSpace::Rgb => "DeviceRGB",
            GroupSpace::Cmyk => "DeviceCMYK",
            GroupSpace::Lab => "Lab",
        }
    }
}

/// An ExtGState `/SMask` (11.6.5.1).
#[derive(Clone, Debug)]
pub enum SoftMask {
    /// `/None`: whatever mask was in force stops applying.
    None,
    /// A group to render and read back as a mask.
    Group(Box<MaskGroup>),
}

/// Whichever resource dictionary is in force: the caller's, or a form's own.
///
/// A borrow while the page's own resources are in force, which is every
/// content stream and most of every other one; owned only while a form that
/// brought its own is running.
enum Scope<'d, F> {
    /// The caller's, borrowed for the whole run.
    Borrowed(&'d F),
    /// A form's own, shared with whatever cached it.
    Owned(Arc<F>),
}

impl<F> core::ops::Deref for Scope<'_, F> {
    type Target = F;

    fn deref(&self) -> &F {
        match self {
            Scope::Borrowed(fonts) => fonts,
            Scope::Owned(fonts) => fonts,
        }
    }
}

/// The `/SMask` dictionary's group, resolved (11.6.5.2).
#[derive(Clone, Debug)]
pub struct MaskGroup {
    /// `/G`, the transparency group XObject that draws the mask.
    pub form: Form,
    /// `/S`: true for `/Luminosity`, false for `/Alpha`.
    pub luminosity: bool,
    /// `/BC`, resolved through the group's own colour space.
    ///
    /// **`None` means black, which means fully masked.** 11.6.5.2 composites
    /// the mask group against a fully opaque backdrop of this colour and
    /// takes the luminosity of the result, and the default is the black of
    /// the group's space. Defaulting to white or to transparent inverts every
    /// drop shadow in a corpus and still looks reasonable on a light page —
    /// the shadow appears where the light should be, which reads as a design
    /// choice rather than as a bug. Only meaningful for `/Luminosity`.
    pub backdrop: Option<Rgb>,
    /// `/TR`, pre-sampled to 256 entries; `None` is `/Identity`.
    ///
    /// Sampled rather than carried as a function because it is applied per
    /// pixel, and a function on a pixel path is both ruinously slow and a
    /// route back to the platform's `libm` (ruling 4).
    pub transfer: Option<[u8; 256]>,
}

/// An optional-content layer, as the resource seam resolved it (8.11).
///
/// The interpreter cannot decide this: `/OCProperties` lives in the catalog
/// and the groups are indirect objects, neither of which this crate can see.
/// So it asks, and gets back the two things it has any use for — whether to
/// paint, and what to call the layer if it does not.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layer {
    /// Whether the document's default configuration paints this layer.
    pub visible: bool,
    /// What to call it: the group's `/Name`, which is the string a viewer's
    /// layer panel shows, falling back to the resource name.
    ///
    /// Ruling 10 — a warning that cannot say *which* layer it hid is not
    /// actionable, and a hidden layer is exactly the leniency a reader cannot
    /// see for themselves.
    pub label: String,
}

pub trait FontSource {
    /// Splits a string into `(code, text, advance in 1/1000 em)`.
    fn decode(&self, font: &[u8], bytes: &[u8]) -> Vec<(u32, String, f64)>;

    /// Whether the named font writes vertically.
    fn is_vertical(&self, font: &[u8]) -> bool {
        let _ = font;
        false
    }

    /// The vertical metrics of one code, in 1/1000 em: `(v_x, v_y, w1_y)`.
    ///
    /// 9.7.4.3. `w1_y` is the displacement — how far the pen moves along the
    /// column, negative because text space has y upward — and `(v_x, v_y)` is
    /// the position vector, which is where within its em box the glyph is
    /// drawn: a comma belongs in a different corner vertically than
    /// horizontally, and the offset is what puts it there.
    ///
    /// Only consulted when [`FontSource::is_vertical`] is true, and it has no
    /// default on purpose. A defaulted one would compile in every
    /// implementation that ever grows a vertical font and quietly advance
    /// every column by nothing — which is the shape of the bug this method
    /// exists to close, where the horizontal advance was applied downward
    /// because nothing else was on offer.
    fn vertical_metrics(&self, font: &[u8], code: u32) -> (f64, f64, f64);

    /// A stable identifier for the named font.
    fn font_id(&self, font: &[u8]) -> u64 {
        let _ = font;
        0
    }

    /// The named font's own name — its `/BaseFont`, as the dictionary writes
    /// it — for [`Glyph::font_name`].
    ///
    /// Asked once per text-showing operator, in the scope the operator runs
    /// in, which is the only place the resource name can be resolved
    /// correctly. `None` — the default — where the source has no name to
    /// give, which is also the honest answer for a font that has none.
    fn font_name(&self, font: &[u8]) -> Option<Arc<str>> {
        let _ = font;
        None
    }

    /// A form XObject, when the interpreter should recurse into one.
    /// Returning `None` skips it.
    fn form(&self, name: &[u8]) -> Option<Form> {
        let _ = name;
        None
    }

    /// The resources a form XObject brings with it, if it has its own.
    ///
    /// 8.10.1: a form's `/Resources` names what its content stream may refer
    /// to, and a form written beside one document and pasted into another
    /// brings the only dictionary its names resolve in. Returning `None` keeps
    /// the invoking scope, which is what a form that omits the key relies on
    /// and what every reader does.
    ///
    /// The device is asked the same question at the same moment, by name,
    /// through [`Device::begin_form`] — the two seams resolve the same form
    /// independently rather than passing a resource object between them, which
    /// is what keeps a crate that must not know what a resource dictionary is
    /// from having to hold one.
    /// Shared rather than owned, and cached by the implementor: a page that
    /// invokes one form a thousand times must not build its resources a
    /// thousand times. Two corpus files stalled outright when it did.
    fn form_scope(&self, name: &[u8]) -> Option<Arc<Self>>
    where
        Self: Sized,
    {
        let _ = name;
        None
    }

    /// A Type 3 glyph procedure and the font's `/FontMatrix` (9.6.5).
    ///
    /// A Type 3 glyph is a content stream, not an outline: it can fill, stroke,
    /// draw images, do anything a page can. So it is *run*, the way a form
    /// XObject is, rather than handed to a glyph source that only knows how to
    /// return curves.
    ///
    /// `None` for every other kind of font, which is what keeps the ordinary
    /// path unchanged.
    fn type3_glyph(&self, font: &[u8], code: u32) -> Option<(Vec<u8>, Matrix)> {
        let _ = (font, code);
        None
    }

    /// The RGB a named colour space gives these components.
    ///
    /// The interpreter cannot know what `/CS0 0.2 0.9 0.1 scn` means — RGB, a
    /// separation, an indexed palette — because only the resource dictionary
    /// says. `None` leaves the colour unchanged, which is what a viewer does
    /// with a space it cannot resolve.
    fn resolve_color(&self, space: &[u8], components: &[f64]) -> Option<Rgb> {
        let _ = (space, components);
        None
    }

    /// The components themselves, as bytes, when the named space **is**
    /// DeviceCMYK, and `None` for every other space — the default, which
    /// keeps every colour light.
    ///
    /// Asked beside [`FontSource::resolve_color`] so that a device
    /// compositing in ink can keep the document's own
    /// ([`GraphicsState::fill_ink`]): light converted back into ink is not
    /// the ink the file chose.
    fn resolve_ink(&self, space: &[u8], components: &[f64]) -> Option<[u8; 4]> {
        let _ = (space, components);
        None
    }

    /// The colour `cs` resets a named space to (8.6.8), which each space's
    /// own clause gives: black in every device space, which for DeviceCMYK is
    /// `0 0 0 1` and not all zeros; a tint of 1.0 for `/Separation` (8.6.6.4)
    /// and 1.0 in every component for `/DeviceN` (8.6.6.5); zero, or the
    /// nearest value a `/Range` allows, for `/Lab` (8.6.5.4).
    ///
    /// The default is all zeros at [`FontSource::color_components`]'s count,
    /// which is right for DeviceGray, DeviceRGB, the CIE-based and ICC
    /// spaces and an `/Indexed` space's index, and wrong for the others
    /// above; an implementation that can tell those apart answers for them.
    fn initial_color(&self, space: &[u8]) -> Option<Vec<f64>> {
        self.color_components(space).map(|n| vec![0.0; n])
    }

    /// The fill and stroke alphas an `/ExtGState` sets, if it sets them.
    fn ext_g_state_alpha(&self, name: &[u8]) -> Option<(Option<f64>, Option<f64>)> {
        let _ = name;
        None
    }

    /// `/BM` from a named external graphics state (11.3.5).
    ///
    /// Separate from the alphas rather than folded in with them because a
    /// dictionary may set either without the other, and `None` here has to
    /// mean "unchanged" rather than "Normal" — a `gs` that sets only `/ca`
    /// must not silently reset the blend mode.
    fn ext_g_state_blend(&self, name: &[u8]) -> Option<crate::state::BlendMode> {
        let _ = name;
        None
    }

    /// `/SMask` from a named external graphics state (11.6.5.1).
    ///
    /// Separate from the alphas and from `/BM` for the same reason those two
    /// are separate from each other: a dictionary may set any of the three
    /// without the others, and `None` here has to mean "unchanged" rather
    /// than "no mask". A `gs` that sets only `/ca` must not clear a soft mask
    /// somebody else installed.
    fn ext_g_state_soft_mask(&self, name: &[u8]) -> Option<SoftMask> {
        let _ = name;
        None
    }

    /// How many components a named colour space takes.
    ///
    /// Used to tell `scn`'s optional trailing pattern name from its numeric
    /// operands.
    fn color_components(&self, space: &[u8]) -> Option<usize> {
        let _ = space;
        None
    }

    /// The optional-content layer a name in the `/Properties` resource
    /// sub-dictionary selects (8.11.3.2).
    ///
    /// `None` means the name is not optional content at all — an ordinary
    /// `/Span` or `/Artifact` property list, or a name the resources do not
    /// define — and that is not the same as a hidden layer. Every `None`
    /// path here ends in content being painted, which is the direction a
    /// reader can recover from.
    fn optional_content(&self, name: &[u8]) -> Option<Layer> {
        let _ = name;
        None
    }

    /// The `/OC` entry on a form or image XObject (8.11.4.4).
    ///
    /// Separate from [`FontSource::optional_content`] because the two look in
    /// different dictionaries: one in `/Properties`, the other on the XObject
    /// itself.
    fn xobject_optional_content(&self, name: &[u8]) -> Option<Layer> {
        let _ = name;
        None
    }

    /// The 14.6.2 and 14.9 values a *named* property list holds
    /// (`/P /MC0 BDC`).
    ///
    /// The same `/Properties` sub-dictionary [`FontSource::optional_content`]
    /// reads, asked a different question: that one wants a layer, this one
    /// wants `/MCID` and the alternate descriptions 14.9 allows beside it. A
    /// name may legitimately answer both, neither, or one — an `/OC` list is
    /// an optional-content group with no `/MCID`, and a `/Span` list is a
    /// property list with no layer — so they are two methods rather than one
    /// returning a pair, and a build that supplies only one is not broken.
    ///
    /// `None` means the name reached no property list this build could read.
    /// It never means "hidden": nothing in this method's answer can suppress
    /// content.
    fn marked_content_properties(&self, name: &[u8]) -> Option<MarkedProps> {
        let _ = name;
        None
    }
}

/// How deep form XObjects may nest before recursion is refused (8.10).
const MAX_FORM_DEPTH: u32 = 16;

/// A `BDC`'s property list, in the two forms 14.6.2 gives it.
///
/// Three variants and not two: "the file wrote no readable list" is a
/// different fact from "the file wrote an empty one", and only the first may
/// ever be inferred from damage. Collapsing them would make a truncated
/// stream indistinguishable from a producer that meant `<< >>`.
enum Properties {
    /// `/Tag /MC0 BDC` — a name into the page's `/Properties`.
    Named(Vec<u8>),
    /// `/Tag << … >> BDC` — an inline dictionary, already reassembled.
    Inline(MarkedProps),
    /// Neither: a `BDC` whose operands this build could not read.
    None,
}

/// Reads the plain values out of a flattened inline property list.
///
/// `body` is every token strictly between the `<<` and its `>>`, in stream
/// order. 7.8.2's tokenizer does not build dictionaries, so this walks the
/// flat run: a name is a key, the token after it is its value, and a value
/// that opens a container is skipped whole. Only 14.7.4.2's `/MCID` and
/// 14.9's four text strings are kept — everything else a property list may
/// carry (`/Type`, `/BBox`, `/Placement`, a producer's private entries) is
/// read past rather than stored, because storing it would put a COS-shaped
/// object in a crate that has no object model.
///
/// **Nothing here can fail.** A key with no value, a value of the wrong
/// type, an unbalanced container, a run of bare values with no key at all:
/// each is skipped and the walk continues. What comes back is what was
/// legible, which for a damaged list is nothing — and nothing is a visible
/// scope with no `/MCID`, which is the direction 14.6.2's failures are ruled
/// to fall in.
fn read_inline_properties(body: &[Token]) -> MarkedProps {
    let mut props = MarkedProps::default();
    let mut at = 0usize;

    while at < body.len() && at < MAX_INLINE_PROPERTY_TOKENS {
        let Some(Token::Name(key)) = body.get(at) else {
            // A value where a key belongs. Step over exactly one token so a
            // run of them costs one step each rather than stalling.
            at += 1;
            continue;
        };
        at += 1;
        let Some(value) = body.get(at) else {
            // 7.3.7's "a key with no value"; there is nothing after it.
            break;
        };
        // A container-valued entry is skipped whole: none of the five keys
        // read here is ever an array or a dictionary, and stepping into one
        // would read its members as top-level keys.
        if matches!(value, Token::ArrayOpen | Token::DictOpen) {
            at = skip_container(body, at);
            continue;
        }
        at += 1;

        match (key.as_slice(), value) {
            // 14.7.4.2: a non-negative integer. `f64` is what the tokenizer
            // produces for every number, so integrality is checked rather
            // than assumed — an `/MCID 3.5` names no marked sequence, and
            // rounding it would join content to the wrong element.
            (b"MCID", Token::Number(n)) => {
                let integral = n.is_finite() && n.fract() == 0.0;
                if integral && *n >= 0.0 && *n <= f64::from(u32::MAX) {
                    props.mcid = Some(*n as u32);
                }
            }
            // 14.9.2 to 14.9.5. All four are *text strings* (7.9.2.2), so
            // they are decoded by the document's own rules rather than read
            // as UTF-8: a `/Alt` written UTF-16BE is the common case, and
            // taking its bytes literally yields interleaved NULs.
            (b"ActualText", Token::String(bytes)) => {
                props.actual_text = Some(decode_text_string(bytes));
            }
            (b"Alt", Token::String(bytes)) => props.alt = Some(decode_text_string(bytes)),
            (b"Lang", Token::String(bytes)) => props.lang = Some(decode_text_string(bytes)),
            (b"E", Token::String(bytes)) => props.expansion = Some(decode_text_string(bytes)),
            _ => {}
        }
    }

    props
}

/// The index just past the container opening at `at`.
///
/// Arrays and dictionaries are counted together, because 7.8.2 flattens both
/// and a stream may close one with the other's delimiter. Treating them as
/// one nesting level means a mismatched close ends the container instead of
/// leaving the scan inside it forever, which is the failure that matters:
/// this walk must terminate on every input, and it is not the place where a
/// malformed inline dictionary gets diagnosed.
fn skip_container(body: &[Token], at: usize) -> usize {
    let mut depth = 0usize;
    let mut index = at;
    while index < body.len() && index < MAX_INLINE_PROPERTY_TOKENS {
        match body[index] {
            Token::ArrayOpen | Token::DictOpen => depth += 1,
            Token::ArrayClose | Token::DictClose => {
                depth -= 1;
                if depth == 0 {
                    return index + 1;
                }
            }
            _ => {}
        }
        index += 1;
    }
    index
}

/// How many tokens of one flattened inline property list are examined
/// (14.6.2, 7.8.2).
///
/// The operand stack is already bounded to 512 by [`Interpreter::run`], so
/// this can never be the binding limit today. It is named anyway because the
/// scan below is the only place in the interpreter that walks the stack
/// *forwards* over an unbounded number of key/value pairs, and a later
/// change to the stack bound must not silently make that walk unbounded.
const MAX_INLINE_PROPERTY_TOKENS: usize = 512;

/// How many marked-content scopes may be open at once (14.6.2).
///
/// Past the cap a scope is not reported to the device at all, and `EMC`
/// balances against the same counter so the nesting the device sees stays
/// correct. Unreported means *visible*, which is the direction a runaway
/// stream should fail in: the alternative is a file that hides a page by
/// nesting `BDC` four thousand deep.
const MAX_MARKED_CONTENT_DEPTH: u32 = 4096;

/// Runs a content stream against a device.
pub fn interpret<D: Device, F: FontSource>(
    content: &[u8],
    initial: Matrix,
    device: &mut D,
    fonts: &F,
) {
    let mut interp = Interpreter {
        device,
        fonts: Scope::Borrowed(fonts),
        stack: Vec::new(),
        gs: GraphicsState::new(initial),
        saved: Vec::new(),
        text_matrix: Matrix::IDENTITY,
        line_matrix: Matrix::IDENTITY,
        path: Vec::new(),
        current: (0.0, 0.0),
        start: (0.0, 0.0),
        depth: 0,
        pending_clip: None,
        marked: 0,
        marked_over_cap: 0,
        streams: Vec::new(),
    };
    interp.run(content);
    // 14.6.2: a stream may end with scopes still open, and a device left
    // inside one would treat everything after it as part of that layer.
    interp.close_open_marked_content();
}

struct Interpreter<'d, D: Device, F: FontSource> {
    device: &'d mut D,
    fonts: Scope<'d, F>,
    stack: Vec<Token>,
    gs: GraphicsState,
    saved: Vec<GraphicsState>,
    text_matrix: Matrix,
    line_matrix: Matrix,
    path: Vec<PathSegment>,
    current: (f64, f64),
    start: (f64, f64),
    depth: u32,
    pending_clip: Option<bool>,
    /// Marked-content scopes open in the stream being run, and reported to
    /// the device (14.6.2).
    marked: u32,
    /// Scopes refused by [`MAX_MARKED_CONTENT_DEPTH`], so that an `EMC`
    /// closes the one it belongs to rather than an outer one.
    marked_over_cap: u32,
    /// The form XObject streams being run, innermost last (14.7.4.2).
    ///
    /// Empty while the page's own content stream is running, which is why
    /// [`Interpreter::stream`] reads an empty stack as `0`. A form whose
    /// [`Form::stream`] is `0` — one the resource layer reached without a
    /// reference — pushes nothing, so its content keeps the identity of the
    /// stream that invoked it: that is the old behaviour, kept for the case
    /// where there is no better answer rather than asserted as one.
    streams: Vec<u64>,
}

impl<D: Device, F: FontSource> Interpreter<'_, D, F> {
    fn run(&mut self, content: &[u8]) {
        let mut tokens = Tokenizer::new(content);

        while let Some(token) = tokens.next_token() {
            if self.device.is_cancelled() {
                return;
            }

            let Token::Operator(op) = token else {
                self.stack.push(token);
                // A runaway operand list means a stream with no operators;
                // bound it rather than accumulate forever.
                if self.stack.len() > 512 {
                    self.stack.remove(0);
                }
                continue;
            };

            match op.as_slice() {
                b"BI" => {
                    // 8.9.7: an inline image's data is not tokenizable, so the
                    // span from here to `EI` is taken whole and handed to the
                    // device, which is the layer that can read a dictionary
                    // and run a filter chain.
                    let rest = tokens.rest();
                    let consumed = skip_inline_image(rest);
                    let at = tokens.position();
                    tokens.seek(at + consumed);

                    let span = rest.get(..consumed).unwrap_or(rest);
                    let (dict, data) = split_inline_image(span);
                    self.device.draw_image(
                        &ImageRef {
                            name: Vec::new(),
                            inline: true,
                            inline_dict: dict.to_vec(),
                            inline_data: data.to_vec(),
                        },
                        &self.gs,
                    );
                }
                _ => self.operator(&op),
            }
            self.stack.clear();
        }
    }

    fn num(&self, from_end: usize) -> Option<f64> {
        match self
            .stack
            .get(self.stack.len().checked_sub(from_end + 1)?)?
        {
            Token::Number(v) if v.is_finite() => Some(*v),
            _ => None,
        }
    }

    /// Reads `d`: a dash array and a phase (8.4.3.6).
    ///
    /// An array of all zeros, or one containing a negative, is invalid and
    /// means a solid line rather than an invisible one — the alternative is a
    /// stroke that vanishes, which reads as missing content.
    fn set_dashes(&mut self) {
        let phase = self.num(0).filter(|v| v.is_finite() && *v >= 0.0);
        let Some(phase) = phase else { return };

        // The array is the operand before the phase, and the tokenizer leaves
        // its elements on the stack between the brackets.
        let mut dashes: Vec<f64> = Vec::new();
        let mut seen_open = false;
        for token in self.stack.iter().rev().skip(1) {
            match token {
                Token::Number(v) if v.is_finite() && *v >= 0.0 => dashes.push(*v),
                Token::ArrayClose => {}
                Token::ArrayOpen => {
                    seen_open = true;
                    break;
                }
                _ => return,
            }
        }
        if !seen_open {
            return;
        }
        dashes.reverse();

        if dashes.iter().all(|v| *v == 0.0) {
            dashes.clear();
        }
        self.gs.dashes = dashes;
        self.gs.dash_phase = phase;
    }

    fn operator(&mut self, op: &[u8]) {
        match op {
            // 8.4.4 graphics state
            b"q" => {
                if self.saved.len() < 64 {
                    self.saved.push(self.gs.clone());
                    self.device.save_state();
                }
            }
            b"Q" => {
                if let Some(prev) = self.saved.pop() {
                    self.gs = prev;
                    self.device.restore_state();
                }
            }
            b"cm" => {
                if let (Some(a), Some(b), Some(c), Some(d), Some(e), Some(f)) = (
                    self.num(5),
                    self.num(4),
                    self.num(3),
                    self.num(2),
                    self.num(1),
                    self.num(0),
                ) {
                    let m = Matrix { a, b, c, d, e, f };
                    let next = m.then(&self.gs.ctm);
                    // A degenerate matrix voids everything after it, so keep
                    // the previous one and carry on.
                    if next.is_finite() {
                        self.gs.ctm = next;
                    }
                }
            }

            // 9.4.1 text objects
            b"BT" => {
                self.text_matrix = Matrix::IDENTITY;
                self.line_matrix = Matrix::IDENTITY;
                self.device.begin_text();
            }
            b"ET" => self.device.end_text(),

            // 9.3 text state
            b"Tf" => {
                if let (Some(Token::Name(name)), Some(size)) = (
                    self.stack.get(self.stack.len().wrapping_sub(2)).cloned(),
                    self.num(0),
                ) {
                    self.gs.text.font = Some(name);
                    self.gs.text.size = size;
                }
            }
            b"Tc" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.char_spacing = v;
                }
            }
            b"Tw" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.word_spacing = v;
                }
            }
            b"Tz" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.horizontal_scale = v / 100.0;
                }
            }
            b"TL" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.leading = v;
                }
            }
            b"Ts" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.rise = v;
                }
            }
            b"Tr" => {
                if let Some(v) = self.num(0) {
                    self.gs.text.render_mode = TextRenderMode::from_i64(v as i64);
                }
            }

            // 9.4.2 text positioning
            b"Td" => {
                if let (Some(tx), Some(ty)) = (self.num(1), self.num(0)) {
                    self.line_matrix = Matrix::translate(tx, ty).then(&self.line_matrix);
                    self.text_matrix = self.line_matrix;
                }
            }
            b"TD" => {
                if let (Some(tx), Some(ty)) = (self.num(1), self.num(0)) {
                    self.gs.text.leading = -ty;
                    self.line_matrix = Matrix::translate(tx, ty).then(&self.line_matrix);
                    self.text_matrix = self.line_matrix;
                }
            }
            b"Tm" => {
                if let (Some(a), Some(b), Some(c), Some(d), Some(e), Some(f)) = (
                    self.num(5),
                    self.num(4),
                    self.num(3),
                    self.num(2),
                    self.num(1),
                    self.num(0),
                ) {
                    let m = Matrix { a, b, c, d, e, f };
                    if m.is_finite() {
                        self.line_matrix = m;
                        self.text_matrix = m;
                    }
                }
            }
            b"T*" => self.next_line(),

            // 9.4.3 text showing
            b"Tj" => {
                if let Some(Token::String(s)) = self.stack.last().cloned() {
                    self.show(&s);
                }
            }
            b"'" => {
                self.next_line();
                if let Some(Token::String(s)) = self.stack.last().cloned() {
                    self.show(&s);
                }
            }
            b"\"" => {
                if let (Some(aw), Some(ac)) = (self.num(2), self.num(1)) {
                    self.gs.text.word_spacing = aw;
                    self.gs.text.char_spacing = ac;
                }
                self.next_line();
                if let Some(Token::String(s)) = self.stack.last().cloned() {
                    self.show(&s);
                }
            }
            b"TJ" => self.show_array(),

            // 8.5.2 path construction, accumulated in user space and
            // transformed as it is built.
            b"m" => {
                if let (Some(x), Some(y)) = (self.num(1), self.num(0)) {
                    let p = self.gs.ctm.apply(x, y);
                    self.current = p;
                    self.start = p;
                    self.push_segment(PathSegment::MoveTo { x: p.0, y: p.1 });
                }
            }
            b"l" => {
                if let (Some(x), Some(y)) = (self.num(1), self.num(0)) {
                    let p = self.gs.ctm.apply(x, y);
                    self.current = p;
                    self.push_segment(PathSegment::LineTo { x: p.0, y: p.1 });
                }
            }
            b"c" => {
                if let (Some(x1), Some(y1), Some(x2), Some(y2), Some(x3), Some(y3)) = (
                    self.num(5),
                    self.num(4),
                    self.num(3),
                    self.num(2),
                    self.num(1),
                    self.num(0),
                ) {
                    let a = self.gs.ctm.apply(x1, y1);
                    let b = self.gs.ctm.apply(x2, y2);
                    let c = self.gs.ctm.apply(x3, y3);
                    self.current = c;
                    self.push_segment(PathSegment::CurveTo {
                        x1: a.0,
                        y1: a.1,
                        x2: b.0,
                        y2: b.1,
                        x3: c.0,
                        y3: c.1,
                    });
                }
            }
            b"v" => {
                if let (Some(x2), Some(y2), Some(x3), Some(y3)) =
                    (self.num(3), self.num(2), self.num(1), self.num(0))
                {
                    let a = self.current;
                    let b = self.gs.ctm.apply(x2, y2);
                    let c = self.gs.ctm.apply(x3, y3);
                    self.current = c;
                    self.push_segment(PathSegment::CurveTo {
                        x1: a.0,
                        y1: a.1,
                        x2: b.0,
                        y2: b.1,
                        x3: c.0,
                        y3: c.1,
                    });
                }
            }
            b"y" => {
                if let (Some(x1), Some(y1), Some(x3), Some(y3)) =
                    (self.num(3), self.num(2), self.num(1), self.num(0))
                {
                    let a = self.gs.ctm.apply(x1, y1);
                    let c = self.gs.ctm.apply(x3, y3);
                    self.current = c;
                    self.push_segment(PathSegment::CurveTo {
                        x1: a.0,
                        y1: a.1,
                        x2: c.0,
                        y2: c.1,
                        x3: c.0,
                        y3: c.1,
                    });
                }
            }
            b"h" => {
                self.current = self.start;
                self.push_segment(PathSegment::Close);
            }
            b"re" => {
                if let (Some(x), Some(y), Some(w), Some(h)) =
                    (self.num(3), self.num(2), self.num(1), self.num(0))
                {
                    let p0 = self.gs.ctm.apply(x, y);
                    let p1 = self.gs.ctm.apply(x + w, y);
                    let p2 = self.gs.ctm.apply(x + w, y + h);
                    let p3 = self.gs.ctm.apply(x, y + h);
                    self.push_segment(PathSegment::MoveTo { x: p0.0, y: p0.1 });
                    self.push_segment(PathSegment::LineTo { x: p1.0, y: p1.1 });
                    self.push_segment(PathSegment::LineTo { x: p2.0, y: p2.1 });
                    self.push_segment(PathSegment::LineTo { x: p3.0, y: p3.1 });
                    self.push_segment(PathSegment::Close);
                    self.current = p0;
                    self.start = p0;
                }
            }

            // 8.5.3 path painting
            b"S" | b"s" => {
                if op == b"s" {
                    self.push_segment(PathSegment::Close);
                }
                let path = std::mem::take(&mut self.path);
                self.device.stroke_path(&path, &self.gs);
                self.apply_pending_clip(&path);
            }
            b"f" | b"F" | b"f*" | b"B" | b"B*" | b"b" | b"b*" => {
                let even_odd = op.ends_with(b"*");
                let path = std::mem::take(&mut self.path);
                self.device.fill_path(&path, &self.gs, even_odd);
                if matches!(op, b"B" | b"B*" | b"b" | b"b*") {
                    self.device.stroke_path(&path, &self.gs);
                }
                self.apply_pending_clip(&path);
            }
            b"n" => {
                let path = std::mem::take(&mut self.path);
                self.apply_pending_clip(&path);
            }
            // 8.5.4: W and W* mark the current path as the new clip, but it
            // does not take effect until the painting operator that ends the
            // path — which is why this only records the intent.
            b"W" => self.pending_clip = Some(false),
            b"W*" => self.pending_clip = Some(true),

            // 8.10 XObjects
            b"Do" => {
                if let Some(Token::Name(name)) = self.stack.last().cloned() {
                    self.do_xobject(&name);
                }
            }

            // 8.4.3 line parameters. All of them reach the device: a stroke
            // drawn with the wrong cap, or without its dashes, is wrong in a
            // way that looks deliberate.
            b"w" => {
                if let Some(v) = self.num(0) {
                    if v.is_finite() && v >= 0.0 {
                        self.gs.line_width = v;
                    }
                }
            }
            b"J" => {
                if let Some(v) = self.num(0) {
                    self.gs.line_cap = LineCap::from_operand(v);
                }
            }
            b"j" => {
                if let Some(v) = self.num(0) {
                    self.gs.line_join = LineJoin::from_operand(v);
                }
            }
            b"M" => {
                if let Some(v) = self.num(0) {
                    // 8.4.3.5: a limit below 1 is meaningless — the ratio it
                    // bounds is never less than 1 — so it is ignored rather
                    // than turning every join into a bevel.
                    if v.is_finite() && v >= 1.0 {
                        self.gs.miter_limit = v;
                    }
                }
            }
            b"d" => self.set_dashes(),
            b"ri" | b"i" => {}

            // 8.6.8 colour. The device operators resolve immediately; the
            // named ones go through the resource seam.
            b"g" | b"G" => {
                if let Some(v) = self.num(0) {
                    let value = to_byte(v);
                    let color = Rgb {
                        r: value,
                        g: value,
                        b: value,
                    };
                    self.set_color(op == b"g", color, None, None);
                }
            }
            b"rg" | b"RG" => {
                if let (Some(r), Some(g), Some(b)) = (self.num(2), self.num(1), self.num(0)) {
                    let color = Rgb {
                        r: to_byte(r),
                        g: to_byte(g),
                        b: to_byte(b),
                    };
                    self.set_color(op == b"rg", color, None, None);
                }
            }
            b"k" | b"K" => {
                if let (Some(c), Some(m), Some(y), Some(k)) =
                    (self.num(3), self.num(2), self.num(1), self.num(0))
                {
                    let ink = [to_byte(c), to_byte(m), to_byte(y), to_byte(k)];
                    self.set_color(op == b"k", cmyk_to_rgb(c, m, y, k), None, Some(ink));
                }
            }
            b"cs" | b"CS" => {
                let Some(Token::Name(space)) = self.stack.last().cloned() else {
                    return;
                };
                let fill = op == b"cs";
                // 8.6.8: selecting a space resets the colour to that space's
                // initial value, which is black in every device space — and
                // DeviceCMYK's black is `0 0 0 1`, which an all-zeros reset
                // made white — and the whole colorant, a tint of 1.0, in a
                // `/Separation` or `/DeviceN` one, which it made none.
                let components = self.fonts.initial_color(&space);
                let initial = components
                    .as_ref()
                    .and_then(|c| self.fonts.resolve_color(&space, c))
                    .unwrap_or(Rgb::BLACK);
                let ink = components
                    .as_ref()
                    .and_then(|c| self.fonts.resolve_ink(&space, c));
                self.set_color(fill, initial, Some(space), ink);
            }
            b"sc" | b"SC" | b"scn" | b"SCN" => {
                let fill = op == b"sc" || op == b"scn";
                let components: Vec<f64> = self
                    .stack
                    .iter()
                    .filter_map(|t| match t {
                        Token::Number(v) if v.is_finite() => Some(*v),
                        _ => None,
                    })
                    .collect();
                let space = if fill {
                    self.gs.fill_space.clone()
                } else {
                    self.gs.stroke_space.clone()
                };

                // 8.6.8.2: `scn` may end with a pattern name, with or without
                // preceding components (an uncoloured pattern takes both).
                if let Some(Token::Name(name)) = self.stack.last().cloned() {
                    // 8.7.3.2: those preceding components are the colour a
                    // `PaintType 2` pattern paints with — it supplies shape
                    // and nothing else — and they are measured in the
                    // underlying space of `[/Pattern base]`, which is the
                    // space this slot is already in. Dropping them, which is
                    // what happened before, left the slot holding whatever
                    // `cs` had reset it to and the pattern with no colour to
                    // take.
                    if !components.is_empty() {
                        if let Some(color) = space
                            .as_ref()
                            .and_then(|s| self.fonts.resolve_color(s, &components))
                        {
                            self.set_color(fill, color, None, None);
                        }
                    }
                    self.set_pattern(fill, name);
                    return;
                }
                if components.is_empty() {
                    return;
                }

                let (resolved, ink) = match &space {
                    Some(space) => (
                        self.fonts.resolve_color(space, &components),
                        self.fonts.resolve_ink(space, &components),
                    ),
                    // Without a named space the component count is the only
                    // clue, and it is a reliable one: four is DeviceCMYK.
                    None => (
                        Some(components_to_rgb(&components)),
                        match components[..] {
                            [c, m, y, k] => Some([to_byte(c), to_byte(m), to_byte(y), to_byte(k)]),
                            _ => None,
                        },
                    ),
                };
                if let Some(color) = resolved {
                    self.set_color(fill, color, space, ink);
                }
            }

            // 8.4.5 external graphics state. Only the alphas are modelled;
            // the rest of an /ExtGState needs the resource dictionary.
            b"gs" => {
                if let Some(Token::Name(name)) = self.stack.last().cloned() {
                    if let Some((fill, stroke)) = self.fonts.ext_g_state_alpha(&name) {
                        if let Some(alpha) = fill {
                            self.gs.fill_alpha = alpha.clamp(0.0, 1.0);
                        }
                        if let Some(alpha) = stroke {
                            self.gs.stroke_alpha = alpha.clamp(0.0, 1.0);
                        }
                    }
                    if let Some(blend) = self.fonts.ext_g_state_blend(&name) {
                        self.gs.blend = blend;
                    }
                    // 11.6.5.1. The group is rendered *here*, at this CTM,
                    // rather than recorded for the paint that will use it.
                    match self.fonts.ext_g_state_soft_mask(&name) {
                        Some(SoftMask::None) => self.device.clear_soft_mask(),
                        Some(SoftMask::Group(mask)) => self.run_soft_mask(&mask),
                        None => {}
                    }
                }
            }

            // 8.7.4.2: `sh` paints a shading over the current clip.
            b"sh" => {
                if let Some(Token::Name(name)) = self.stack.last().cloned() {
                    self.device.draw_shading(&name, &self.gs);
                }
            }

            // 14.6.2 marked content, and 8.11.3.2's use of it for optional
            // content. `BDC` is the only operator in the language that can
            // stop a page drawing, so it is the only one that looks at its
            // property list here.
            b"BDC" => {
                let (tag, properties) = self.bdc_operands();
                let (layer, props) = match &properties {
                    // 8.11.3.2: only the `/OC` tag selects optional content,
                    // and only the name form of the list can reach a group.
                    Properties::Named(name) => {
                        let layer = (tag.as_slice() == b"OC")
                            .then(|| self.fonts.optional_content(name))
                            .flatten();
                        (layer, self.fonts.marked_content_properties(name))
                    }
                    Properties::Inline(props) => (None, Some(props.clone())),
                    Properties::None => (None, None),
                };
                // 14.7.4.2: the sequence resides in the stream its `BDC` was
                // written in, and only the interpreter knows which that is.
                // Stamped after `is_empty`, so a list holding nothing but the
                // stream identity is still no list at all.
                let props = props.filter(|p| !p.is_empty()).map(|mut props| {
                    props.stream = self.stream();
                    props
                });
                self.open_marked_content(&tag, layer, props.as_ref());
            }
            // 14.6.1: `BMC` has a tag and no property list, so it can name
            // no layer, carries no `/MCID`, and always paints.
            b"BMC" => {
                let tag = match self.stack.last() {
                    Some(Token::Name(tag)) => tag.clone(),
                    _ => Vec::new(),
                };
                self.open_marked_content(&tag, None, None);
            }
            b"EMC" => self.close_marked_content(),
            // 14.6.1's marked-content *points*, which mark a position rather
            // than open a scope, and 7.8.2's compatibility brackets. All
            // four do nothing here, and are named rather than left to the
            // arm below so that a reader can see the difference between `MP`
            // and `BMC` was considered: reading `DP` as a scope would leave
            // the device inside a layer with no `EMC` ever to close it.
            b"MP" | b"DP" | b"BX" | b"EX" => {}

            _ => {}
        }
    }

    /// A `BDC`'s two operands: its tag, and its property list (14.6.2).
    ///
    /// `BDC` takes `tag properties`, and the property list is either a name
    /// into the page's `/Properties` sub-dictionary or an inline dictionary
    /// written out in the stream.
    ///
    /// # The inline scan is back, and now it changes answers
    ///
    /// This reassembles 7.8.2's flattened `DictOpen`/`DictClose` tokens. An
    /// earlier build wrote that scan, deleted it, and recorded the deletion
    /// here: a deliberate defect injection could not make it change a single
    /// answer, because the only thing then read from a property list was
    /// `/OC`, and an inline list can never name a layer — 8.11.3.2 makes an
    /// `/OC` entry a reference to a group or a membership dictionary, and
    /// 7.3.10 puts indirect references in the file structure, where a content
    /// stream cannot write one. Both the scan and the two-token peek that
    /// replaced it produced a visible scope for every inline list, well
    /// formed or not, so the scan was dead weight and the note said so.
    ///
    /// **That argument stopped holding the moment `/MCID` was read from the
    /// same list.** 14.7.4.2 puts `/MCID` in the property list itself, not
    /// behind a reference, and `/P << /MCID 3 >> BDC` is the form nearly
    /// every tagging producer emits — so without the reassembly a tagged page
    /// has no marked content this engine can see at all. The 14.9 values
    /// beside it (`/ActualText`, `/Alt`, `/Lang`, `/E`) are text strings,
    /// which a content stream can also write inline, and they are read here
    /// for the same reason.
    ///
    /// The old note was right about a second thing, and the scan inherits it:
    /// a list this cannot read yields **no** properties and a **visible**
    /// scope. Nothing here can hide content.
    ///
    /// It also closes a defect the two-token peek carried. The tag sits
    /// before the `<<`, and peeking one token below the top of the stack
    /// finds whatever the dictionary's *last value* happened to be — so
    /// `/OC << /Type /OCMD >> BDC` reported its tag as `OCMD`, and
    /// `/Artifact << /Type /Pagination >> BDC` reported `Pagination` rather
    /// than `Artifact`. The text device excludes artifacts by that tag
    /// (14.8.2.2), so an artifact written with an inline property list was
    /// extracted as though it were the author's content. Finding the `<<` is
    /// what fixes it, and only the reassembly can find the `<<`.
    fn bdc_operands(&self) -> (Vec<u8>, Properties) {
        match self.stack.last() {
            // `/Tag /MC0 BDC`: the list is a name, and the tag is below it.
            Some(Token::Name(property)) => {
                let tag = match self.stack.iter().rev().nth(1) {
                    Some(Token::Name(tag)) => tag.clone(),
                    _ => Vec::new(),
                };
                (tag, Properties::Named(property.clone()))
            }
            // `/Tag << … >> BDC`: the tokenizer left the dictionary flat.
            Some(Token::DictClose) => {
                let Some(open) = self.inline_dict_start() else {
                    // A `>>` with no `<<` before it is damage, not a list.
                    return (Vec::new(), Properties::None);
                };
                let tag = match open.checked_sub(1).and_then(|at| self.stack.get(at)) {
                    Some(Token::Name(tag)) => tag.clone(),
                    _ => Vec::new(),
                };
                let body = self
                    .stack
                    .get(open + 1..self.stack.len() - 1)
                    .unwrap_or_default();
                (tag, Properties::Inline(read_inline_properties(body)))
            }
            // No property list at all, which `BDC` requires. The scope still
            // opens — 14.6.2's `EMC` will arrive for it either way — and it
            // is nameless rather than guessed at.
            _ => (Vec::new(), Properties::None),
        }
    }

    /// The index of the `<<` matching the `>>` on top of the stack.
    ///
    /// Scanned backwards with a depth counter, so a dictionary nested inside
    /// the list does not end the search early. `None` when the stack holds no
    /// matching `<<` — which happens both for genuine damage and for a list
    /// so long that [`Interpreter::run`]'s operand bound dropped its opening
    /// brace, and both mean "no properties, visible scope".
    fn inline_dict_start(&self) -> Option<usize> {
        let mut depth = 0usize;
        for (at, token) in self
            .stack
            .iter()
            .enumerate()
            .rev()
            .take(MAX_INLINE_PROPERTY_TOKENS)
        {
            match token {
                Token::DictClose => depth += 1,
                Token::DictOpen => {
                    depth -= 1;
                    if depth == 0 {
                        return Some(at);
                    }
                }
                _ => {}
            }
        }
        None
    }

    /// Which content stream is being run (14.7.4.2).
    ///
    /// The **innermost** form, not the outermost: 14.7.4.2 puts a sequence in
    /// the stream its `BDC` was written in, and a form invoked from inside
    /// another form writes its own. Reporting the outer one would give two
    /// nested forms one identity and put the collision this key exists to
    /// break back exactly where it was.
    fn stream(&self) -> u64 {
        self.streams.last().copied().unwrap_or(0)
    }

    /// Opens a marked-content scope and tells the device whether to paint
    /// what follows.
    fn open_marked_content(
        &mut self,
        tag: &[u8],
        layer: Option<Layer>,
        props: Option<&MarkedProps>,
    ) {
        if self.marked >= MAX_MARKED_CONTENT_DEPTH {
            self.marked_over_cap = self.marked_over_cap.saturating_add(1);
            return;
        }
        self.marked += 1;
        match layer {
            Some(layer) if !layer.visible => {
                self.device
                    .begin_marked_content(tag, false, Some(&layer.label), props);
            }
            _ => self.device.begin_marked_content(tag, true, None, props),
        }
    }

    /// Closes the innermost scope, if there is one.
    ///
    /// An `EMC` with nothing open is damage, and is dropped. Acting on it
    /// would let a form XObject — or a stray one halfway down a page — close
    /// a scope it never opened, which reaches out of the stream that wrote
    /// it and un-hides a layer somewhere else entirely.
    fn close_marked_content(&mut self) {
        if self.marked_over_cap > 0 {
            self.marked_over_cap -= 1;
            return;
        }
        if self.marked > 0 {
            self.marked -= 1;
            self.device.end_marked_content();
        }
    }

    /// Closes every scope the stream just run left open.
    fn close_open_marked_content(&mut self) {
        self.marked_over_cap = 0;
        while self.marked > 0 {
            self.marked -= 1;
            self.device.end_marked_content();
        }
    }

    /// Hands a recorded `W`/`W*` to the device, now that the path has ended.
    fn apply_pending_clip(&mut self, path: &[PathSegment]) {
        if let Some(even_odd) = self.pending_clip.take() {
            self.device.clip_path(path, &self.gs, even_odd);
        }
    }

    /// Applies a colour to the fill or stroke slot, with its DeviceCMYK
    /// components when it has them.
    fn set_color(&mut self, fill: bool, color: Rgb, space: Option<Vec<u8>>, ink: Option<[u8; 4]>) {
        if fill {
            self.gs.fill_color = color;
            self.gs.fill_ink = ink;
            self.gs.fill_pattern = None;
            if let Some(space) = space {
                self.gs.fill_space = Some(space);
            }
        } else {
            self.gs.stroke_color = color;
            self.gs.stroke_ink = ink;
            self.gs.stroke_pattern = None;
            if let Some(space) = space {
                self.gs.stroke_space = Some(space);
            }
        }
    }

    /// Records the pattern a `scn`/`SCN` selected (8.7.3).
    fn set_pattern(&mut self, fill: bool, name: Vec<u8>) {
        if fill {
            self.gs.fill_pattern = Some(name);
        } else {
            self.gs.stroke_pattern = Some(name);
        }
    }

    fn push_segment(&mut self, segment: PathSegment) {
        // A page can describe an unbounded path; cap it so one hostile stream
        // cannot exhaust memory.
        if self.path.len() < 1 << 20 {
            self.path.push(segment);
        }
    }

    fn next_line(&mut self) {
        let leading = self.gs.text.leading;
        self.line_matrix = Matrix::translate(0.0, -leading).then(&self.line_matrix);
        self.text_matrix = self.line_matrix;
    }

    fn do_xobject(&mut self, name: &[u8]) {
        // 8.11.4.4: an `/OC` entry on a form or image XObject hides the whole
        // XObject, and lives on the XObject's own dictionary rather than in
        // `/Properties`. It is expressed here as a marked-content scope
        // around the invocation, so the engine has one suppression mechanism
        // and not two: a hidden image is left undrawn for exactly the reason
        // a hidden rectangle is, and a hidden *form* is still run, so its
        // text still extracts and its state changes still happen.
        let hidden = match self.fonts.xobject_optional_content(name) {
            Some(layer) if !layer.visible => {
                self.open_marked_content(b"OC", Some(layer), None);
                true
            }
            _ => false,
        };
        self.run_xobject(name);
        if hidden {
            self.close_marked_content();
        }
    }

    fn run_xobject(&mut self, name: &[u8]) {
        let Some(form) = self.fonts.form(name) else {
            self.device.draw_image(
                &ImageRef {
                    name: name.to_vec(),
                    inline: false,
                    inline_dict: Vec::new(),
                    inline_data: Vec::new(),
                },
                &self.gs,
            );
            return;
        };

        if self.depth >= MAX_FORM_DEPTH {
            return;
        }
        let id = self.fonts.font_id(name);
        // 8.10.1: a form may bring its own resources, and the device is asked
        // for the same form by the same name so that both seams change scope
        // together.
        let nested = self.fonts.form_scope(name);
        if !self.device.begin_form(id, name) {
            return;
        }
        let outer = nested.map(|scope| mem::replace(&mut self.fonts, Scope::Owned(scope)));

        // 8.10.2: a form's /Matrix maps its space into the current one, and
        // its content runs with the surrounding state saved.
        let saved_gs = self.gs.clone();
        let saved_stack = std::mem::take(&mut self.saved);
        let saved_path = std::mem::take(&mut self.path);
        let saved_text = self.text_matrix;
        let saved_line = self.line_matrix;
        // 14.6.2: marked content nests within one stream. A form that leaves
        // a scope open must not leave its caller inside it, and an `EMC` it
        // has no `BDC` for must not close one of the caller's — so the count
        // starts at zero here and is emptied below.
        let saved_marked = std::mem::replace(&mut self.marked, 0);
        let saved_over_cap = std::mem::replace(&mut self.marked_over_cap, 0);
        // 14.7.4.2: an `/MCID` numbers a sequence within *this* stream, so
        // the form's own identity is what the sequences it opens are keyed
        // on. A form the resource layer reached without a reference pushes
        // nothing and keeps the caller's identity, which is the answer this
        // engine gave before there was a stack at all.
        let pushed_stream = form.stream != 0;
        if pushed_stream {
            self.streams.push(form.stream);
        }

        let combined = form.matrix.then(&self.gs.ctm);
        if combined.is_finite() {
            self.gs.ctm = combined;
        }

        // 8.10.2: the form is clipped to its bounding box, which is expressed
        // in form space — so with `/Matrix` already folded into the CTM, the
        // rectangle goes in unmodified. Without this a form that draws
        // outside its box paints across the rest of the page, and forms are
        // how most producers place repeated content, so it is not a rare
        // shape. `begin_form` saved the clip and `end_form` restores it.
        if let Some(box_path) = self.bbox_quad(form.bbox) {
            self.device.clip_path(&box_path, &self.gs, false);
        }

        // 11.6.6: a transparency group's contents are composited into a buffer
        // of their own and the result painted as one object, so the alphas and
        // the blend mode in force at the `Do` belong to the *result*. Inside
        // the group they are reset — without this a group with `ca 0.5` fades
        // each element separately and two overlapping opaque shapes inside it
        // show a seam where they cross, which is the observable difference
        // between per-element alpha and group alpha.
        //
        // The soft mask goes the same way, and the device does that half: it
        // is pixels, so it lives there (ruling 8).
        let grouped = match form.group {
            Some(group) if self.device.begin_group(group, &self.gs) => {
                self.gs.fill_alpha = 1.0;
                self.gs.stroke_alpha = 1.0;
                self.gs.blend = crate::state::BlendMode::Normal;
                true
            }
            _ => false,
        };

        self.depth += 1;
        self.run(&form.content);
        self.depth -= 1;

        self.close_open_marked_content();
        if grouped {
            self.device.end_group();
        }
        if pushed_stream {
            self.streams.pop();
        }
        self.marked = saved_marked;
        self.marked_over_cap = saved_over_cap;
        self.gs = saved_gs;
        self.saved = saved_stack;
        self.path = saved_path;
        self.text_matrix = saved_text;
        self.line_matrix = saved_line;
        if let Some(outer) = outer {
            self.fonts = outer;
        }
        self.device.end_form(id);
    }

    /// A form's `/BBox` as a quad in the space a `Device` receives paths in.
    ///
    /// A `Device` receives paths already transformed by the CTM — `re` and
    /// friends apply it as they build them — so the corners are transformed
    /// here too. Passing the rectangle in form space instead clips somewhere
    /// else entirely, which with an identity `/Matrix` happens to look almost
    /// right and with any other matrix erases the form completely.
    ///
    /// Shared between the clip a form installs (8.10.2) and the bound a soft
    /// mask's group gives its buffer (11.6.5.2), because two spellings of the
    /// same rectangle is how the clip and the buffer come to disagree about
    /// where the mask is.
    fn bbox_quad(&self, bbox: Option<[f64; 4]>) -> Option<[PathSegment; 5]> {
        let [x0, y0, x1, y1] = bbox?;
        if ![x0, y0, x1, y1].iter().all(|v| v.is_finite()) || x1 <= x0 || y1 <= y0 {
            return None;
        }
        let p0 = self.gs.ctm.apply(x0, y0);
        let p1 = self.gs.ctm.apply(x1, y0);
        let p2 = self.gs.ctm.apply(x1, y1);
        let p3 = self.gs.ctm.apply(x0, y1);
        Some([
            PathSegment::MoveTo { x: p0.0, y: p0.1 },
            PathSegment::LineTo { x: p1.0, y: p1.1 },
            PathSegment::LineTo { x: p2.0, y: p2.1 },
            PathSegment::LineTo { x: p3.0, y: p3.1 },
            PathSegment::Close,
        ])
    }

    /// Renders an ExtGState `/SMask`'s group, now, at this CTM (11.6.5.2).
    ///
    /// **Now** is the whole point. The mask group is rendered with the
    /// transform in force at the `gs` operator, not with the one in force
    /// when the masked content is painted. The two are almost always
    /// different — a `gs` is set once and the content it masks is drawn under
    /// its own `cm` — and getting it wrong puts the shadow a few points from
    /// where it belongs, which looks like a slightly misplaced shadow rather
    /// than like a bug.
    fn run_soft_mask(&mut self, mask: &MaskGroup) {
        if self.depth >= MAX_FORM_DEPTH {
            return;
        }

        // The state the group runs under, saved exactly as a form's is: the
        // mask group is a content stream and may do anything one can.
        let saved_gs = self.gs.clone();
        let saved_stack = std::mem::take(&mut self.saved);
        let saved_path = std::mem::take(&mut self.path);
        let saved_text = self.text_matrix;
        let saved_line = self.line_matrix;
        let saved_marked = std::mem::replace(&mut self.marked, 0);
        let saved_over_cap = std::mem::replace(&mut self.marked_over_cap, 0);
        // 11.6.5.2's `/G` is a form XObject like any other, so 14.7.4.2's
        // per-stream numbering applies to it the same way.
        let pushed_stream = mask.form.stream != 0;
        if pushed_stream {
            self.streams.push(mask.form.stream);
        }

        // 8.10.2's `/Matrix`, composed onto the CTM at the `gs`.
        let combined = mask.form.matrix.then(&self.gs.ctm);
        if combined.is_finite() {
            self.gs.ctm = combined;
        }
        let bbox = self.bbox_quad(mask.form.bbox);

        let accepted = self.device.begin_soft_mask(
            mask,
            bbox.as_ref().map_or(&[], |b| b.as_slice()),
            &self.gs,
        );
        if accepted {
            // 8.10.2 still clips the group to its box, and 11.6.6 still
            // resets the alphas and the blend mode inside it — a mask group
            // is a transparency group, whatever `/G`'s own `/Group` says.
            if let Some(box_path) = bbox {
                self.device.clip_path(&box_path, &self.gs, false);
            }
            self.gs.fill_alpha = 1.0;
            self.gs.stroke_alpha = 1.0;
            self.gs.blend = crate::state::BlendMode::Normal;

            self.depth += 1;
            self.run(&mask.form.content);
            self.depth -= 1;
            self.close_open_marked_content();
            self.device.end_soft_mask();
        }

        if pushed_stream {
            self.streams.pop();
        }
        self.marked = saved_marked;
        self.marked_over_cap = saved_over_cap;
        self.gs = saved_gs;
        self.saved = saved_stack;
        self.path = saved_path;
        self.text_matrix = saved_text;
        self.line_matrix = saved_line;
    }

    fn show_array(&mut self) {
        // TJ's operand is an array of strings and numbers; the numbers move
        // the pen backwards in thousandths of text space (9.4.3).
        let items: Vec<Token> = self
            .stack
            .iter()
            .rev()
            .take_while(|t| !matches!(t, Token::ArrayOpen))
            .cloned()
            .collect::<Vec<_>>()
            .into_iter()
            .rev()
            .collect();

        // 9.4.3: the adjustment is subtracted from "the current horizontal or
        // vertical coordinate, depending on the writing mode" — so which axis
        // it moves along is a property of the font, not of the operator. A
        // vertical run whose adjustments went sideways would step out of its
        // own column, one kern at a time. `Tf` cannot appear inside a `TJ`
        // array, so the font is fixed for the whole of it.
        let vertical = self
            .gs
            .text
            .font
            .as_ref()
            .is_some_and(|name| self.fonts.is_vertical(name));

        for item in items {
            match item {
                Token::String(s) => self.show(&s),
                Token::Number(adjust) if adjust.is_finite() => {
                    let ts = &self.gs.text;
                    // 9.4.4's tx carries Th and its ty does not: Th is a
                    // horizontal scaling and there is no horizontal motion to
                    // scale in a vertical run.
                    self.text_matrix = if vertical {
                        let shift = -adjust / 1000.0 * ts.size;
                        Matrix::translate(0.0, shift).then(&self.text_matrix)
                    } else {
                        let shift = -adjust / 1000.0 * ts.size * ts.horizontal_scale;
                        Matrix::translate(shift, 0.0).then(&self.text_matrix)
                    };
                }
                _ => {}
            }
        }
    }

    fn show(&mut self, bytes: &[u8]) {
        let Some(font_name) = self.gs.text.font.clone() else {
            return;
        };
        let vertical = self.fonts.is_vertical(&font_name);
        let font_id = self.fonts.font_id(&font_name);
        let font_label = self.fonts.font_name(&font_name);

        for (code, text, width) in self.fonts.decode(&font_name, bytes) {
            let ts = self.gs.text.clone();

            // 9.4.4: the glyph is placed by the text matrix scaled by the font
            // size, horizontal scaling and rise.
            let scale = Matrix {
                a: ts.size * ts.horizontal_scale,
                b: 0.0,
                c: 0.0,
                d: ts.size,
                e: 0.0,
                f: ts.rise,
            };

            // 9.7.4.3: a vertical font displaces the pen by w1 rather than by
            // the horizontal w0, and draws the glyph at the current point
            // offset by *minus* the position vector v — v points from the
            // glyph's horizontal origin to the one vertical setting uses, so
            // undoing it is what puts the glyph in the column. Both come out
            // of one call, because a build where the advance and the placement
            // read different numbers is the failure 9.7.4.3 is easiest to get
            // half right about.
            let (v_x, v_y, w1_y) = if vertical {
                self.fonts.vertical_metrics(&font_name, code)
            } else {
                (0.0, 0.0, 0.0)
            };

            // v is in glyph space, so the offset goes *inside* the size
            // scaling — 9.4.4 sends the position vector through Trm like every
            // other glyph-space coordinate, which is what makes it scale with
            // the font size and with Th.
            let placed = if vertical {
                Matrix::translate(-v_x / 1000.0, -v_y / 1000.0).then(&scale)
            } else {
                scale
            };
            let transform = placed.then(&self.text_matrix).then(&self.gs.ctm);

            // The same point with 9.4.3's rise taken out, for a consumer that
            // has to decide which line this glyph belongs to. Computed only
            // when there is a rise, so the ordinary glyph pays one comparison
            // and no matrix multiplication: `Ts` is rare and a page is
            // millions of glyphs. See [`Glyph::baseline`].
            let baseline = if ts.rise == 0.0 {
                None
            } else {
                let flat = Matrix { f: 0.0, ..scale };
                let flat = if vertical {
                    Matrix::translate(-v_x / 1000.0, -v_y / 1000.0).then(&flat)
                } else {
                    flat
                };
                let at = flat.then(&self.text_matrix).then(&self.gs.ctm);
                Some((at.e, at.f))
            };

            // 9.6.5: a Type 3 glyph is a content stream. Its procedure runs in
            // glyph space, which the font matrix maps into text space — so the
            // matrix goes *inside* the transform that places the glyph, not
            // outside it.
            if let Some((proc_bytes, font_matrix)) = self.fonts.type3_glyph(&font_name, code) {
                if self.depth < MAX_FORM_DEPTH {
                    let saved_gs = self.gs.clone();
                    let saved_text = self.text_matrix;
                    let saved_line = self.line_matrix;
                    // A glyph procedure is a content stream like a form's,
                    // and 14.6.2's scopes are per stream in the same way.
                    let saved_marked = std::mem::replace(&mut self.marked, 0);
                    let saved_over_cap = std::mem::replace(&mut self.marked_over_cap, 0);

                    self.gs.ctm = font_matrix.then(&transform);
                    self.depth += 1;
                    self.device.save_state();
                    let inner = proc_bytes.clone();
                    self.run(&inner);
                    self.close_open_marked_content();
                    self.device.restore_state();
                    self.depth -= 1;

                    self.marked = saved_marked;
                    self.marked_over_cap = saved_over_cap;
                    self.gs = saved_gs;
                    self.text_matrix = saved_text;
                    self.line_matrix = saved_line;
                }

                // The advance still comes from /Widths, which are in glyph
                // space and so scale by the font matrix rather than by 1/1000.
                let advance = width * font_matrix.a * ts.size * ts.horizontal_scale;
                let shift =
                    advance + (ts.char_spacing + word_spacing(code, &ts)) * ts.horizontal_scale;
                self.text_matrix = Matrix::translate(shift, 0.0).then(&self.text_matrix);
                continue;
            }

            let glyph = Glyph {
                code,
                text: text.clone(),
                transform,
                baseline,
                advance: if vertical { w1_y } else { width } / 1000.0 * ts.size,
                size: ts.size,
                vertical,
                font_id,
                font_name: font_label.clone(),
            };
            self.device.show_glyph(&glyph, &self.gs);

            // 9.4.4: word spacing applies to a single-byte code 32 only, which
            // is why it must not be added for a two-byte CID font.
            let word = if code == 32 && !vertical {
                ts.word_spacing
            } else {
                0.0
            };

            // 9.4.4, in full:
            //   tx = ((w0 - Tj/1000) * Tfs + Tc + Tw) * Th
            //   ty =  (w1 - Tj/1000) * Tfs + Tc + Tw
            // Two differences, and both of them matter. The displacement is w1
            // and not w0 — a downward number, already signed, so it is added
            // rather than subtracted and an engine that negates a negative
            // runs the column upward. And Th does not appear in ty at all:
            // horizontal scaling scales horizontal motion, of which a vertical
            // run has none.
            self.text_matrix = if vertical {
                let ty = w1_y / 1000.0 * ts.size + ts.char_spacing + word;
                Matrix::translate(0.0, ty).then(&self.text_matrix)
            } else {
                let tx = (width / 1000.0 * ts.size + ts.char_spacing + word) * ts.horizontal_scale;
                Matrix::translate(tx, 0.0).then(&self.text_matrix)
            };
        }
    }
}

fn to_byte(value: f64) -> u8 {
    if !value.is_finite() {
        return 0;
    }
    (value.clamp(0.0, 1.0) * 255.0).round() as u8
}

/// 8.6.4.4: the additive complement, with black applied.
fn cmyk_to_rgb(c: f64, m: f64, y: f64, k: f64) -> Rgb {
    let k = k.clamp(0.0, 1.0);
    Rgb {
        r: to_byte((1.0 - c.clamp(0.0, 1.0)) * (1.0 - k)),
        g: to_byte((1.0 - m.clamp(0.0, 1.0)) * (1.0 - k)),
        b: to_byte((1.0 - y.clamp(0.0, 1.0)) * (1.0 - k)),
    }
}

/// Reads components as a device colour, by how many there are.
///
/// `sc` without a preceding `cs` is malformed but occurs; the count is the
/// only signal available and it is an unambiguous one.
fn components_to_rgb(components: &[f64]) -> Rgb {
    let at = |i: usize| components.get(i).copied().unwrap_or(0.0);
    match components.len() {
        1 => {
            let v = to_byte(at(0));
            Rgb { r: v, g: v, b: v }
        }
        4 => cmyk_to_rgb(at(0), at(1), at(2), at(3)),
        _ => Rgb {
            r: to_byte(at(0)),
            g: to_byte(at(1)),
            b: to_byte(at(2)),
        },
    }
}

/// Finds the end of an inline image, returning how many bytes to skip.
///
/// 8.9.7 ends the data at `EI` surrounded by whitespace, and binary data can
/// contain those bytes, so the match is only accepted when what follows looks
/// like a content stream again.
/// 9.4.4: word spacing applies to a single-byte code 32 and to nothing else.
fn word_spacing(code: u32, ts: &crate::state::TextState) -> f64 {
    if code == 32 {
        ts.word_spacing
    } else {
        0.0
    }
}

/// Splits an inline image's span into its dictionary and its data (8.9.7).
///
/// `ID` is followed by exactly one whitespace byte before the data starts, and
/// the span ends at `EI`. A span with no `ID` at all is all dictionary and no
/// data, which is what a truncated stream leaves behind.
///
/// The whitespace byte *before* `EI` belongs to the syntax too, and is dropped
/// for the same reason 7.3.8.2 drops the end-of-line before `endstream`. It
/// costs nothing on unfiltered samples, whose length the dictionary already
/// gives — but on a filtered image it is one byte past the end of a complete
/// zlib or LZW stream, which every decoder here reports as trailing garbage.
fn split_inline_image(span: &[u8]) -> (&[u8], &[u8]) {
    let mut i = 0usize;
    while i + 1 < span.len() {
        if span[i] == b'I' && span[i + 1] == b'D' {
            let before_ok =
                i == 0 || span[i - 1].is_ascii_whitespace() || is_delimiter(span[i - 1]);
            if before_ok {
                let dict = &span[..i];
                // One whitespace byte separates `ID` from the samples.
                let start = (i + 3).min(span.len());
                let mut end = span.len().saturating_sub(2).max(start);
                if end > start && span.get(end - 1).is_some_and(is_inline_space) {
                    end -= 1;
                }
                return (dict, &span[start..end]);
            }
        }
        i += 1;
    }
    (span, &[])
}

/// The white space 8.9.7 allows between an inline image's data and `EI`.
///
/// 7.2.3's set, which includes NUL — the byte `skip_inline_image` already
/// accepts in that position.
fn is_inline_space(b: &u8) -> bool {
    b.is_ascii_whitespace() || *b == 0
}

/// How many bytes of `rest` — what follows a `BI` operator — the inline
/// image takes, through its `EI` (8.9.7).
///
/// Public for the other reader of content streams that must not tokenize an
/// inline image's samples: the facade's redaction, which rewrites a stream
/// token by token and would otherwise re-serialize the samples as whatever
/// tokens they happened to spell. One answer to where an inline image ends,
/// so the interpreter and the rewrite cannot disagree about it.
#[must_use]
pub fn skip_inline_image(rest: &[u8]) -> usize {
    let mut i = 0usize;
    while i + 1 < rest.len() {
        if rest.get(i) == Some(&b'E') && rest.get(i + 1) == Some(&b'I') {
            let before_ok = i == 0
                || rest
                    .get(i - 1)
                    .is_some_and(|b| b.is_ascii_whitespace() || *b == 0);
            let after = rest.get(i + 2);
            let after_ok = after.is_none_or(|b| b.is_ascii_whitespace() || is_delimiter(*b));
            if before_ok && after_ok {
                return i + 2;
            }
        }
        i += 1;
    }
    rest.len()
}

fn is_delimiter(c: u8) -> bool {
    matches!(
        c,
        b'(' | b')' | b'<' | b'>' | b'[' | b']' | b'{' | b'}' | b'/' | b'%'
    )
}

#[cfg(test)]
mod tests {
    //! These tests used to carry **five** devices of their own — `Recorder`,
    //! `GroupEvents`, `Painted`, `Scopes` and `Images` — each recording the
    //! subset one test needed, with heavy overlap and no two agreeing on what
    //! an event was. All five are gone; every test below drives
    //! [`crate::record::RecordingDevice`], which keeps every call in order.
    //!
    //! What each of them asserted is unchanged. What moved is where the
    //! *derived* answers are computed: the enclosing visibility of a scope was
    //! a field `Scopes` maintained, and is now
    //! [`RecordingDevice::hidden_at`](crate::record::RecordingDevice::hidden_at)
    //! over the scopes the recorder kept — so a test here still fails for the
    //! same reason a real drawing device would.

    use super::*;
    use crate::record::{Answers, Event, EventKind, RecordingDevice};

    /// Every byte is one code, 500/1000 em wide, mapping to itself.
    struct Simple;

    impl FontSource for Simple {
        fn decode(&self, _font: &[u8], bytes: &[u8]) -> Vec<(u32, String, f64)> {
            bytes
                .iter()
                .map(|&b| (u32::from(b), char::from(b).to_string(), 500.0))
                .collect()
        }
        /// Never vertical, so nothing here is ever asked. Written out because
        /// the trait has no default for it: 9.7.4.3's metrics have no safe
        /// one, and a source that grows a vertical font is made to say so.
        fn vertical_metrics(&self, _font: &[u8], _code: u32) -> (f64, f64, f64) {
            (0.0, 880.0, -1000.0)
        }
    }

    // -----------------------------------------------------------------------
    // Transparency groups (11.6.6).
    // -----------------------------------------------------------------------

    /// A source offering one grouped form and one plain one, both drawing a
    /// rectangle.
    struct Groups {
        group: Option<Group>,
    }

    impl FontSource for Groups {
        fn decode(&self, _font: &[u8], _bytes: &[u8]) -> Vec<(u32, String, f64)> {
            Vec::new()
        }
        fn vertical_metrics(&self, _font: &[u8], _code: u32) -> (f64, f64, f64) {
            (0.0, 880.0, -1000.0)
        }
        fn form(&self, name: &[u8]) -> Option<Form> {
            (name == b"Fm").then(|| Form {
                content: b"0 0 5 5 re f".to_vec(),
                matrix: Matrix::IDENTITY,
                bbox: None,
                group: self.group,
                stream: 0,
            })
        }
        fn ext_g_state_alpha(&self, name: &[u8]) -> Option<(Option<f64>, Option<f64>)> {
            (name == b"Half").then_some((Some(0.5), Some(0.25)))
        }
        fn ext_g_state_blend(&self, name: &[u8]) -> Option<crate::state::BlendMode> {
            (name == b"Half").then_some(crate::state::BlendMode::Multiply)
        }
    }

    /// The attributes of every transparency group the stream offered, in
    /// order.
    fn groups_offered(d: &RecordingDevice) -> Vec<Group> {
        d.of_kind(EventKind::BeginGroup)
            .filter_map(|event| match event {
                Event::BeginGroup { group, .. } => Some(*group),
                _ => None,
            })
            .collect()
    }

    /// The `ca`, `CA` and blend mode every event of `kind` saw.
    ///
    /// The three that 11.6.6 resets inside an accepted group, read back off
    /// the state the recorder copied **at each call** — which is what makes
    /// the group's own state and its contents' distinguishable at all.
    fn alphas(d: &RecordingDevice, kind: EventKind) -> Vec<(f64, f64, crate::state::BlendMode)> {
        d.of_kind(kind)
            .map(|event| {
                let state = event.state().expect("the state was captured");
                (state.fill_alpha, state.stroke_alpha, state.blend)
            })
            .collect()
    }

    /// 11.6.6: the alphas and the blend mode at the `Do` belong to the group's
    /// result, so inside the content they are reset. Without this a group at
    /// `ca 0.5` fades every element separately *and* the result again.
    #[test]
    fn a_transparency_group_resets_the_alphas_and_the_blend_mode_inside_it() {
        let mut device = RecordingDevice::new().answering(Answers {
            groups: true,
            ..Answers::default()
        });
        let fonts = Groups {
            group: Some(Group {
                isolated: true,
                knockout: false,
                space: None,
            }),
        };
        interpret(b"/Half gs /Fm Do", Matrix::IDENTITY, &mut device, &fonts);

        assert_eq!(
            groups_offered(&device),
            vec![Group {
                isolated: true,
                knockout: false,
                space: None,
            }],
            "the group's own attributes reach the device"
        );
        assert_eq!(
            alphas(&device, EventKind::BeginGroup),
            vec![(0.5, 0.25, crate::state::BlendMode::Multiply)],
            "and it is handed the state at the `Do`, which is the group's own"
        );
        assert_eq!(
            alphas(&device, EventKind::FillPath),
            vec![(1.0, 1.0, crate::state::BlendMode::Normal)],
            "while the content inside runs at full strength under Normal"
        );
        assert_eq!(
            device.count(EventKind::EndGroup),
            1,
            "and the group is closed exactly once"
        );
    }

    /// A device that declines the group must not have the state reset
    /// underneath it — the text device and the recorders keep no buffer, and
    /// content that was painting at `ca 0.5` would start painting at full
    /// strength with nothing left to fade it.
    #[test]
    fn declining_a_group_leaves_the_state_alone() {
        let mut device = RecordingDevice::new();
        let fonts = Groups {
            group: Some(Group::default()),
        };
        interpret(b"/Half gs /Fm Do", Matrix::IDENTITY, &mut device, &fonts);

        assert_eq!(
            device.count(EventKind::BeginGroup),
            1,
            "it was still offered"
        );
        assert_eq!(
            device.count(EventKind::EndGroup),
            0,
            "and not closed, having never opened"
        );
        assert_eq!(
            alphas(&device, EventKind::FillPath),
            vec![(0.5, 0.25, crate::state::BlendMode::Multiply)],
            "the content keeps the alphas the page set"
        );
    }

    /// A form that is not a transparency group is not offered at all.
    #[test]
    fn a_plain_form_raises_no_group_event() {
        let mut device = RecordingDevice::new().answering(Answers {
            groups: true,
            ..Answers::default()
        });
        interpret(
            b"/Half gs /Fm Do",
            Matrix::IDENTITY,
            &mut device,
            &Groups { group: None },
        );
        assert_eq!(device.count(EventKind::BeginGroup), 0);
        assert_eq!(device.count(EventKind::EndGroup), 0);
        assert_eq!(
            alphas(&device, EventKind::FillPath),
            vec![(0.5, 0.25, crate::state::BlendMode::Multiply)]
        );
    }

    /// The same font written vertically, with metrics that are all different
    /// numbers.
    ///
    /// Every component is distinct and none is a multiple of another, so an
    /// assertion below can only hold for one arrangement of them: `w1_y` is
    /// -800 where the *horizontal* width is 500, so a pen still advancing by
    /// `w0` — the defect this closes — lands somewhere none of these tests
    /// accept, and so does one that negates the sign.
    ///
    /// `A` and `B` differ from each other as well, so a run of two glyphs
    /// cannot pass by applying either one's metrics twice.
    struct Vertical;

    impl Vertical {
        /// `(v_x, v_y, w1_y)` per code, in 1/1000 em.
        fn metrics(code: u32) -> (f64, f64, f64) {
            match code {
                0x41 => (250.0, 700.0, -800.0),
                0x42 => (300.0, 650.0, -900.0),
                _ => (0.0, 880.0, -1000.0),
            }
        }
    }

    impl FontSource for Vertical {
        fn decode(&self, _font: &[u8], bytes: &[u8]) -> Vec<(u32, String, f64)> {
            bytes
                .iter()
                .map(|&b| (u32::from(b), char::from(b).to_string(), 500.0))
                .collect()
        }
        fn is_vertical(&self, _font: &[u8]) -> bool {
            true
        }
        fn vertical_metrics(&self, _font: &[u8], code: u32) -> (f64, f64, f64) {
            Vertical::metrics(code)
        }
    }

    fn run(src: &[u8]) -> RecordingDevice {
        let mut d = RecordingDevice::new();
        interpret(src, Matrix::IDENTITY, &mut d, &Simple);
        d
    }

    fn run_vertical(src: &[u8]) -> RecordingDevice {
        let mut d = RecordingDevice::new();
        interpret(src, Matrix::IDENTITY, &mut d, &Vertical);
        d
    }

    #[test]
    fn glyphs_advance_by_their_width() {
        let d = run(b"BT /F0 10 Tf 0 0 Td (AB) Tj ET");
        let text: String = d.glyphs().map(|g| g.text.as_str()).collect();
        assert_eq!(text, "AB");
        // 500/1000 em at 10pt is 5 points per glyph.
        assert_eq!(d.glyphs().next().map(|g| g.transform.e), Some(0.0));
        assert_eq!(d.glyphs().nth(1).map(|g| g.transform.e), Some(5.0));
    }

    #[test]
    fn tj_adjustments_move_the_pen_backwards() {
        let d = run(b"BT /F0 10 Tf [(A) -1000 (B)] TJ ET");
        // -1000 thousandths at 10pt closes 10 points, so B lands at 5 + 10.
        assert_eq!(d.glyphs().nth(1).map(|g| g.transform.e), Some(15.0));
    }

    #[test]
    fn character_and_word_spacing_apply_where_the_spec_says() {
        let spaced = run(b"BT /F0 10 Tf 2 Tc (AB) Tj ET");
        assert_eq!(spaced.glyphs().nth(1).map(|g| g.transform.e), Some(7.0));

        // Word spacing applies to code 32 only.
        let worded = run(b"BT /F0 10 Tf 100 Tw (A B) Tj ET");
        let xs: Vec<f64> = worded.glyphs().map(|g| g.transform.e).collect();
        assert_eq!(xs.first(), Some(&0.0), "A");
        assert_eq!(xs.get(1), Some(&5.0), "the space itself is not shifted");
        assert_eq!(xs.get(2), Some(&110.0), "B follows the word space");
    }

    // -----------------------------------------------------------------------
    // Vertical writing (gap 05, 9.4.4 and 9.7.4.3).
    // -----------------------------------------------------------------------

    /// Absolute positions after two glyphs, which is the whole point of the
    /// assertion: an inverted vertical displacement still draws a tidy column,
    /// just one running upward, and a test on the *gaps* between glyphs would
    /// accept it. A test on where the glyphs actually are cannot.
    ///
    /// Every number below is hand-computed from 9.4.4 with the pen starting at
    /// (100, 700) and 10pt text:
    ///
    /// - `A` is drawn at the pen offset by -v = (-250, -700)/1000 x 10, so at
    ///   (100 - 2.5, 700 - 7) = (97.5, 693).
    /// - the pen then moves by w1 = -800/1000 x 10 = -8, to (100, 692).
    /// - `B` is drawn at that pen offset by its own -v = (-3, -6.5), so at
    ///   (97, 685.5).
    ///
    /// The horizontal width is 500 for both, so a pen still advancing by `w0`
    /// puts `B` at y = 688.5 and a sign inversion puts it at 701.5. Neither is
    /// 685.5.
    #[test]
    fn a_vertical_run_advances_by_w1_and_is_placed_by_v() {
        let d = run_vertical(b"BT /F0 10 Tf 100 700 Td (AB) Tj ET");

        assert_eq!(
            d.glyphs().next().map(|g| (g.transform.e, g.transform.f)),
            Some((97.5, 693.0)),
            "A, at the pen minus its position vector"
        );
        assert_eq!(
            d.glyphs().nth(1).map(|g| (g.transform.e, g.transform.f)),
            Some((97.0, 685.5)),
            "B, one w1 further down and offset by its own v"
        );

        // The glyph event carries the same displacement, signed: a consumer
        // measuring a column reads it rather than recomputing it.
        assert_eq!(
            d.glyphs().map(|g| g.advance).collect::<Vec<_>>(),
            vec![-8.0, -9.0]
        );
    }

    /// The position vector is the half of 9.7.4.3 that has nothing to do with
    /// the advance, so it is asserted on its own: two codes with the same
    /// displacement and different vectors sit in different places.
    ///
    /// `A` and `B` are drawn one after another here, and the difference in
    /// their x is `(250 - 300)/1000 x 10 = -0.5` — a sideways shift inside the
    /// em box, in a writing mode where nothing else moves sideways at all.
    #[test]
    fn the_position_vector_shifts_the_glyph_within_its_em_box() {
        let d = run_vertical(b"BT /F0 10 Tf 100 700 Td (AB) Tj ET");
        let xs: Vec<f64> = d.glyphs().map(|g| g.transform.e).collect();
        assert_eq!(xs, vec![97.5, 97.0]);
        assert!(
            xs.iter().all(|x| *x != 100.0),
            "neither glyph sits at the pen itself, which is what applying no \
             position vector would look like"
        );
    }

    /// 9.4.4's `ty` has no `Th` in it, and its `Tc` is added to a negative
    /// displacement rather than scaling it. `Tz 200` doubles the *glyph*
    /// horizontally — so the position vector's x doubles with it, since v is a
    /// glyph-space coordinate — and leaves the column's step alone.
    #[test]
    fn horizontal_scaling_does_not_reach_a_vertical_advance() {
        let d = run_vertical(b"BT /F0 10 Tf 2 Tc 200 Tz 100 700 Td (AB) Tj ET");

        assert_eq!(
            d.glyphs().next().map(|g| (g.transform.e, g.transform.f)),
            Some((95.0, 693.0)),
            "A: v_x doubled by Tz, v_y untouched by it"
        );
        // The step is -8 + 2 = -6, and 9.4.4 does not multiply it by Th.
        // Character spacing shortens a downward step because the spec adds it
        // to a negative number; scaling it by 2 would put B at y = 682.
        assert_eq!(
            d.glyphs().nth(1).map(|g| (g.transform.e, g.transform.f)),
            Some((94.0, 687.5)),
            "B: one step of -6 down, not -12"
        );
    }

    /// 9.4.3: a `TJ` number is subtracted from "the current horizontal or
    /// vertical coordinate, depending on the writing mode". It went on the
    /// horizontal one whatever the mode, so a vertical run drifted sideways by
    /// every kern in it while the column itself never noticed.
    #[test]
    fn tj_adjustments_move_a_vertical_pen_along_its_own_column() {
        let d = run_vertical(b"BT /F0 10 Tf 100 700 Td [(A) -1000 (B)] TJ ET");

        // A is where it always was; the pen is then at (100, 692), and -1000
        // thousandths at 10pt subtracts -10 from y, taking it to 702.
        assert_eq!(
            d.glyphs().nth(1).map(|g| (g.transform.e, g.transform.f)),
            Some((97.0, 695.5))
        );
        assert_eq!(
            d.glyphs().nth(1).map(|g| g.transform.e),
            Some(97.0),
            "and the column has not moved sideways, which is what the \
             adjustment used to do"
        );
    }

    #[test]
    fn horizontal_scaling_multiplies_the_advance() {
        let d = run(b"BT /F0 10 Tf 50 Tz (AB) Tj ET");
        assert_eq!(d.glyphs().nth(1).map(|g| g.transform.e), Some(2.5));
    }

    #[test]
    fn td_and_t_star_move_by_the_leading() {
        let d = run(b"BT /F0 10 Tf 12 TL 5 700 Td (A) Tj T* (B) Tj ET");
        assert_eq!(
            d.glyphs().next().map(|g| (g.transform.e, g.transform.f)),
            Some((5.0, 700.0))
        );
        assert_eq!(
            d.glyphs().nth(1).map(|g| (g.transform.e, g.transform.f)),
            Some((5.0, 688.0))
        );
    }

    #[test]
    fn invisible_text_is_still_shown_to_the_device() {
        // Mode 3 is what a scanned page's OCR layer uses; extraction must see
        // it even though a renderer paints nothing.
        let d = run(b"BT /F0 10 Tf 3 Tr (hidden) Tj ET");
        let text: String = d.glyphs().map(|g| g.text.as_str()).collect();
        assert_eq!(text, "hidden");
    }

    #[test]
    fn the_transform_stack_restores_state() {
        let d = run(b"q 2 0 0 2 0 0 cm BT /F0 10 Tf (A) Tj ET Q BT /F0 10 Tf (B) Tj ET");
        // Inside the q/Q the CTM doubles the font size's effect on advance,
        // but both glyphs start at the origin.
        assert_eq!(d.count(EventKind::ShowGlyph), 2);
        assert_eq!(d.glyphs().next().map(|g| g.transform.e), Some(0.0));
        assert_eq!(d.glyphs().nth(1).map(|g| g.transform.e), Some(0.0));
    }

    #[test]
    fn paths_reach_the_device() {
        let d = run(b"0 0 m 10 10 l S 0 0 100 100 re f");
        assert_eq!(d.count(EventKind::StrokePath), 1);
        assert_eq!(d.count(EventKind::FillPath), 1);
    }

    #[test]
    fn an_inline_image_does_not_derail_the_stream() {
        let d = run(b"BI /W 2 /H 2 ID \x00\x01\x02\x03 EI BT /F0 10 Tf (A) Tj ET");
        let text: String = d.glyphs().map(|g| g.text.as_str()).collect();
        assert_eq!(text, "A", "text after an inline image still runs");
    }

    #[test]
    fn malformed_streams_do_not_panic() {
        for src in [
            b"".as_slice(),
            b"Tj",
            b"BT ET ET ET",
            b"Q Q Q",
            b"1 0 0 1 cm",
            b"BT /F0 Tf (x) Tj ET",
            b"[ ( unclosed",
            &[0xFF; 512],
        ] {
            let _ = run(src);
        }
    }

    #[test]
    fn a_non_finite_matrix_is_refused() {
        // Without the guard everything after this would be at NaN.
        let d = run(b"BT /F0 10 Tf 0 0 Td (A) Tj 1 0 0 0 0 0 Tm (B) Tj ET");
        assert!(d
            .glyphs()
            .all(|g| g.transform.e.is_finite() && g.transform.f.is_finite()));
    }

    // -----------------------------------------------------------------------
    // Patterns (gap 07, 8.7.3).
    // -----------------------------------------------------------------------

    /// Two uncoloured pattern spaces (8.7.3.2), over different underlying
    /// spaces so a test cannot pass by resolving against the wrong one:
    /// `/Prgb` reads three components as RGB, `/Pgray` reads one as grey.
    struct PatternSpaces;

    impl FontSource for PatternSpaces {
        fn decode(&self, _font: &[u8], _bytes: &[u8]) -> Vec<(u32, String, f64)> {
            Vec::new()
        }
        fn vertical_metrics(&self, _font: &[u8], _code: u32) -> (f64, f64, f64) {
            (0.0, 880.0, -1000.0)
        }
        fn color_components(&self, space: &[u8]) -> Option<usize> {
            match space {
                b"Prgb" => Some(3),
                b"Pgray" => Some(1),
                _ => None,
            }
        }
        fn resolve_color(&self, space: &[u8], components: &[f64]) -> Option<Rgb> {
            let byte = |v: f64| (v.clamp(0.0, 1.0) * 255.0).round() as u8;
            match (space, components) {
                (b"Prgb", [r, g, b]) => Some(Rgb {
                    r: byte(*r),
                    g: byte(*g),
                    b: byte(*b),
                }),
                (b"Pgray", [v]) => Some(Rgb {
                    r: byte(*v),
                    g: byte(*v),
                    b: byte(*v),
                }),
                _ => None,
            }
        }
    }

    fn run_patterned(src: &[u8]) -> RecordingDevice {
        let mut d = RecordingDevice::new();
        interpret(src, Matrix::IDENTITY, &mut d, &PatternSpaces);
        d
    }

    /// The state the stroke saw, copied at the call.
    ///
    /// `Painted` kept one `Vec<GraphicsState>` for fills and strokes alike;
    /// every assertion it fed was about a stroke, and this says so.
    fn stroke_state(d: &RecordingDevice) -> Option<&GraphicsState> {
        d.of_kind(EventKind::StrokePath)
            .next()
            .and_then(Event::state)
    }

    /// 8.7.3.2: a `PaintType 2` pattern paints with the colour the operands
    /// before its name supply, in the pattern space's underlying space. The
    /// operands were being collected and then dropped, so the slot held
    /// whatever `cs`/`CS` had reset it to and the pattern had no colour at all
    /// to take.
    ///
    /// The two slots take different spaces *and* different colours here, so
    /// neither can pass by being written twice from the other's operands.
    #[test]
    fn an_uncoloured_pattern_keeps_the_colour_its_operands_gave() {
        let d = run_patterned(
            b"/Prgb cs 1 0 0 /P0 scn \
              /Pgray CS 0.5 /P1 SCN \
              0 0 m 10 10 l S",
        );

        let state = stroke_state(&d).expect("the stroke reached the device");
        assert_eq!(
            state.fill_color,
            Rgb { r: 255, g: 0, b: 0 },
            "the fill slot took its three operands as RGB"
        );
        assert_eq!(
            state.stroke_color,
            Rgb {
                r: 128,
                g: 128,
                b: 128
            },
            "and the stroke slot took its one operand as grey"
        );
        assert_eq!(
            state.fill_pattern.as_deref(),
            Some(b"P0".as_slice()),
            "with both patterns still selected"
        );
        assert_eq!(state.stroke_pattern.as_deref(), Some(b"P1".as_slice()));
    }

    /// A coloured pattern names itself and nothing else. Whatever colour the
    /// slot held stays put — there is nothing to overwrite it with, and the
    /// pattern supplies its own paint.
    #[test]
    fn a_pattern_named_alone_leaves_the_colour_where_it_was() {
        let d = run_patterned(b"0 1 0 RG /P1 SCN 0 0 m 10 10 l S");

        let state = stroke_state(&d).expect("the stroke reached the device");
        assert_eq!(
            state.stroke_color,
            Rgb { r: 0, g: 255, b: 0 },
            "no operands, so no new colour"
        );
        assert_eq!(state.stroke_pattern.as_deref(), Some(b"P1".as_slice()));
    }

    /// Choosing an ordinary colour has to clear the pattern on the stroke slot
    /// as it does on the fill slot, or every later stroke keeps painting it.
    #[test]
    fn an_ordinary_stroking_colour_clears_the_stroke_pattern() {
        let d = run_patterned(b"/P1 SCN 0 0 1 RG 0 0 m 10 10 l S");

        let state = stroke_state(&d).expect("the stroke reached the device");
        assert_eq!(state.stroke_pattern, None);
        assert_eq!(state.stroke_color, Rgb { r: 0, g: 0, b: 255 });
    }

    /// Resources that know DeviceCMYK by name, as the facade's do.
    struct CmykSpaces;

    impl FontSource for CmykSpaces {
        fn decode(&self, _font: &[u8], _bytes: &[u8]) -> Vec<(u32, String, f64)> {
            Vec::new()
        }
        fn vertical_metrics(&self, _font: &[u8], _code: u32) -> (f64, f64, f64) {
            (0.0, 880.0, -1000.0)
        }
        fn color_components(&self, space: &[u8]) -> Option<usize> {
            (space == b"DeviceCMYK").then_some(4)
        }
        fn resolve_color(&self, space: &[u8], c: &[f64]) -> Option<Rgb> {
            match (space, c) {
                (b"DeviceCMYK", [c, m, y, k]) => Some(cmyk_to_rgb(*c, *m, *y, *k)),
                _ => None,
            }
        }
        fn resolve_ink(&self, space: &[u8], c: &[f64]) -> Option<[u8; 4]> {
            match (space, c) {
                (b"DeviceCMYK", [c, m, y, k]) => {
                    Some([to_byte(*c), to_byte(*m), to_byte(*y), to_byte(*k)])
                }
                _ => None,
            }
        }
        fn initial_color(&self, space: &[u8]) -> Option<Vec<f64>> {
            (space == b"DeviceCMYK").then(|| vec![0.0, 0.0, 0.0, 1.0])
        }
    }

    /// A colour set in DeviceCMYK keeps its components beside its light —
    /// `k` and `K` by the operator, `cs`/`sc` by asking the resources — and a
    /// colour set any other way has none, so an ink device composites the
    /// file's own ink and nothing it would have to guess at. `cs` resets to
    /// the space's initial colour, which for DeviceCMYK is 8.6.8's `0 0 0 1`.
    #[test]
    fn a_device_cmyk_colour_keeps_its_components_beside_its_light() {
        let mut d = RecordingDevice::new();
        interpret(
            b"1 1 1 1 k 0.2 0.4 0.6 0.1 K 0 0 m 10 10 l S \
              1 0 0 rg 0 0 m 10 10 l S \
              /DeviceCMYK cs 0 0 m 10 10 l S \
              /DeviceCMYK CS 0.5 0 0 0 SC 0 0 m 10 10 l S \
              0.5 G 0 0 m 10 10 l S",
            Matrix::IDENTITY,
            &mut d,
            &CmykSpaces,
        );
        let states: Vec<&GraphicsState> = d
            .of_kind(EventKind::StrokePath)
            .filter_map(Event::state)
            .collect();
        assert_eq!(states.len(), 5);
        assert_eq!(states[0].fill_ink, Some([255; 4]), "a rich black");
        assert_eq!(states[0].fill_color, Rgb::BLACK, "whose light is black");
        assert_eq!(states[0].stroke_ink, Some([51, 102, 153, 26]), "`K`");
        assert_eq!(states[1].fill_ink, None, "`rg` is light and has no ink");
        assert_eq!(states[1].stroke_ink, Some([51, 102, 153, 26]));
        assert_eq!(states[2].fill_ink, Some([0, 0, 0, 255]), "`cs` resets");
        assert_eq!(states[2].fill_color, Rgb::BLACK, "to black, not white");
        assert_eq!(states[3].stroke_ink, Some([128, 0, 0, 0]), "`SC`");
        assert_eq!(states[4].stroke_ink, None, "`G` is light");
    }

    // -----------------------------------------------------------------------
    // Marked content and optional content (gap 06, 14.6.2 and 8.11.3.2).
    // -----------------------------------------------------------------------

    /// Every scope's own `(visible, layer)`, in order.
    ///
    /// Each scope's **own** answer, which is what the device is handed; the
    /// enclosing answer is [`hidden_fills`] and `hidden_at` below.
    fn begins(d: &RecordingDevice) -> Vec<(bool, Option<String>)> {
        d.scopes()
            .map(|scope| (scope.visible, scope.hidden_layer.clone()))
            .collect()
    }

    /// Every scope's tag, in order.
    fn scope_tags(d: &RecordingDevice) -> Vec<Vec<u8>> {
        d.scopes().map(|scope| scope.tag.clone()).collect()
    }

    /// Every scope's property list, in order.
    fn scope_props(d: &RecordingDevice) -> Vec<Option<MarkedProps>> {
        d.scopes().map(|scope| scope.props.clone()).collect()
    }

    /// One entry per fill: whether **any** scope open at that fill was hiding
    /// it.
    ///
    /// Derived rather than stored, which is the whole nesting argument: the
    /// device keeps each scope's own answer and this walks the stack, exactly
    /// as a drawing device must — so a test here fails for the same reason
    /// the renderer would.
    fn hidden_fills(d: &RecordingDevice) -> Vec<bool> {
        d.indices(EventKind::FillPath)
            .map(|index| d.hidden_at(index))
            .collect()
    }

    /// The fills that were painted with nothing hiding them.
    fn painted(d: &RecordingDevice) -> usize {
        hidden_fills(d).iter().filter(|hidden| !**hidden).count()
    }

    /// The property lists the interpreter reported, in order.
    fn props_of(source: &[u8]) -> Vec<Option<MarkedProps>> {
        scope_props(&run_layers(source))
    }

    /// The tags it reported, as strings.
    fn tags_of(source: &[u8]) -> Vec<String> {
        scope_tags(&run_layers(source))
            .iter()
            .map(|tag| String::from_utf8_lossy(tag).into_owned())
            .collect()
    }

    /// 14.7.4.2: a marked sequence carries the stream its `BDC` was written
    /// in, and a nested form's is its own rather than its caller's.
    ///
    /// Three sequences all numbered 0 — the page's, a form's, and a form that
    /// form invokes — which without the stream identity are one sequence
    /// numbered three times. The stack has to unwind too: the identity is a
    /// property of where the `BDC` is, so a form that has returned must not
    /// leave its own on the next sequence its caller opens.
    #[test]
    fn a_marked_sequence_carries_the_stream_its_bdc_was_written_in() {
        let props = props_of(b"/P << /MCID 0 >> BDC 0 0 2 2 re f EMC /OuterFrm Do");

        let sequences: Vec<(u64, Option<u32>)> = props
            .iter()
            .map(|p| p.as_ref().map_or((0, None), |p| (p.stream, p.mcid)))
            .collect();
        assert_eq!(
            sequences,
            vec![(0, Some(0)), (0x3_0000, Some(0)), (0x4_0000, Some(0))],
            "the page's own stream is 0, and the innermost form is the one \
             that wrote the sequence"
        );
    }

    /// The common form: `/P << /MCID 3 >> BDC`.
    ///
    /// 14.7.4.2 puts `/MCID` in the property list, and 7.8.2 flattens that
    /// list to tokens — so this is the reassembly working, and without it a
    /// tagged page has no marked content this engine can see at all.
    #[test]
    fn an_inline_property_list_yields_its_mcid() {
        let props = props_of(b"/P << /MCID 3 >> BDC 0 0 2 2 re f EMC");
        assert_eq!(props.len(), 1);
        assert_eq!(props[0].as_ref().and_then(|p| p.mcid), Some(3));
        assert_eq!(
            tags_of(b"/P << /MCID 3 >> BDC EMC"),
            vec!["P"],
            "the tag is the name before the `<<`, not the last value inside it"
        );
    }

    /// 14.9's four values, inline, beside the `/MCID` and around entries this
    /// build reads past.
    ///
    /// `/BBox` is an array and `/A` a nested dictionary: both are values a
    /// property list legitimately carries, and a scan that stepped *into*
    /// either would read their members as top-level keys and find an `/E`
    /// that is not the abbreviation expansion.
    #[test]
    fn an_inline_property_list_yields_the_accessibility_values() {
        let props = props_of(
            b"/Span << /Type /Pagination /BBox [0 0 9 9] /MCID 12 \
                /ActualText (fi) /Alt (a ligature) /Lang (en-GB) /E (etc.) \
                /A << /E (not this one) >> >> BDC 0 0 2 2 re f EMC",
        );
        let props = props[0].clone().expect("a property list");
        assert_eq!(props.mcid, Some(12));
        assert_eq!(props.actual_text.as_deref(), Some("fi"));
        assert_eq!(props.alt.as_deref(), Some("a ligature"));
        assert_eq!(props.lang.as_deref(), Some("en-GB"));
        assert_eq!(
            props.expansion.as_deref(),
            Some("etc."),
            "the /E read is the one at the top level, not the one inside /A"
        );
    }

    /// 7.9.2.2: the four are *text strings*, so a UTF-16BE one decodes rather
    /// than arriving as interleaved NULs.
    #[test]
    fn an_inline_text_string_is_decoded_by_the_documents_rules() {
        let props = props_of(b"/Span << /MCID 0 /Alt <FEFF00660069> >> BDC EMC");
        assert_eq!(
            props[0].as_ref().and_then(|p| p.alt.clone()).as_deref(),
            Some("fi")
        );
    }

    /// `/P /MC0 BDC`: the same values through the `/Properties` seam.
    ///
    /// The two forms must be indistinguishable at the device, because 14.6.2
    /// gives a consumer no reason to care which one a producer chose.
    #[test]
    fn a_named_property_list_yields_the_same_values() {
        let props = props_of(b"/P /MC0 BDC 0 0 2 2 re f EMC");
        let props = props[0].clone().expect("a property list");
        assert_eq!(props.mcid, Some(7));
        assert_eq!(props.alt.as_deref(), Some("a named list"));
    }

    /// A name the resources define as *optional content* and not as a
    /// property list answers the layer question and not this one, and the
    /// other way round. Neither lookup may stand in for the other.
    #[test]
    fn the_two_property_lookups_are_independent() {
        let d = &run_layers(b"/OC /Off BDC EMC /P /Plain BDC EMC");
        assert_eq!(
            begins(d)[0],
            (false, Some("Construction lines".to_string())),
            "/Off is a layer"
        );
        assert!(scope_props(d)[0].is_none(), "and carries no /MCID");
        assert_eq!(begins(d)[1], (true, None), "/Plain is not a layer");
        assert!(
            scope_props(d)[1].is_none(),
            "and is not a property list either"
        );
    }

    /// Every shape of malformed list: **no `/MCID`, and a visible scope.**
    ///
    /// The direction is the one already ruled for `/OC` — a list this build
    /// cannot read must not be able to hide content, and must not invent an
    /// identifier either, because an invented one joins content to the wrong
    /// structure element and reads as a reordering rather than as damage.
    #[test]
    fn a_malformed_property_list_yields_no_mcid_and_a_visible_scope() {
        let cases: &[&[u8]] = &[
            b"/P << >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID (three) >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID -1 >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID 2.5 >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID [1] >> BDC 0 0 2 2 re f EMC",
            // Unbalanced: no `<<` for the `>>` to match.
            b"/P /MCID 3 >> BDC 0 0 2 2 re f EMC",
            // A bare value run with no key at all.
            b"/P << 1 2 3 >> BDC 0 0 2 2 re f EMC",
            b"/P << /MCID /Three >> BDC 0 0 2 2 re f EMC",
            b"BDC 0 0 2 2 re f EMC",
        ];
        for source in cases {
            let d = run_layers(source);
            let what = String::from_utf8_lossy(source);
            assert_eq!(hidden_fills(&d), vec![false], "{what} should paint");
            assert_eq!(
                d.count(EventKind::BeginMarkedContent),
                1,
                "{what} should open one scope"
            );
            assert_eq!(
                scope_props(&d)[0].as_ref().and_then(|p| p.mcid),
                None,
                "{what} should name no marked sequence"
            );
        }
    }

    /// An `/MCID` nested inside a hidden `/OC` scope.
    ///
    /// The two are orthogonal: 8.11.3.2 decides whether the *renderer* paints
    /// and 14.7.4.2 decides what the *structure tree* claims, so a paragraph
    /// inside a layer that is switched off is still that paragraph. A build
    /// that let visibility gate the property list would drop a tagged
    /// document's alternate-language content out of its own reading order.
    #[test]
    fn a_property_list_survives_nesting_inside_a_hidden_layer() {
        let d = run_layers(
            b"/OC /Off BDC \
                /P << /MCID 4 >> BDC 0 0 2 2 re f EMC \
              EMC \
              /P << /MCID 5 >> BDC 0 0 3 3 re f EMC",
        );

        assert_eq!(
            begins(&d),
            vec![
                (false, Some("Construction lines".to_string())),
                (true, None),
                (true, None)
            ],
            "the layer hides, the two paragraphs do not"
        );
        assert_eq!(
            scope_props(&d)
                .iter()
                .map(|p| p.as_ref().and_then(|p| p.mcid))
                .collect::<Vec<_>>(),
            vec![None, Some(4), Some(5)],
            "the hidden scope carries no identifier and the nested one does"
        );
        assert_eq!(
            hidden_fills(&d),
            vec![true, false],
            "and only the painting was suppressed"
        );
        assert_eq!(d.count(EventKind::EndMarkedContent), 3);
    }

    /// 14.6.1: `BMC` has no property list at all, so it can carry no `/MCID`.
    #[test]
    fn a_bmc_carries_no_properties() {
        let d = run_layers(b"/Span BMC 0 0 2 2 re f EMC");
        assert_eq!(scope_tags(&d), vec![b"Span".to_vec()]);
        assert_eq!(scope_props(&d), vec![None]);
    }

    /// An `/Artifact` with an inline property list is an artifact.
    ///
    /// The tag lives before the `<<`, and the peek this replaced read the
    /// dictionary's last *value* instead — so an artifact written this way
    /// reported its tag as `Pagination`, and the text device, which excludes
    /// artifacts by tag (14.8.2.2), extracted a running head as though it were
    /// the author's own content.
    #[test]
    fn an_artifact_with_an_inline_list_is_still_tagged_artifact() {
        assert_eq!(
            tags_of(b"/Artifact << /Type /Pagination /BBox [0 0 9 9] >> BDC EMC"),
            vec!["Artifact"]
        );
    }

    /// `/Off` names a layer the configuration hides, `/On` one it shows, and
    /// `/Plain` is a property list that is not optional content at all.
    ///
    /// Three answers rather than two, because "hidden" and "not a layer" are
    /// different `None`s and a seam that collapsed them would hide every
    /// `/Span`.
    ///
    /// It also answers the *second* question the same `/Properties`
    /// sub-dictionary is asked (14.6.2): `/MC0` is a named property list
    /// carrying an `/MCID` and an `/Alt`, and `/Plain` deliberately answers
    /// neither question — which is what says the two lookups are independent
    /// rather than one lookup asked twice.
    struct Layers;

    impl FontSource for Layers {
        fn decode(&self, _font: &[u8], bytes: &[u8]) -> Vec<(u32, String, f64)> {
            bytes
                .iter()
                .map(|&b| (u32::from(b), char::from(b).to_string(), 500.0))
                .collect()
        }
        fn vertical_metrics(&self, _font: &[u8], _code: u32) -> (f64, f64, f64) {
            (0.0, 880.0, -1000.0)
        }
        fn optional_content(&self, name: &[u8]) -> Option<Layer> {
            match name {
                b"Off" => Some(Layer {
                    visible: false,
                    label: "Construction lines".to_string(),
                }),
                b"On" => Some(Layer {
                    visible: true,
                    label: "Base".to_string(),
                }),
                _ => None,
            }
        }
        fn form(&self, name: &[u8]) -> Option<Form> {
            match name {
                // Opens a scope and never closes it, and closes one it never
                // opened. Both are what a real damaged form does.
                b"Frm" => Some(Form {
                    content: b"EMC /OC /Off BDC 0 0 5 5 re f".to_vec(),
                    matrix: Matrix::IDENTITY,
                    bbox: None,
                    group: None,
                    stream: 0x1_0000,
                }),
                // A well-behaved form, used to test the `/OC` on the XObject
                // itself rather than anything in its content.
                b"HiddenFrm" | b"PlainFrm" => Some(Form {
                    content: b"BT /F0 10 Tf (form text) Tj ET 0 0 5 5 re f".to_vec(),
                    matrix: Matrix::IDENTITY,
                    bbox: None,
                    group: None,
                    stream: 0x2_0000,
                }),
                // One form invoking another, each numbering a sequence 0.
                // 14.7.4.2 numbers within a stream, so the two are different
                // sequences and only the stream identity says so.
                b"OuterFrm" => Some(Form {
                    content: b"/P << /MCID 0 >> BDC 0 0 5 5 re f EMC /InnerFrm Do".to_vec(),
                    matrix: Matrix::IDENTITY,
                    bbox: None,
                    group: None,
                    stream: 0x3_0000,
                }),
                b"InnerFrm" => Some(Form {
                    content: b"/P << /MCID 0 >> BDC 0 0 5 5 re f EMC".to_vec(),
                    matrix: Matrix::IDENTITY,
                    bbox: None,
                    group: None,
                    stream: 0x4_0000,
                }),
                _ => None,
            }
        }
        fn xobject_optional_content(&self, name: &[u8]) -> Option<Layer> {
            (name == b"HiddenFrm" || name == b"HiddenImg").then(|| Layer {
                visible: false,
                label: "Construction lines".to_string(),
            })
        }
        fn marked_content_properties(&self, name: &[u8]) -> Option<MarkedProps> {
            // Only `/MC0` is a property list. `/Off`, `/On` and `/Plain` reach
            // here too and answer nothing, which is what makes the two
            // `/Properties` questions independent rather than one question
            // asked twice.
            (name == b"MC0").then(|| MarkedProps {
                mcid: Some(7),
                alt: Some("a named list".to_string()),
                ..MarkedProps::default()
            })
        }
    }

    fn run_layers(src: &[u8]) -> RecordingDevice {
        let mut d = RecordingDevice::new();
        interpret(src, Matrix::IDENTITY, &mut d, &Layers);
        d
    }

    /// M2's first exit criterion: a nested `BDC` inside a hidden scope stays
    /// hidden.
    ///
    /// The inner scope names a layer that is *on*, so a build that reported
    /// only the innermost answer — or that let a nested `BDC` reset the
    /// state — would paint the middle rectangle. Three rectangles, one
    /// outside the scopes entirely, so "nothing painted" cannot pass either.
    #[test]
    fn a_scope_nested_inside_a_hidden_one_stays_hidden() {
        let d = run_layers(
            b"0 0 1 1 re f \
              /OC /Off BDC \
                0 0 2 2 re f \
                /OC /On BDC 0 0 3 3 re f EMC \
                /Span /Plain BDC 0 0 4 4 re f EMC \
              EMC \
              0 0 5 5 re f",
        );

        assert_eq!(hidden_fills(&d).len(), 5, "every fill reached the device");
        assert_eq!(
            hidden_fills(&d),
            vec![false, true, true, true, false],
            "the three inside the /Off scope are hidden, including the two \
             nested ones"
        );
        assert_eq!(painted(&d), 2);
        assert_eq!(d.count(EventKind::EndMarkedContent), 3, "one EMC per BDC");
    }

    /// M2's second exit criterion: an unbalanced `EMC` does not underflow.
    ///
    /// Four strays before anything opens, and two more after the one scope
    /// closes. A build that let them through would pop past the bottom of the
    /// device's stack; one that counted them would report more `end`s than
    /// `begin`s, which is the same defect one level up.
    #[test]
    fn a_stray_emc_is_dropped_rather_than_underflowing() {
        let d = run_layers(b"EMC EMC EMC EMC /OC /Off BDC 0 0 2 2 re f EMC EMC EMC 0 0 3 3 re f");

        assert_eq!(d.count(EventKind::BeginMarkedContent), 1);
        assert_eq!(
            d.count(EventKind::EndMarkedContent),
            1,
            "six of the seven EMCs had nothing to close"
        );
        assert_eq!(hidden_fills(&d), vec![true, false]);
    }

    /// 14.6.2: a stream may end inside a scope, and the device must not be
    /// left there. The page's own content is the outer case; a form XObject
    /// is the one that would otherwise reach out of itself.
    #[test]
    fn an_unclosed_scope_is_closed_at_the_end_of_its_stream() {
        let d = run_layers(b"/OC /Off BDC 0 0 2 2 re f");
        assert_eq!(d.count(EventKind::BeginMarkedContent), 1);
        assert_eq!(
            d.count(EventKind::EndMarkedContent),
            1,
            "the page's own trailing scope was closed"
        );
        assert!(d.open_scopes().is_empty());

        // `Frm` opens one scope it never closes and closes one it never
        // opened. Neither may reach the page: the fill after the form is
        // outside every layer.
        let d = run_layers(b"/Frm Do 0 0 9 9 re f");
        assert_eq!(
            hidden_fills(&d),
            vec![true, false],
            "the form's own fill is hidden and the page's is not"
        );
        assert_eq!(d.count(EventKind::BeginMarkedContent), 1);
        assert_eq!(d.count(EventKind::EndMarkedContent), 1);
    }

    /// 8.11.3.2: only an `/OC` tag selects optional content.
    #[test]
    fn a_tag_that_is_not_oc_hides_nothing() {
        // `/Off` is a hidden layer, but the tag here is `/Span`, so the name
        // is an ordinary property list and the fill paints.
        let d = run_layers(b"/Span /Off BDC 0 0 2 2 re f EMC");
        assert_eq!(hidden_fills(&d), vec![false]);
        assert_eq!(begins(&d), vec![(true, None)]);
    }

    /// Ruling 10: the scope that hides carries the layer's name, so a device
    /// can say what it hid rather than only that something was hidden.
    #[test]
    fn a_hidden_scope_names_its_layer() {
        let d = run_layers(b"/OC /Off BDC 0 0 2 2 re f EMC");
        assert_eq!(
            begins(&d),
            vec![(false, Some("Construction lines".to_string()))]
        );
    }

    /// An inline property list (7.8.2 tokenizes it flat) renders.
    ///
    /// 7.3.10 keeps indirect references out of content streams and 8.11.3.2
    /// makes an `/OC` entry a reference, so an inline list cannot name a
    /// layer. The tag still has to be found, though — it sits before the
    /// `<<`, not before the operator — and a malformed one must not turn into
    /// a hidden scope. Every case here paints.
    #[test]
    fn an_inline_property_list_renders() {
        for src in [
            b"/OC << /Type /OCMD >> BDC 0 0 2 2 re f EMC".as_slice(),
            b"/OC << /OCGs [ ] /P /AllOff >> BDC 0 0 2 2 re f EMC",
            b"/OC << /A << /B 1 >> >> BDC 0 0 2 2 re f EMC",
            // Unbalanced: no `<<` for the `>>` to match.
            b"/OC /Type /OCMD >> BDC 0 0 2 2 re f EMC",
            // No tag at all.
            b"<< /Type /OCMD >> BDC 0 0 2 2 re f EMC",
            b"BDC 0 0 2 2 re f EMC",
        ] {
            let d = run_layers(src);
            assert_eq!(
                hidden_fills(&d),
                vec![false],
                "{} should paint",
                String::from_utf8_lossy(src)
            );
        }
    }

    /// The operators that used to fall into the catch-all, in one stream that
    /// also draws. None of them opens a scope, and none of them may swallow
    /// the operators after it.
    #[test]
    fn the_remaining_marked_content_operators_are_no_ops() {
        let d = run_layers(
            b"BX /Weird1 op EX \
              /Point MP \
              /Point << /K 1 >> DP \
              BMC 0 0 2 2 re f EMC \
              0 0 3 3 re f",
        );

        assert_eq!(
            d.count(EventKind::BeginMarkedContent),
            1,
            "only the BMC opened a scope"
        );
        assert_eq!(begins(&d), vec![(true, None)]);
        assert_eq!(d.count(EventKind::EndMarkedContent), 1);
        assert_eq!(hidden_fills(&d), vec![false, false], "both fills painted");
    }

    /// Hidden content still runs. The pen advances, `q`/`Q` balance, and the
    /// glyphs reach the device — the whole reason suppression belongs at the
    /// paint rather than here.
    #[test]
    fn a_hidden_scope_still_interprets_everything_inside_it() {
        let d = run_layers(
            b"/OC /Off BDC q 2 0 0 2 0 0 cm BT /F0 10 Tf (AB) Tj ET Q EMC \
              BT /F0 10 Tf (C) Tj ET",
        );

        let text: String = d.glyphs().map(|g| g.text.as_str()).collect();
        assert_eq!(text, "ABC", "the hidden glyphs were still shown");
        assert_eq!(
            d.indices(EventKind::ShowGlyph)
                .map(|index| d.hidden_at(index))
                .collect::<Vec<_>>(),
            vec![true, true, false],
            "and only their painting was marked hidden"
        );
    }

    /// 8.11.4.4: an `/OC` on the XObject itself hides it, and does so through
    /// the same scope machinery a `BDC` uses — so a hidden form is still run
    /// and its text still reaches the device.
    ///
    /// `PlainFrm` is the decoy: the same content, no `/OC`, and it paints.
    #[test]
    fn an_oc_entry_on_an_xobject_hides_it_without_skipping_it() {
        let d = run_layers(b"/PlainFrm Do /HiddenFrm Do 0 0 9 9 re f");

        assert_eq!(
            hidden_fills(&d),
            vec![false, true, false],
            "the plain form paints, the hidden one does not, and the page \
             after both does"
        );
        let text: String = d.glyphs().map(|g| g.text.as_str()).collect();
        assert_eq!(
            text, "form textform text",
            "the hidden form was still interpreted"
        );
        assert_eq!(
            begins(&d),
            vec![(false, Some("Construction lines".to_string()))],
            "one scope, opened around the `Do` rather than inside the form"
        );
        assert_eq!(d.count(EventKind::EndMarkedContent), 1);
        assert!(d.open_scopes().is_empty());
    }

    /// An image XObject is the branch where `form` returns `None`, so it is
    /// asserted separately: a hidden one is wrapped in a hidden scope, and a
    /// device that honours the scope never decodes it to find out it cannot.
    ///
    /// **This test used to be named `…_is_not_handed_to_the_device`, and the
    /// device it drove claimed in a comment to record "whether it was asked at
    /// all, which is the stronger property".** It did not: its `draw_image`
    /// returned early while a scope was hiding, so it recorded what it *drew*.
    /// `run_xobject` calls `draw_image` unconditionally — the `/OC` on the
    /// XObject opens a scope around the `Do` and nothing else — so the hidden
    /// image *is* handed over, and the claim was false about the code beside
    /// it. The promoted recorder makes the difference visible rather than
    /// absorbing it, because it keeps the call and derives the suppression;
    /// the last assertion is the property the comment was reaching for, now
    /// stated in the direction that is true.
    #[test]
    fn a_hidden_image_xobject_arrives_inside_a_hidden_scope() {
        let mut d = RecordingDevice::new();
        interpret(
            b"/PlainImg Do /HiddenImg Do",
            Matrix::IDENTITY,
            &mut d,
            &Layers,
        );

        let drawn: Vec<Vec<u8>> = d
            .indices(EventKind::DrawImage)
            .filter(|index| !d.hidden_at(*index))
            .filter_map(|index| match &d.events()[index] {
                Event::DrawImage { image, .. } => Some(image.name.clone()),
                _ => None,
            })
            .collect();
        assert_eq!(drawn, vec![b"PlainImg".to_vec()]);
        assert!(d.open_scopes().is_empty());

        let offered: Vec<Vec<u8>> = d
            .of_kind(EventKind::DrawImage)
            .filter_map(|event| match event {
                Event::DrawImage { image, .. } => Some(image.name.clone()),
                _ => None,
            })
            .collect();
        assert_eq!(
            offered,
            vec![b"PlainImg".to_vec(), b"HiddenImg".to_vec()],
            "both were handed over; only the scope around the second one \
             tells a device not to decode it"
        );
    }

    /// Depth is bounded, and running out of it shows content rather than
    /// hiding it — the direction a hostile stream should fail in.
    ///
    /// The arrangement is the one that can tell a build that *counts* the
    /// scopes it refused from one that silently drops them. A hidden scope
    /// is opened first, the cap is then filled with visible ones, and three
    /// more are opened past it. The three `EMC`s that follow belong to those
    /// three; a build that let them close reported scopes instead would be
    /// three short by the time the unwinding reaches the outer hidden one,
    /// close it early, and paint the last rectangle. Every simpler ordering
    /// — nest to the cap, then unwind completely — gives the same pixels
    /// either way, which is how this test came to be written twice.
    #[test]
    fn runaway_nesting_is_bounded_and_stays_balanced() {
        let cap = MAX_MARKED_CONTENT_DEPTH as usize;
        let mut src = Vec::from(b"/OC /Off BDC ".as_slice());
        for _ in 0..cap - 1 {
            src.extend_from_slice(b"/OC /On BDC ");
        }
        for _ in 0..3 {
            src.extend_from_slice(b"/OC /Off BDC ");
        }
        src.extend_from_slice(b"0 0 2 2 re f ");
        // The three that belong to the scopes past the cap.
        src.extend_from_slice(b"EMC EMC EMC ");
        // Then the cap's worth, less the outermost.
        for _ in 0..cap - 1 {
            src.extend_from_slice(b"EMC ");
        }
        src.extend_from_slice(b"0 0 3 3 re f EMC 0 0 4 4 re f");

        let d = run_layers(&src);
        assert_eq!(d.count(EventKind::BeginMarkedContent), cap, "the cap held");
        assert_eq!(
            d.count(EventKind::BeginMarkedContent),
            d.count(EventKind::EndMarkedContent),
            "and every one was closed"
        );
        assert!(d.open_scopes().is_empty());
        assert_eq!(
            hidden_fills(&d),
            vec![true, true, false],
            "the fill inside is hidden; so is the one after the unwinding, \
             because the outermost scope is still open; only the fill after \
             its own EMC paints"
        );
        assert!(
            begins(&d).iter().filter(|(visible, _)| !*visible).count() == 1,
            "the three scopes past the cap were refused, and a refused scope \
             is a visible one"
        );
    }
}
